"""
Configuración centralizada de ClawSphere AMS.
Soporta variables de entorno y archivos de configuración.
"""

from typing import List, Dict, Any, Optional
from pydantic import Field, validator
from pydantic_settings import BaseSettings
from functools import lru_cache
import os


class SecuritySettings(BaseSettings):
    """Configuración de seguridad."""
    
    SECRET_KEY: str = Field(default="your-super-secret-key-change-in-production")
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRATION_HOURS: int = 8
    ENCRYPTION_KEY: str = Field(default="your-encryption-key-32chars-long!!")
    
    # AD/LDAP Configuration
    LDAP_SERVER: str = Field(default="")
    LDAP_PORT: int = 389
    LDAP_USE_SSL: bool = True
    LDAP_BIND_DN: str = Field(default="")
    LDAP_BIND_PASSWORD: str = Field(default="")
    LDAP_BASE_DN: str = Field(default="")
    LDAP_USER_FILTER: str = "(sAMAccountName={username})"
    
    # MFA Settings
    MFA_ENABLED: bool = True
    MFA_ISSUER: str = "ClawSphere AMS"
    
    class Config:
        env_prefix = "CLAWSPHERE_SECURITY_"


class DatabaseSettings(BaseSettings):
    """Configuración de conexiones a bases de datos."""
    
    # Pool Configuration
    POOL_SIZE: int = 10
    POOL_MAX_OVERFLOW: int = 20
    POOL_TIMEOUT: int = 30
    POOL_RECYCLE: int = 3600
    
    # Query Limits
    MAX_ROWS_RETURN: int = 1000
    QUERY_TIMEOUT: int = 300
    
    # Security
    READ_ONLY_MODE: bool = True  # Por defecto, solo lectura
    ALLOWED_SCHEMAS: List[str] = Field(default_factory=list)
    BLOCKED_KEYWORDS: List[str] = Field(default_factory=lambda: [
        "DROP", "DELETE", "TRUNCATE", "ALTER", "CREATE", 
        "INSERT", "UPDATE", "EXEC", "EXECUTE", "SP_", "XP_"
    ])
    
    class Config:
        env_prefix = "CLAWSPHERE_DB_"


class AISettings(BaseSettings):
    """Configuración de proveedores de IA."""
    
    # Default Provider
    DEFAULT_PROVIDER: str = "ollama"
    
    # Ollama
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_DEFAULT_MODEL: str = "qwen2.5-coder"
    OLLAMA_TIMEOUT: int = 180
    
    # OpenAI
    OPENAI_API_KEY: str = Field(default="")
    OPENAI_DEFAULT_MODEL: str = "gpt-4"
    OPENAI_TIMEOUT: int = 60
    
    # Anthropic
    ANTHROPIC_API_KEY: str = Field(default="")
    ANTHROPIC_DEFAULT_MODEL: str = "claude-3-opus-20240229"
    ANTHROPIC_TIMEOUT: int = 60
    
    # Google
    GOOGLE_API_KEY: str = Field(default="")
    GOOGLE_DEFAULT_MODEL: str = "gemini-pro"
    
    # DeepSeek
    DEEPSEEK_API_KEY: str = Field(default="")
    DEEPSEEK_DEFAULT_MODEL: str = "deepseek-chat"
    
    # Local Models
    LMSTUDIO_BASE_URL: str = "http://localhost:1234/v1"
    GPT4ALL_BASE_URL: str = "http://localhost:4891/v1"
    VLLM_BASE_URL: str = "http://localhost:8000/v1"
    
    class Config:
        env_prefix = "CLAWSPHERE_AI_"


class MessagingSettings(BaseSettings):
    """Configuración de integraciones de mensajería."""
    
    # Microsoft Teams
    TEAMS_APP_ID: str = Field(default="")
    TEAMS_APP_PASSWORD: str = Field(default="")
    TEAMS_TENANT_ID: str = Field(default="")
    
    # Telegram
    TELEGRAM_BOT_TOKEN: str = Field(default="")
    TELEGRAM_WEBHOOK_URL: str = Field(default="")
    
    # WhatsApp (Twilio)
    TWILIO_ACCOUNT_SID: str = Field(default="")
    TWILIO_AUTH_TOKEN: str = Field(default="")
    TWILIO_WHATSAPP_NUMBER: str = Field(default="")
    
    class Config:
        env_prefix = "CLAWSPHERE_MSG_"


class AuditSettings(BaseSettings):
    """Configuración de auditoría."""
    
    ENABLED: bool = True
    LOG_LEVEL: str = "INFO"
    RETENTION_DAYS: int = 365
    LOG_ALL_QUERIES: bool = True
    LOG_ALL_COMMANDS: bool = True
    ALERT_ON_SENSITIVE_ACCESS: bool = True
    
    class Config:
        env_prefix = "CLAWSPHERE_AUDIT_"


class PrometheusSettings(BaseSettings):
    """Configuración de integración con Prometheus."""
    
    # Prometheus Server
    URL: str = Field(default="")
    TIMEOUT: int = 30
    
    # Alertmanager
    ALERTMANAGER_URL: str = Field(default="")
    
    # Metrics Exporter
    EXPORTER_ENABLED: bool = True
    EXPORTER_PORT: int = 9091
    EXPORTER_HOST: str = "0.0.0.0"
    
    # Collection Settings
    COLLECTION_INTERVAL: int = 60  # segundos
    ALERT_EVAL_INTERVAL: int = 60  # segundos
    
    class Config:
        env_prefix = "CLAWSPHERE_PROMETHEUS_"


class Settings(BaseSettings):
    """Configuración global de ClawSphere AMS."""
    
    # Application
    APP_NAME: str = "ClawSphere AMS"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    ENVIRONMENT: str = "production"
    
    # Server
    HOST: str = "0.0.0.0"
    PORT: int = 7550
    WORKERS: int = 4
    
    # Sub-configurations
    SECURITY: SecuritySettings = Field(default_factory=SecuritySettings)
    DATABASE: DatabaseSettings = Field(default_factory=DatabaseSettings)
    AI: AISettings = Field(default_factory=AISettings)
    MESSAGING: MessagingSettings = Field(default_factory=MessagingSettings)
    AUDIT: AuditSettings = Field(default_factory=AuditSettings)
    PROMETHEUS: PrometheusSettings = Field(default_factory=PrometheusSettings)
    
    # Feature Flags
    FEATURES: Dict[str, bool] = Field(default_factory=lambda: {
        "mfa": True,
        "approval_workflow": True,
        "auto_remediation": False,
        "predictive_alerts": True,
        "advanced_analytics": True
    })
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True


@lru_cache()
def get_settings() -> Settings:
    """Obtiene la configuración cacheada."""
    return Settings()
