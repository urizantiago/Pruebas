"""
Bus de Eventos.
Sistema de publicación/suscripción para eventos asíncronos.
"""

import logging
from typing import Dict, List, Callable, Any
from asyncio import Queue, create_task
import asyncio

logger = logging.getLogger(__name__)


class EventBus:
    """
    Bus de eventos para comunicación asíncrona entre componentes.
    Implementa patrón Pub/Sub.
    """
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._subscribers: Dict[str, List[Callable]] = {}
            cls._instance._queue = Queue()
            cls._instance._running = False
        return cls._instance
    
    def subscribe(self, event_type: str, handler: Callable) -> None:
        """
        Suscribe un handler a un tipo de evento.
        
        Args:
            event_type: Tipo de evento
            handler: Función a llamar cuando ocurra el evento
        """
        if event_type not in self._subscribers:
            self._subscribers[event_type] = []
        
        self._subscribers[event_type].append(handler)
        logger.debug(f"Handler suscrito a evento '{event_type}'")
    
    def unsubscribe(self, event_type: str, handler: Callable) -> bool:
        """
        Desuscribe un handler.
        
        Args:
            event_type: Tipo de evento
            handler: Handler a remover
            
        Returns:
            True si se removió
        """
        if event_type in self._subscribers:
            if handler in self._subscribers[event_type]:
                self._subscribers[event_type].remove(handler)
                return True
        return False
    
    async def publish(self, event_type: str, data: Any) -> None:
        """
        Publica un evento.
        
        Args:
            event_type: Tipo de evento
            data: Datos del evento
        """
        event = {
            "type": event_type,
            "data": data,
            "timestamp": asyncio.get_event_loop().time()
        }
        
        await self._queue.put(event)
        logger.debug(f"Evento '{event_type}' publicado")
        
        # Procesar inmediatamente
        await self._process_event(event)
    
    async def _process_event(self, event: Dict) -> None:
        """Procesa un evento llamando a los suscriptores."""
        event_type = event["type"]
        data = event["data"]
        
        if event_type not in self._subscribers:
            return
        
        handlers = self._subscribers[event_type][:]
        
        for handler in handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(data)
                else:
                    handler(data)
            except Exception as e:
                logger.exception(f"Error en handler de evento '{event_type}': {e}")
    
    async def start(self) -> None:
        """Inicia el procesamiento de eventos."""
        if self._running:
            return
        
        self._running = True
        logger.info("EventBus iniciado")
        
        while self._running:
            try:
                event = await asyncio.wait_for(self._queue.get(), timeout=1.0)
                await self._process_event(event)
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.exception(f"Error procesando evento: {e}")
    
    def stop(self) -> None:
        """Detiene el procesamiento de eventos."""
        self._running = False
        logger.info("EventBus detenido")
    
    def get_subscribers(self) -> Dict[str, int]:
        """Retorna conteo de suscriptores por tipo."""
        return {
            event_type: len(handlers)
            for event_type, handlers in self._subscribers.items()
        }
