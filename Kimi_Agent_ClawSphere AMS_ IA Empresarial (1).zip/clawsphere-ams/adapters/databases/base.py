"""
Clase base para adaptadores de bases de datos.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional, AsyncIterator
from contextlib import asynccontextmanager


class DatabaseConnection:
    """Representa una conexión a base de datos."""
    
    def __init__(self, connection_id: str, db_type: str, connection_string: str):
        self.connection_id = connection_id
        self.db_type = db_type
        self.connection_string = connection_string
        self._native_conn = None
        self._is_connected = False
    
    @property
    def is_connected(self) -> bool:
        return self._is_connected
    
    def set_native_connection(self, conn):
        self._native_conn = conn
        self._is_connected = True
    
    async def close(self):
        """Cierra la conexión."""
        if self._native_conn:
            await self._close_native()
            self._is_connected = False
    
    async def _close_native(self):
        """Implementación específica de cierre."""
        pass


class BaseDatabaseAdapter(ABC):
    """
    Clase base para adaptadores de bases de datos.
    """
    
    name: str = ""
    description: str = ""
    supports_async: bool = False
    supports_transactions: bool = True
    supports_prepared_statements: bool = True
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self._initialized = False
        self._connections: Dict[str, DatabaseConnection] = {}
    
    @abstractmethod
    async def initialize(self) -> None:
        """Inicializa el adaptador."""
        pass
    
    @abstractmethod
    async def connect(
        self, 
        connection_string: str,
        connection_id: Optional[str] = None
    ) -> DatabaseConnection:
        """
        Establece conexión a la base de datos.
        
        Args:
            connection_string: Cadena de conexión
            connection_id: ID opcional para la conexión
            
        Returns:
            Objeto DatabaseConnection
        """
        pass
    
    @abstractmethod
    async def execute_query(
        self,
        query: str,
        parameters: List[Any] = None,
        connection_id: str = None,
        max_rows: int = None
    ) -> List[Dict[str, Any]]:
        """
        Ejecuta una consulta SELECT.
        
        Args:
            query: Query SQL
            parameters: Parámetros de la query
            connection_id: ID de conexión a usar
            max_rows: Máximo de filas a retornar
            
        Returns:
            Lista de diccionarios con los resultados
        """
        pass
    
    @abstractmethod
    async def execute_command(
        self,
        command: str,
        parameters: List[Any] = None,
        connection_id: str = None
    ) -> int:
        """
        Ejecuta un comando (INSERT, UPDATE, DELETE).
        
        Args:
            command: Comando SQL
            parameters: Parámetros
            connection_id: ID de conexión
            
        Returns:
            Número de filas afectadas
        """
        pass
    
    @abstractmethod
    async def get_schema(
        self,
        table_name: str = None,
        connection_id: str = None
    ) -> Dict[str, Any]:
        """
        Obtiene el esquema de la base de datos o tabla.
        
        Args:
            table_name: Nombre de tabla (None = todas)
            connection_id: ID de conexión
            
        Returns:
            Esquema en formato dict
        """
        pass
    
    @abstractmethod
    async def test_connection(self, connection_string: str) -> tuple[bool, str]:
        """
        Prueba una conexión.
        
        Args:
            connection_string: Cadena de conexión
            
        Returns:
            Tuple (éxito, mensaje)
        """
        pass
    
    async def disconnect(self, connection_id: str) -> None:
        """Cierra una conexión."""
        if connection_id in self._connections:
            await self._connections[connection_id].close()
            del self._connections[connection_id]
    
    async def disconnect_all(self) -> None:
        """Cierra todas las conexiones."""
        for conn_id in list(self._connections.keys()):
            await self.disconnect(conn_id)
    
    def get_connection(self, connection_id: str) -> Optional[DatabaseConnection]:
        """Obtiene una conexión por ID."""
        return self._connections.get(connection_id)
    
    def get_info(self) -> Dict[str, Any]:
        """Retorna información del adaptador."""
        return {
            "name": self.name,
            "description": self.description,
            "supports_async": self.supports_async,
            "supports_transactions": self.supports_transactions,
            "active_connections": len(self._connections)
        }
    
    def _sanitize_query(self, query: str) -> str:
        """
        Sanitiza una query para prevenir inyección.
        
        Args:
            query: Query a sanitizar
            
        Returns:
            Query sanitizada
        """
        # Lista negra de palabras clave peligrosas
        blocked_patterns = [
            r";\s*DROP\s+",
            r";\s*DELETE\s+FROM\s+",
            r";\s*TRUNCATE\s+",
            r"EXEC\s*\(",
            r"EXECUTE\s*\(",
            r"xp_",
            r"sp_"
        ]
        
        import re
        query_upper = query.upper()
        
        for pattern in blocked_patterns:
            if re.search(pattern, query_upper):
                raise ValueError(f"Query bloqueada por seguridad: contiene patrón prohibido")
        
        return query
