"""
Adaptador para SQL Server (incluyendo Azure SQL).
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional
import pyodbc

from .base import BaseDatabaseAdapter, DatabaseConnection

logger = logging.getLogger(__name__)


class SQLServerAdapter(BaseDatabaseAdapter):
    """
    Adaptador para SQL Server y Azure SQL Database.
    """
    
    name = "sqlserver"
    description = "Microsoft SQL Server / Azure SQL"
    supports_async = False  # pyodbc no es async nativo
    supports_transactions = True
    supports_prepared_statements = True
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.query_timeout = config.get("query_timeout", 300)
        self.isolation_level = config.get("isolation_level", "READ UNCOMMITTED")
    
    async def initialize(self) -> None:
        """Inicializa el adaptador."""
        self._initialized = True
        logger.info("SQLServerAdapter inicializado")
    
    async def connect(
        self, 
        connection_string: str,
        connection_id: Optional[str] = None
    ) -> DatabaseConnection:
        """Establece conexión a SQL Server."""
        if not connection_id:
            import uuid
            connection_id = f"mssql_{uuid.uuid4().hex[:8]}"
        
        try:
            # pyodbc no es async, usar executor
            loop = asyncio.get_event_loop()
            conn = await loop.run_in_executor(
                None,
                lambda: pyodbc.connect(connection_string, timeout=self.query_timeout)
            )
            
            db_conn = DatabaseConnection(connection_id, "sqlserver", connection_string)
            db_conn.set_native_connection(conn)
            
            self._connections[connection_id] = db_conn
            
            logger.info(f"Conexión SQL Server establecida: {connection_id}")
            return db_conn
            
        except Exception as e:
            logger.error(f"Error conectando a SQL Server: {e}")
            raise
    
    async def execute_query(
        self,
        query: str,
        parameters: List[Any] = None,
        connection_id: str = None,
        max_rows: int = None
    ) -> List[Dict[str, Any]]:
        """Ejecuta una consulta SELECT."""
        # Sanitizar query
        query = self._sanitize_query(query)
        
        # Agregar nivel de aislamiento
        if not query.strip().upper().startswith("SET"):
            query = f"SET TRANSACTION ISOLATION LEVEL {self.isolation_level};\n{query}"
        
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada o cerrada: {connection_id}")
        
        try:
            loop = asyncio.get_event_loop()
            
            def _execute():
                cursor = conn._native_conn.cursor()
                if parameters:
                    cursor.execute(query, parameters)
                else:
                    cursor.execute(query)
                
                # Obtener columnas
                columns = [column[0] for column in cursor.description] if cursor.description else []
                
                # Obtener filas
                rows = cursor.fetchmany(max_rows) if max_rows else cursor.fetchall()
                
                # Convertir a diccionarios
                results = []
                for row in rows:
                    row_dict = {}
                    for i, col in enumerate(columns):
                        value = row[i]
                        # Convertir tipos no serializables
                        if hasattr(value, 'isoformat'):
                            value = value.isoformat()
                        row_dict[col] = value
                    results.append(row_dict)
                
                cursor.close()
                return results
            
            return await loop.run_in_executor(None, _execute)
            
        except Exception as e:
            logger.error(f"Error ejecutando query: {e}")
            raise
    
    async def execute_command(
        self,
        command: str,
        parameters: List[Any] = None,
        connection_id: str = None
    ) -> int:
        """Ejecuta un comando."""
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        try:
            loop = asyncio.get_event_loop()
            
            def _execute():
                cursor = conn._native_conn.cursor()
                if parameters:
                    cursor.execute(command, parameters)
                else:
                    cursor.execute(command)
                
                rows_affected = cursor.rowcount
                conn._native_conn.commit()
                cursor.close()
                return rows_affected
            
            return await loop.run_in_executor(None, _execute)
            
        except Exception as e:
            logger.error(f"Error ejecutando comando: {e}")
            raise
    
    async def get_schema(
        self,
        table_name: str = None,
        connection_id: str = None
    ) -> Dict[str, Any]:
        """Obtiene el esquema de la base de datos."""
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        try:
            loop = asyncio.get_event_loop()
            
            def _get_schema():
                cursor = conn._native_conn.cursor()
                
                if table_name:
                    # Esquema de tabla específica
                    cursor.execute("""
                        SELECT 
                            COLUMN_NAME,
                            DATA_TYPE,
                            IS_NULLABLE,
                            COLUMN_DEFAULT,
                            CHARACTER_MAXIMUM_LENGTH
                        FROM INFORMATION_SCHEMA.COLUMNS
                        WHERE TABLE_NAME = ?
                        ORDER BY ORDINAL_POSITION
                    """, (table_name,))
                    
                    columns = []
                    for row in cursor.fetchall():
                        columns.append({
                            "name": row[0],
                            "type": row[1],
                            "nullable": row[2] == "YES",
                            "default": row[3],
                            "max_length": row[4]
                        })
                    
                    return {"table": table_name, "columns": columns}
                
                else:
                    # Todas las tablas
                    cursor.execute("""
                        SELECT TABLE_SCHEMA, TABLE_NAME, TABLE_TYPE
                        FROM INFORMATION_SCHEMA.TABLES
                        WHERE TABLE_TYPE = 'BASE TABLE'
                        ORDER BY TABLE_SCHEMA, TABLE_NAME
                    """)
                    
                    tables = []
                    for row in cursor.fetchall():
                        tables.append({
                            "schema": row[0],
                            "name": row[1],
                            "type": row[2]
                        })
                    
                    return {"tables": tables}
            
            return await loop.run_in_executor(None, _get_schema)
            
        except Exception as e:
            logger.error(f"Error obteniendo esquema: {e}")
            raise
    
    async def test_connection(self, connection_string: str) -> tuple[bool, str]:
        """Prueba una conexión."""
        try:
            loop = asyncio.get_event_loop()
            
            def _test():
                conn = pyodbc.connect(connection_string, timeout=10)
                cursor = conn.cursor()
                cursor.execute("SELECT @@VERSION")
                version = cursor.fetchone()[0]
                conn.close()
                return True, version
            
            return await loop.run_in_executor(None, _test)
            
        except Exception as e:
            return False, str(e)
    
    async def get_performance_metrics(self, connection_id: str) -> Dict[str, Any]:
        """Obtiene métricas de performance."""
        queries = {
            "active_connections": """
                SELECT COUNT(*) as count 
                FROM sys.dm_exec_sessions 
                WHERE status = 'sleeping' AND last_request_start_time < DATEADD(SECOND, -10, GETDATE())
            """,
            "blocking_queries": """
                SELECT COUNT(*) as count 
                FROM sys.dm_tran_locks 
                WHERE request_status = 'WAIT'
            """,
            "slow_queries": """
                SELECT TOP 10 
                    sql_text.text,
                    qs.execution_count,
                    qs.total_elapsed_time/1000 as total_elapsed_time_ms,
                    qs.last_elapsed_time/1000 as last_elapsed_time_ms
                FROM sys.dm_exec_query_stats qs
                CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) sql_text
                ORDER BY qs.total_elapsed_time DESC
            """
        }
        
        results = {}
        for name, query in queries.items():
            try:
                results[name] = await self.execute_query(query, connection_id=connection_id)
            except Exception as e:
                results[name] = {"error": str(e)}
        
        return results
    
    async def get_locks(self, connection_id: str) -> List[Dict[str, Any]]:
        """Obtiene información de bloqueos."""
        query = """
            SELECT 
                tl.request_session_id as spid,
                tl.resource_type,
                tl.request_mode,
                tl.request_status,
                OBJECT_NAME(p.object_id) as object_name,
                sql_text.text as sql_command
            FROM sys.dm_tran_locks tl
            LEFT JOIN sys.partitions p ON tl.resource_associated_entity_id = p.hobt_id
            CROSS APPLY sys.dm_exec_sql_text(
                (SELECT most_recent_sql_handle FROM sys.dm_exec_sessions WHERE session_id = tl.request_session_id)
            ) sql_text
            WHERE tl.request_status = 'WAIT'
        """
        return await self.execute_query(query, connection_id=connection_id)
