"""
Adaptador SSH para servidores Linux/Unix/AIX.
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional
import paramiko
from io import StringIO

from .base import BaseServerAdapter, ServerConnection, CommandResult, ServerType

logger = logging.getLogger(__name__)


class SSHAdapter(BaseServerAdapter):
    """
    Adaptador SSH para Linux, Unix, AIX.
    """
    
    name = "ssh"
    description = "SSH - Linux/Unix/AIX Servers"
    supports_async = False
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.default_port = config.get("port", 22)
        self.default_timeout = config.get("timeout", 30)
        self.key_files = config.get("key_files", [])
    
    async def initialize(self) -> None:
        """Inicializa el adaptador."""
        self._initialized = True
        logger.info("SSHAdapter inicializado")
    
    async def connect(
        self,
        hostname: str,
        username: str,
        password: str = None,
        key_file: str = None,
        key_content: str = None,
        port: int = None,
        connection_id: str = None
    ) -> ServerConnection:
        """Conecta vía SSH."""
        if not connection_id:
            import uuid
            connection_id = f"ssh_{uuid.uuid4().hex[:8]}"
        
        port = port or self.default_port
        
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            # Intentar conexión
            connect_kwargs = {
                "hostname": hostname,
                "port": port,
                "username": username,
                "timeout": self.default_timeout,
                "look_for_keys": True
            }
            
            if password:
                connect_kwargs["password"] = password
            elif key_content:
                private_key = paramiko.RSAKey.from_private_key(StringIO(key_content))
                connect_kwargs["pkey"] = private_key
            elif key_file:
                connect_kwargs["key_filename"] = key_file
            
            # Ejecutar en executor (paramiko es sync)
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, lambda: client.connect(**connect_kwargs))
            
            # Detectar tipo de servidor
            server_type = await self._detect_server_type(client)
            
            conn = ServerConnection(
                connection_id=connection_id,
                server_type=server_type,
                hostname=hostname,
                username=username
            )
            conn.set_connected(client)
            
            self._connections[connection_id] = conn
            
            logger.info(f"Conexión SSH establecida: {connection_id} ({hostname})")
            return conn
            
        except Exception as e:
            logger.error(f"Error conectando SSH a {hostname}: {e}")
            raise
    
    async def _detect_server_type(self, client: paramiko.SSHClient) -> ServerType:
        """Detecta el tipo de servidor."""
        try:
            stdin, stdout, stderr = client.exec_command("uname -s")
            output = stdout.read().decode().strip().lower()
            
            if "linux" in output:
                return ServerType.LINUX
            elif "aix" in output:
                return ServerType.AIX
            elif "sunos" in output or "solaris" in output:
                return ServerType.SOLARIS
            else:
                return ServerType.LINUX
        except:
            return ServerType.LINUX
    
    async def execute_command(
        self,
        command: str,
        connection_id: str,
        timeout: int = 60,
        sudo: bool = False
    ) -> CommandResult:
        """Ejecuta un comando SSH."""
        import time
        start_time = time.time()
        
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        client = conn._native_conn
        
        if sudo and not command.startswith("sudo "):
            command = f"sudo {command}"
        
        try:
            loop = asyncio.get_event_loop()
            
            def _execute():
                stdin, stdout, stderr = client.exec_command(
                    command,
                    timeout=timeout,
                    get_pty=True  # Para sudo
                )
                
                exit_code = stdout.channel.recv_exit_status()
                stdout_str = stdout.read().decode('utf-8', errors='replace')
                stderr_str = stderr.read().decode('utf-8', errors='replace')
                
                return exit_code, stdout_str, stderr_str
            
            exit_code, stdout, stderr = await loop.run_in_executor(None, _execute)
            
            execution_time = (time.time() - start_time) * 1000
            
            return CommandResult(
                success=exit_code == 0,
                stdout=stdout,
                stderr=stderr,
                exit_code=exit_code,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"Error ejecutando comando: {e}")
            return CommandResult(
                success=False,
                stdout="",
                stderr=str(e),
                exit_code=-1,
                execution_time_ms=(time.time() - start_time) * 1000
            )
    
    async def execute_script(
        self,
        script: str,
        connection_id: str,
        script_type: str = "bash",
        timeout: int = 300
    ) -> CommandResult:
        """Ejecuta un script en el servidor."""
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        # Crear archivo temporal y ejecutar
        import uuid
        temp_file = f"/tmp/clawsphere_{uuid.uuid4().hex[:8]}.sh"
        
        try:
            # Escribir script
            client = conn._native_conn
            
            loop = asyncio.get_event_loop()
            
            def _write_and_execute():
                # Escribir archivo
                sftp = client.open_sftp()
                with sftp.file(temp_file, 'w') as f:
                    f.write(script)
                sftp.chmod(temp_file, 0o755)
                sftp.close()
                
                # Ejecutar
                stdin, stdout, stderr = client.exec_command(
                    f"bash {temp_file}",
                    timeout=timeout
                )
                
                exit_code = stdout.channel.recv_exit_status()
                stdout_str = stdout.read().decode('utf-8', errors='replace')
                stderr_str = stderr.read().decode('utf-8', errors='replace')
                
                # Limpiar
                try:
                    client.exec_command(f"rm {temp_file}")
                except:
                    pass
                
                return exit_code, stdout_str, stderr_str
            
            exit_code, stdout, stderr = await loop.run_in_executor(None, _write_and_execute)
            
            return CommandResult(
                success=exit_code == 0,
                stdout=stdout,
                stderr=stderr,
                exit_code=exit_code
            )
            
        except Exception as e:
            logger.error(f"Error ejecutando script: {e}")
            return CommandResult(
                success=False,
                stdout="",
                stderr=str(e),
                exit_code=-1
            )
    
    async def read_file(
        self,
        file_path: str,
        connection_id: str,
        limit_lines: int = None
    ) -> str:
        """Lee un archivo del servidor."""
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        command = f"cat '{file_path}'"
        if limit_lines:
            command = f"head -n {limit_lines} '{file_path}'"
        
        result = await self.execute_command(command, connection_id)
        
        if result.success:
            return result.stdout
        else:
            raise Exception(f"Error leyendo archivo: {result.stderr}")
    
    async def file_exists(self, file_path: str, connection_id: str) -> bool:
        """Verifica si un archivo existe."""
        result = await self.execute_command(
            f"test -f '{file_path}' && echo 'EXISTS'",
            connection_id
        )
        return "EXISTS" in result.stdout
    
    async def tail_log(
        self,
        file_path: str,
        connection_id: str,
        lines: int = 100,
        follow: bool = False
    ) -> str:
        """Lee las últimas líneas de un log."""
        command = f"tail -n {lines} '{file_path}'"
        if follow:
            command = f"tail -f -n {lines} '{file_path}'"
        
        result = await self.execute_command(command, connection_id, timeout=10 if not follow else 30)
        return result.stdout
    
    async def grep_logs(
        self,
        file_path: str,
        pattern: str,
        connection_id: str,
        case_sensitive: bool = False,
        context_lines: int = 2
    ) -> List[Dict[str, str]]:
        """Busca en logs con grep."""
        flags = "-n"
        if not case_sensitive:
            flags += " -i"
        if context_lines > 0:
            flags += f" -C {context_lines}"
        
        command = f"grep {flags} '{pattern}' '{file_path}'"
        result = await self.execute_command(command, connection_id)
        
        matches = []
        if result.success:
            for line in result.stdout.split('\n'):
                if line.strip():
                    # Parsear línea con número
                    if ':' in line:
                        parts = line.split(':', 1)
                        try:
                            line_num = int(parts[0])
                            matches.append({
                                "line_number": line_num,
                                "content": parts[1]
                            })
                        except:
                            matches.append({"content": line})
                    else:
                        matches.append({"content": line})
        
        return matches
    
    async def get_system_info(self, connection_id: str) -> Dict[str, Any]:
        """Obtiene información del sistema."""
        commands = {
            "hostname": "hostname",
            "os": "cat /etc/os-release 2>/dev/null || uname -a",
            "uptime": "uptime",
            "cpu": "cat /proc/cpuinfo | grep 'model name' | head -1",
            "memory": "free -h",
            "disk": "df -h",
            "load": "cat /proc/loadavg"
        }
        
        results = {}
        for name, cmd in commands.items():
            try:
                result = await self.execute_command(cmd, connection_id)
                results[name] = result.stdout.strip() if result.success else f"Error: {result.stderr}"
            except Exception as e:
                results[name] = f"Error: {str(e)}"
        
        return results
    
    async def get_processes(
        self, 
        connection_id: str,
        filter_pattern: str = None
    ) -> List[Dict[str, str]]:
        """Obtiene lista de procesos."""
        command = "ps aux"
        if filter_pattern:
            command += f" | grep '{filter_pattern}'"
        
        result = await self.execute_command(command, connection_id)
        
        processes = []
        if result.success:
            lines = result.stdout.strip().split('\n')
            if len(lines) > 1:
                # Primera línea es header
                headers = lines[0].split()
                for line in lines[1:]:
                    parts = line.split(None, len(headers) - 1)
                    if len(parts) >= len(headers):
                        proc = {}
                        for i, header in enumerate(headers):
                            proc[header.lower()] = parts[i] if i < len(parts) else ""
                        processes.append(proc)
        
        return processes
