"""
Adaptador WinRM para servidores Windows.
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional
import winrm

from .base import BaseServerAdapter, ServerConnection, CommandResult, ServerType

logger = logging.getLogger(__name__)


class WinRMAdapter(BaseServerAdapter):
    """
    Adaptador WinRM para Windows Servers.
    Permite ejecutar comandos PowerShell y CMD.
    """
    
    name = "winrm"
    description = "WinRM - Windows Servers (PowerShell)"
    supports_async = False
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.default_port = config.get("port", 5985)
        self.use_ssl = config.get("use_ssl", False)
        self.timeout = config.get("timeout", 60)
        self.transport = config.get("transport", "ntlm")
    
    async def initialize(self) -> None:
        """Inicializa el adaptador."""
        self._initialized = True
        logger.info("WinRMAdapter inicializado")
    
    async def connect(
        self,
        hostname: str,
        username: str,
        password: str = None,
        key_file: str = None,
        port: int = None,
        connection_id: str = None
    ) -> ServerConnection:
        """Conecta vía WinRM."""
        if not connection_id:
            import uuid
            connection_id = f"winrm_{uuid.uuid4().hex[:8]}"
        
        port = port or self.default_port
        protocol = "https" if self.use_ssl else "http"
        
        try:
            endpoint = f"{protocol}://{hostname}:{port}"
            
            session = winrm.Session(
                endpoint,
                auth=(username, password),
                transport=self.transport,
                server_cert_validation='ignore'
            )
            
            # Probar conexión
            loop = asyncio.get_event_loop()
            
            def _test():
                result = session.run_cmd("echo", ["ClawSphere_Test"])
                return result.status_code == 0
            
            success = await loop.run_in_executor(None, _test)
            
            if not success:
                raise Exception("No se pudo establecer conexión WinRM")
            
            conn = ServerConnection(
                connection_id=connection_id,
                server_type=ServerType.WINDOWS,
                hostname=hostname,
                username=username
            )
            conn.set_connected(session)
            
            self._connections[connection_id] = conn
            
            logger.info(f"Conexión WinRM establecida: {connection_id} ({hostname})")
            return conn
            
        except Exception as e:
            logger.error(f"Error conectando WinRM a {hostname}: {e}")
            raise
    
    async def execute_command(
        self,
        command: str,
        connection_id: str,
        timeout: int = 60,
        sudo: bool = False
    ) -> CommandResult:
        """Ejecuta un comando CMD."""
        import time
        start_time = time.time()
        
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        session = conn._native_conn
        
        try:
            loop = asyncio.get_event_loop()
            
            def _execute():
                result = session.run_cmd(command)
                return result.status_code, result.std_out.decode('utf-8', errors='replace'), result.std_err.decode('utf-8', errors='replace')
            
            exit_code, stdout, stderr = await loop.run_in_executor(None, _execute)
            
            execution_time = (time.time() - start_time) * 1000
            
            return CommandResult(
                success=exit_code == 0,
                stdout=stdout,
                stderr=stderr,
                exit_code=exit_code,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"Error ejecutando comando: {e}")
            return CommandResult(
                success=False,
                stdout="",
                stderr=str(e),
                exit_code=-1,
                execution_time_ms=(time.time() - start_time) * 1000
            )
    
    async def execute_powershell(
        self,
        script: str,
        connection_id: str,
        timeout: int = 300
    ) -> CommandResult:
        """Ejecuta un script PowerShell."""
        import time
        start_time = time.time()
        
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        session = conn._native_conn
        
        try:
            loop = asyncio.get_event_loop()
            
            def _execute():
                result = session.run_ps(script)
                return result.status_code, result.std_out.decode('utf-8', errors='replace'), result.std_err.decode('utf-8', errors='replace')
            
            exit_code, stdout, stderr = await loop.run_in_executor(None, _execute)
            
            execution_time = (time.time() - start_time) * 1000
            
            return CommandResult(
                success=exit_code == 0,
                stdout=stdout,
                stderr=stderr,
                exit_code=exit_code,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"Error ejecutando PowerShell: {e}")
            return CommandResult(
                success=False,
                stdout="",
                stderr=str(e),
                exit_code=-1,
                execution_time_ms=(time.time() - start_time) * 1000
            )
    
    async def execute_script(
        self,
        script: str,
        connection_id: str,
        script_type: str = "powershell",
        timeout: int = 300
    ) -> CommandResult:
        """Ejecuta un script."""
        if script_type.lower() in ["powershell", "ps", "ps1"]:
            return await self.execute_powershell(script, connection_id, timeout)
        else:
            # CMD batch
            return await self.execute_command(script, connection_id, timeout)
    
    async def read_file(
        self,
        file_path: str,
        connection_id: str,
        limit_lines: int = None
    ) -> str:
        """Lee un archivo del servidor."""
        if limit_lines:
            ps_script = f"Get-Content -Path '{file_path}' -TotalCount {limit_lines}"
        else:
            ps_script = f"Get-Content -Path '{file_path}'"
        
        result = await self.execute_powershell(ps_script, connection_id)
        
        if result.success:
            return result.stdout
        else:
            raise Exception(f"Error leyendo archivo: {result.stderr}")
    
    async def file_exists(self, file_path: str, connection_id: str) -> bool:
        """Verifica si un archivo existe."""
        ps_script = f"Test-Path -Path '{file_path}'"
        result = await self.execute_powershell(ps_script, connection_id)
        return "True" in result.stdout
    
    async def get_system_info(self, connection_id: str) -> Dict[str, Any]:
        """Obtiene información del sistema Windows."""
        commands = {
            "computer_info": "Get-ComputerInfo | Select-Object WindowsProductName, WindowsVersion, TotalPhysicalMemory, CsProcessors",
            "uptime": "(Get-Date) - (Get-CimInstance Win32_OperatingSystem).LastBootUpTime | Select-Object Days, Hours, Minutes",
            "cpu": "Get-WmiObject -Class Win32_Processor | Select-Object Name, LoadPercentage",
            "memory": "Get-WmiObject -Class Win32_OperatingSystem | Select-Object @{Name='TotalGB';Expression={[math]::Round($_.TotalVisibleMemorySize/1MB,2)}}, @{Name='FreeGB';Expression={[math]::Round($_.FreePhysicalMemory/1MB,2)}}",
            "disk": "Get-WmiObject -Class Win32_LogicalDisk | Select-Object DeviceID, @{Name='SizeGB';Expression={[math]::Round($_.Size/1GB,2)}}, @{Name='FreeGB';Expression={[math]::Round($_.FreeSpace/1GB,2)}}",
            "services": "Get-Service | Where-Object {$_.Status -eq 'Running'} | Measure-Object | Select-Object -ExpandProperty Count"
        }
        
        results = {}
        for name, ps_cmd in commands.items():
            try:
                result = await self.execute_powershell(ps_cmd, connection_id)
                results[name] = result.stdout.strip() if result.success else f"Error: {result.stderr}"
            except Exception as e:
                results[name] = f"Error: {str(e)}"
        
        return results
    
    async def get_iis_info(self, connection_id: str) -> Dict[str, Any]:
        """Obtiene información de IIS."""
        ps_script = """
        Import-Module WebAdministration
        Get-Website | Select-Object Name, State, PhysicalPath, Bindings
        """
        
        result = await self.execute_powershell(ps_script, connection_id)
        
        if result.success:
            return {"sites": result.stdout}
        else:
            return {"error": result.stderr}
    
    async def recycle_app_pool(
        self, 
        app_pool_name: str, 
        connection_id: str
    ) -> CommandResult:
        """Recicla un Application Pool de IIS."""
        ps_script = f"""
        Import-Module WebAdministration
        Restart-WebAppPool -Name "{app_pool_name}"
        """
        
        return await self.execute_powershell(ps_script, connection_id)
    
    async def get_event_logs(
        self,
        connection_id: str,
        log_name: str = "System",
        entry_type: str = "Error",
        limit: int = 50
    ) -> List[Dict[str, str]]:
        """Obtiene event logs de Windows."""
        ps_script = f"""
        Get-EventLog -LogName {log_name} -EntryType {entry_type} -Newest {limit} | 
        Select-Object TimeGenerated, Source, Message | 
        ConvertTo-Json
        """
        
        result = await self.execute_powershell(ps_script, connection_id)
        
        if result.success:
            import json
            try:
                logs = json.loads(result.stdout)
                return logs if isinstance(logs, list) else [logs]
            except:
                return [{"message": result.stdout}]
        
        return []
