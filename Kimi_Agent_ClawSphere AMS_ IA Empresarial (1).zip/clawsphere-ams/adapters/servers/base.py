"""
Clase base para adaptadores de servidores.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from enum import Enum


class ServerType(Enum):
    """Tipos de servidor soportados."""
    LINUX = "linux"
    WINDOWS = "windows"
    AIX = "aix"
    SOLARIS = "solaris"


@dataclass
class ServerConnection:
    """Representa una conexión a servidor."""
    connection_id: str
    server_type: ServerType
    hostname: str
    username: str
    _native_conn = None
    _is_connected: bool = False
    
    @property
    def is_connected(self) -> bool:
        return self._is_connected
    
    def set_connected(self, conn):
        self._native_conn = conn
        self._is_connected = True
    
    async def close(self):
        if self._native_conn:
            await self._close_native()
            self._is_connected = False
    
    async def _close_native(self):
        pass


@dataclass
class CommandResult:
    """Resultado de un comando."""
    success: bool
    stdout: str
    stderr: str
    exit_code: int
    execution_time_ms: float = 0.0


class BaseServerAdapter(ABC):
    """
    Clase base para adaptadores de servidores.
    """
    
    name: str = ""
    description: str = ""
    supports_async: bool = False
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self._initialized = False
        self._connections: Dict[str, ServerConnection] = {}
    
    @abstractmethod
    async def connect(
        self,
        hostname: str,
        username: str,
        password: str = None,
        key_file: str = None,
        port: int = None,
        connection_id: str = None
    ) -> ServerConnection:
        """
        Conecta a un servidor.
        
        Args:
            hostname: Hostname o IP
            username: Usuario
            password: Contraseña
            key_file: Archivo de clave SSH
            port: Puerto
            connection_id: ID de conexión
            
        Returns:
            ServerConnection
        """
        pass
    
    @abstractmethod
    async def execute_command(
        self,
        command: str,
        connection_id: str,
        timeout: int = 60,
        sudo: bool = False
    ) -> CommandResult:
        """
        Ejecuta un comando en el servidor.
        
        Args:
            command: Comando a ejecutar
            connection_id: ID de conexión
            timeout: Timeout en segundos
            sudo: Ejecutar con sudo
            
        Returns:
            CommandResult
        """
        pass
    
    @abstractmethod
    async def execute_script(
        self,
        script: str,
        connection_id: str,
        script_type: str = "bash",
        timeout: int = 300
    ) -> CommandResult:
        """
        Ejecuta un script en el servidor.
        
        Args:
            script: Contenido del script
            connection_id: ID de conexión
            script_type: Tipo de script (bash, powershell, python)
            timeout: Timeout
            
        Returns:
            CommandResult
        """
        pass
    
    @abstractmethod
    async def read_file(
        self,
        file_path: str,
        connection_id: str,
        limit_lines: int = None
    ) -> str:
        """
        Lee un archivo del servidor.
        
        Args:
            file_path: Ruta del archivo
            connection_id: ID de conexión
            limit_lines: Límite de líneas
            
        Returns:
            Contenido del archivo
        """
        pass
    
    @abstractmethod
    async def file_exists(self, file_path: str, connection_id: str) -> bool:
        """Verifica si un archivo existe."""
        pass
    
    async def disconnect(self, connection_id: str) -> None:
        """Cierra una conexión."""
        if connection_id in self._connections:
            await self._connections[connection_id].close()
            del self._connections[connection_id]
    
    async def disconnect_all(self) -> None:
        """Cierra todas las conexiones."""
        for conn_id in list(self._connections.keys()):
            await self.disconnect(conn_id)
    
    def get_connection(self, connection_id: str) -> Optional[ServerConnection]:
        """Obtiene una conexión por ID."""
        return self._connections.get(connection_id)
    
    def get_info(self) -> Dict[str, Any]:
        """Retorna información del adaptador."""
        return {
            "name": self.name,
            "description": self.description,
            "supports_async": self.supports_async,
            "active_connections": len(self._connections)
        }
