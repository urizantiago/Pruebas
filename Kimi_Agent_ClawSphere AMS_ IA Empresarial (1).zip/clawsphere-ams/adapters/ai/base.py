"""
Clase base para adaptadores de IA.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional, AsyncGenerator


class BaseAIAdapter(ABC):
    """
    Clase base para adaptadores de IA/LLM.
    """
    
    name: str = ""
    description: str = ""
    supports_streaming: bool = False
    supports_functions: bool = False
    supports_vision: bool = False
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self._initialized = False
    
    @abstractmethod
    async def initialize(self) -> None:
        """Inicializa el adaptador."""
        pass
    
    @abstractmethod
    async def generate_response(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> str:
        """
        Genera una respuesta de texto.
        
        Args:
            prompt: Prompt del usuario
            system_prompt: Prompt de sistema
            temperature: Temperatura de generación
            max_tokens: Máximo de tokens
            
        Returns:
            Respuesta generada
        """
        pass
    
    @abstractmethod
    async def generate_stream(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        **kwargs
    ) -> AsyncGenerator[str, None]:
        """
        Genera una respuesta en streaming.
        
        Args:
            prompt: Prompt del usuario
            system_prompt: Prompt de sistema
            temperature: Temperatura
            
        Yields:
            Fragmentos de la respuesta
        """
        pass
    
    @abstractmethod
    async def is_available(self) -> bool:
        """Verifica si el servicio está disponible."""
        pass
    
    def get_info(self) -> Dict[str, Any]:
        """Retorna información del adaptador."""
        return {
            "name": self.name,
            "description": self.description,
            "supports_streaming": self.supports_streaming,
            "supports_functions": self.supports_functions,
            "supports_vision": self.supports_vision,
            "config": {k: v for k, v in self.config.items() if 'key' not in k.lower()}
        }
