"""
Adaptador para OpenAI / Azure OpenAI.
"""

import openai
import logging
from typing import Dict, Any, Optional, AsyncGenerator

from .base import BaseAIAdapter

logger = logging.getLogger(__name__)


class OpenAIAdapter(BaseAIAdapter):
    """
    Adaptador para OpenAI y Azure OpenAI.
    Soporta: GPT-4, GPT-3.5, etc.
    """
    
    name = "openai"
    description = "OpenAI / Azure OpenAI (GPT-4, GPT-3.5)"
    supports_streaming = True
    supports_functions = True
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_key = config.get("api_key", "")
        self.base_url = config.get("base_url")  # Para Azure
        self.default_model = config.get("default_model", "gpt-4")
        self.timeout = config.get("timeout", 60)
        self._client: Optional[openai.AsyncOpenAI] = None
    
    async def initialize(self) -> None:
        """Inicializa el cliente OpenAI."""
        client_kwargs = {
            "api_key": self.api_key,
            "timeout": self.timeout
        }
        
        if self.base_url:
            client_kwargs["base_url"] = self.base_url
        
        self._client = openai.AsyncOpenAI(**client_kwargs)
        self._initialized = True
        logger.info("OpenAIAdapter inicializado")
    
    async def generate_response(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        model: Optional[str] = None,
        **kwargs
    ) -> str:
        """Genera respuesta usando OpenAI."""
        if not self._client:
            await self.initialize()
        
        model = model or self.default_model
        
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        try:
            response = await self._client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                **kwargs
            )
            
            return response.choices[0].message.content or ""
            
        except Exception as e:
            logger.error(f"Error en OpenAI: {e}")
            raise
    
    async def generate_stream(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        model: Optional[str] = None,
        **kwargs
    ) -> AsyncGenerator[str, None]:
        """Genera respuesta en streaming."""
        if not self._client:
            await self.initialize()
        
        model = model or self.default_model
        
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        try:
            stream = await self._client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                stream=True,
                **kwargs
            )
            
            async for chunk in stream:
                if chunk.choices[0].delta.content:
                    yield chunk.choices[0].delta.content
                    
        except Exception as e:
            logger.error(f"Error en streaming OpenAI: {e}")
            raise
    
    async def is_available(self) -> bool:
        """Verifica si OpenAI está disponible."""
        if not self._client:
            await self.initialize()
        
        try:
            # Intentar listar modelos
            await self._client.models.list()
            return True
        except:
            return False
    
    async def list_models(self) -> list:
        """Lista modelos disponibles."""
        if not self._client:
            await self.initialize()
        
        try:
            models = await self._client.models.list()
            return [m.id for m in models.data]
        except:
            return []
