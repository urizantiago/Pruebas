"""
Adaptador para Ollama (modelos locales).
"""

import aiohttp
import logging
from typing import Dict, Any, Optional, AsyncGenerator

from .base import BaseAIAdapter

logger = logging.getLogger(__name__)


class OllamaAdapter(BaseAIAdapter):
    """
    Adaptador para Ollama - ejecuta modelos localmente.
    Soporta: Qwen, Llama, Mistral, CodeLlama, etc.
    """
    
    name = "ollama"
    description = "Ollama - Modelos locales (Qwen, Llama, Mistral)"
    supports_streaming = True
    supports_functions = False
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = config.get("base_url", "http://localhost:11434")
        self.default_model = config.get("default_model", "qwen2.5-coder")
        self.timeout = config.get("timeout", 180)
        self._session: Optional[aiohttp.ClientSession] = None
    
    async def initialize(self) -> None:
        """Inicializa la sesión HTTP."""
        self._session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=self.timeout)
        )
        self._initialized = True
        logger.info(f"OllamaAdapter inicializado - URL: {self.base_url}")
    
    async def generate_response(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        model: Optional[str] = None,
        **kwargs
    ) -> str:
        """Genera respuesta usando Ollama."""
        if not self._session:
            await self.initialize()
        
        model = model or self.default_model
        
        # Construir el prompt completo
        full_prompt = prompt
        if system_prompt:
            full_prompt = f"{system_prompt}\n\n{prompt}"
        
        payload = {
            "model": model,
            "prompt": full_prompt,
            "stream": False,
            "options": {
                "temperature": temperature
            }
        }
        
        if max_tokens:
            payload["options"]["num_predict"] = max_tokens
        
        try:
            async with self._session.post(
                f"{self.base_url}/api/generate",
                json=payload
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise Exception(f"Ollama error {response.status}: {error_text}")
                
                data = await response.json()
                return data.get("response", "").strip()
                
        except Exception as e:
            logger.error(f"Error en Ollama: {e}")
            raise
    
    async def generate_stream(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        model: Optional[str] = None,
        **kwargs
    ) -> AsyncGenerator[str, None]:
        """Genera respuesta en streaming."""
        if not self._session:
            await self.initialize()
        
        model = model or self.default_model
        
        full_prompt = prompt
        if system_prompt:
            full_prompt = f"{system_prompt}\n\n{prompt}"
        
        payload = {
            "model": model,
            "prompt": full_prompt,
            "stream": True,
            "options": {
                "temperature": temperature
            }
        }
        
        try:
            async with self._session.post(
                f"{self.base_url}/api/generate",
                json=payload
            ) as response:
                async for line in response.content:
                    if line:
                        try:
                            data = line.decode('utf-8').strip()
                            if data:
                                import json
                                chunk = json.loads(data)
                                if "response" in chunk:
                                    yield chunk["response"]
                        except:
                            pass
        except Exception as e:
            logger.error(f"Error en streaming Ollama: {e}")
            raise
    
    async def is_available(self) -> bool:
        """Verifica si Ollama está disponible."""
        if not self._session:
            await self.initialize()
        
        try:
            async with self._session.get(
                f"{self.base_url}/api/tags",
                timeout=aiohttp.ClientTimeout(total=5)
            ) as response:
                return response.status == 200
        except:
            return False
    
    async def list_models(self) -> list:
        """Lista modelos disponibles en Ollama."""
        if not self._session:
            await self.initialize()
        
        try:
            async with self._session.get(f"{self.base_url}/api/tags") as response:
                if response.status == 200:
                    data = await response.json()
                    return [m["name"] for m in data.get("models", [])]
                return []
        except:
            return []
    
    async def pull_model(self, model_name: str) -> bool:
        """Descarga un modelo en Ollama."""
        if not self._session:
            await self.initialize()
        
        try:
            async with self._session.post(
                f"{self.base_url}/api/pull",
                json={"name": model_name}
            ) as response:
                return response.status == 200
        except:
            return False
