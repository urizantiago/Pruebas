# NexusAI Enterprise - Security Architecture
=============================================

## Visión General

NexusAI Enterprise está diseñado con seguridad como principio fundamental. Implementamos múltiples capas de seguridad para proteger datos sensibles empresariales.

## Modelo de Amenazas

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           MODELO DE AMENAZAS                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        CAPA EXTERNA                                  │   │
│  │  • DDoS Protection (CloudFlare/AWS Shield)                          │   │
│  │  • WAF (Web Application Firewall)                                   │   │
│  │  • Rate Limiting                                                    │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        RED Y TRANSPORTE                              │   │
│  │  • TLS 1.3 (mínimo)                                                 │   │
│  │  • Certificate Pinning                                              │   │
│  │  • Network Segmentation (VPC)                                       │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        APLICACIÓN                                    │   │
│  │  • Authentication (JWT + MFA)                                       │   │
│  │  • Authorization (RBAC + ABAC)                                      │   │
│  │  • Input Validation                                                 │   │
│  │  • Output Encoding                                                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        DATOS                                         │   │
│  │  • Encryption at Rest (AES-256-GCM)                                 │   │
│  │  • Encryption in Transit (TLS 1.3)                                  │   │
│  │  • Field-level Encryption                                           │   │
│  │  • Tokenization (PCI DSS)                                           │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        INFRAESTRUCTURA                               │   │
│  │  • Secrets Management (Vault)                                       │   │
│  │  • Container Security                                               │   │
│  │  • Vulnerability Scanning                                           │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Autenticación y Autorización

### Flujo de Autenticación

```
Usuario
   │
   ▼
┌─────────────────┐
│  Credentials   │
│  (User/Pass)   │
└────────┬────────┘
         │
         ▼
┌─────────────────┐     ┌─────────────────┐
│  Auth Service   │────▶│  User DB        │
│  (Validate)     │     │  (PostgreSQL)   │
└────────┬────────┘     └─────────────────┘
         │
         ▼
┌─────────────────┐
│  MFA Required?  │──── NO ───▶┌─────────────┐
│                 │            │ Access Token│
└────────┬────────┘            │ (JWT)       │
         │ YES                 └─────────────┘
         ▼
┌─────────────────┐
│  MFA Provider   │
│  (TOTP/SMS)     │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Access Token   │
│  + Refresh Token│
└─────────────────┘
```

### JSON Web Tokens (JWT)

**Estructura del Access Token:**
```json
{
  "sub": "user-uuid",
  "email": "user@empresa.com",
  "tenant_id": "tenant-uuid",
  "roles": ["sre_engineer", "database_admin"],
  "permissions": ["server:read", "database:execute"],
  "iat": 1704067200,
  "exp": 1704069000,
  "jti": "unique-token-id",
  "mfa_verified": true
}
```

**Configuración de Seguridad:**
- Algoritmo: RS256 (asimétrico)
- Expiración: 30 minutos
- Refresh token: 7 días con rotación
- Revocación: Lista negra en Redis

### Multi-Factor Authentication (MFA)

| Método | Soporte | Recomendación |
|--------|---------|---------------|
| TOTP (Google Auth) | ✅ | Primario |
| SMS | ✅ | Backup |
| Hardware Key (YubiKey) | 📝 | Alta seguridad |
| Push Notification | 📝 | Conveniencia |
| Biometric | 📝 | Mobile apps |

## Encriptación

### Datos en Reposo

```python
# AES-256-GCM con autenticación
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

# Generar key de 256 bits
key = os.urandom(32)
aesgcm = AESGCM(key)

# Encriptar con nonce aleatorio
nonce = os.urandom(12)
ciphertext = aesgcm.encrypt(nonce, plaintext, associated_data)

# Formato: nonce (12 bytes) + ciphertext + tag (16 bytes)
```

**Campos Encriptados:**
- Contraseñas de bases de datos
- Claves API
- Tokens de acceso
- Información PII/PHI
- Logs con datos sensibles

### Datos en Tránsito

```
Cliente ──TLS 1.3──▶ Load Balancer ──TLS 1.3──▶ API Gateway ──mTLS──▶ Servicios
```

**Configuración TLS:**
- Versión mínima: TLS 1.3
- Cipher suites: TLS_AES_256_GCM_SHA384, TLS_CHACHA20_POLY1305_SHA256
- Certificados: Let's Encrypt / Enterprise CA
- Renovar: Automático cada 60 días

## Prevención de Ataques

### Inyección SQL

```python
# ✅ Seguro - Uso de ORM
result = await db.execute(
    select(User).where(User.id == user_id)
)

# ✅ Seguro - Query parametrizada
result = await db.execute(
    text("SELECT * FROM users WHERE id = :user_id"),
    {"user_id": user_id}
)

# ❌ Inseguro - Concatenación
query = f"SELECT * FROM users WHERE id = {user_id}"
```

**Medidas Implementadas:**
1. ORM SQLAlchemy con queries parametrizadas
2. Validación de input con regex
3. Principio de mínimo privilegio (solo SELECT para lectura)
4. Auditoría de todas las queries

### Command Injection

```python
# ✅ Seguro - Lista blanca de comandos
ALLOWED_COMMANDS = {
    "disk_usage": ["df", "-h"],
    "memory_info": ["free", "-m"],
}

# ✅ Seguro - Sin shell=True
subprocess.run(command_list, shell=False)

# ❌ Inseguro
os.system(f"ping {user_input}")
```

### Cross-Site Scripting (XSS)

**Prevención:**
- Escapado de output en templates
- Content Security Policy (CSP)
- HttpOnly cookies
- X-XSS-Protection header

```http
Content-Security-Policy: default-src 'self'; script-src 'self' 'nonce-{random}';
X-XSS-Protection: 1; mode=block
Set-Cookie: session=xxx; HttpOnly; Secure; SameSite=Strict
```

### Cross-Site Request Forgery (CSRF)

```python
# FastAPI con CSRF protection
from fastapi_csrf_protect import CsrfProtect

@CsrfProtect.load_config
def get_csrf_config():
    return [
        ("secret_key", "secret"),
        ("cookie_secure", True),
        ("cookie_samesite", "Strict"),
    ]
```

## Gestión de Secretos

### HashiCorp Vault Integration

```python
import hvac

# Autenticación con Vault
client = hvac.Client(url=VAULT_ADDR)
client.auth.kubernetes.login(
    role="nexusai-api",
    jwt=service_account_token
)

# Leer secreto
secret = client.secrets.kv.v2.read_secret_version(
    path="databases/production"
)
password = secret["data"]["data"]["password"]

# Rotación automática
client.secrets.database.rotate_root_credentials(
    name="postgres-prod"
)
```

**Secretos Gestionados:**
- Credenciales de bases de datos
- Claves API de proveedores de IA
- Certificados SSL/TLS
- Claves de encriptación
- Tokens de integraciones

## Auditoría y Logging

### Eventos de Seguridad Auditados

| Evento | Severidad | Retención |
|--------|-----------|-----------|
| Login exitoso | INFO | 1 año |
| Login fallido | WARNING | 3 años |
| MFA fallido | WARNING | 3 años |
| Acceso denegado | ERROR | 7 años |
| Skill destructivo | CRITICAL | 10 años |
| Cambio de permisos | SECURITY | 10 años |

### Formato de Logs

```json
{
  "timestamp": "2024-01-15T10:30:00Z",
  "level": "SECURITY",
  "event": "skill.execution.completed",
  "severity": "CRITICAL",
  "tenant_id": "tenant-uuid",
  "user_id": "user-uuid",
  "user_email": "admin@empresa.com",
  "resource_type": "skill",
  "resource_id": "server.restart",
  "context": {
    "ip_address": "192.168.1.100",
    "user_agent": "Mozilla/5.0...",
    "session_id": "sess-uuid"
  },
  "data": {
    "request": {"server_id": "srv-001"},
    "response": {"status": "success"},
    "changes": [{"field": "server.status", "old": "running", "new": "restarting"}]
  },
  "hash": "sha256-of-record",
  "signature": "digital-signature"
}
```

## Cumplimiento Normativo

### ISO 27001

| Control | Implementación |
|---------|----------------|
| A.9.1.1 Política de acceso | RBAC + ABAC |
| A.9.2.1 Registro de usuarios | Onboarding workflow |
| A.9.4.1 Restricción de acceso | IP whitelist, MFA |
| A.10.1.1 Política criptográfica | AES-256, TLS 1.3 |
| A.12.3.1 Almacenamiento de logs | ELK stack, 7 años |
| A.16.1.1 Procedimientos de incidentes | PagerDuty integration |

### GDPR

| Requisito | Implementación |
|-----------|----------------|
| Derecho al olvido | API endpoint `/user/delete` |
| Portabilidad de datos | Export en JSON/CSV |
| Consentimiento | Registro explícito |
| Breach notification | 72h alertas automáticas |
| Data Protection Officer | Rol configurado |

### SOC 2 Tipo II

| Trust Service Criteria | Evidencia |
|------------------------|-----------|
| Security | Pentests trimestrales |
| Availability | 99.9% SLA, monitoreo 24/7 |
| Processing Integrity | Validación de inputs |
| Confidentiality | Encriptación end-to-end |
| Privacy | Políticas de retención |

## Pentesting y Vulnerabilidades

### Herramientas Integradas

```yaml
# CI/CD Pipeline
security_scan:
  - bandit: Python SAST
  - safety: Dependency scanning
  - trivy: Container scanning
  - owasp-zap: DAST
  - sonarqube: Code quality
```

### Reporte de Vulnerabilidades

Si descubres una vulnerabilidad:

1. **NO** abras un issue público
2. Envía email a: security@nexusai.enterprise
3. Incluye:
   - Descripción detallada
   - Pasos para reproducir
   - Impacto potencial
   - Sugerencias de mitigación

**Política de Divulgación:**
- Acknowledgement: 48 horas
- Fix timeline: 30 días (crítico), 90 días (alto)
- Public disclosure: Después del fix

## Referencias

- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [NIST Cybersecurity Framework](https://www.nist.gov/cyberframework)
- [CIS Controls](https://www.cisecurity.org/controls/)
- [SANS Top 25](https://www.sans.org/top25-software-errors/)
