# NexusAI Enterprise - Quick Start Guide
=============================================

## Instalación en 5 Minutos

### Requisitos Previos

- Docker 24.0+
- Docker Compose 2.20+
- 8GB RAM mínimo
- 20GB espacio en disco

### Paso 1: Clonar y Configurar

```bash
# Clonar repositorio
git clone https://github.com/enterprise/nexusai-enterprise.git
cd nexusai-enterprise

# Copiar configuración
cp backend/.env.example backend/.env

# Generar claves JWT
mkdir -p backend/certs
openssl genrsa -out backend/certs/jwt-private.pem 2048
openssl rsa -in backend/certs/jwt-private.pem -pubout -out backend/certs/jwt-public.pem

# Generar master key
openssl rand -base64 32
# Copiar resultado a NEXUS_MASTER_KEY en backend/.env
```

### Paso 2: Iniciar Servicios

```bash
cd docker

# Iniciar todos los servicios
docker-compose up -d

# Verificar estado
docker-compose ps

# Ver logs
docker-compose logs -f api
```

### Paso 3: Configurar Vault

```bash
# Acceder a Vault UI
curl http://localhost:8200
# Token: nexusai-dev-token

# O usar CLI
docker exec -it nexusai-vault vault kv put secret/databases/production \
  host=postgres \
  port=5432 \
  username=nexusai \
  password=nexusai_secure_password
```

### Paso 4: Crear Tenant y Usuario Admin

```bash
# Crear tenant
curl -X POST http://localhost:8000/api/v1/tenants \
  -H "Content-Type: application/json" \
  -H "X-API-Key: nexusai-dev-token" \
  -d '{
    "name": "Mi Empresa",
    "legal_name": "Mi Empresa S.A.",
    "tier": "enterprise",
    "primary_contact_email": "admin@miempresa.com"
  }'

# Crear usuario admin
curl -X POST http://localhost:8000/api/v1/users \
  -H "Content-Type: application/json" \
  -H "X-Tenant-ID: {tenant-id}" \
  -d '{
    "email": "admin@miempresa.com",
    "username": "admin",
    "full_name": "Administrador",
    "roles": ["tenant_admin"],
    "password": "SecurePassword123!"
  }'
```

### Paso 5: Login y Prueba

```bash
# Login
curl -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@miempresa.com",
    "password": "SecurePassword123!"
  }'

# Respuesta incluye access_token
# Guardar en variable: export TOKEN="eyJ..."

# Verificar salud
curl http://localhost:8000/health \
  -H "Authorization: Bearer $TOKEN"

# Listar skills disponibles
curl http://localhost:8000/api/v1/skills \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Tenant-ID: {tenant-id}"
```

## Uso Básico

### 1. Registrar una Aplicación

```bash
curl -X POST http://localhost:8000/api/v1/applications \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Tenant-ID: {tenant-id}" \
  -H "Content-Type: application/json" \
  -d '{
    "code": "ERP_PROD",
    "name": "ERP Producción",
    "description": "Sistema ERP principal",
    "criticality": "tier_1_mission_critical",
    "owner_team": "Operaciones",
    "technical_owner": "juan.perez@miempresa.com"
  }'
```

### 2. Agregar Base de Datos

```bash
curl -X POST http://localhost:8000/api/v1/databases \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Tenant-ID: {tenant-id}" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "erp_production",
    "display_name": "ERP Production DB",
    "db_type": "postgresql",
    "connection": {
      "host": "postgres.miempresa.com",
      "port": 5432,
      "database_name": "erp",
      "vault_secret_path": "secret/databases/erp"
    }
  }'
```

### 3. Ejecutar Skill de Análisis

```bash
# Analizar logs
curl -X POST http://localhost:8000/api/v1/skills/execute \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Tenant-ID: {tenant-id}" \
  -H "Content-Type: application/json" \
  -d '{
    "skill_code": "server.analyze_logs",
    "target": {
      "application_code": "ERP_PROD"
    },
    "parameters": {
      "log_path": "/var/log/erp/application.log",
      "pattern": "ERROR|EXCEPTION",
      "time_range": "last_24h"
    }
  }'
```

### 4. Chat con IA

```bash
# Consulta en lenguaje natural
curl -X POST http://localhost:8000/api/v1/chat \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Tenant-ID: {tenant-id}" \
  -H "Content-Type: application/json" \
  -d '{
    "message": "¿Cuáles son las ventas del último mes por región?",
    "context": {
      "application_code": "ERP_PROD"
    }
  }'
```

## Configurar Integraciones

### Microsoft Teams

1. Crear app en [Microsoft Bot Framework](https://dev.botframework.com/)
2. Configurar en `.env`:
   ```env
   NEXUS_TEAMS_ENABLED=true
   NEXUS_TEAMS_APP_ID=your-app-id
   NEXUS_TEAMS_APP_PASSWORD=your-app-password
   ```
3. Reiniciar: `docker-compose restart api`

### Azure OpenAI

1. Crear recurso en [Azure Portal](https://portal.azure.com)
2. Configurar en `.env`:
   ```env
   NEXUS_AZURE_OPENAI_ENABLED=true
   NEXUS_AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com
   NEXUS_AZURE_OPENAI_KEY=your-key
   NEXUS_AZURE_OPENAI_DEPLOYMENT=gpt-4
   ```

### SSO (Azure AD)

1. Registrar aplicación en Azure AD
2. Configurar en `.env`:
   ```env
   NEXUS_SSO_ENABLED=true
   NEXUS_SSO_PROVIDER=azure_ad
   NEXUS_SSO_CLIENT_ID=your-client-id
   NEXUS_SSO_CLIENT_SECRET=your-secret
   NEXUS_SSO_TENANT_ID=your-tenant-id
   ```

## Monitoreo

### Dashboards

| Servicio | URL | Credenciales |
|----------|-----|--------------|
| API | http://localhost:8000/docs | - |
| Grafana | http://localhost:3001 | admin/admin |
| Prometheus | http://localhost:9090 | - |
| Jaeger | http://localhost:16686 | - |
| Vault | http://localhost:8200 | nexusai-dev-token |

### Métricas Clave

```bash
# Health check
curl http://localhost:8000/health

# Métricas Prometheus
curl http://localhost:8000/metrics

# Estadísticas de skills
curl http://localhost:8000/api/v1/admin/stats \
  -H "Authorization: Bearer $TOKEN"
```

## Troubleshooting

### Problema: Puerto 8000 ocupado

```bash
# Cambiar puerto en docker-compose.yml
ports:
  - "8080:8000"  # Cambiar 8000 por 8080
```

### Problema: Vault no inicia

```bash
# Resetear Vault
docker-compose rm -f vault
docker volume rm docker_vault-data
docker-compose up -d vault
```

### Problema: PostgreSQL connection refused

```bash
# Verificar estado
docker-compose logs postgres

# Esperar a que esté healthy
docker-compose ps
```

### Problema: Permiso denegado en skills

```bash
# Verificar roles del usuario
curl http://localhost:8000/api/v1/users/me \
  -H "Authorization: Bearer $TOKEN"

# Verificar permisos del skill
curl http://localhost:8000/api/v1/skills/server.analyze_logs \
  -H "Authorization: Bearer $TOKEN"
```

## Comandos Útiles

```bash
# Ver logs de todos los servicios
docker-compose logs -f

# Ver logs de un servicio específico
docker-compose logs -f api

# Reiniciar servicio
docker-compose restart api

# Rebuild después de cambios
docker-compose up -d --build api

# Ejecutar comandos en contenedor
docker-compose exec api python -c "print('Hello')"

# Backup de base de datos
docker-compose exec postgres pg_dump -U nexusai nexusai > backup.sql

# Restaurar base de datos
docker-compose exec -T postgres psql -U nexusai nexusai < backup.sql
```

## Siguientes Pasos

1. **Configurar Alertas**: Editar `docker/alertmanager/alertmanager.yml`
2. **Agregar Skills**: Ver `docs/development/ADDING_SKILLS.md`
3. **Personalizar Dashboards**: Importar en Grafana
4. **Configurar Backup**: Automatizar con cron
5. **Revisar Seguridad**: Ver `docs/security/SECURITY.md`

## Soporte

- 📖 Documentación: https://docs.nexusai.enterprise
- 💬 Community: https://community.nexusai.enterprise
- 🐛 Issues: GitHub Issues (no reportes de seguridad)
- 🔒 Security: security@nexusai.enterprise
- 📧 General: support@nexusai.enterprise
