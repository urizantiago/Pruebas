"""
NexusAI Enterprise - PostgreSQL Connector
==========================================
Conector para PostgreSQL con asyncpg.
"""
import asyncio
from typing import Any, Dict, List, Optional, AsyncGenerator
import asyncpg

from .base import IDatabaseConnector, ConnectionConfig, QueryResult, QueryType, DatabaseMetrics


class PostgreSQLConnector(IDatabaseConnector):
    """Conector para PostgreSQL."""
    
    def __init__(self):
        self._pool: Optional[asyncpg.Pool] = None
        self._config: Optional[ConnectionConfig] = None
    
    @property
    def database_type(self) -> str:
        return "postgresql"
    
    async def connect(self, config: ConnectionConfig) -> bool:
        """Establece conexión con PostgreSQL."""
        try:
            self._config = config
            
            # Construir DSN
            dsn = f"postgresql://{config.username}:{config.password}@{config.host}:{config.port}/{config.database}"
            
            # SSL config
            ssl = None
            if config.ssl_mode != "disable":
                ssl = config.ssl_mode
            
            # Crear pool de conexiones
            self._pool = await asyncpg.create_pool(
                dsn=dsn,
                ssl=ssl,
                min_size=config.pool_size,
                max_size=config.pool_size + config.max_overflow,
                max_inactive_time=config.pool_timeout,
                command_timeout=config.query_timeout,
                server_settings={
                    'application_name': 'NexusAI Enterprise',
                    'statement_timeout': str(config.statement_timeout)
                }
            )
            
            return True
        except Exception as e:
            print(f"Error conectando a PostgreSQL: {e}")
            return False
    
    async def disconnect(self) -> bool:
        """Cierra la conexión."""
        if self._pool:
            await self._pool.close()
            self._pool = None
        return True
    
    async def is_connected(self) -> bool:
        """Verifica conexión activa."""
        if not self._pool:
            return False
        try:
            async with self._pool.acquire() as conn:
                await conn.fetchval("SELECT 1")
            return True
        except Exception:
            return False
    
    async def execute_query(
        self,
        query: str,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
        read_only: bool = True
    ) -> QueryResult:
        """Ejecuta consulta SQL."""
        if not self._pool:
            return QueryResult(success=False, error_message="No hay conexión")
        
        start_time = asyncio.get_event_loop().time()
        
        try:
            async with self._pool.acquire() as conn:
                # Establecer modo solo lectura si es necesario
                if read_only:
                    await conn.execute("SET TRANSACTION READ ONLY")
                
                # Ejecutar consulta
                if params:
                    rows = await conn.fetch(query, *params.values())
                else:
                    rows = await conn.fetch(query)
                
                execution_time = int((asyncio.get_event_loop().time() - start_time) * 1000)
                
                # Convertir a diccionarios
                if rows:
                    columns = [key for key in rows[0].keys()]
                    data = [dict(row) for row in rows]
                else:
                    columns = []
                    data = []
                
                return QueryResult(
                    success=True,
                    data=data,
                    columns=columns,
                    row_count=len(data),
                    execution_time_ms=execution_time,
                    query_type=QueryType.SELECT
                )
                
        except Exception as e:
            return QueryResult(
                success=False,
                error_message=str(e),
                execution_time_ms=int((asyncio.get_event_loop().time() - start_time) * 1000)
            )
    
    async def execute_query_stream(
        self,
        query: str,
        params: Optional[Dict[str, Any]] = None,
        batch_size: int = 100
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Ejecuta consulta en streaming."""
        if not self._pool:
            return
        
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                if params:
                    cursor = await conn.cursor(query, *params.values())
                else:
                    cursor = await conn.cursor(query)
                
                async for row in cursor:
                    yield dict(row)
    
    async def get_schema(self, table_name: Optional[str] = None) -> Dict[str, Any]:
        """Obtiene esquema de la base de datos."""
        schema = {"tables": {}}
        
        try:
            async with self._pool.acquire() as conn:
                if table_name:
                    # Esquema de tabla específica
                    query = """
                        SELECT column_name, data_type, is_nullable, column_default
                        FROM information_schema.columns
                        WHERE table_name = $1
                        ORDER BY ordinal_position
                    """
                    rows = await conn.fetch(query, table_name)
                    schema["tables"][table_name] = [
                        {
                            "name": row["column_name"],
                            "type": row["data_type"],
                            "nullable": row["is_nullable"] == "YES",
                            "default": row["column_default"]
                        }
                        for row in rows
                    ]
                else:
                    # Todas las tablas
                    query = """
                        SELECT table_name 
                        FROM information_schema.tables 
                        WHERE table_schema = 'public'
                    """
                    rows = await conn.fetch(query)
                    for row in rows:
                        schema["tables"][row["table_name"]] = []
                        
        except Exception as e:
            schema["error"] = str(e)
        
        return schema
    
    async def get_tables(self) -> List[str]:
        """Lista tablas."""
        try:
            async with self._pool.acquire() as conn:
                query = """
                    SELECT table_name 
                    FROM information_schema.tables 
                    WHERE table_schema = 'public'
                    ORDER BY table_name
                """
                rows = await conn.fetch(query)
                return [row["table_name"] for row in rows]
        except Exception:
            return []
    
    async def get_metrics(self) -> DatabaseMetrics:
        """Obtiene métricas."""
        metrics = DatabaseMetrics()
        
        try:
            async with self._pool.acquire() as conn:
                # Conexiones activas
                result = await conn.fetchval(
                    "SELECT count(*) FROM pg_stat_activity WHERE state = 'active'"
                )
                metrics.active_queries = result or 0
                
                # Total conexiones
                result = await conn.fetchval("SELECT count(*) FROM pg_stat_activity")
                metrics.connection_count = result or 0
                
                # Cache hit ratio
                result = await conn.fetchval("""
                    SELECT round(blks_hit * 100.0 / (blks_hit + blks_read), 2)
                    FROM pg_stat_database WHERE datname = current_database()
                """)
                metrics.cache_hit_ratio = result or 0.0
                
                # Deadlocks
                result = await conn.fetchval("""
                    SELECT deadlocks FROM pg_stat_database 
                    WHERE datname = current_database()
                """)
                metrics.deadlocks = result or 0
                        
        except Exception:
            pass
        
        return metrics
    
    async def get_slow_queries(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Obtiene consultas lentas."""
        try:
            async with self._pool.acquire() as conn:
                query = """
                    SELECT query, calls, mean_exec_time, total_exec_time
                    FROM pg_stat_statements
                    WHERE dbid = (SELECT oid FROM pg_database WHERE datname = current_database())
                    ORDER BY mean_exec_time DESC
                    LIMIT $1
                """
                rows = await conn.fetch(query, limit)
                return [
                    {
                        "query": row["query"][:500],
                        "calls": row["calls"],
                        "mean_time_ms": row["mean_exec_time"],
                        "total_time_ms": row["total_exec_time"]
                    }
                    for row in rows
                ]
        except Exception:
            return []
    
    async def get_blocking_queries(self) -> List[Dict[str, Any]]:
        """Obtiene consultas bloqueantes."""
        try:
            async with self._pool.acquire() as conn:
                query = """
                    SELECT blocked_locks.pid AS blocked_pid,
                           blocked_activity.usename AS blocked_user,
                           blocking_locks.pid AS blocking_pid,
                           blocking_activity.usename AS blocking_user,
                           blocked_activity.query AS blocked_statement,
                           blocking_activity.query AS blocking_statement
                    FROM pg_catalog.pg_locks blocked_locks
                    JOIN pg_catalog.pg_stat_activity blocked_activity ON blocked_activity.pid = blocked_locks.pid
                    JOIN pg_catalog.pg_locks blocking_locks ON blocking_locks.locktype = blocked_locks.locktype
                    JOIN pg_catalog.pg_stat_activity blocking_activity ON blocking_activity.pid = blocking_locks.pid
                    WHERE NOT blocked_locks.granted
                """
                rows = await conn.fetch(query)
                return [
                    {
                        "blocked_pid": row["blocked_pid"],
                        "blocked_user": row["blocked_user"],
                        "blocking_pid": row["blocking_pid"],
                        "blocked_query": row["blocked_statement"][:200]
                    }
                    for row in rows
                ]
        except Exception:
            return []
    
    async def kill_session(self, session_id: str) -> bool:
        """Mata una sesión."""
        try:
            async with self._pool.acquire() as conn:
                await conn.execute(f"SELECT pg_terminate_backend({session_id})")
            return True
        except Exception:
            return False
    
    async def validate_query(self, query: str) -> tuple[bool, Optional[str]]:
        """Valida consulta sin ejecutar."""
        try:
            async with self._pool.acquire() as conn:
                # Usar EXPLAIN para validar sintaxis
                await conn.execute(f"EXPLAIN {query}")
            return True, None
        except Exception as e:
            return False, str(e)
    
    async def test_connection(self, config: ConnectionConfig) -> tuple[bool, Optional[str]]:
        """Prueba conexión."""
        try:
            connector = PostgreSQLConnector()
            success = await connector.connect(config)
            if success:
                await connector.disconnect()
                return True, None
            return False, "No se pudo conectar"
        except Exception as e:
            return False, str(e)
