"""
NexusAI Enterprise - Database Connector Base
=============================================
Interfaz base para conectores de base de datos.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, AsyncGenerator
from enum import Enum


class QueryType(Enum):
    """Tipos de consultas SQL."""
    SELECT = "select"
    INSERT = "insert"
    UPDATE = "update"
    DELETE = "delete"
    DDL = "ddl"
    STORED_PROCEDURE = "stored_procedure"


@dataclass
class QueryResult:
    """Resultado de una consulta."""
    success: bool
    data: Optional[List[Dict[str, Any]]] = None
    columns: Optional[List[str]] = None
    row_count: int = 0
    execution_time_ms: int = 0
    error_message: Optional[str] = None
    warning_message: Optional[str] = None
    query_type: Optional[QueryType] = None
    affected_rows: int = 0


@dataclass
class DatabaseMetrics:
    """Métricas de la base de datos."""
    connection_count: int = 0
    active_queries: int = 0
    slow_queries: int = 0
    cache_hit_ratio: float = 0.0
    disk_usage_gb: float = 0.0
    memory_usage_mb: float = 0.0
    cpu_percent: float = 0.0
    deadlocks: int = 0
    blocked_processes: int = 0


@dataclass
class ConnectionConfig:
    """Configuración de conexión a base de datos."""
    host: str
    port: int
    database: str
    username: str
    password: Optional[str] = None
    
    # SSL/TLS
    ssl_mode: str = "require"  # disable, allow, prefer, require, verify-ca, verify-full
    ssl_root_cert: Optional[str] = None
    ssl_cert: Optional[str] = None
    ssl_key: Optional[str] = None
    
    # Pool de conexiones
    pool_size: int = 5
    max_overflow: int = 10
    pool_timeout: int = 30
    pool_recycle: int = 3600
    
    # Timeouts
    connect_timeout: int = 10
    query_timeout: int = 300
    statement_timeout: int = 60000
    
    # Opciones adicionales
    options: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.options is None:
            self.options = {}


class IDatabaseConnector(ABC):
    """Interfaz base para conectores de base de datos."""
    
    @property
    @abstractmethod
    def database_type(self) -> str:
        """Retorna el tipo de base de datos."""
        pass
    
    @abstractmethod
    async def connect(self, config: ConnectionConfig) -> bool:
        """Establece conexión con la base de datos."""
        pass
    
    @abstractmethod
    async def disconnect(self) -> bool:
        """Cierra la conexión."""
        pass
    
    @abstractmethod
    async def is_connected(self) -> bool:
        """Verifica si hay conexión activa."""
        pass
    
    @abstractmethod
    async def execute_query(
        self,
        query: str,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
        read_only: bool = True
    ) -> QueryResult:
        """Ejecuta una consulta SQL."""
        pass
    
    @abstractmethod
    async def execute_query_stream(
        self,
        query: str,
        params: Optional[Dict[str, Any]] = None,
        batch_size: int = 100
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Ejecuta consulta en streaming."""
        pass
    
    @abstractmethod
    async def get_schema(self, table_name: Optional[str] = None) -> Dict[str, Any]:
        """Obtiene el esquema de la base de datos."""
        pass
    
    @abstractmethod
    async def get_tables(self) -> List[str]:
        """Lista tablas de la base de datos."""
        pass
    
    @abstractmethod
    async def get_metrics(self) -> DatabaseMetrics:
        """Obtiene métricas de rendimiento."""
        pass
    
    @abstractmethod
    async def get_slow_queries(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Obtiene consultas lentas."""
        pass
    
    @abstractmethod
    async def get_blocking_queries(self) -> List[Dict[str, Any]]:
        """Obtiene consultas bloqueantes."""
        pass
    
    @abstractmethod
    async def kill_session(self, session_id: str) -> bool:
        """Mata una sesión/SPID."""
        pass
    
    @abstractmethod
    async def validate_query(self, query: str) -> tuple[bool, Optional[str]]:
        """Valida una consulta SQL sin ejecutarla."""
        pass
    
    @abstractmethod
    async def test_connection(self, config: ConnectionConfig) -> tuple[bool, Optional[str]]:
        """Prueba una configuración de conexión."""
        pass
    
    def sanitize_query(self, query: str) -> str:
        """Sanitiza una consulta para prevenir inyección."""
        import re
        # Remover comentarios
        query = re.sub(r"/\*.*?\*/", "", query, flags=re.DOTALL)
        query = re.sub(r"--.*?$", "", query, flags=re.MULTILINE)
        query = re.sub(r"#.*?$", "", query, flags=re.MULTILINE)
        # Normalizar espacios
        query = " ".join(query.split())
        return query.strip()
    
    def is_read_only_query(self, query: str) -> bool:
        """Verifica si es consulta de solo lectura."""
        query_upper = query.upper().strip()
        
        allowed_starts = ["SELECT", "WITH", "EXPLAIN", "SHOW", "DESCRIBE", "SET"]
        if not any(query_upper.startswith(s) for s in allowed_starts):
            return False
        
        dangerous = ["INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "CREATE", 
                     "TRUNCATE", "EXEC", "EXECUTE", "SP_", "XP_"]
        for word in dangerous:
            if word in query_upper:
                return False
        
        return True
