"""
NexusAI Enterprise - Database Connectors Module
"""
from .base import (
    IDatabaseConnector,
    ConnectionConfig,
    QueryResult,
    DatabaseMetrics,
    QueryPlan,
    IndexInfo,
    TableStats,
    ConnectionHealth,
)
from .postgresql_connector import PostgreSQLConnector, PostgreSQLConfig
from .mysql_connector import MySQLConnector, MySQLConfig
from .sqlserver_connector import SQLServerConnector, SQLServerConfig
from .oracle_connector import OracleConnector, OracleConfig

__all__ = [
    # Base
    "IDatabaseConnector",
    "ConnectionConfig",
    "QueryResult",
    "DatabaseMetrics",
    "QueryPlan",
    "IndexInfo",
    "TableStats",
    "ConnectionHealth",
    # Connectors
    "PostgreSQLConnector",
    "MySQLConnector",
    "SQLServerConnector",
    "OracleConnector",
    # Configs
    "PostgreSQLConfig",
    "MySQLConfig",
    "SQLServerConfig",
    "OracleConfig",
]


class DatabaseConnectorFactory:
    """Factory for creating database connectors."""
    
    _connectors = {
        "postgresql": PostgreSQLConnector,
        "postgres": PostgreSQLConnector,
        "mysql": MySQLConnector,
        "mariadb": MySQLConnector,
        "sqlserver": SQLServerConnector,
        "mssql": SQLServerConnector,
        "oracle": OracleConnector,
        "oracledb": OracleConnector,
    }
    
    @classmethod
    def create(cls, database_type: str) -> IDatabaseConnector:
        """Create a database connector by type."""
        database_type = database_type.lower()
        
        if database_type not in cls._connectors:
            raise ValueError(f"Unsupported database type: {database_type}")
        
        return cls._connectors[database_type]()
    
    @classmethod
    def register(cls, database_type: str, connector_class: type):
        """Register a new connector type."""
        cls._connectors[database_type.lower()] = connector_class
    
    @classmethod
    def supported_types(cls) -> list:
        """Get list of supported database types."""
        return list(cls._connectors.keys())
