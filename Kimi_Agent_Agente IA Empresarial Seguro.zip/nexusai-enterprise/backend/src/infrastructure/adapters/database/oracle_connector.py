"""
NexusAI Enterprise - Oracle Connector
Enterprise-grade Oracle database connector with async support.
"""
import asyncio
import logging
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, AsyncGenerator, Dict, List, Optional, Tuple, Union

import cx_Oracle

from .base import (
    IDatabaseConnector,
    ConnectionConfig,
    QueryResult,
    DatabaseMetrics,
    QueryPlan,
    IndexInfo,
    TableStats,
    ConnectionHealth,
)

logger = logging.getLogger(__name__)


@dataclass
class OracleConfig:
    """Oracle specific configuration."""
    
    # Connection settings
    host: str
    port: int = 1521
    service_name: Optional[str] = None
    sid: Optional[str] = None
    username: str = ""
    password: str = ""
    
    # Connection pooling
    pool_size: int = 5
    max_overflow: int = 10
    pool_timeout: int = 30
    connection_timeout: int = 30
    
    # SSL/TLS settings
    wallet_location: Optional[str] = None
    ssl_server_cert_dn: Optional[str] = None
    
    # Advanced options
    mode: Optional[int] = None  # cx_Oracle.SYSDBA, etc.
    encoding: str = "UTF-8"
    nencoding: str = "UTF-8"
    
    # TNS_ADMIN for tnsnames.ora
    tns_admin: Optional[str] = None
    
    # Additional options
    options: Dict[str, Any] = field(default_factory=dict)


class OracleConnector(IDatabaseConnector):
    """
    Enterprise Oracle database connector with async support.
    
    Features:
    - Connection pooling with cx_Oracle
    - Service name and SID support
    - SSL/TLS encryption with wallets
    - Query plan analysis with DBMS_XPLAN
    - Index recommendations
    - Performance metrics from V$ views
    - Session management
    - PL/SQL execution
    """
    
    def __init__(self):
        self._pool: Optional[cx_Oracle.SessionPool] = None
        self._config: Optional[OracleConfig] = None
        self._connection_config: Optional[ConnectionConfig] = None
        self._health = ConnectionHealth()
        self._query_history: List[Dict[str, Any]] = []
        self._max_history = 1000
        self._lock = asyncio.Lock()
        self._loop: Optional[asyncio.AbstractEventLoop] = None
    
    @property
    def database_type(self) -> str:
        return "oracle"
    
    @property
    def health(self) -> ConnectionHealth:
        return self._health
    
    def _build_dsn(self, config: OracleConfig) -> str:
        """Build Oracle DSN string."""
        if config.tns_admin:
            # Use TNS names
            return config.service_name or config.sid or ""
        
        # Build Easy Connect string
        if config.service_name:
            return f"{config.host}:{config.port}/{config.service_name}"
        elif config.sid:
            return f"{config.host}:{config.port}:{config.sid}"
        else:
            raise ValueError("Either service_name or sid must be provided")
    
    async def connect(self, config: ConnectionConfig) -> bool:
        """Establish connection to Oracle database."""
        try:
            self._loop = asyncio.get_event_loop()
            
            # Parse Oracle specific config
            oracle_config = OracleConfig(
                host=config.host,
                port=config.port,
                username=config.username,
                password=config.password,
                pool_size=config.pool_size,
                max_overflow=config.max_overflow,
                options=config.options or {},
            )
            
            # Extract service name or SID from database field
            if config.database:
                if "/" in config.database:
                    oracle_config.service_name = config.database
                else:
                    oracle_config.sid = config.database
            
            # Handle SSL options
            if config.ssl_mode:
                oracle_config.options["ssl"] = config.ssl_mode in ("require", "prefer")
            
            if config.ca_cert:
                oracle_config.wallet_location = config.ca_cert
            
            self._config = oracle_config
            self._connection_config = config
            
            dsn = self._build_dsn(oracle_config)
            
            # Create connection pool in thread pool (cx_Oracle is synchronous)
            def create_pool():
                return cx_Oracle.SessionPool(
                    user=oracle_config.username,
                    password=oracle_config.password,
                    dsn=dsn,
                    min=oracle_config.pool_size,
                    max=oracle_config.pool_size + oracle_config.max_overflow,
                    increment=1,
                    encoding=oracle_config.encoding,
                    nencoding=oracle_config.nencoding,
                    timeout=oracle_config.connection_timeout,
                    mode=oracle_config.mode or cx_Oracle.DEFAULT_AUTH,
                )
            
            self._pool = await self._loop.run_in_executor(None, create_pool)
            
            # Test connection
            def test_connection():
                conn = self._pool.acquire()
                try:
                    cursor = conn.cursor()
                    cursor.execute("SELECT * FROM v$version")
                    version = cursor.fetchone()[0]
                    cursor.execute("SELECT SYS_CONTEXT('USERENV', 'DB_NAME') FROM DUAL")
                    db_name = cursor.fetchone()[0]
                    return version, db_name
                finally:
                    self._pool.release(conn)
            
            version, db_name = await self._loop.run_in_executor(None, test_connection)
            logger.info(f"Connected to Oracle: {db_name} - {version[:50]}...")
            
            self._health.status = "healthy"
            self._health.last_check = datetime.utcnow()
            logger.info(f"Oracle pool created: {oracle_config.host}:{oracle_config.port}/{oracle_config.service_name or oracle_config.sid}")
            
            return True
            
        except Exception as e:
            self._health.status = "unhealthy"
            self._health.last_error = str(e)
            logger.error(f"Failed to connect to Oracle: {e}")
            raise ConnectionError(f"Oracle connection failed: {e}")
    
    async def disconnect(self) -> bool:
        """Close all connections."""
        try:
            if self._pool:
                def close_pool():
                    self._pool.close()
                
                await self._loop.run_in_executor(None, close_pool)
                self._pool = None
            
            self._health.status = "disconnected"
            logger.info("Oracle connections closed")
            return True
            
        except Exception as e:
            logger.error(f"Error disconnecting from Oracle: {e}")
            return False
    
    async def is_connected(self) -> bool:
        """Check if database connection is alive."""
        if not self._pool:
            return False
        
        try:
            def check():
                conn = self._pool.acquire()
                try:
                    cursor = conn.cursor()
                    cursor.execute("SELECT 1 FROM DUAL")
                    cursor.fetchone()
                    return True
                finally:
                    self._pool.release(conn)
            
            return await self._loop.run_in_executor(None, check)
        except Exception:
            return False
    
    @asynccontextmanager
    async def _get_connection(self) -> AsyncGenerator[cx_Oracle.Connection, None]:
        """Get connection from pool with automatic cleanup."""
        conn = None
        try:
            def acquire():
                return self._pool.acquire()
            
            conn = await self._loop.run_in_executor(None, acquire)
            yield conn
        finally:
            if conn:
                def release():
                    self._pool.release(conn)
                await self._loop.run_in_executor(None, release)
    
    async def execute_query(
        self,
        query: str,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
        read_only: bool = True,
    ) -> QueryResult:
        """Execute a query and return results."""
        start_time = datetime.utcnow()
        
        try:
            async with self._get_connection() as conn:
                def execute():
                    cursor = conn.cursor()
                    
                    # Set timeout if provided
                    if timeout:
                        cursor.callproc("DBMS_SESSION.SET_SQL_TRACE", [True])
                    
                    # Execute query
                    if params:
                        cursor.execute(query, params)
                    else:
                        cursor.execute(query)
                    
                    # Get column names
                    columns = [desc[0] for desc in cursor.description] if cursor.description else []
                    
                    # Fetch all rows
                    rows = []
                    if cursor.description:
                        raw_rows = cursor.fetchall()
                        rows = [dict(zip(columns, row)) for row in raw_rows]
                    
                    row_count = cursor.rowcount if not read_only else len(rows)
                    
                    cursor.close()
                    return columns, rows, row_count
                
                columns, rows, row_count = await self._loop.run_in_executor(None, execute)
                
                execution_time = (datetime.utcnow() - start_time).total_seconds()
                
                result = QueryResult(
                    columns=columns,
                    rows=rows,
                    row_count=row_count,
                    execution_time=execution_time,
                    query=query,
                )
                
                # Log query
                await self._log_query(query, params, execution_time, True)
                
                return result
                
        except Exception as e:
            execution_time = (datetime.utcnow() - start_time).total_seconds()
            await self._log_query(query, params, execution_time, False, str(e))
            logger.error(f"Query execution failed: {e}")
            raise
    
    async def execute_command(
        self,
        command: str,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> QueryResult:
        """Execute a DDL/DML command."""
        return await self.execute_query(command, params, timeout, read_only=False)
    
    async def execute_transaction(
        self,
        queries: List[Tuple[str, Optional[Dict[str, Any]]]],
        timeout: Optional[int] = None,
    ) -> List[QueryResult]:
        """Execute multiple queries in a transaction."""
        results = []
        
        async with self._get_connection() as conn:
            try:
                def execute_all():
                    cursor = conn.cursor()
                    local_results = []
                    
                    for query, params in queries:
                        if params:
                            cursor.execute(query, params)
                        else:
                            cursor.execute(query)
                        
                        columns = [desc[0] for desc in cursor.description] if cursor.description else []
                        rows = []
                        
                        if cursor.description:
                            raw_rows = cursor.fetchall()
                            rows = [dict(zip(columns, row)) for row in raw_rows]
                        
                        local_results.append(QueryResult(
                            columns=columns,
                            rows=rows,
                            row_count=cursor.rowcount,
                            execution_time=0,
                            query=query,
                        ))
                    
                    cursor.close()
                    conn.commit()
                    return local_results
                
                results = await self._loop.run_in_executor(None, execute_all)
                return results
                
            except Exception as e:
                def rollback():
                    conn.rollback()
                await self._loop.run_in_executor(None, rollback)
                logger.error(f"Transaction failed: {e}")
                raise
    
    async def execute_plsql(
        self,
        procedure_name: str,
        params: Optional[Dict[str, Any]] = None,
        out_params: Optional[List[Tuple[str, Any]]] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Execute a PL/SQL procedure or function."""
        try:
            async with self._get_connection() as conn:
                def execute():
                    cursor = conn.cursor()
                    
                    # Build parameter list
                    param_list = []
                    param_values = []
                    
                    if params:
                        for key, value in params.items():
                            param_list.append(f":{key}")
                            param_values.append(value)
                    
                    if out_params:
                        for name, var_type in out_params:
                            param_list.append(f":{name}")
                            param_values.append(cursor.var(var_type))
                    
                    # Execute procedure
                    param_str = ", ".join(param_list) if param_list else ""
                    cursor.execute(f"BEGIN {procedure_name}({param_str}); END;", param_values)
                    
                    # Extract OUT parameters
                    result = {}
                    if out_params:
                        for i, (name, _) in enumerate(out_params):
                            result[name] = param_values[len(params) + i].getvalue() if params else param_values[i].getvalue()
                    
                    cursor.close()
                    return result
                
                return await self._loop.run_in_executor(None, execute)
                
        except Exception as e:
            logger.error(f"PL/SQL execution failed: {e}")
            raise
    
    async def get_metrics(self) -> DatabaseMetrics:
        """Get comprehensive Oracle metrics."""
        metrics = DatabaseMetrics()
        
        try:
            async with self._get_connection() as conn:
                def get_metrics_sync():
                    cursor = conn.cursor()
                    results = {}
                    
                    # Database size
                    cursor.execute("""
                        SELECT SUM(bytes) / 1024 / 1024 AS size_mb
                        FROM dba_segments
                        WHERE owner = USER
                    """)
                    row = cursor.fetchone()
                    results['database_size_mb'] = row[0] if row and row[0] else 0
                    
                    # Connection count
                    cursor.execute("""
                        SELECT COUNT(*) FROM v$session WHERE type = 'USER'
                    """)
                    row = cursor.fetchone()
                    results['connection_count'] = row[0] if row else 0
                    
                    # Active queries
                    cursor.execute("""
                        SELECT COUNT(*) FROM v$session 
                        WHERE status = 'ACTIVE' AND type = 'USER'
                    """)
                    row = cursor.fetchone()
                    results['active_queries'] = row[0] if row else 0
                    
                    # Cache hit ratio
                    cursor.execute("""
                        SELECT 
                            ROUND((1 - (phy.value / (cur.value + con.value))) * 100, 2) AS cache_hit_ratio
                        FROM v$sysstat cur, v$sysstat con, v$sysstat phy
                        WHERE cur.name = 'db block gets'
                        AND con.name = 'consistent gets'
                        AND phy.name = 'physical reads'
                    """)
                    row = cursor.fetchone()
                    results['cache_hit_ratio'] = row[0] if row and row[0] else 0
                    
                    # Lock waits
                    cursor.execute("""
                        SELECT COUNT(*) FROM v$lock WHERE block = 1
                    """)
                    row = cursor.fetchone()
                    results['lock_waits'] = row[0] if row else 0
                    
                    # Deadlocks
                    cursor.execute("""
                        SELECT value FROM v$sysstat WHERE name = 'enqueue deadlocks'
                    """)
                    row = cursor.fetchone()
                    results['deadlocks'] = row[0] if row else 0
                    
                    # Transactions per second (simplified)
                    cursor.execute("""
                        SELECT value FROM v$sysstat WHERE name = 'user commits'
                    """)
                    row = cursor.fetchone()
                    results['user_commits'] = row[0] if row else 0
                    
                    cursor.close()
                    return results
                
                results = await self._loop.run_in_executor(None, get_metrics_sync)
                
                metrics.database_size_mb = results.get('database_size_mb', 0)
                metrics.connection_count = results.get('connection_count', 0)
                metrics.active_queries = results.get('active_queries', 0)
                metrics.cache_hit_ratio = results.get('cache_hit_ratio', 0)
                metrics.lock_waits = results.get('lock_waits', 0)
                metrics.deadlocks = results.get('deadlocks', 0)
                metrics.transactions_per_sec = results.get('user_commits', 0)
                metrics.timestamp = datetime.utcnow()
                    
        except Exception as e:
            logger.error(f"Failed to get metrics: {e}")
        
        return metrics
    
    async def get_query_plan(self, query: str, params: Optional[Dict[str, Any]] = None) -> QueryPlan:
        """Get execution plan for a query using DBMS_XPLAN."""
        try:
            async with self._get_connection() as conn:
                def get_plan():
                    cursor = conn.cursor()
                    
                    # Explain plan
                    if params:
                        cursor.execute(f"EXPLAIN PLAN FOR {query}", params)
                    else:
                        cursor.execute(f"EXPLAIN PLAN FOR {query}")
                    
                    # Get plan output
                    cursor.execute("SELECT PLAN_TABLE_OUTPUT FROM TABLE(DBMS_XPLAN.DISPLAY())")
                    plan_lines = [row[0] for row in cursor.fetchall()]
                    plan_text = "\n".join(plan_lines)
                    
                    # Get estimated cost from plan_table
                    cursor.execute("""
                        SELECT MAX(cost) FROM plan_table 
                        WHERE statement_id = (SELECT MAX(statement_id) FROM plan_table)
                    """)
                    row = cursor.fetchone()
                    estimated_cost = row[0] if row and row[0] else 0
                    
                    cursor.close()
                    return plan_text, estimated_cost
                
                plan_text, estimated_cost = await self._loop.run_in_executor(None, get_plan)
                
                return QueryPlan(
                    plan_data=plan_text,
                    estimated_cost=float(estimated_cost),
                    estimated_rows=0,
                )
                    
        except Exception as e:
            logger.error(f"Failed to get query plan: {e}")
            return QueryPlan(plan_data="", estimated_cost=0, estimated_rows=0)
    
    async def get_index_recommendations(self, table_name: Optional[str] = None) -> List[IndexInfo]:
        """Get index recommendations from Oracle advisors."""
        recommendations = []
        
        try:
            async with self._get_connection() as conn:
                def get_recommendations():
                    cursor = conn.cursor()
                    results = []
                    
                    # Query SQL Tuning Advisor recommendations
                    query = """
                        SELECT 
                            s.table_name,
                            s.index_name,
                            s.column_names,
                            s.improvement_factor
                        FROM dba_advisor_recommendations r
                        JOIN dba_sqltune_indexes s ON r.task_id = s.task_id
                        WHERE r.type = 'INDEX'
                    """
                    
                    if table_name:
                        query += f" AND s.table_name = '{table_name.upper()}'"
                    
                    cursor.execute(query)
                    
                    for row in cursor.fetchall():
                        results.append(IndexInfo(
                            table_name=row[0] or "",
                            index_name=row[1] or "",
                            columns=row[2] or "",
                            index_type="B-TREE",
                            estimated_improvement=row[3] or 0,
                            size_mb=0,
                        ))
                    
                    cursor.close()
                    return results
                
                recommendations = await self._loop.run_in_executor(None, get_recommendations)
                        
        except Exception as e:
            logger.error(f"Failed to get index recommendations: {e}")
        
        return recommendations
    
    async def get_table_stats(self, table_name: Optional[str] = None) -> List[TableStats]:
        """Get statistics for tables."""
        stats = []
        
        try:
            async with self._get_connection() as conn:
                def get_stats():
                    cursor = conn.cursor()
                    results = []
                    
                    query = """
                        SELECT 
                            table_name,
                            num_rows,
                            ROUND(blocks * 8 / 1024, 2) AS size_mb,
                            last_analyzed
                        FROM user_tables
                        WHERE 1=1
                    """
                    
                    if table_name:
                        query += f" AND table_name = '{table_name.upper()}'"
                    
                    query += " ORDER BY num_rows DESC NULLS LAST"
                    
                    cursor.execute(query)
                    
                    for row in cursor.fetchall():
                        results.append(TableStats(
                            table_name=row[0] or "",
                            row_count=row[1] or 0,
                            size_mb=row[2] or 0,
                            index_count=0,  # Would need separate query
                            last_analyzed=row[3],
                        ))
                    
                    cursor.close()
                    return results
                
                stats = await self._loop.run_in_executor(None, get_stats)
                        
        except Exception as e:
            logger.error(f"Failed to get table stats: {e}")
        
        return stats
    
    async def stream_query(
        self,
        query: str,
        params: Optional[Dict[str, Any]] = None,
        batch_size: int = 1000,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Stream query results in batches."""
        try:
            async with self._get_connection() as conn:
                def fetch_batches():
                    cursor = conn.cursor()
                    cursor.arraysize = batch_size
                    
                    if params:
                        cursor.execute(query, params)
                    else:
                        cursor.execute(query)
                    
                    columns = [desc[0] for desc in cursor.description] if cursor.description else []
                    
                    while True:
                        rows = cursor.fetchmany(batch_size)
                        if not rows:
                            break
                        
                        for row in rows:
                            yield dict(zip(columns, row))
                    
                    cursor.close()
                
                # Run in executor and yield results
                iterator = await self._loop.run_in_executor(None, lambda: list(fetch_batches()))
                for item in iterator:
                    yield item
                    
        except Exception as e:
            logger.error(f"Streaming query failed: {e}")
            raise
    
    async def test_connection(self) -> Tuple[bool, str]:
        """Test database connectivity."""
        try:
            async with self._get_connection() as conn:
                def test():
                    cursor = conn.cursor()
                    cursor.execute("SELECT * FROM v$version")
                    version = cursor.fetchone()[0]
                    cursor.execute("SELECT SYS_CONTEXT('USERENV', 'DB_NAME') FROM DUAL")
                    db_name = cursor.fetchone()[0]
                    cursor.execute("SELECT SYS_CONTEXT('USERENV', 'SESSIONID') FROM DUAL")
                    session_id = cursor.fetchone()[0]
                    cursor.close()
                    return version, db_name, session_id
                
                version, db_name, session_id = await self._loop.run_in_executor(None, test)
                return True, f"Connected to {db_name} (Session: {session_id}) - {version[:50]}"
            
        except Exception as e:
            return False, str(e)
    
    async def _log_query(
        self,
        query: str,
        params: Optional[Dict[str, Any]],
        execution_time: float,
        success: bool,
        error: Optional[str] = None,
    ):
        """Log query execution for monitoring."""
        async with self._lock:
            self._query_history.append({
                "timestamp": datetime.utcnow().isoformat(),
                "query": query[:500],
                "params": str(params)[:200] if params else None,
                "execution_time": execution_time,
                "success": success,
                "error": error,
            })
            
            if len(self._query_history) > self._max_history:
                self._query_history = self._query_history[-self._max_history:]
    
    async def get_slow_queries(self, limit: int = 10, min_duration_ms: float = 1000) -> List[Dict[str, Any]]:
        """Get slow queries from history."""
        slow_queries = [
            q for q in self._query_history
            if q["execution_time"] * 1000 >= min_duration_ms
        ]
        return sorted(slow_queries, key=lambda x: x["execution_time"], reverse=True)[:limit]
    
    async def kill_session(self, session_id: int) -> bool:
        """Kill a database session."""
        try:
            async with self._get_connection() as conn:
                def kill():
                    cursor = conn.cursor()
                    cursor.execute(f"ALTER SYSTEM KILL SESSION '{session_id},1' IMMEDIATE")
                    cursor.close()
                
                await self._loop.run_in_executor(None, kill)
                return True
                
        except Exception as e:
            logger.error(f"Failed to kill session {session_id}: {e}")
            return False
    
    async def get_active_sessions(self) -> List[Dict[str, Any]]:
        """Get active database sessions."""
        sessions = []
        
        try:
            async with self._get_connection() as conn:
                def get_sessions():
                    cursor = conn.cursor()
                    cursor.execute("""
                        SELECT 
                            sid,
                            serial#,
                            username,
                            program,
                            machine,
                            status,
                            sql_id,
                            event,
                            seconds_in_wait,
                            logon_time
                        FROM v$session
                        WHERE type = 'USER'
                        ORDER BY cpu_used DESC NULLS LAST
                    """)
                    
                    columns = [desc[0] for desc in cursor.description]
                    results = []
                    
                    for row in cursor.fetchall():
                        results.append(dict(zip(columns, row)))
                    
                    cursor.close()
                    return results
                
                sessions = await self._loop.run_in_executor(None, get_sessions)
                        
        except Exception as e:
            logger.error(f"Failed to get active sessions: {e}")
        
        return sessions
    
    async def gather_table_statistics(self, table_name: str) -> bool:
        """Gather statistics for a table using DBMS_STATS."""
        try:
            async with self._get_connection() as conn:
                def gather():
                    cursor = conn.cursor()
                    cursor.execute(f"BEGIN DBMS_STATS.GATHER_TABLE_STATS(OWNNAME => USER, TABNAME => '{table_name.upper()}'); END;")
                    cursor.close()
                
                await self._loop.run_in_executor(None, gather)
                return True
                
        except Exception as e:
            logger.error(f"Failed to gather statistics for {table_name}: {e}")
            return False
