"""
NexusAI Enterprise - SQL Server Connector
Enterprise-grade SQL Server database connector with async support.
"""
import asyncio
import logging
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, AsyncGenerator, Dict, List, Optional, Tuple, Union

import aioodbc
import pyodbc
from aioodbc import Pool

from .base import (
    IDatabaseConnector,
    ConnectionConfig,
    QueryResult,
    DatabaseMetrics,
    QueryPlan,
    IndexInfo,
    TableStats,
    ConnectionHealth,
)

logger = logging.getLogger(__name__)


@dataclass
class SQLServerConfig:
    """SQL Server specific configuration."""
    
    # Connection settings
    host: str
    port: int = 1433
    database: str = "master"
    username: str = ""
    password: str = ""
    instance: Optional[str] = None
    
    # Windows Authentication
    use_windows_auth: bool = False
    domain: Optional[str] = None
    
    # SSL/TLS settings
    encrypt: bool = True
    trust_server_certificate: bool = False
    ca_cert_path: Optional[str] = None
    
    # Connection pooling
    pool_size: int = 5
    max_overflow: int = 10
    pool_timeout: int = 30
    connection_timeout: int = 30
    command_timeout: int = 30
    
    # Failover settings
    failover_partner: Optional[str] = None
    multi_subnet_failover: bool = True
    
    # Application intent
    application_intent: str = "readwrite"  # readwrite or readonly
    application_name: str = "NexusAI Enterprise"
    
    # Additional options
    options: Dict[str, Any] = field(default_factory=dict)


class SQLServerConnector(IDatabaseConnector):
    """
    Enterprise SQL Server database connector with full async support.
    
    Features:
    - Connection pooling with aioodbc
    - Windows and SQL authentication
    - SSL/TLS encryption
    - Always On availability group support
    - Query plan analysis
    - Index recommendations
    - Performance metrics
    - Deadlock detection
    """
    
    def __init__(self):
        self._pool: Optional[Pool] = None
        self._config: Optional[SQLServerConfig] = None
        self._connection_config: Optional[ConnectionConfig] = None
        self._health = ConnectionHealth()
        self._query_history: List[Dict[str, Any]] = []
        self._max_history = 1000
        self._lock = asyncio.Lock()
    
    @property
    def database_type(self) -> str:
        return "sqlserver"
    
    @property
    def health(self) -> ConnectionHealth:
        return self._health
    
    def _build_connection_string(self, config: SQLServerConfig) -> str:
        """Build ODBC connection string for SQL Server."""
        parts = [
            f"DRIVER={{ODBC Driver 18 for SQL Server}}",
            f"SERVER={config.host},{config.port}",
            f"DATABASE={config.database}",
            f"Connection Timeout={config.connection_timeout}",
            f"Command Timeout={config.command_timeout}",
            f"Application Name={config.application_name}",
            f"ApplicationIntent={config.application_intent}",
        ]
        
        # Instance name
        if config.instance:
            parts[1] = f"SERVER={config.host}\\{config.instance}"
        
        # Authentication
        if config.use_windows_auth:
            parts.append("Trusted_Connection=yes")
            if config.domain:
                parts.append(f"Domain={config.domain}")
        else:
            parts.append(f"UID={config.username}")
            parts.append(f"PWD={config.password}")
        
        # Encryption
        parts.append(f"Encrypt={'yes' if config.encrypt else 'no'}")
        parts.append(f"TrustServerCertificate={'yes' if config.trust_server_certificate else 'no'}")
        
        if config.ca_cert_path:
            parts.append(f"CA={config.ca_cert_path}")
        
        # Failover
        if config.failover_partner:
            parts.append(f"Failover_Partner={config.failover_partner}")
        
        if config.multi_subnet_failover:
            parts.append("MultiSubnetFailover=yes")
        
        # Additional options
        for key, value in config.options.items():
            parts.append(f"{key}={value}")
        
        return ";".join(parts)
    
    async def connect(self, config: ConnectionConfig) -> bool:
        """Establish connection to SQL Server."""
        try:
            # Parse SQL Server specific config
            sql_config = SQLServerConfig(
                host=config.host,
                port=config.port,
                database=config.database,
                username=config.username,
                password=config.password,
                pool_size=config.pool_size,
                max_overflow=config.max_overflow,
                options=config.options or {},
            )
            
            # Override with connection-specific options
            if config.ssl_mode:
                sql_config.encrypt = config.ssl_mode in ("require", "prefer")
                sql_config.trust_server_certificate = config.ssl_mode == "prefer"
            
            if config.ca_cert:
                sql_config.ca_cert_path = config.ca_cert
            
            self._config = sql_config
            self._connection_config = config
            
            connection_string = self._build_connection_string(sql_config)
            
            # Create connection pool
            self._pool = await aioodbc.create_pool(
                dsn=connection_string,
                min_size=sql_config.pool_size,
                max_size=sql_config.pool_size + sql_config.max_overflow,
                echo=False,
            )
            
            # Test connection
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cursor:
                    await cursor.execute("SELECT @@VERSION")
                    row = await cursor.fetchone()
                    version = row[0] if row else "Unknown"
                    logger.info(f"Connected to SQL Server: {version[:50]}...")
            
            self._health.status = "healthy"
            self._health.last_check = datetime.utcnow()
            logger.info(f"SQL Server pool created: {sql_config.host}:{sql_config.port}/{sql_config.database}")
            
            return True
            
        except Exception as e:
            self._health.status = "unhealthy"
            self._health.last_error = str(e)
            logger.error(f"Failed to connect to SQL Server: {e}")
            raise ConnectionError(f"SQL Server connection failed: {e}")
    
    async def disconnect(self) -> bool:
        """Close all connections."""
        try:
            if self._pool:
                self._pool.close()
                await self._pool.wait_closed()
                self._pool = None
            
            self._health.status = "disconnected"
            logger.info("SQL Server connections closed")
            return True
            
        except Exception as e:
            logger.error(f"Error disconnecting from SQL Server: {e}")
            return False
    
    async def is_connected(self) -> bool:
        """Check if database connection is alive."""
        if not self._pool:
            return False
        
        try:
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cursor:
                    await cursor.execute("SELECT 1")
                    await cursor.fetchone()
            return True
        except Exception:
            return False
    
    @asynccontextmanager
    async def _get_connection(self) -> AsyncGenerator:
        """Get connection from pool with automatic cleanup."""
        conn = None
        try:
            conn = await self._pool.acquire()
            yield conn
        finally:
            if conn:
                await self._pool.release(conn)
    
    async def execute_query(
        self,
        query: str,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
        read_only: bool = True,
    ) -> QueryResult:
        """Execute a query and return results."""
        start_time = datetime.utcnow()
        
        try:
            async with self._get_connection() as conn:
                # Set command timeout
                if timeout:
                    conn.timeout = timeout
                
                async with conn.cursor() as cursor:
                    # Execute query
                    if params:
                        await cursor.execute(query, list(params.values()))
                    else:
                        await cursor.execute(query)
                    
                    # Fetch results
                    columns = [desc[0] for desc in cursor.description] if cursor.description else []
                    
                    rows = []
                    if not read_only or cursor.description:
                        batch = await cursor.fetchmany(1000)
                        while batch:
                            rows.extend([dict(zip(columns, row)) for row in batch])
                            batch = await cursor.fetchmany(1000)
                    
                    # Get row count
                    row_count = cursor.rowcount if not read_only else len(rows)
                    
                    execution_time = (datetime.utcnow() - start_time).total_seconds()
                    
                    result = QueryResult(
                        columns=columns,
                        rows=rows,
                        row_count=row_count,
                        execution_time=execution_time,
                        query=query,
                    )
                    
                    # Log query
                    await self._log_query(query, params, execution_time, True)
                    
                    return result
                    
        except Exception as e:
            execution_time = (datetime.utcnow() - start_time).total_seconds()
            await self._log_query(query, params, execution_time, False, str(e))
            logger.error(f"Query execution failed: {e}")
            raise
    
    async def execute_command(
        self,
        command: str,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> QueryResult:
        """Execute a DDL/DML command."""
        return await self.execute_query(command, params, timeout, read_only=False)
    
    async def execute_transaction(
        self,
        queries: List[Tuple[str, Optional[Dict[str, Any]]]],
        timeout: Optional[int] = None,
    ) -> List[QueryResult]:
        """Execute multiple queries in a transaction."""
        results = []
        
        async with self._get_connection() as conn:
            try:
                async with conn.cursor() as cursor:
                    for query, params in queries:
                        if params:
                            await cursor.execute(query, list(params.values()))
                        else:
                            await cursor.execute(query)
                        
                        columns = [desc[0] for desc in cursor.description] if cursor.description else []
                        rows = []
                        
                        if cursor.description:
                            batch = await cursor.fetchmany(1000)
                            while batch:
                                rows.extend([dict(zip(columns, row)) for row in batch])
                                batch = await cursor.fetchmany(1000)
                        
                        results.append(QueryResult(
                            columns=columns,
                            rows=rows,
                            row_count=cursor.rowcount,
                            execution_time=0,
                            query=query,
                        ))
                
                await conn.commit()
                return results
                
            except Exception as e:
                await conn.rollback()
                logger.error(f"Transaction failed: {e}")
                raise
    
    async def execute_stored_procedure(
        self,
        procedure_name: str,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> QueryResult:
        """Execute a stored procedure."""
        start_time = datetime.utcnow()
        
        try:
            async with self._get_connection() as conn:
                async with conn.cursor() as cursor:
                    # Build parameter placeholders
                    if params:
                        param_placeholders = ", ".join([f"?" for _ in params])
                        query = f"EXEC {procedure_name} {param_placeholders}"
                        await cursor.execute(query, list(params.values()))
                    else:
                        query = f"EXEC {procedure_name}"
                        await cursor.execute(query)
                    
                    columns = [desc[0] for desc in cursor.description] if cursor.description else []
                    rows = []
                    
                    if cursor.description:
                        batch = await cursor.fetchmany(1000)
                        while batch:
                            rows.extend([dict(zip(columns, row)) for row in batch])
                            batch = await cursor.fetchmany(1000)
                    
                    execution_time = (datetime.utcnow() - start_time).total_seconds()
                    
                    return QueryResult(
                        columns=columns,
                        rows=rows,
                        row_count=len(rows),
                        execution_time=execution_time,
                        query=query,
                    )
                    
        except Exception as e:
            logger.error(f"Stored procedure execution failed: {e}")
            raise
    
    async def get_metrics(self) -> DatabaseMetrics:
        """Get comprehensive SQL Server metrics."""
        metrics = DatabaseMetrics()
        
        try:
            async with self._get_connection() as conn:
                async with conn.cursor() as cursor:
                    # Database size
                    await cursor.execute("""
                        SELECT 
                            DB_NAME(database_id) AS database_name,
                            SUM(size * 8.0 / 1024) AS size_mb
                        FROM sys.master_files
                        WHERE database_id = DB_ID()
                        GROUP BY database_id
                    """)
                    row = await cursor.fetchone()
                    if row:
                        metrics.database_size_mb = row[1]
                    
                    # Connection count
                    await cursor.execute("""
                        SELECT COUNT(*) 
                        FROM sys.dm_exec_sessions 
                        WHERE database_id = DB_ID()
                    """)
                    row = await cursor.fetchone()
                    metrics.connection_count = row[0] if row else 0
                    
                    # Active queries
                    await cursor.execute("""
                        SELECT COUNT(*) 
                        FROM sys.dm_exec_requests 
                        WHERE status IN ('running', 'suspended', 'runnable')
                    """)
                    row = await cursor.fetchone()
                    metrics.active_queries = row[0] if row else 0
                    
                    # Wait time
                    await cursor.execute("""
                        SELECT AVG(wait_time_ms) 
                        FROM sys.dm_os_wait_stats 
                        WHERE wait_type IN ('PAGEIOLATCH_SH', 'PAGEIOLATCH_EX', 'WRITELOG')
                    """)
                    row = await cursor.fetchone()
                    metrics.avg_query_time_ms = row[0] if row and row[0] else 0
                    
                    # Cache hit ratio
                    await cursor.execute("""
                        SELECT 
                            (a.cntr_value * 1.0 / b.cntr_value) * 100 AS cache_hit_ratio
                        FROM sys.dm_os_performance_counters a
                        JOIN sys.dm_os_performance_counters b ON a.object_name = b.object_name
                        WHERE a.counter_name = 'Buffer cache hit ratio'
                        AND b.counter_name = 'Buffer cache hit ratio base'
                    """)
                    row = await cursor.fetchone()
                    metrics.cache_hit_ratio = row[0] if row and row[0] else 0
                    
                    # Lock waits
                    await cursor.execute("""
                        SELECT COUNT(*) 
                        FROM sys.dm_tran_locks 
                        WHERE request_status = 'WAIT'
                    """)
                    row = await cursor.fetchone()
                    metrics.lock_waits = row[0] if row else 0
                    
                    # Deadlocks
                    await cursor.execute("""
                        SELECT cntr_value 
                        FROM sys.dm_os_performance_counters 
                        WHERE counter_name = 'Number of Deadlocks/sec'
                    """)
                    row = await cursor.fetchone()
                    metrics.deadlocks = row[0] if row else 0
                    
                    # Transactions per second
                    await cursor.execute("""
                        SELECT cntr_value 
                        FROM sys.dm_os_performance_counters 
                        WHERE counter_name = 'Transactions/sec'
                        AND instance_name = DB_NAME()
                    """)
                    row = await cursor.fetchone()
                    metrics.transactions_per_sec = row[0] if row else 0
                    
                    # Timestamp
                    metrics.timestamp = datetime.utcnow()
                    
        except Exception as e:
            logger.error(f"Failed to get metrics: {e}")
        
        return metrics
    
    async def get_query_plan(self, query: str, params: Optional[Dict[str, Any]] = None) -> QueryPlan:
        """Get execution plan for a query."""
        try:
            async with self._get_connection() as conn:
                async with conn.cursor() as cursor:
                    # Get estimated execution plan
                    plan_query = f"SET SHOWPLAN_XML ON; {query}; SET SHOWPLAN_XML OFF;"
                    await cursor.execute(plan_query)
                    
                    # Fetch the XML plan
                    row = await cursor.fetchone()
                    plan_xml = row[0] if row else ""
                    
                    # Parse plan for key metrics (simplified)
                    estimated_cost = 0.0
                    estimated_rows = 0
                    
                    return QueryPlan(
                        plan_data=plan_xml,
                        estimated_cost=estimated_cost,
                        estimated_rows=estimated_rows,
                    )
                    
        except Exception as e:
            logger.error(f"Failed to get query plan: {e}")
            return QueryPlan(plan_data="", estimated_cost=0, estimated_rows=0)
    
    async def get_index_recommendations(self, table_name: Optional[str] = None) -> List[IndexInfo]:
        """Get index recommendations from missing index DMVs."""
        recommendations = []
        
        try:
            async with self._get_connection() as conn:
                async with conn.cursor() as cursor:
                    query = """
                        SELECT 
                            mig.index_handle,
                            mid.statement AS table_name,
                            mid.equality_columns,
                            mid.inequality_columns,
                            mid.included_columns,
                            migs.user_seeks,
                            migs.user_scans,
                            migs.avg_total_user_cost,
                            migs.avg_user_impact
                        FROM sys.dm_db_missing_index_groups mig
                        INNER JOIN sys.dm_db_missing_index_group_stats migs 
                            ON mig.index_group_handle = migs.group_handle
                        INNER JOIN sys.dm_db_missing_index_details mid 
                            ON mig.index_handle = mid.index_handle
                        WHERE mid.database_id = DB_ID()
                    """
                    
                    if table_name:
                        query += f" AND mid.statement LIKE '%{table_name}%'"
                    
                    query += " ORDER BY migs.avg_user_impact DESC"
                    
                    await cursor.execute(query)
                    columns = [desc[0] for desc in cursor.description]
                    
                    rows = await cursor.fetchall()
                    for row in rows:
                        row_dict = dict(zip(columns, row))
                        
                        # Build index name
                        index_name = f"IX_{row_dict.get('table_name', 'unknown').split('.')[-1]}"
                        if row_dict.get('equality_columns'):
                            index_name += f"_{row_dict['equality_columns'].replace(',', '_').replace(' ', '')}"
                        
                        recommendations.append(IndexInfo(
                            table_name=row_dict.get('table_name', ''),
                            index_name=index_name[:128],
                            columns=row_dict.get('equality_columns', '') or '',
                            index_type="NONCLUSTERED",
                            estimated_improvement=row_dict.get('avg_user_impact', 0),
                            size_mb=0,  # Would need to estimate
                        ))
                        
        except Exception as e:
            logger.error(f"Failed to get index recommendations: {e}")
        
        return recommendations
    
    async def get_table_stats(self, table_name: Optional[str] = None) -> List[TableStats]:
        """Get statistics for tables."""
        stats = []
        
        try:
            async with self._get_connection() as conn:
                async with conn.cursor() as cursor:
                    query = """
                        SELECT 
                            t.NAME AS table_name,
                            p.rows AS row_count,
                            SUM(a.total_pages) * 8 AS total_size_kb,
                            SUM(a.used_pages) * 8 AS used_size_kb,
                            SUM(a.data_pages) * 8 AS data_size_kb,
                            MAX(p.index_id) AS index_count
                        FROM sys.tables t
                        INNER JOIN sys.indexes i ON t.OBJECT_ID = i.object_id
                        INNER JOIN sys.partitions p ON i.object_id = p.OBJECT_ID AND i.index_id = p.index_id
                        INNER JOIN sys.allocation_units a ON p.partition_id = a.container_id
                        WHERE t.is_ms_shipped = 0
                        AND i.OBJECT_ID > 255
                    """
                    
                    if table_name:
                        query += f" AND t.NAME = '{table_name}'"
                    
                    query += """
                        GROUP BY t.NAME, p.rows
                        ORDER BY total_size_kb DESC
                    """
                    
                    await cursor.execute(query)
                    columns = [desc[0] for desc in cursor.description]
                    
                    rows = await cursor.fetchall()
                    for row in rows:
                        row_dict = dict(zip(columns, row))
                        
                        stats.append(TableStats(
                            table_name=row_dict.get('table_name', ''),
                            row_count=row_dict.get('row_count', 0),
                            size_mb=(row_dict.get('total_size_kb', 0) or 0) / 1024,
                            index_count=row_dict.get('index_count', 0) or 0,
                            last_analyzed=datetime.utcnow(),
                        ))
                        
        except Exception as e:
            logger.error(f"Failed to get table stats: {e}")
        
        return stats
    
    async def stream_query(
        self,
        query: str,
        params: Optional[Dict[str, Any]] = None,
        batch_size: int = 1000,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Stream query results in batches."""
        try:
            async with self._get_connection() as conn:
                async with conn.cursor() as cursor:
                    if params:
                        await cursor.execute(query, list(params.values()))
                    else:
                        await cursor.execute(query)
                    
                    columns = [desc[0] for desc in cursor.description] if cursor.description else []
                    
                    while True:
                        rows = await cursor.fetchmany(batch_size)
                        if not rows:
                            break
                        
                        for row in rows:
                            yield dict(zip(columns, row))
                            
        except Exception as e:
            logger.error(f"Streaming query failed: {e}")
            raise
    
    async def test_connection(self) -> Tuple[bool, str]:
        """Test database connectivity."""
        try:
            async with self._get_connection() as conn:
                async with conn.cursor() as cursor:
                    await cursor.execute("SELECT @@VERSION, DB_NAME(), @@SPID")
                    row = await cursor.fetchone()
                    
                    if row:
                        version = row[0][:50] if row[0] else "Unknown"
                        db_name = row[1] or "Unknown"
                        spid = row[2] or 0
                        return True, f"Connected to {db_name} (SPID: {spid}) - {version}"
                    
            return False, "No response from server"
            
        except Exception as e:
            return False, str(e)
    
    async def _log_query(
        self,
        query: str,
        params: Optional[Dict[str, Any]],
        execution_time: float,
        success: bool,
        error: Optional[str] = None,
    ):
        """Log query execution for monitoring."""
        async with self._lock:
            self._query_history.append({
                "timestamp": datetime.utcnow().isoformat(),
                "query": query[:500],
                "params": str(params)[:200] if params else None,
                "execution_time": execution_time,
                "success": success,
                "error": error,
            })
            
            # Trim history
            if len(self._query_history) > self._max_history:
                self._query_history = self._query_history[-self._max_history:]
    
    async def get_slow_queries(self, limit: int = 10, min_duration_ms: float = 1000) -> List[Dict[str, Any]]:
        """Get slow queries from history."""
        slow_queries = [
            q for q in self._query_history
            if q["execution_time"] * 1000 >= min_duration_ms
        ]
        return sorted(slow_queries, key=lambda x: x["execution_time"], reverse=True)[:limit]
    
    async def kill_session(self, session_id: int) -> bool:
        """Kill a database session."""
        try:
            async with self._get_connection() as conn:
                async with conn.cursor() as cursor:
                    await cursor.execute(f"KILL {session_id}")
                    return True
        except Exception as e:
            logger.error(f"Failed to kill session {session_id}: {e}")
            return False
    
    async def get_active_sessions(self) -> List[Dict[str, Any]]:
        """Get active database sessions."""
        sessions = []
        
        try:
            async with self._get_connection() as conn:
                async with conn.cursor() as cursor:
                    await cursor.execute("""
                        SELECT 
                            session_id,
                            login_name,
                            program_name,
                            client_interface_name,
                            status,
                            cpu_time,
                            memory_usage,
                            total_elapsed_time,
                            last_request_start_time,
                            host_name
                        FROM sys.dm_exec_sessions
                        WHERE is_user_process = 1
                        AND database_id = DB_ID()
                        ORDER BY cpu_time DESC
                    """)
                    
                    columns = [desc[0] for desc in cursor.description]
                    rows = await cursor.fetchall()
                    
                    for row in rows:
                        sessions.append(dict(zip(columns, row)))
                        
        except Exception as e:
            logger.error(f"Failed to get active sessions: {e}")
        
        return sessions
