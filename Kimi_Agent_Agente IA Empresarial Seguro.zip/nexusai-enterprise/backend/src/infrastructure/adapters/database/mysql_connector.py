"""
NexusAI Enterprise - MySQL/MariaDB Connector
=============================================
Conector para MySQL y MariaDB con aiomysql.
"""
import asyncio
from typing import Any, Dict, List, Optional, AsyncGenerator
import aiomysql

from .base import IDatabaseConnector, ConnectionConfig, QueryResult, QueryType, DatabaseMetrics


class MySQLConnector(IDatabaseConnector):
    """Conector para MySQL/MariaDB."""
    
    def __init__(self):
        self._pool: Optional[aiomysql.Pool] = None
        self._config: Optional[ConnectionConfig] = None
    
    @property
    def database_type(self) -> str:
        return "mysql"
    
    async def connect(self, config: ConnectionConfig) -> bool:
        """Establece conexión con MySQL."""
        try:
            self._config = config
            
            # SSL config
            ssl_config = None
            if config.ssl_mode != "disable":
                ssl_config = {'ca': config.ssl_root_cert} if config.ssl_root_cert else {}
            
            self._pool = await aiomysql.create_pool(
                host=config.host,
                port=config.port,
                user=config.username,
                password=config.password,
                db=config.database,
                ssl=ssl_config,
                minsize=config.pool_size,
                maxsize=config.pool_size + config.max_overflow,
                connect_timeout=config.connect_timeout,
                autocommit=True
            )
            
            return True
        except Exception as e:
            print(f"Error conectando a MySQL: {e}")
            return False
    
    async def disconnect(self) -> bool:
        """Cierra la conexión."""
        if self._pool:
            self._pool.close()
            await self._pool.wait_closed()
            self._pool = None
        return True
    
    async def is_connected(self) -> bool:
        """Verifica conexión activa."""
        if not self._pool:
            return False
        try:
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute("SELECT 1")
            return True
        except Exception:
            return False
    
    async def execute_query(
        self,
        query: str,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
        read_only: bool = True
    ) -> QueryResult:
        """Ejecuta consulta SQL."""
        if not self._pool:
            return QueryResult(success=False, error_message="No hay conexión")
        
        start_time = asyncio.get_event_loop().time()
        
        try:
            async with self._pool.acquire() as conn:
                async with conn.cursor(aiomysql.DictCursor) as cur:
                    # Establecer timeout
                    if timeout:
                        await cur.execute(f"SET SESSION MAX_EXECUTION_TIME={timeout * 1000}")
                    
                    # Ejecutar
                    if params:
                        await cur.execute(query, tuple(params.values()))
                    else:
                        await cur.execute(query)
                    
                    # Obtener resultados
                    rows = await cur.fetchall()
                    columns = [desc[0] for desc in cur.description] if cur.description else []
                    
                    execution_time = int((asyncio.get_event_loop().time() - start_time) * 1000)
                    
                    return QueryResult(
                        success=True,
                        data=list(rows) if rows else [],
                        columns=columns,
                        row_count=len(rows) if rows else 0,
                        execution_time_ms=execution_time,
                        query_type=QueryType.SELECT
                    )
                    
        except Exception as e:
            return QueryResult(
                success=False,
                error_message=str(e),
                execution_time_ms=int((asyncio.get_event_loop().time() - start_time) * 1000)
            )
    
    async def execute_query_stream(
        self,
        query: str,
        params: Optional[Dict[str, Any]] = None,
        batch_size: int = 100
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Ejecuta consulta en streaming."""
        if not self._pool:
            return
        
        async with self._pool.acquire() as conn:
            async with conn.cursor(aiomysql.DictCursor) as cur:
                if params:
                    await cur.execute(query, tuple(params.values()))
                else:
                    await cur.execute(query)
                
                while True:
                    rows = await cur.fetchmany(batch_size)
                    if not rows:
                        break
                    for row in rows:
                        yield dict(row)
    
    async def get_schema(self, table_name: Optional[str] = None) -> Dict[str, Any]:
        """Obtiene esquema."""
        schema = {"tables": {}}
        
        try:
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cur:
                    if table_name:
                        await cur.execute("""
                            SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT
                            FROM INFORMATION_SCHEMA.COLUMNS
                            WHERE TABLE_NAME = %s AND TABLE_SCHEMA = DATABASE()
                            ORDER BY ORDINAL_POSITION
                        """, (table_name,))
                        rows = await cur.fetchall()
                        schema["tables"][table_name] = [
                            {
                                "name": row[0],
                                "type": row[1],
                                "nullable": row[2] == "YES",
                                "default": row[3]
                            }
                            for row in rows
                        ]
                    else:
                        await cur.execute("""
                            SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES
                            WHERE TABLE_SCHEMA = DATABASE()
                        """)
                        rows = await cur.fetchall()
                        for row in rows:
                            schema["tables"][row[0]] = []
                            
        except Exception as e:
            schema["error"] = str(e)
        
        return schema
    
    async def get_tables(self) -> List[str]:
        """Lista tablas."""
        try:
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute("""
                        SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES
                        WHERE TABLE_SCHEMA = DATABASE()
                        ORDER BY TABLE_NAME
                    """)
                    rows = await cur.fetchall()
                    return [row[0] for row in rows]
        except Exception:
            return []
    
    async def get_metrics(self) -> DatabaseMetrics:
        """Obtiene métricas."""
        metrics = DatabaseMetrics()
        
        try:
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cur:
                    # Conexiones
                    await cur.execute("SHOW STATUS LIKE 'Threads_connected'")
                    row = await cur.fetchone()
                    if row:
                        metrics.connection_count = int(row[1])
                    
                    # Queries activas
                    await cur.execute("SHOW PROCESSLIST")
                    rows = await cur.fetchall()
                    metrics.active_queries = len([r for r in rows if r[4] != 'Sleep'])
                    
                    # Cache hit ratio
                    await cur.execute("SHOW STATUS LIKE 'Qcache_hits'")
                    hits = await cur.fetchone()
                    await cur.execute("SHOW STATUS LIKE 'Qcache_inserts'")
                    inserts = await cur.fetchone()
                    if hits and inserts and int(inserts[1]) > 0:
                        metrics.cache_hit_ratio = int(hits[1]) / (int(hits[1]) + int(inserts[1]))
                        
        except Exception:
            pass
        
        return metrics
    
    async def get_slow_queries(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Obtiene consultas lentas."""
        try:
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute("""
                        SELECT sql_text, count_star, avg_timer_wait/1000000000 as avg_time_ms
                        FROM performance_schema.events_statements_summary_by_digest
                        ORDER BY avg_timer_wait DESC
                        LIMIT %s
                    """, (limit,))
                    rows = await cur.fetchall()
                    return [
                        {
                            "query": row[0][:500] if row[0] else "",
                            "calls": row[1],
                            "avg_time_ms": float(row[2])
                        }
                        for row in rows
                    ]
        except Exception:
            return []
    
    async def get_blocking_queries(self) -> List[Dict[str, Any]]:
        """Obtiene consultas bloqueantes."""
        try:
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute("""
                        SELECT r.trx_id waiting_trx_id, r.trx_mysql_thread_id waiting_thread,
                               b.trx_id blocking_trx_id, b.trx_mysql_thread_id blocking_thread
                        FROM information_schema.innodb_lock_waits w
                        JOIN information_schema.innodb_trx b ON b.trx_id = w.blocking_trx_id
                        JOIN information_schema.innodb_trx r ON r.trx_id = w.requesting_trx_id
                    """)
                    rows = await cur.fetchall()
                    return [
                        {
                            "waiting_thread": row[1],
                            "blocking_thread": row[3]
                        }
                        for row in rows
                    ]
        except Exception:
            return []
    
    async def kill_session(self, session_id: str) -> bool:
        """Mata una sesión."""
        try:
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(f"KILL {session_id}")
            return True
        except Exception:
            return False
    
    async def validate_query(self, query: str) -> tuple[bool, Optional[str]]:
        """Valida consulta."""
        try:
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(f"EXPLAIN {query}")
            return True, None
        except Exception as e:
            return False, str(e)
    
    async def test_connection(self, config: ConnectionConfig) -> tuple[bool, Optional[str]]:
        """Prueba conexión."""
        try:
            connector = MySQLConnector()
            success = await connector.connect(config)
            if success:
                await connector.disconnect()
                return True, None
            return False, "No se pudo conectar"
        except Exception as e:
            return False, str(e)
