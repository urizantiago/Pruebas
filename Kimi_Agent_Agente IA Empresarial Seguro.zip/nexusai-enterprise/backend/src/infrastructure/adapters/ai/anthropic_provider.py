"""
NexusAI Enterprise - Anthropic Provider
Anthropic Claude API provider implementation.
"""
import logging
from dataclasses import dataclass, field
from typing import Any, AsyncGenerator, Dict, List, Optional, Union

from anthropic import AsyncAnthropic

from .base import (
    IAIProvider,
    AIConfig,
    Message,
    MessageRole,
    ChatCompletion,
    EmbeddingResult,
    ModelInfo,
    TokenUsage,
    FunctionDefinition,
)

logger = logging.getLogger(__name__)


@dataclass
class AnthropicConfig:
    """Anthropic specific configuration."""
    
    # API settings
    api_key: str = ""
    api_base: Optional[str] = None
    
    # Model settings
    model: str = "claude-3-opus-20240229"
    
    # Generation parameters
    temperature: float = 0.7
    max_tokens: Optional[int] = 4096
    top_p: float = 1.0
    top_k: Optional[int] = None
    
    # Timeout
    timeout: int = 60
    request_timeout: int = 30
    
    # Retry settings
    max_retries: int = 3
    retry_delay: float = 1.0
    
    # Additional options
    options: Dict[str, Any] = field(default_factory=dict)


class AnthropicProvider(IAIProvider):
    """
    Anthropic Claude API provider implementation.
    
    Supports:
    - Claude 3 models (Opus, Sonnet, Haiku)
    - Vision capabilities
    - Tool use (function calling)
    - Streaming responses
    - Token counting
    """
    
    # Model information
    MODELS = {
        "claude-3-opus-20240229": ModelInfo(
            id="claude-3-opus-20240229",
            name="Claude 3 Opus",
            description="Most powerful Claude model for complex tasks",
            max_tokens=4096,
            context_window=200000,
            supports_functions=True,
            supports_vision=True,
            supports_embeddings=False,
            pricing={"input": 0.015, "output": 0.075},
        ),
        "claude-3-sonnet-20240229": ModelInfo(
            id="claude-3-sonnet-20240229",
            name="Claude 3 Sonnet",
            description="Balanced performance and cost",
            max_tokens=4096,
            context_window=200000,
            supports_functions=True,
            supports_vision=True,
            supports_embeddings=False,
            pricing={"input": 0.003, "output": 0.015},
        ),
        "claude-3-haiku-20240307": ModelInfo(
            id="claude-3-haiku-20240307",
            name="Claude 3 Haiku",
            description="Fastest and most cost-effective model",
            max_tokens=4096,
            context_window=200000,
            supports_functions=True,
            supports_vision=True,
            supports_embeddings=False,
            pricing={"input": 0.00025, "output": 0.00125},
        ),
        "claude-2.1": ModelInfo(
            id="claude-2.1",
            name="Claude 2.1",
            description="Previous generation with 200K context",
            max_tokens=4096,
            context_window=200000,
            supports_functions=False,
            supports_vision=False,
            supports_embeddings=False,
            pricing={"input": 0.008, "output": 0.024},
        ),
        "claude-2.0": ModelInfo(
            id="claude-2.0",
            name="Claude 2.0",
            description="Previous generation with 100K context",
            max_tokens=4096,
            context_window=100000,
            supports_functions=False,
            supports_vision=False,
            supports_embeddings=False,
            pricing={"input": 0.008, "output": 0.024},
        ),
    }
    
    def __init__(self):
        self._client: Optional[AsyncAnthropic] = None
        self._config: Optional[AnthropicConfig] = None
    
    @property
    def provider_name(self) -> str:
        return "anthropic"
    
    async def initialize(self, config: AIConfig) -> bool:
        """Initialize Anthropic client."""
        try:
            # Parse Anthropic config
            anthropic_config = AnthropicConfig(
                api_key=config.api_key,
                api_base=config.api_base,
                model=config.model or "claude-3-opus-20240229",
                temperature=config.temperature,
                max_tokens=config.max_tokens or 4096,
                top_p=config.top_p,
                timeout=config.timeout,
                max_retries=config.max_retries,
                options=config.options or {},
            )
            
            if config.options:
                if "top_k" in config.options:
                    anthropic_config.top_k = config.options["top_k"]
            
            self._config = anthropic_config
            
            # Initialize client
            client_kwargs = {
                "api_key": anthropic_config.api_key,
                "timeout": anthropic_config.timeout,
                "max_retries": anthropic_config.max_retries,
            }
            
            if anthropic_config.api_base:
                client_kwargs["base_url"] = anthropic_config.api_base
            
            self._client = AsyncAnthropic(**client_kwargs)
            
            logger.info(f"Anthropic provider initialized with model: {anthropic_config.model}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize Anthropic provider: {e}")
            raise
    
    def _convert_messages(self, messages: List[Message]) -> tuple:
        """
        Convert internal messages to Anthropic format.
        Returns (system, messages) tuple.
        """
        system = None
        anthropic_messages = []
        
        for msg in messages:
            if msg.role == MessageRole.SYSTEM:
                system = msg.content
            elif msg.role == MessageRole.USER:
                anthropic_messages.append({
                    "role": "user",
                    "content": msg.content,
                })
            elif msg.role == MessageRole.ASSISTANT:
                anthropic_messages.append({
                    "role": "assistant",
                    "content": msg.content,
                })
            elif msg.role == MessageRole.TOOL:
                # Anthropic handles tool results as user messages
                anthropic_messages.append({
                    "role": "user",
                    "content": f"Tool result: {msg.content}",
                })
        
        return system, anthropic_messages
    
    def _convert_tools(self, functions: List[FunctionDefinition]) -> List[Dict[str, Any]]:
        """Convert function definitions to Anthropic tool format."""
        return [
            {
                "name": func.name,
                "description": func.description,
                "input_schema": func.parameters,
            }
            for func in functions
        ]
    
    async def chat_completion(
        self,
        messages: List[Message],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        functions: Optional[List[FunctionDefinition]] = None,
        stream: bool = False,
    ) -> Union[ChatCompletion, AsyncGenerator[ChatCompletion, None]]:
        """Generate chat completion."""
        try:
            model = model or self._config.model
            temperature = temperature if temperature is not None else self._config.temperature
            max_tokens = max_tokens if max_tokens is not None else self._config.max_tokens
            
            # Convert messages
            system, anthropic_messages = self._convert_messages(messages)
            
            # Build request
            request = {
                "model": model,
                "messages": anthropic_messages,
                "temperature": temperature,
                "max_tokens": max_tokens,
                "top_p": self._config.top_p,
                "stream": stream,
            }
            
            if system:
                request["system"] = system
            
            if self._config.top_k:
                request["top_k"] = self._config.top_k
            
            if functions:
                request["tools"] = self._convert_tools(functions)
            
            if stream:
                return self._stream_chat_completion(request)
            
            # Non-streaming request
            response = await self._client.messages.create(**request)
            
            # Extract usage
            usage = TokenUsage(
                prompt_tokens=response.usage.input_tokens if response.usage else 0,
                completion_tokens=response.usage.output_tokens if response.usage else 0,
                total_tokens=(response.usage.input_tokens + response.usage.output_tokens) if response.usage else 0,
            )
            
            # Extract content
            content = ""
            tool_calls = None
            
            for block in response.content:
                if block.type == "text":
                    content += block.text
                elif block.type == "tool_use":
                    if tool_calls is None:
                        tool_calls = []
                    tool_calls.append({
                        "id": block.id,
                        "type": "function",
                        "function": {
                            "name": block.name,
                            "arguments": block.input,
                        }
                    })
            
            message = Message(
                role=MessageRole.ASSISTANT,
                content=content,
                tool_calls=tool_calls,
            )
            
            return ChatCompletion(
                id=response.id,
                model=response.model,
                message=message,
                usage=usage,
                finish_reason=response.stop_reason or "",
                raw_response={
                    "id": response.id,
                    "model": response.model,
                    "stop_reason": response.stop_reason,
                    "usage": response.usage.model_dump() if response.usage else None,
                },
            )
            
        except Exception as e:
            logger.error(f"Anthropic chat completion failed: {e}")
            raise
    
    async def _stream_chat_completion(
        self,
        request: Dict[str, Any],
    ) -> AsyncGenerator[ChatCompletion, None]:
        """Stream chat completion."""
        try:
            stream = await self._client.messages.create(**request)
            
            async for event in stream:
                if event.type == "content_block_delta":
                    delta = event.delta
                    
                    if delta.type == "text_delta":
                        message = Message(
                            role=MessageRole.ASSISTANT,
                            content=delta.text,
                        )
                        
                        yield ChatCompletion(
                            id=event.message.id if hasattr(event, 'message') else "",
                            model=request["model"],
                            message=message,
                            usage=TokenUsage(),
                            finish_reason="",
                            raw_response={"type": event.type},
                        )
                        
        except Exception as e:
            logger.error(f"Anthropic streaming chat completion failed: {e}")
            raise
    
    async def create_embedding(
        self,
        texts: List[str],
        model: Optional[str] = None,
    ) -> List[EmbeddingResult]:
        """Create embeddings for texts."""
        # Anthropic doesn't currently offer embeddings API
        logger.warning("Anthropic does not support embeddings. Use OpenAI or Azure OpenAI instead.")
        return [
            EmbeddingResult(
                embedding=[],
                index=i,
                model="none",
                usage=TokenUsage(),
            )
            for i in range(len(texts))
        ]
    
    async def list_models(self) -> List[ModelInfo]:
        """List available models."""
        return list(self.MODELS.values())
    
    async def get_model_info(self, model_id: str) -> Optional[ModelInfo]:
        """Get information about a specific model."""
        return self.MODELS.get(model_id)
    
    async def count_tokens(self, text: str, model: Optional[str] = None) -> int:
        """Count tokens in text using Anthropic's tokenizer."""
        try:
            # Use Anthropic's token counting if available
            response = await self._client.messages.count_tokens(
                model=model or self._config.model,
                messages=[{"role": "user", "content": text}],
            )
            return response.input_tokens
        except Exception as e:
            logger.warning(f"Anthropic token counting failed: {e}")
            # Fallback: approximate (4 chars per token)
            return len(text) // 4
    
    async def validate_api_key(self) -> bool:
        """Validate API key."""
        try:
            # Try a simple request
            await self._client.messages.create(
                model=self._config.model,
                messages=[{"role": "user", "content": "test"}],
                max_tokens=1,
            )
            return True
        except Exception as e:
            logger.warning(f"API key validation failed: {e}")
            return False
    
    async def health_check(self) -> Dict[str, Any]:
        """Check provider health."""
        try:
            is_valid = await self.validate_api_key()
            
            return {
                "status": "healthy" if is_valid else "unhealthy",
                "provider": self.provider_name,
                "model": self._config.model if self._config else None,
                "api_key_valid": is_valid,
            }
        except Exception as e:
            return {
                "status": "error",
                "provider": self.provider_name,
                "error": str(e),
            }
    
    # Anthropic-specific methods
    
    async def count_message_tokens(
        self,
        messages: List[Message],
        model: Optional[str] = None,
    ) -> int:
        """Count tokens for a list of messages."""
        try:
            system, anthropic_messages = self._convert_messages(messages)
            
            response = await self._client.messages.count_tokens(
                model=model or self._config.model,
                messages=anthropic_messages,
                system=system,
            )
            
            return response.input_tokens
            
        except Exception as e:
            logger.warning(f"Message token counting failed: {e}")
            # Fallback: approximate
            total_text = " ".join([m.content for m in messages])
            return len(total_text) // 4
