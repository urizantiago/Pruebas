"""
NexusAI Enterprise - Azure OpenAI Provider
Azure OpenAI Service provider implementation.
"""
import logging
from dataclasses import dataclass, field
from typing import Any, AsyncGenerator, Dict, List, Optional, Union

import tiktoken
from openai import AsyncAzureOpenAI

from .base import (
    IAIProvider,
    AIConfig,
    Message,
    MessageRole,
    ChatCompletion,
    EmbeddingResult,
    ModelInfo,
    TokenUsage,
    FunctionDefinition,
)
from .openai_provider import OpenAIProvider

logger = logging.getLogger(__name__)


@dataclass
class AzureOpenAIConfig:
    """Azure OpenAI specific configuration."""
    
    # Azure settings
    api_key: str = ""
    endpoint: str = ""  # https://your-resource.openai.azure.com
    api_version: str = "2024-02-01"
    
    # Deployment names
    chat_deployment: str = ""
    embedding_deployment: str = ""
    
    # Model mapping (Azure deployment name -> OpenAI model name)
    model_mapping: Dict[str, str] = field(default_factory=dict)
    
    # Generation parameters
    temperature: float = 0.7
    max_tokens: Optional[int] = None
    top_p: float = 1.0
    frequency_penalty: float = 0.0
    presence_penalty: float = 0.0
    stop_sequences: Optional[List[str]] = None
    
    # Timeout
    timeout: int = 60
    request_timeout: int = 30
    
    # Retry settings
    max_retries: int = 3
    retry_delay: float = 1.0
    
    # Additional options
    options: Dict[str, Any] = field(default_factory=dict)


class AzureOpenAIProvider(IAIProvider):
    """
    Azure OpenAI Service provider implementation.
    
    Features:
    - Azure AD authentication support
    - Private endpoint support
    - Regional deployment
    - Enterprise-grade security
    """
    
    # Default model mapping
    DEFAULT_MODEL_MAPPING = {
        "gpt-4": "gpt-4",
        "gpt-4-turbo": "gpt-4",
        "gpt-35-turbo": "gpt-3.5-turbo",
        "text-embedding-ada-002": "text-embedding-ada-002",
        "text-embedding-3-small": "text-embedding-3-small",
        "text-embedding-3-large": "text-embedding-3-large",
    }
    
    def __init__(self):
        self._client: Optional[AsyncAzureOpenAI] = None
        self._config: Optional[AzureOpenAIConfig] = None
        self._encoding: Optional[tiktoken.Encoding] = None
        self._openai_provider = OpenAIProvider()
    
    @property
    def provider_name(self) -> str:
        return "azure_openai"
    
    async def initialize(self, config: AIConfig) -> bool:
        """Initialize Azure OpenAI client."""
        try:
            # Parse Azure OpenAI config
            azure_config = AzureOpenAIConfig(
                api_key=config.api_key,
                endpoint=config.api_base or "",
                api_version=config.api_version or "2024-02-01",
                chat_deployment=config.model or "",
                embedding_deployment=config.embedding_model or "",
                temperature=config.temperature,
                max_tokens=config.max_tokens,
                top_p=config.top_p,
                frequency_penalty=config.frequency_penalty,
                presence_penalty=config.presence_penalty,
                stop_sequences=config.stop_sequences,
                timeout=config.timeout,
                max_retries=config.max_retries,
                options=config.options or {},
            )
            
            # Parse model mapping from options
            if config.options:
                if "model_mapping" in config.options:
                    azure_config.model_mapping = config.options["model_mapping"]
                else:
                    azure_config.model_mapping = self.DEFAULT_MODEL_MAPPING.copy()
                
                if "chat_deployment" in config.options:
                    azure_config.chat_deployment = config.options["chat_deployment"]
                if "embedding_deployment" in config.options:
                    azure_config.embedding_deployment = config.options["embedding_deployment"]
            
            self._config = azure_config
            
            # Validate endpoint
            if not azure_config.endpoint:
                raise ValueError("Azure OpenAI endpoint is required")
            
            # Initialize client
            self._client = AsyncAzureOpenAI(
                api_key=azure_config.api_key,
                azure_endpoint=azure_config.endpoint,
                api_version=azure_config.api_version,
                timeout=azure_config.timeout,
                max_retries=azure_config.max_retries,
            )
            
            # Initialize tokenizer
            try:
                self._encoding = tiktoken.encoding_for_model("gpt-4")
            except KeyError:
                self._encoding = tiktoken.get_encoding("cl100k_base")
            
            logger.info(f"Azure OpenAI provider initialized: {azure_config.endpoint}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize Azure OpenAI provider: {e}")
            raise
    
    def _get_deployment_name(self, model: str) -> str:
        """Get Azure deployment name for a model."""
        # Check if model is already a deployment name
        if self._config.chat_deployment == model:
            return model
        if self._config.embedding_deployment == model:
            return model
        
        # Map model to deployment
        for deployment, mapped_model in self._config.model_mapping.items():
            if mapped_model == model:
                return deployment
        
        # Return as-is if no mapping found
        return model
    
    def _convert_messages(self, messages: List[Message]) -> List[Dict[str, str]]:
        """Convert internal messages to Azure OpenAI format."""
        openai_messages = []
        
        for msg in messages:
            openai_msg = {
                "role": msg.role.value,
                "content": msg.content,
            }
            
            if msg.name:
                openai_msg["name"] = msg.name
            
            if msg.tool_calls:
                openai_msg["tool_calls"] = msg.tool_calls
            
            if msg.tool_call_id:
                openai_msg["tool_call_id"] = msg.tool_call_id
            
            openai_messages.append(openai_msg)
        
        return openai_messages
    
    def _convert_functions(self, functions: List[FunctionDefinition]) -> List[Dict[str, Any]]:
        """Convert function definitions to Azure OpenAI format."""
        return [
            {
                "type": "function",
                "function": {
                    "name": func.name,
                    "description": func.description,
                    "parameters": func.parameters,
                }
            }
            for func in functions
        ]
    
    async def chat_completion(
        self,
        messages: List[Message],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        functions: Optional[List[FunctionDefinition]] = None,
        stream: bool = False,
    ) -> Union[ChatCompletion, AsyncGenerator[ChatCompletion, None]]:
        """Generate chat completion."""
        try:
            deployment = self._get_deployment_name(model or self._config.chat_deployment)
            temperature = temperature if temperature is not None else self._config.temperature
            max_tokens = max_tokens if max_tokens is not None else self._config.max_tokens
            
            # Build request
            request = {
                "model": deployment,
                "messages": self._convert_messages(messages),
                "temperature": temperature,
                "top_p": self._config.top_p,
                "frequency_penalty": self._config.frequency_penalty,
                "presence_penalty": self._config.presence_penalty,
                "stream": stream,
            }
            
            if max_tokens:
                request["max_tokens"] = max_tokens
            
            if self._config.stop_sequences:
                request["stop"] = self._config.stop_sequences
            
            if functions:
                request["tools"] = self._convert_functions(functions)
                request["tool_choice"] = "auto"
            
            if stream:
                return self._stream_chat_completion(request)
            
            # Non-streaming request
            response = await self._client.chat.completions.create(**request)
            
            # Extract usage
            usage = TokenUsage(
                prompt_tokens=response.usage.prompt_tokens if response.usage else 0,
                completion_tokens=response.usage.completion_tokens if response.usage else 0,
                total_tokens=response.usage.total_tokens if response.usage else 0,
            )
            
            # Extract message
            choice = response.choices[0]
            message = Message(
                role=MessageRole(choice.message.role),
                content=choice.message.content or "",
                tool_calls=[tc.model_dump() for tc in choice.message.tool_calls] if choice.message.tool_calls else None,
            )
            
            return ChatCompletion(
                id=response.id,
                model=response.model,
                message=message,
                usage=usage,
                finish_reason=choice.finish_reason,
                raw_response=response.model_dump(),
            )
            
        except Exception as e:
            logger.error(f"Azure chat completion failed: {e}")
            raise
    
    async def _stream_chat_completion(
        self,
        request: Dict[str, Any],
    ) -> AsyncGenerator[ChatCompletion, None]:
        """Stream chat completion."""
        try:
            stream = await self._client.chat.completions.create(**request)
            
            async for chunk in stream:
                if chunk.choices and chunk.choices[0].delta:
                    delta = chunk.choices[0].delta
                    
                    message = Message(
                        role=MessageRole(delta.role) if delta.role else MessageRole.ASSISTANT,
                        content=delta.content or "",
                    )
                    
                    yield ChatCompletion(
                        id=chunk.id,
                        model=chunk.model,
                        message=message,
                        usage=TokenUsage(),
                        finish_reason=chunk.choices[0].finish_reason or "",
                        raw_response=chunk.model_dump(),
                    )
                    
        except Exception as e:
            logger.error(f"Azure streaming chat completion failed: {e}")
            raise
    
    async def create_embedding(
        self,
        texts: List[str],
        model: Optional[str] = None,
    ) -> List[EmbeddingResult]:
        """Create embeddings for texts."""
        try:
            deployment = self._get_deployment_name(model or self._config.embedding_deployment)
            
            response = await self._client.embeddings.create(
                model=deployment,
                input=texts,
            )
            
            results = []
            for i, item in enumerate(response.data):
                results.append(EmbeddingResult(
                    embedding=item.embedding,
                    index=item.index,
                    model=deployment,
                    usage=TokenUsage(
                        total_tokens=response.usage.total_tokens if response.usage else 0,
                    ) if i == 0 else None,
                ))
            
            return results
            
        except Exception as e:
            logger.error(f"Azure embedding creation failed: {e}")
            raise
    
    async def list_models(self) -> List[ModelInfo]:
        """List available models."""
        # Azure doesn't have a direct model list API
        # Return models based on deployment mapping
        models = []
        for deployment, model_name in self._config.model_mapping.items():
            if model_name in self._openai_provider.MODELS:
                model_info = self._openai_provider.MODELS[model_name]
                models.append(ModelInfo(
                    id=deployment,
                    name=f"{model_info.name} ({deployment})",
                    description=model_info.description,
                    max_tokens=model_info.max_tokens,
                    context_window=model_info.context_window,
                    supports_functions=model_info.supports_functions,
                    supports_vision=model_info.supports_vision,
                    supports_embeddings=model_info.supports_embeddings,
                    pricing=model_info.pricing,
                ))
        
        return models
    
    async def get_model_info(self, model_id: str) -> Optional[ModelInfo]:
        """Get information about a specific model."""
        # Map deployment to model
        model_name = self._config.model_mapping.get(model_id, model_id)
        return self._openai_provider.MODELS.get(model_name)
    
    async def count_tokens(self, text: str, model: Optional[str] = None) -> int:
        """Count tokens in text."""
        try:
            if self._encoding:
                return len(self._encoding.encode(text))
            else:
                # Fallback: approximate (4 chars per token)
                return len(text) // 4
        except Exception as e:
            logger.warning(f"Token counting failed: {e}")
            return len(text) // 4
    
    async def validate_api_key(self) -> bool:
        """Validate API key."""
        try:
            # Try a simple request
            await self._client.chat.completions.create(
                model=self._config.chat_deployment,
                messages=[{"role": "user", "content": "test"}],
                max_tokens=1,
            )
            return True
        except Exception as e:
            logger.warning(f"API key validation failed: {e}")
            return False
    
    async def health_check(self) -> Dict[str, Any]:
        """Check provider health."""
        try:
            is_valid = await self.validate_api_key()
            
            return {
                "status": "healthy" if is_valid else "unhealthy",
                "provider": self.provider_name,
                "endpoint": self._config.endpoint if self._config else None,
                "api_version": self._config.api_version if self._config else None,
                "chat_deployment": self._config.chat_deployment if self._config else None,
                "api_key_valid": is_valid,
            }
        except Exception as e:
            return {
                "status": "error",
                "provider": self.provider_name,
                "error": str(e),
            }
    
    # Azure-specific methods
    
    async def get_deployments(self) -> List[Dict[str, Any]]:
        """Get Azure OpenAI deployments."""
        # This would require Azure Management API
        # For now, return configured deployments
        return [
            {
                "name": self._config.chat_deployment,
                "type": "chat",
                "model": self._config.model_mapping.get(self._config.chat_deployment, "unknown"),
            },
            {
                "name": self._config.embedding_deployment,
                "type": "embedding",
                "model": self._config.model_mapping.get(self._config.embedding_deployment, "unknown"),
            },
        ]
    
    async def get_quota_info(self) -> Dict[str, Any]:
        """Get quota information."""
        # Azure doesn't expose quota via API directly
        # This would require Azure Management API
        return {
            "note": "Quota information requires Azure Management API access",
            "deployments": await self.get_deployments(),
        }
