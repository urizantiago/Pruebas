"""
NexusAI Enterprise - OpenAI Provider
OpenAI API provider implementation.
"""
import logging
from dataclasses import dataclass, field
from typing import Any, AsyncGenerator, Dict, List, Optional, Union

import openai
import tiktoken
from openai import AsyncOpenAI

from .base import (
    IAIProvider,
    AIConfig,
    Message,
    MessageRole,
    ChatCompletion,
    EmbeddingResult,
    ModelInfo,
    TokenUsage,
    FunctionDefinition,
    ToolCall,
)

logger = logging.getLogger(__name__)


@dataclass
class OpenAIConfig:
    """OpenAI specific configuration."""
    
    # API settings
    api_key: str = ""
    api_base: Optional[str] = None
    organization: Optional[str] = None
    
    # Model settings
    model: str = "gpt-4"
    embedding_model: str = "text-embedding-3-small"
    
    # Generation parameters
    temperature: float = 0.7
    max_tokens: Optional[int] = None
    top_p: float = 1.0
    frequency_penalty: float = 0.0
    presence_penalty: float = 0.0
    stop_sequences: Optional[List[str]] = None
    
    # Timeout
    timeout: int = 60
    request_timeout: int = 30
    
    # Retry settings
    max_retries: int = 3
    retry_delay: float = 1.0
    
    # Additional options
    options: Dict[str, Any] = field(default_factory=dict)


class OpenAIProvider(IAIProvider):
    """
    OpenAI API provider implementation.
    
    Supports:
    - Chat completions (GPT-4, GPT-3.5)
    - Embeddings
    - Function calling
    - Streaming responses
    - Token counting
    """
    
    # Model information
    MODELS = {
        "gpt-4": ModelInfo(
            id="gpt-4",
            name="GPT-4",
            description="Most capable GPT-4 model",
            max_tokens=8192,
            context_window=8192,
            supports_functions=True,
            supports_vision=False,
            supports_embeddings=False,
            pricing={"input": 0.03, "output": 0.06},
        ),
        "gpt-4-turbo": ModelInfo(
            id="gpt-4-turbo",
            name="GPT-4 Turbo",
            description="Latest GPT-4 model with improved capabilities",
            max_tokens=4096,
            context_window=128000,
            supports_functions=True,
            supports_vision=True,
            supports_embeddings=False,
            pricing={"input": 0.01, "output": 0.03},
        ),
        "gpt-4o": ModelInfo(
            id="gpt-4o",
            name="GPT-4o",
            description="Most advanced multimodal model",
            max_tokens=4096,
            context_window=128000,
            supports_functions=True,
            supports_vision=True,
            supports_embeddings=False,
            pricing={"input": 0.005, "output": 0.015},
        ),
        "gpt-3.5-turbo": ModelInfo(
            id="gpt-3.5-turbo",
            name="GPT-3.5 Turbo",
            description="Fast and cost-effective model",
            max_tokens=4096,
            context_window=16385,
            supports_functions=True,
            supports_vision=False,
            supports_embeddings=False,
            pricing={"input": 0.0005, "output": 0.0015},
        ),
        "text-embedding-3-small": ModelInfo(
            id="text-embedding-3-small",
            name="Text Embedding 3 Small",
            description="Efficient embedding model",
            max_tokens=8191,
            context_window=8191,
            supports_functions=False,
            supports_vision=False,
            supports_embeddings=True,
            pricing={"input": 0.00002},
        ),
        "text-embedding-3-large": ModelInfo(
            id="text-embedding-3-large",
            name="Text Embedding 3 Large",
            description="Most capable embedding model",
            max_tokens=8191,
            context_window=8191,
            supports_functions=False,
            supports_vision=False,
            supports_embeddings=True,
            pricing={"input": 0.00013},
        ),
    }
    
    def __init__(self):
        self._client: Optional[AsyncOpenAI] = None
        self._config: Optional[OpenAIConfig] = None
        self._encoding: Optional[tiktoken.Encoding] = None
    
    @property
    def provider_name(self) -> str:
        return "openai"
    
    async def initialize(self, config: AIConfig) -> bool:
        """Initialize OpenAI client."""
        try:
            # Parse OpenAI config
            openai_config = OpenAIConfig(
                api_key=config.api_key,
                api_base=config.api_base,
                model=config.model or "gpt-4",
                embedding_model=config.embedding_model or "text-embedding-3-small",
                temperature=config.temperature,
                max_tokens=config.max_tokens,
                top_p=config.top_p,
                frequency_penalty=config.frequency_penalty,
                presence_penalty=config.presence_penalty,
                stop_sequences=config.stop_sequences,
                timeout=config.timeout,
                max_retries=config.max_retries,
                options=config.options or {},
            )
            
            if config.options:
                if "organization" in config.options:
                    openai_config.organization = config.options["organization"]
            
            self._config = openai_config
            
            # Initialize client
            client_kwargs = {
                "api_key": openai_config.api_key,
                "timeout": openai_config.timeout,
                "max_retries": openai_config.max_retries,
            }
            
            if openai_config.api_base:
                client_kwargs["base_url"] = openai_config.api_base
            
            if openai_config.organization:
                client_kwargs["organization"] = openai_config.organization
            
            self._client = AsyncOpenAI(**client_kwargs)
            
            # Initialize tokenizer
            try:
                self._encoding = tiktoken.encoding_for_model(openai_config.model)
            except KeyError:
                self._encoding = tiktoken.get_encoding("cl100k_base")
            
            logger.info(f"OpenAI provider initialized with model: {openai_config.model}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize OpenAI provider: {e}")
            raise
    
    def _convert_messages(self, messages: List[Message]) -> List[Dict[str, str]]:
        """Convert internal messages to OpenAI format."""
        openai_messages = []
        
        for msg in messages:
            openai_msg = {
                "role": msg.role.value,
                "content": msg.content,
            }
            
            if msg.name:
                openai_msg["name"] = msg.name
            
            if msg.tool_calls:
                openai_msg["tool_calls"] = msg.tool_calls
            
            if msg.tool_call_id:
                openai_msg["tool_call_id"] = msg.tool_call_id
            
            openai_messages.append(openai_msg)
        
        return openai_messages
    
    def _convert_functions(self, functions: List[FunctionDefinition]) -> List[Dict[str, Any]]:
        """Convert function definitions to OpenAI format."""
        return [
            {
                "type": "function",
                "function": {
                    "name": func.name,
                    "description": func.description,
                    "parameters": func.parameters,
                }
            }
            for func in functions
        ]
    
    async def chat_completion(
        self,
        messages: List[Message],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        functions: Optional[List[FunctionDefinition]] = None,
        stream: bool = False,
    ) -> Union[ChatCompletion, AsyncGenerator[ChatCompletion, None]]:
        """Generate chat completion."""
        try:
            model = model or self._config.model
            temperature = temperature if temperature is not None else self._config.temperature
            max_tokens = max_tokens if max_tokens is not None else self._config.max_tokens
            
            # Build request
            request = {
                "model": model,
                "messages": self._convert_messages(messages),
                "temperature": temperature,
                "top_p": self._config.top_p,
                "frequency_penalty": self._config.frequency_penalty,
                "presence_penalty": self._config.presence_penalty,
                "stream": stream,
            }
            
            if max_tokens:
                request["max_tokens"] = max_tokens
            
            if self._config.stop_sequences:
                request["stop"] = self._config.stop_sequences
            
            if functions:
                request["tools"] = self._convert_functions(functions)
                request["tool_choice"] = "auto"
            
            if stream:
                return self._stream_chat_completion(request)
            
            # Non-streaming request
            response = await self._client.chat.completions.create(**request)
            
            # Extract usage
            usage = TokenUsage(
                prompt_tokens=response.usage.prompt_tokens if response.usage else 0,
                completion_tokens=response.usage.completion_tokens if response.usage else 0,
                total_tokens=response.usage.total_tokens if response.usage else 0,
            )
            
            # Extract message
            choice = response.choices[0]
            message = Message(
                role=MessageRole(choice.message.role),
                content=choice.message.content or "",
                tool_calls=[tc.model_dump() for tc in choice.message.tool_calls] if choice.message.tool_calls else None,
            )
            
            return ChatCompletion(
                id=response.id,
                model=response.model,
                message=message,
                usage=usage,
                finish_reason=choice.finish_reason,
                raw_response=response.model_dump(),
            )
            
        except Exception as e:
            logger.error(f"Chat completion failed: {e}")
            raise
    
    async def _stream_chat_completion(
        self,
        request: Dict[str, Any],
    ) -> AsyncGenerator[ChatCompletion, None]:
        """Stream chat completion."""
        try:
            stream = await self._client.chat.completions.create(**request)
            
            async for chunk in stream:
                if chunk.choices and chunk.choices[0].delta:
                    delta = chunk.choices[0].delta
                    
                    message = Message(
                        role=MessageRole(delta.role) if delta.role else MessageRole.ASSISTANT,
                        content=delta.content or "",
                    )
                    
                    yield ChatCompletion(
                        id=chunk.id,
                        model=chunk.model,
                        message=message,
                        usage=TokenUsage(),
                        finish_reason=chunk.choices[0].finish_reason or "",
                        raw_response=chunk.model_dump(),
                    )
                    
        except Exception as e:
            logger.error(f"Streaming chat completion failed: {e}")
            raise
    
    async def create_embedding(
        self,
        texts: List[str],
        model: Optional[str] = None,
    ) -> List[EmbeddingResult]:
        """Create embeddings for texts."""
        try:
            model = model or self._config.embedding_model
            
            response = await self._client.embeddings.create(
                model=model,
                input=texts,
            )
            
            results = []
            for i, item in enumerate(response.data):
                results.append(EmbeddingResult(
                    embedding=item.embedding,
                    index=item.index,
                    model=model,
                    usage=TokenUsage(
                        total_tokens=response.usage.total_tokens if response.usage else 0,
                    ) if i == 0 else None,
                ))
            
            return results
            
        except Exception as e:
            logger.error(f"Embedding creation failed: {e}")
            raise
    
    async def list_models(self) -> List[ModelInfo]:
        """List available models."""
        try:
            response = await self._client.models.list()
            
            models = []
            for model_data in response.data:
                model_id = model_data.id
                if model_id in self.MODELS:
                    models.append(self.MODELS[model_id])
            
            return models
            
        except Exception as e:
            logger.error(f"Failed to list models: {e}")
            return list(self.MODELS.values())
    
    async def get_model_info(self, model_id: str) -> Optional[ModelInfo]:
        """Get information about a specific model."""
        return self.MODELS.get(model_id)
    
    async def count_tokens(self, text: str, model: Optional[str] = None) -> int:
        """Count tokens in text."""
        try:
            if self._encoding:
                return len(self._encoding.encode(text))
            else:
                # Fallback: approximate (4 chars per token)
                return len(text) // 4
        except Exception as e:
            logger.warning(f"Token counting failed: {e}")
            return len(text) // 4
    
    async def validate_api_key(self) -> bool:
        """Validate API key."""
        try:
            await self._client.models.list()
            return True
        except Exception:
            return False
    
    async def health_check(self) -> Dict[str, Any]:
        """Check provider health."""
        try:
            is_valid = await self.validate_api_key()
            
            return {
                "status": "healthy" if is_valid else "unhealthy",
                "provider": self.provider_name,
                "model": self._config.model if self._config else None,
                "api_key_valid": is_valid,
            }
        except Exception as e:
            return {
                "status": "error",
                "provider": self.provider_name,
                "error": str(e),
            }
