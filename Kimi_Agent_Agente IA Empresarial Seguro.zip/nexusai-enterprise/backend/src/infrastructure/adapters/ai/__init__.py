"""
NexusAI Enterprise - AI Providers Module
"""
from .base import (
    IAIProvider,
    AIConfig,
    Message,
    ChatCompletion,
    EmbeddingResult,
    ModelInfo,
    TokenUsage,
    FunctionDefinition,
    ToolCall,
)
from .openai_provider import OpenAIProvider, OpenAIConfig
from .azure_openai_provider import AzureOpenAIProvider, AzureOpenAIConfig
from .anthropic_provider import AnthropicProvider, AnthropicConfig

__all__ = [
    # Base
    "IAIProvider",
    "AIConfig",
    "Message",
    "ChatCompletion",
    "EmbeddingResult",
    "ModelInfo",
    "TokenUsage",
    "FunctionDefinition",
    "ToolCall",
    # Providers
    "OpenAIProvider",
    "AzureOpenAIProvider",
    "AnthropicProvider",
    # Configs
    "OpenAIConfig",
    "AzureOpenAIConfig",
    "AnthropicConfig",
]


class AIProviderFactory:
    """Factory for creating AI providers."""
    
    _providers = {
        "openai": OpenAIProvider,
        "azure": AzureOpenAIProvider,
        "azure_openai": AzureOpenAIProvider,
        "anthropic": AnthropicProvider,
    }
    
    @classmethod
    def create(cls, provider_type: str) -> IAIProvider:
        """Create an AI provider by type."""
        provider_type = provider_type.lower()
        
        if provider_type not in cls._providers:
            raise ValueError(f"Unsupported AI provider type: {provider_type}")
        
        return cls._providers[provider_type]()
    
    @classmethod
    def register(cls, provider_type: str, provider_class: type):
        """Register a new provider type."""
        cls._providers[provider_type.lower()] = provider_class
    
    @classmethod
    def supported_types(cls) -> list:
        """Get list of supported AI provider types."""
        return list(cls._providers.keys())
