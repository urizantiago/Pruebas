"""
NexusAI Enterprise - Base AI Provider Interface
Defines the contract for all AI providers.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, AsyncGenerator, Dict, List, Optional, Union


class MessageRole(Enum):
    """Message role enumeration."""
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


@dataclass
class Message:
    """Chat message."""
    role: MessageRole
    content: str
    name: Optional[str] = None
    tool_calls: Optional[List[Dict[str, Any]]] = None
    tool_call_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TokenUsage:
    """Token usage information."""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


@dataclass
class ChatCompletion:
    """Chat completion result."""
    id: str
    model: str
    message: Message
    usage: TokenUsage
    finish_reason: str
    created_at: datetime = field(default_factory=datetime.utcnow)
    raw_response: Optional[Dict[str, Any]] = None


@dataclass
class EmbeddingResult:
    """Embedding result."""
    embedding: List[float]
    index: int = 0
    model: str = ""
    usage: Optional[TokenUsage] = None


@dataclass
class ModelInfo:
    """Model information."""
    id: str
    name: str
    description: str
    max_tokens: int
    context_window: int
    supports_functions: bool = False
    supports_vision: bool = False
    supports_embeddings: bool = False
    pricing: Dict[str, float] = field(default_factory=dict)


@dataclass
class FunctionDefinition:
    """Function definition for function calling."""
    name: str
    description: str
    parameters: Dict[str, Any]


@dataclass
class ToolCall:
    """Tool call result."""
    id: str
    type: str
    function: Dict[str, Any]


@dataclass
class AIConfig:
    """Base AI provider configuration."""
    
    # API settings
    api_key: str = ""
    api_base: Optional[str] = None
    api_version: Optional[str] = None
    
    # Model settings
    model: str = ""
    embedding_model: Optional[str] = None
    
    # Generation parameters
    temperature: float = 0.7
    max_tokens: Optional[int] = None
    top_p: float = 1.0
    frequency_penalty: float = 0.0
    presence_penalty: float = 0.0
    stop_sequences: Optional[List[str]] = None
    
    # Timeout
    timeout: int = 60
    request_timeout: int = 30
    
    # Retry settings
    max_retries: int = 3
    retry_delay: float = 1.0
    
    # Streaming
    streaming: bool = False
    
    # Additional options
    options: Dict[str, Any] = field(default_factory=dict)


class IAIProvider(ABC):
    """
    Abstract base class for AI providers.
    
    All AI providers must implement this interface to ensure
    consistent behavior across different providers (OpenAI, Anthropic, etc.).
    """
    
    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Return the provider name."""
        pass
    
    @abstractmethod
    async def initialize(self, config: AIConfig) -> bool:
        """Initialize the provider with configuration."""
        pass
    
    @abstractmethod
    async def chat_completion(
        self,
        messages: List[Message],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        functions: Optional[List[FunctionDefinition]] = None,
        stream: bool = False,
    ) -> Union[ChatCompletion, AsyncGenerator[ChatCompletion, None]]:
        """Generate chat completion."""
        pass
    
    @abstractmethod
    async def create_embedding(
        self,
        texts: List[str],
        model: Optional[str] = None,
    ) -> List[EmbeddingResult]:
        """Create embeddings for texts."""
        pass
    
    @abstractmethod
    async def list_models(self) -> List[ModelInfo]:
        """List available models."""
        pass
    
    @abstractmethod
    async def get_model_info(self, model_id: str) -> Optional[ModelInfo]:
        """Get information about a specific model."""
        pass
    
    @abstractmethod
    async def count_tokens(self, text: str, model: Optional[str] = None) -> int:
        """Count tokens in text."""
        pass
    
    @abstractmethod
    async def validate_api_key(self) -> bool:
        """Validate API key."""
        pass
    
    @abstractmethod
    async def health_check(self) -> Dict[str, Any]:
        """Check provider health."""
        pass
