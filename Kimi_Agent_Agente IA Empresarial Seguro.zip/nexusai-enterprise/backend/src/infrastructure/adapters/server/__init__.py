"""
NexusAI Enterprise - Server Connectors Module
"""
from .base import IServerConnector, ServerConfig, CommandResult, ServerMetrics
from .ssh_connector import SSHConnector, SSHConfig
from .winrm_connector import WinRMConnector, WinRMConfig

__all__ = [
    # Base
    "IServerConnector",
    "ServerConfig",
    "CommandResult",
    "ServerMetrics",
    # Connectors
    "SSHConnector",
    "WinRMConnector",
    # Configs
    "SSHConfig",
    "WinRMConfig",
]


class ServerConnectorFactory:
    """Factory for creating server connectors."""
    
    _connectors = {
        "ssh": SSHConnector,
        "linux": SSHConnector,
        "unix": SSHConnector,
        "winrm": WinRMConnector,
        "windows": WinRMConnector,
    }
    
    @classmethod
    def create(cls, server_type: str) -> IServerConnector:
        """Create a server connector by type."""
        server_type = server_type.lower()
        
        if server_type not in cls._connectors:
            raise ValueError(f"Unsupported server type: {server_type}")
        
        return cls._connectors[server_type]()
    
    @classmethod
    def register(cls, server_type: str, connector_class: type):
        """Register a new connector type."""
        cls._connectors[server_type.lower()] = connector_class
    
    @classmethod
    def supported_types(cls) -> list:
        """Get list of supported server types."""
        return list(cls._connectors.keys())
