"""
NexusAI Enterprise - WinRM Connector
Enterprise-grade WinRM connector for Windows servers.
"""
import asyncio
import base64
import logging
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import winrm
from winrm.protocol import Protocol

from .base import (
    IServerConnector,
    ServerConfig,
    CommandResult,
    ServerMetrics,
    FileInfo,
    ProcessInfo,
    ConnectionHealth,
)

logger = logging.getLogger(__name__)


@dataclass
class WinRMConfig:
    """WinRM specific configuration."""
    
    # Host settings
    host: str
    port: int = 5985  # HTTP default, 5986 for HTTPS
    
    # Authentication
    username: str = ""
    password: Optional[str] = None
    
    # SSL/TLS
    use_https: bool = False
    server_cert_validation: bool = True
    ca_trust_path: Optional[str] = None
    
    # WinRM settings
    transport: str = "ntlm"  # ntlm, kerberos, basic, certificate
    read_timeout_sec: int = 30
    operation_timeout_sec: int = 20
    max_envelope_size: int = 153600
    
    # Connection pooling
    connection_timeout: int = 10
    
    # Kerberos settings
    realm: Optional[str] = None
    service_name: str = "HTTP"
    
    # Certificate authentication
    cert_pem: Optional[str] = None
    cert_key_pem: Optional[str] = None
    
    # Additional options
    options: Dict[str, Any] = field(default_factory=dict)


class WinRMConnector(IServerConnector):
    """
    Enterprise WinRM connector for Windows servers.
    
    Features:
    - Multiple authentication methods (NTLM, Kerberos, Basic, Certificate)
    - HTTP and HTTPS transport
    - PowerShell execution
    - File operations via PowerShell
    - WMI queries
    - Service management
    - Event log access
    - Registry operations
    """
    
    def __init__(self):
        self._session: Optional[winrm.Session] = None
        self._protocol: Optional[Protocol] = None
        self._config: Optional[WinRMConfig] = None
        self._health = ConnectionHealth()
        self._command_history: List[Dict[str, Any]] = []
        self._max_history = 1000
        self._lock = asyncio.Lock()
        self._loop: Optional[asyncio.AbstractEventLoop] = None
    
    @property
    def server_type(self) -> str:
        return "winrm"
    
    async def connect(self, config: ServerConfig) -> bool:
        """Establish WinRM connection."""
        try:
            self._loop = asyncio.get_event_loop()
            
            # Parse WinRM config
            winrm_config = WinRMConfig(
                host=config.host,
                port=config.port,
                username=config.username,
                password=config.password,
                connection_timeout=config.connection_timeout,
                options=config.options or {},
            )
            
            # Determine HTTPS from port
            if config.port == 5986:
                winrm_config.use_https = True
            
            # Handle SSL options
            if config.options:
                if "use_https" in config.options:
                    winrm_config.use_https = config.options["use_https"]
                if "transport" in config.options:
                    winrm_config.transport = config.options["transport"]
                if "server_cert_validation" in config.options:
                    winrm_config.server_cert_validation = config.options["server_cert_validation"]
            
            self._config = winrm_config
            
            # Build endpoint URL
            protocol = "https" if winrm_config.use_https else "http"
            endpoint = f"{protocol}://{winrm_config.host}:{winrm_config.port}/wsman"
            
            # Create session
            def create_session():
                return winrm.Session(
                    target=winrm_config.host,
                    auth=(winrm_config.username, winrm_config.password),
                    transport=winrm_config.transport,
                    server_cert_validation=winrm_config.server_cert_validation
                    if winrm_config.use_https else "ignore",
                    read_timeout_sec=winrm_config.read_timeout_sec,
                    operation_timeout_sec=winrm_config.operation_timeout_sec,
                )
            
            self._session = await self._loop.run_in_executor(None, create_session)
            
            # Test connection
            result = await self.execute_command("whoami")
            
            if result.success:
                self._health.status = "healthy"
                self._health.last_check = datetime.utcnow()
                logger.info(f"WinRM connected to {winrm_config.host}:{winrm_config.port}")
                return True
            else:
                raise ConnectionError(f"WinRM test command failed: {result.stderr}")
                
        except Exception as e:
            self._health.status = "error"
            self._health.last_error = str(e)
            logger.error(f"WinRM connection failed: {e}")
            raise ConnectionError(f"WinRM connection failed: {e}")
    
    async def disconnect(self) -> bool:
        """Close WinRM connection."""
        try:
            self._session = None
            self._health.status = "disconnected"
            logger.info("WinRM connection closed")
            return True
            
        except Exception as e:
            logger.error(f"Error disconnecting WinRM: {e}")
            return False
    
    async def is_connected(self) -> bool:
        """Check if WinRM connection is active."""
        if not self._session:
            return False
        
        try:
            result = await self.execute_command("echo test", timeout=5)
            return result.success
        except Exception:
            return False
    
    async def execute_command(
        self,
        command: str,
        timeout: Optional[int] = None,
        sudo: bool = False,
        env: Optional[Dict[str, str]] = None,
    ) -> CommandResult:
        """Execute a command via WinRM."""
        start_time = datetime.utcnow()
        
        try:
            # Set environment variables if provided
            if env:
                env_prefix = "; ".join([f"$env:{k} = '{v}'" for k, v in env.items()])
                command = f"{env_prefix}; {command}"
            
            def run_cmd():
                result = self._session.run_cmd(command)
                return result.status_code, result.std_out.decode("utf-8", errors="replace"), result.std_err.decode("utf-8", errors="replace")
            
            exit_code, stdout, stderr = await self._loop.run_in_executor(None, run_cmd)
            
            execution_time = (datetime.utcnow() - start_time).total_seconds()
            
            cmd_result = CommandResult(
                command=command,
                stdout=stdout,
                stderr=stderr,
                exit_code=exit_code,
                execution_time=execution_time,
            )
            
            # Log command
            await self._log_command(command, execution_time, cmd_result.success)
            
            return cmd_result
            
        except Exception as e:
            execution_time = (datetime.utcnow() - start_time).total_seconds()
            await self._log_command(command, execution_time, False, str(e))
            raise
    
    async def execute_powershell(
        self,
        script: str,
        timeout: Optional[int] = None,
        args: Optional[List[str]] = None,
    ) -> CommandResult:
        """Execute PowerShell script via WinRM."""
        start_time = datetime.utcnow()
        
        try:
            # Build argument string
            arg_string = ""
            if args:
                arg_string = " " + " ".join([f"'{arg}'" for arg in args])
            
            def run_ps():
                result = self._session.run_ps(script + arg_string)
                return result.status_code, result.std_out.decode("utf-8", errors="replace"), result.std_err.decode("utf-8", errors="replace")
            
            exit_code, stdout, stderr = await self._loop.run_in_executor(None, run_ps)
            
            execution_time = (datetime.utcnow() - start_time).total_seconds()
            
            return CommandResult(
                command=f"powershell -Command {script[:50]}...",
                stdout=stdout,
                stderr=stderr,
                exit_code=exit_code,
                execution_time=execution_time,
            )
            
        except Exception as e:
            logger.error(f"PowerShell execution failed: {e}")
            raise
    
    async def execute_script(
        self,
        script: str,
        interpreter: str = "powershell",
        timeout: Optional[int] = None,
    ) -> CommandResult:
        """Execute a script on the server."""
        if interpreter.lower() in ("powershell", "ps", "ps1"):
            return await self.execute_powershell(script, timeout)
        else:
            # For batch files
            return await self.execute_command(f"cmd /c {script}", timeout)
    
    async def upload_file(
        self,
        local_path: str,
        remote_path: str,
        permissions: Optional[str] = None,
    ) -> bool:
        """Upload a file via WinRM (using PowerShell)."""
        try:
            # Read local file
            def read_file():
                with open(local_path, "rb") as f:
                    return f.read()
            
            content = await self._loop.run_in_executor(None, read_file)
            content_b64 = base64.b64encode(content).decode("utf-8")
            
            # Upload via PowerShell
            ps_script = f"""
            $content = [Convert]::FromBase64String('{content_b64}')
            [IO.File]::WriteAllBytes('{remote_path}', $content)
            """
            
            result = await self.execute_powershell(ps_script)
            return result.success
            
        except Exception as e:
            logger.error(f"File upload failed: {e}")
            return False
    
    async def download_file(
        self,
        remote_path: str,
        local_path: str,
    ) -> bool:
        """Download a file via WinRM (using PowerShell)."""
        try:
            # Download via PowerShell
            ps_script = f"""
            $content = [IO.File]::ReadAllBytes('{remote_path}')
            [Convert]::ToBase64String($content)
            """
            
            result = await self.execute_powershell(ps_script)
            
            if result.success:
                content = base64.b64decode(result.stdout.strip())
                
                def write_file():
                    with open(local_path, "wb") as f:
                        f.write(content)
                
                await self._loop.run_in_executor(None, write_file)
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"File download failed: {e}")
            return False
    
    async def list_directory(
        self,
        path: str = ".",
        pattern: Optional[str] = None,
    ) -> List[FileInfo]:
        """List directory contents via PowerShell."""
        files = []
        
        try:
            filter_pattern = f" -Filter '{pattern}'" if pattern else ""
            
            ps_script = f"""
            Get-ChildItem -Path '{path}'{filter_pattern} | Select-Object Name, FullName, Length, 
                Mode, LastWriteTime, CreationTime, @{Name='IsDirectory';Expression={{$_.PSIsContainer}}} |
                ConvertTo-Json
            """
            
            result = await self.execute_powershell(ps_script)
            
            if result.success:
                import json
                data = json.loads(result.stdout)
                
                # Handle single item case
                if isinstance(data, dict):
                    data = [data]
                
                for item in data:
                    files.append(FileInfo(
                        path=item.get("FullName", ""),
                        name=item.get("Name", ""),
                        size=item.get("Length", 0),
                        is_directory=item.get("IsDirectory", False),
                        is_file=not item.get("IsDirectory", False),
                        permissions=item.get("Mode", ""),
                        modified_time=datetime.fromisoformat(item.get("LastWriteTime", "").replace("Z", "+00:00")) if item.get("LastWriteTime") else None,
                        created_time=datetime.fromisoformat(item.get("CreationTime", "").replace("Z", "+00:00")) if item.get("CreationTime") else None,
                    ))
                    
        except Exception as e:
            logger.error(f"Directory listing failed: {e}")
        
        return files
    
    async def file_exists(self, path: str) -> bool:
        """Check if file exists."""
        ps_script = f"Test-Path -Path '{path}'"
        result = await self.execute_powershell(ps_script)
        return result.success and "True" in result.stdout
    
    async def read_file(
        self,
        path: str,
        offset: int = 0,
        limit: Optional[int] = None,
    ) -> str:
        """Read file contents via PowerShell."""
        try:
            if limit:
                ps_script = f""
                # Read specific range
                ps_script = f"""
                $content = Get-Content -Path '{path}' -Raw
                $content.Substring({offset}, [Math]::Min({limit}, $content.Length - {offset}))
                """
            else:
                ps_script = f"Get-Content -Path '{path}' -Raw"
            
            result = await self.execute_powershell(ps_script)
            
            if result.success:
                return result.stdout
            else:
                raise FileNotFoundError(f"Could not read file: {result.stderr}")
                
        except Exception as e:
            logger.error(f"File read failed: {e}")
            raise
    
    async def write_file(
        self,
        path: str,
        content: str,
        append: bool = False,
    ) -> bool:
        """Write content to file via PowerShell."""
        try:
            # Escape content for PowerShell
            escaped_content = content.replace("'", "''")
            
            if append:
                ps_script = f"Add-Content -Path '{path}' -Value '{escaped_content}'"
            else:
                ps_script = f"Set-Content -Path '{path}' -Value '{escaped_content}'"
            
            result = await self.execute_powershell(ps_script)
            return result.success
            
        except Exception as e:
            logger.error(f"File write failed: {e}")
            return False
    
    async def delete_file(self, path: str) -> bool:
        """Delete a file via PowerShell."""
        ps_script = f"Remove-Item -Path '{path}' -Force"
        result = await self.execute_powershell(ps_script)
        return result.success
    
    async def create_directory(
        self,
        path: str,
        parents: bool = True,
    ) -> bool:
        """Create a directory via PowerShell."""
        try:
            ps_script = f"New-Item -ItemType Directory -Path '{path}' -Force"
            result = await self.execute_powershell(ps_script)
            return result.success
            
        except Exception as e:
            logger.error(f"Directory creation failed: {e}")
            return False
    
    async def delete_directory(
        self,
        path: str,
        recursive: bool = False,
    ) -> bool:
        """Delete a directory via PowerShell."""
        try:
            recurse_flag = " -Recurse" if recursive else ""
            ps_script = f"Remove-Item -Path '{path}' -Force{recurse_flag}"
            result = await self.execute_powershell(ps_script)
            return result.success
            
        except Exception as e:
            logger.error(f"Directory deletion failed: {e}")
            return False
    
    async def get_metrics(self) -> ServerMetrics:
        """Get Windows server performance metrics via PowerShell."""
        metrics = ServerMetrics()
        
        try:
            # CPU info
            ps_script = """
            $cpu = Get-CimInstance Win32_Processor
            $cpuLoad = Get-Counter '\Processor(_Total)\% Processor Time'
            @{
                Count = ($cpu | Measure-Object).Count
                LoadPercent = [math]::Round($cpuLoad.CounterSamples[0].CookedValue, 2)
            } | ConvertTo-Json
            """
            
            result = await self.execute_powershell(ps_script)
            if result.success:
                import json
                cpu_data = json.loads(result.stdout)
                metrics.cpu_count = cpu_data.get("Count", 0)
                metrics.cpu_percent = cpu_data.get("LoadPercent", 0)
            
            # Memory info
            ps_script = """
            $mem = Get-CimInstance Win32_OperatingSystem
            @{
                Total = $mem.TotalVisibleMemorySize * 1KB
                Free = $mem.FreePhysicalMemory * 1KB
                Used = ($mem.TotalVisibleMemorySize - $mem.FreePhysicalMemory) * 1KB
                PercentUsed = [math]::Round((($mem.TotalVisibleMemorySize - $mem.FreePhysicalMemory) / $mem.TotalVisibleMemorySize) * 100, 2)
            } | ConvertTo-Json
            """
            
            result = await self.execute_powershell(ps_script)
            if result.success:
                import json
                mem_data = json.loads(result.stdout)
                metrics.memory_total = mem_data.get("Total", 0)
                metrics.memory_available = mem_data.get("Free", 0)
                metrics.memory_used = mem_data.get("Used", 0)
                metrics.memory_percent = mem_data.get("PercentUsed", 0)
            
            # Disk info
            ps_script = """
            Get-CimInstance Win32_LogicalDisk | Where-Object { $_.DriveType -eq 3 } | 
                Select-Object DeviceID, Size, FreeSpace, @{Name='Used';Expression={$_.Size - $_.FreeSpace}},
                @{Name='PercentUsed';Expression={[math]::Round((($_.Size - $_.FreeSpace) / $_.Size) * 100, 2)}} |
                ConvertTo-Json
            """
            
            result = await self.execute_powershell(ps_script)
            if result.success:
                import json
                disk_data = json.loads(result.stdout)
                if isinstance(disk_data, dict):
                    disk_data = [disk_data]
                
                if disk_data:
                    first_disk = disk_data[0]
                    metrics.disk_total = first_disk.get("Size", 0)
                    metrics.disk_free = first_disk.get("FreeSpace", 0)
                    metrics.disk_used = first_disk.get("Used", 0)
                    metrics.disk_percent = first_disk.get("PercentUsed", 0)
                
                for disk in disk_data:
                    metrics.disk_partitions.append({
                        "drive": disk.get("DeviceID", ""),
                        "total": disk.get("Size", 0),
                        "used": disk.get("Used", 0),
                        "free": disk.get("FreeSpace", 0),
                        "percent": disk.get("PercentUsed", 0),
                    })
            
            # Process count
            ps_script = "(Get-Process).Count"
            result = await self.execute_powershell(ps_script)
            if result.success:
                metrics.process_count = int(result.stdout.strip())
            
            # Uptime
            ps_script = """
            $uptime = (Get-Date) - (Get-CimInstance Win32_OperatingSystem).LastBootUpTime
            $uptime.TotalSeconds
            """
            
            result = await self.execute_powershell(ps_script)
            if result.success:
                metrics.uptime_seconds = int(float(result.stdout.strip()))
            
        except Exception as e:
            logger.error(f"Failed to get metrics: {e}")
        
        return metrics
    
    async def get_processes(
        self,
        pattern: Optional[str] = None,
    ) -> List[ProcessInfo]:
        """Get running processes via PowerShell."""
        processes = []
        
        try:
            filter_cmd = f" | Where-Object {{ $_.Name -like '*{pattern}*' }}" if pattern else ""
            
            ps_script = f"""
            Get-Process{filter_cmd} | Select-Object Id, ProcessName, UserProcessorTime, 
                WorkingSet, VirtualMemorySize, @{Name='CPU';Expression={{[math]::Round($_.CPU, 2)}}} |
                ConvertTo-Json
            """
            
            result = await self.execute_powershell(ps_script)
            
            if result.success:
                import json
                data = json.loads(result.stdout)
                
                if isinstance(data, dict):
                    data = [data]
                
                for item in data:
                    processes.append(ProcessInfo(
                        pid=item.get("Id", 0),
                        name=item.get("ProcessName", ""),
                        user="",  # Would need additional query
                        cpu_percent=item.get("CPU", 0),
                        memory_percent=0,  # Would need calculation
                        memory_rss=item.get("WorkingSet", 0),
                        memory_vms=item.get("VirtualMemorySize", 0),
                        status="running",
                        created_time=datetime.utcnow(),
                    ))
                    
        except Exception as e:
            logger.error(f"Failed to get processes: {e}")
        
        return processes
    
    async def kill_process(
        self,
        pid: int,
        signal: int = 15,
    ) -> bool:
        """Kill a process via PowerShell."""
        ps_script = f"Stop-Process -Id {pid} -Force"
        result = await self.execute_powershell(ps_script)
        return result.success
    
    async def tail_log(
        self,
        path: str,
        lines: int = 100,
        follow: bool = False,
    ) -> str:
        """Tail a log file via PowerShell."""
        try:
            ps_script = f"Get-Content -Path '{path}' -Tail {lines}"
            result = await self.execute_powershell(ps_script)
            return result.stdout if result.success else ""
            
        except Exception as e:
            logger.error(f"Tail log failed: {e}")
            return ""
    
    async def find_files(
        self,
        path: str = ".",
        name: Optional[str] = None,
        pattern: Optional[str] = None,
        modified_within: Optional[int] = None,
    ) -> List[str]:
        """Find files via PowerShell."""
        files = []
        
        try:
            filter_name = f" -Filter '{name}'" if name else ""
            
            ps_script = f"""
            Get-ChildItem -Path '{path}' -Recurse{filter_name} | Select-Object -ExpandProperty FullName
            """
            
            result = await self.execute_powershell(ps_script)
            
            if result.success:
                files = [f.strip() for f in result.stdout.strip().split("\n") if f.strip()]
                
                if pattern:
                    import re
                    files = [f for f in files if re.search(pattern, f)]
                    
        except Exception as e:
            logger.error(f"Find files failed: {e}")
        
        return files
    
    async def get_disk_usage(self, path: str = "C:") -> Dict[str, Any]:
        """Get disk usage for a drive."""
        ps_script = f"""
        $disk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='{path[:1].upper()}:'"
        @{{
            Drive = $disk.DeviceID
            Total = $disk.Size
            Used = $disk.Size - $disk.FreeSpace
            Free = $disk.FreeSpace
            Percent = [math]::Round((($disk.Size - $disk.FreeSpace) / $disk.Size) * 100, 2)
        }} | ConvertTo-Json
        """
        
        result = await self.execute_powershell(ps_script)
        
        if result.success:
            import json
            return json.loads(result.stdout)
        
        return {}
    
    async def get_health(self) -> ConnectionHealth:
        """Get connection health status."""
        if self._session:
            is_alive = await self.is_connected()
            self._health.status = "healthy" if is_alive else "unhealthy"
            self._health.last_check = datetime.utcnow()
        
        return self._health
    
    async def test_connection(self) -> Tuple[bool, str]:
        """Test WinRM connection."""
        try:
            ps_script = """
            $os = Get-CimInstance Win32_OperatingSystem
            $computer = Get-CimInstance Win32_ComputerSystem
            "Connected as $($computer.Name) - $($os.Caption) $($os.Version)"
            """
            
            result = await self.execute_powershell(ps_script)
            
            if result.success:
                return True, result.stdout.strip()
            else:
                return False, result.stderr
                
        except Exception as e:
            return False, str(e)
    
    async def _log_command(
        self,
        command: str,
        execution_time: float,
        success: bool,
        error: Optional[str] = None,
    ):
        """Log command execution for monitoring."""
        async with self._lock:
            self._command_history.append({
                "timestamp": datetime.utcnow().isoformat(),
                "command": command[:200],
                "execution_time": execution_time,
                "success": success,
                "error": error,
            })
            
            if len(self._command_history) > self._max_history:
                self._command_history = self._command_history[-self._max_history:]
    
    async def get_command_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get command execution history."""
        return self._command_history[-limit:]
    
    # Windows-specific methods
    
    async def get_services(self, pattern: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get Windows services."""
        services = []
        
        try:
            filter_cmd = f" | Where-Object {{ $_.Name -like '*{pattern}*' }}" if pattern else ""
            
            ps_script = f"""
            Get-Service{filter_cmd} | Select-Object Name, DisplayName, Status, StartType | ConvertTo-Json
            """
            
            result = await self.execute_powershell(ps_script)
            
            if result.success:
                import json
                data = json.loads(result.stdout)
                
                if isinstance(data, dict):
                    data = [data]
                
                services = data
                    
        except Exception as e:
            logger.error(f"Failed to get services: {e}")
        
        return services
    
    async def manage_service(
        self,
        service_name: str,
        action: str,  # start, stop, restart, status
    ) -> bool:
        """Manage a Windows service."""
        try:
            if action == "start":
                ps_script = f"Start-Service -Name '{service_name}'"
            elif action == "stop":
                ps_script = f"Stop-Service -Name '{service_name}'"
            elif action == "restart":
                ps_script = f"Restart-Service -Name '{service_name}'"
            elif action == "status":
                ps_script = f"Get-Service -Name '{service_name}' | Select-Object Status | ConvertTo-Json"
            else:
                return False
            
            result = await self.execute_powershell(ps_script)
            return result.success
            
        except Exception as e:
            logger.error(f"Service management failed: {e}")
            return False
    
    async def get_event_logs(
        self,
        log_name: str = "System",
        level: Optional[str] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """Get Windows event logs."""
        logs = []
        
        try:
            level_filter = f" -Level {level}" if level else ""
            
            ps_script = f"""
            Get-WinEvent -LogName '{log_name}'{level_filter} -MaxEvents {limit} |
                Select-Object TimeCreated, Id, LevelDisplayName, Message | ConvertTo-Json
            """
            
            result = await self.execute_powershell(ps_script)
            
            if result.success:
                import json
                data = json.loads(result.stdout)
                
                if isinstance(data, dict):
                    data = [data]
                
                logs = data
                    
        except Exception as e:
            logger.error(f"Failed to get event logs: {e}")
        
        return logs
    
    async def analyze_logs(
        self,
        log_name: str = "System",
        pattern: str = "",
        hours: int = 24,
    ) -> List[Dict[str, Any]]:
        """Analyze Windows event logs."""
        matches = []
        
        try:
            ps_script = f"""
            $startTime = (Get-Date).AddHours(-{hours})
            Get-WinEvent -LogName '{log_name}' | 
                Where-Object {{ $_.TimeCreated -gt $startTime -and $_.Message -like '*{pattern}*' }} |
                Select-Object TimeCreated, Id, LevelDisplayName, Message | ConvertTo-Json
            """
            
            result = await self.execute_powershell(ps_script)
            
            if result.success:
                import json
                data = json.loads(result.stdout)
                
                if isinstance(data, dict):
                    data = [data]
                
                matches = data
                    
        except Exception as e:
            logger.error(f"Log analysis failed: {e}")
        
        return matches
