"""
NexusAI Enterprise - Base Server Connector Interface
Defines the contract for all server connectors.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple


class ConnectionStatus(Enum):
    """Connection status enumeration."""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    ERROR = "error"


@dataclass
class ServerConfig:
    """Base server connection configuration."""
    
    # Host settings
    host: str
    port: int = 22
    
    # Authentication
    username: str = ""
    password: Optional[str] = None
    private_key: Optional[str] = None
    private_key_path: Optional[str] = None
    passphrase: Optional[str] = None
    
    # Connection settings
    timeout: int = 30
    connection_timeout: int = 10
    keepalive_interval: int = 30
    
    # Security
    verify_host_key: bool = True
    known_hosts_path: Optional[str] = None
    
    # Proxy/Jump host
    proxy_host: Optional[str] = None
    proxy_port: int = 22
    proxy_username: Optional[str] = None
    proxy_password: Optional[str] = None
    proxy_private_key: Optional[str] = None
    
    # Additional options
    options: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CommandResult:
    """Result of a command execution."""
    
    command: str
    stdout: str
    stderr: str
    exit_code: int
    execution_time: float
    timestamp: datetime = field(default_factory=datetime.utcnow)
    
    @property
    def success(self) -> bool:
        return self.exit_code == 0
    
    @property
    def output(self) -> str:
        return self.stdout if self.success else self.stderr


@dataclass
class FileInfo:
    """File information."""
    
    path: str
    name: str
    size: int
    is_directory: bool
    is_file: bool
    is_symlink: bool = False
    permissions: str = ""
    owner: str = ""
    group: str = ""
    modified_time: Optional[datetime] = None
    created_time: Optional[datetime] = None


@dataclass
class ProcessInfo:
    """Process information."""
    
    pid: int
    name: str
    user: str
    cpu_percent: float
    memory_percent: float
    memory_rss: int
    memory_vms: int
    status: str
    created_time: datetime
    cmdline: str = ""
    parent_pid: Optional[int] = None
    threads: int = 0


@dataclass
class ServerMetrics:
    """Server performance metrics."""
    
    # CPU
    cpu_count: int = 0
    cpu_percent: float = 0.0
    cpu_per_core: List[float] = field(default_factory=list)
    load_average: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    
    # Memory
    memory_total: int = 0
    memory_available: int = 0
    memory_percent: float = 0.0
    memory_used: int = 0
    swap_total: int = 0
    swap_used: int = 0
    swap_percent: float = 0.0
    
    # Disk
    disk_total: int = 0
    disk_used: int = 0
    disk_free: int = 0
    disk_percent: float = 0.0
    disk_partitions: List[Dict[str, Any]] = field(default_factory=list)
    
    # Network
    network_bytes_sent: int = 0
    network_bytes_recv: int = 0
    network_packets_sent: int = 0
    network_packets_recv: int = 0
    network_connections: int = 0
    
    # Processes
    process_count: int = 0
    zombie_processes: int = 0
    
    # Uptime
    uptime_seconds: int = 0
    boot_time: Optional[datetime] = None
    
    # Timestamp
    timestamp: datetime = field(default_factory=datetime.utcnow)


@dataclass
class ConnectionHealth:
    """Connection health status."""
    
    status: str = "unknown"
    last_check: Optional[datetime] = None
    last_error: Optional[str] = None
    latency_ms: float = 0.0
    reconnect_count: int = 0


class IServerConnector(ABC):
    """
    Abstract base class for server connectors.
    
    All server connectors must implement this interface to ensure
    consistent behavior across different server types (SSH, WinRM, etc.).
    """
    
    @property
    @abstractmethod
    def server_type(self) -> str:
        """Return the server type identifier."""
        pass
    
    @abstractmethod
    async def connect(self, config: ServerConfig) -> bool:
        """Establish connection to the server."""
        pass
    
    @abstractmethod
    async def disconnect(self) -> bool:
        """Close the connection."""
        pass
    
    @abstractmethod
    async def is_connected(self) -> bool:
        """Check if connection is active."""
        pass
    
    @abstractmethod
    async def execute_command(
        self,
        command: str,
        timeout: Optional[int] = None,
        sudo: bool = False,
        env: Optional[Dict[str, str]] = None,
    ) -> CommandResult:
        """Execute a command on the server."""
        pass
    
    @abstractmethod
    async def execute_script(
        self,
        script: str,
        interpreter: str = "bash",
        timeout: Optional[int] = None,
    ) -> CommandResult:
        """Execute a script on the server."""
        pass
    
    @abstractmethod
    async def upload_file(
        self,
        local_path: str,
        remote_path: str,
        permissions: Optional[str] = None,
    ) -> bool:
        """Upload a file to the server."""
        pass
    
    @abstractmethod
    async def download_file(
        self,
        remote_path: str,
        local_path: str,
    ) -> bool:
        """Download a file from the server."""
        pass
    
    @abstractmethod
    async def list_directory(
        self,
        path: str = ".",
        pattern: Optional[str] = None,
    ) -> List[FileInfo]:
        """List directory contents."""
        pass
    
    @abstractmethod
    async def file_exists(self, path: str) -> bool:
        """Check if file exists."""
        pass
    
    @abstractmethod
    async def read_file(
        self,
        path: str,
        offset: int = 0,
        limit: Optional[int] = None,
    ) -> str:
        """Read file contents."""
        pass
    
    @abstractmethod
    async def write_file(
        self,
        path: str,
        content: str,
        append: bool = False,
    ) -> bool:
        """Write content to file."""
        pass
    
    @abstractmethod
    async def delete_file(self, path: str) -> bool:
        """Delete a file."""
        pass
    
    @abstractmethod
    async def create_directory(
        self,
        path: str,
        parents: bool = True,
    ) -> bool:
        """Create a directory."""
        pass
    
    @abstractmethod
    async def delete_directory(
        self,
        path: str,
        recursive: bool = False,
    ) -> bool:
        """Delete a directory."""
        pass
    
    @abstractmethod
    async def get_metrics(self) -> ServerMetrics:
        """Get server performance metrics."""
        pass
    
    @abstractmethod
    async def get_processes(
        self,
        pattern: Optional[str] = None,
    ) -> List[ProcessInfo]:
        """Get running processes."""
        pass
    
    @abstractmethod
    async def kill_process(
        self,
        pid: int,
        signal: int = 15,
    ) -> bool:
        """Kill a process."""
        pass
    
    @abstractmethod
    async def tail_log(
        self,
        path: str,
        lines: int = 100,
        follow: bool = False,
    ) -> str:
        """Tail a log file."""
        pass
    
    @abstractmethod
    async def find_files(
        self,
        path: str = ".",
        name: Optional[str] = None,
        pattern: Optional[str] = None,
        modified_within: Optional[int] = None,
    ) -> List[str]:
        """Find files matching criteria."""
        pass
    
    @abstractmethod
    async def get_disk_usage(self, path: str = "/") -> Dict[str, Any]:
        """Get disk usage for a path."""
        pass
    
    @abstractmethod
    async def get_health(self) -> ConnectionHealth:
        """Get connection health status."""
        pass
    
    @abstractmethod
    async def test_connection(self) -> Tuple[bool, str]:
        """Test connection to server."""
        pass
