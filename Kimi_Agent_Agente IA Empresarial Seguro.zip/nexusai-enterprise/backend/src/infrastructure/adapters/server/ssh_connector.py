"""
NexusAI Enterprise - SSH Connector
Enterprise-grade SSH connector using asyncssh.
"""
import asyncio
import io
import logging
import os
import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import asyncssh
from asyncssh import SSHClientConnection, SSHClientConnectionOptions

from .base import (
    IServerConnector,
    ServerConfig,
    CommandResult,
    ServerMetrics,
    FileInfo,
    ProcessInfo,
    ConnectionHealth,
)

logger = logging.getLogger(__name__)


@dataclass
class SSHConfig:
    """SSH specific configuration."""
    
    # Host settings
    host: str
    port: int = 22
    
    # Authentication
    username: str = ""
    password: Optional[str] = None
    private_key: Optional[str] = None
    private_key_path: Optional[str] = None
    passphrase: Optional[str] = None
    
    # Connection settings
    timeout: int = 30
    connection_timeout: int = 10
    keepalive_interval: int = 30
    keepalive_count_max: int = 3
    
    # Security
    verify_host_key: bool = True
    known_hosts_path: Optional[str] = None
    allowed_host_key_algs: List[str] = field(default_factory=lambda: [
        "ssh-ed25519", "ecdsa-sha2-nistp521", "ecdsa-sha2-nistp384",
        "ecdsa-sha2-nistp256", "rsa-sha2-512", "rsa-sha2-256"
    ])
    
    # Proxy/Jump host
    proxy_host: Optional[str] = None
    proxy_port: int = 22
    proxy_username: Optional[str] = None
    proxy_password: Optional[str] = None
    proxy_private_key: Optional[str] = None
    
    # Compression
    compression: bool = True
    compression_algs: List[str] = field(default_factory=lambda: ["zlib@openssh.com", "zlib"])
    
    # Ciphers
    encryption_algs: List[str] = field(default_factory=lambda: [
        "chacha20-poly1305@openssh.com",
        "aes256-gcm@openssh.com", "aes128-gcm@openssh.com",
        "aes256-ctr", "aes192-ctr", "aes128-ctr"
    ])
    
    # Additional options
    options: Dict[str, Any] = field(default_factory=dict)


class SSHConnector(IServerConnector):
    """
    Enterprise SSH connector using asyncssh.
    
    Features:
    - Async SSH connections
    - Key-based and password authentication
    - Jump host / proxy support
    - SFTP file operations
    - Connection pooling and multiplexing
    - Comprehensive server metrics
    - Process management
    - Log tailing
    """
    
    def __init__(self):
        self._conn: Optional[SSHClientConnection] = None
        self._sftp: Optional[asyncssh.SFTPClient] = None
        self._config: Optional[SSHConfig] = None
        self._health = ConnectionHealth()
        self._command_history: List[Dict[str, Any]] = []
        self._max_history = 1000
        self._lock = asyncio.Lock()
    
    @property
    def server_type(self) -> str:
        return "ssh"
    
    async def connect(self, config: ServerConfig) -> bool:
        """Establish SSH connection."""
        try:
            # Parse SSH config
            ssh_config = SSHConfig(
                host=config.host,
                port=config.port,
                username=config.username,
                password=config.password,
                private_key=config.private_key,
                private_key_path=config.private_key_path,
                passphrase=config.passphrase,
                timeout=config.timeout,
                connection_timeout=config.connection_timeout,
                keepalive_interval=config.keepalive_interval,
                verify_host_key=config.verify_host_key,
                known_hosts_path=config.known_hosts_path,
                proxy_host=config.proxy_host,
                proxy_port=config.proxy_port,
                proxy_username=config.proxy_username,
                proxy_password=config.proxy_password,
                proxy_private_key=config.proxy_private_key,
                options=config.options or {},
            )
            
            self._config = ssh_config
            
            # Load private key if provided
            client_keys = None
            if ssh_config.private_key:
                client_keys = [asyncssh.import_private_key(ssh_config.private_key, ssh_config.passphrase)]
            elif ssh_config.private_key_path:
                client_keys = [ssh_config.private_key_path]
            
            # Configure known hosts
            known_hosts = None
            if ssh_config.verify_host_key:
                if ssh_config.known_hosts_path and os.path.exists(ssh_config.known_hosts_path):
                    known_hosts = ssh_config.known_hosts_path
                else:
                    known_hosts = ()  # Load default known_hosts
            else:
                known_hosts = None  # Accept any host key
            
            # Build connection options
            options = SSHClientConnectionOptions(
                host=ssh_config.host,
                port=ssh_config.port,
                username=ssh_config.username,
                password=ssh_config.password,
                client_keys=client_keys,
                known_hosts=known_hosts,
                keepalive_interval=ssh_config.keepalive_interval,
                keepalive_count_max=ssh_config.keepalive_count_max,
                compression_algs=ssh_config.compression_algs if ssh_config.compression else [],
                encryption_algs=ssh_config.encryption_algs,
                server_host_key_algs=ssh_config.allowed_host_key_algs,
                connect_timeout=ssh_config.connection_timeout,
            )
            
            # Handle jump host
            if ssh_config.proxy_host:
                # Connect to jump host first
                proxy_conn = await asyncssh.connect(
                    host=ssh_config.proxy_host,
                    port=ssh_config.proxy_port,
                    username=ssh_config.proxy_username or ssh_config.username,
                    password=ssh_config.proxy_password or ssh_config.password,
                    client_keys=ssh_config.proxy_private_key,
                    known_hosts=known_hosts,
                )
                
                # Open tunnel through jump host
                self._conn = await proxy_conn.connect_ssh(
                    host=ssh_config.host,
                    port=ssh_config.port,
                    options=options,
                )
            else:
                # Direct connection
                self._conn = await asyncssh.connect(
                    host=ssh_config.host,
                    options=options,
                )
            
            # Open SFTP session
            self._sftp = await self._conn.start_sftp_client()
            
            self._health.status = "healthy"
            self._health.last_check = datetime.utcnow()
            logger.info(f"SSH connected to {ssh_config.host}:{ssh_config.port}")
            
            return True
            
        except Exception as e:
            self._health.status = "error"
            self._health.last_error = str(e)
            logger.error(f"SSH connection failed: {e}")
            raise ConnectionError(f"SSH connection failed: {e}")
    
    async def disconnect(self) -> bool:
        """Close SSH connection."""
        try:
            if self._sftp:
                self._sftp.exit()
                self._sftp = None
            
            if self._conn:
                self._conn.close()
                await self._conn.wait_closed()
                self._conn = None
            
            self._health.status = "disconnected"
            logger.info("SSH connection closed")
            return True
            
        except Exception as e:
            logger.error(f"Error disconnecting SSH: {e}")
            return False
    
    async def is_connected(self) -> bool:
        """Check if SSH connection is active."""
        if not self._conn:
            return False
        
        try:
            # Try to execute a simple command
            result = await self._conn.run("echo 1", timeout=5)
            return result.exit_status == 0
        except Exception:
            return False
    
    async def execute_command(
        self,
        command: str,
        timeout: Optional[int] = None,
        sudo: bool = False,
        env: Optional[Dict[str, str]] = None,
    ) -> CommandResult:
        """Execute a command via SSH."""
        start_time = datetime.utcnow()
        
        try:
            # Add sudo if requested
            if sudo and not command.startswith("sudo "):
                command = f"sudo {command}"
            
            # Set environment variables
            env_prefix = ""
            if env:
                for key, value in env.items():
                    env_prefix += f'export {key}="{value}"; '
            
            full_command = f"{env_prefix}{command}" if env_prefix else command
            
            # Execute command
            result = await self._conn.run(
                full_command,
                timeout=timeout or self._config.timeout,
            )
            
            execution_time = (datetime.utcnow() - start_time).total_seconds()
            
            cmd_result = CommandResult(
                command=command,
                stdout=result.stdout or "",
                stderr=result.stderr or "",
                exit_code=result.exit_status or 0,
                execution_time=execution_time,
            )
            
            # Log command
            await self._log_command(command, execution_time, cmd_result.success)
            
            return cmd_result
            
        except asyncssh.TimeoutError:
            execution_time = (datetime.utcnow() - start_time).total_seconds()
            await self._log_command(command, execution_time, False, "Timeout")
            return CommandResult(
                command=command,
                stdout="",
                stderr="Command timed out",
                exit_code=-1,
                execution_time=execution_time,
            )
        except Exception as e:
            execution_time = (datetime.utcnow() - start_time).total_seconds()
            await self._log_command(command, execution_time, False, str(e))
            raise
    
    async def execute_script(
        self,
        script: str,
        interpreter: str = "bash",
        timeout: Optional[int] = None,
    ) -> CommandResult:
        """Execute a script on the server."""
        # Create temporary script file
        timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
        remote_script = f"/tmp/nexusai_script_{timestamp}.sh"
        
        try:
            # Upload script
            await self._sftp.put(
                io.BytesIO(script.encode()),
                remote_script,
            )
            
            # Make executable
            await self._sftp.chmod(remote_script, 0o755)
            
            # Execute
            result = await self.execute_command(
                f"{interpreter} {remote_script}",
                timeout=timeout,
            )
            
            # Cleanup
            try:
                await self._sftp.remove(remote_script)
            except Exception:
                pass
            
            return result
            
        except Exception as e:
            logger.error(f"Script execution failed: {e}")
            raise
    
    async def upload_file(
        self,
        local_path: str,
        remote_path: str,
        permissions: Optional[str] = None,
    ) -> bool:
        """Upload a file via SFTP."""
        try:
            await self._sftp.put(local_path, remote_path)
            
            if permissions:
                mode = int(permissions, 8)
                await self._sftp.chmod(remote_path, mode)
            
            return True
            
        except Exception as e:
            logger.error(f"File upload failed: {e}")
            return False
    
    async def download_file(
        self,
        remote_path: str,
        local_path: str,
    ) -> bool:
        """Download a file via SFTP."""
        try:
            await self._sftp.get(remote_path, local_path)
            return True
            
        except Exception as e:
            logger.error(f"File download failed: {e}")
            return False
    
    async def list_directory(
        self,
        path: str = ".",
        pattern: Optional[str] = None,
    ) -> List[FileInfo]:
        """List directory contents via SFTP."""
        files = []
        
        try:
            entries = await self._sftp.listdir(path)
            
            for entry in entries:
                if pattern and not re.match(pattern, entry):
                    continue
                
                full_path = f"{path}/{entry}".replace("//", "/")
                
                try:
                    attrs = await self._sftp.stat(full_path)
                    
                    files.append(FileInfo(
                        path=full_path,
                        name=entry,
                        size=attrs.size,
                        is_directory=attrs.type == 2,  # SFTP file type directory
                        is_file=attrs.type == 1,  # SFTP file type regular
                        is_symlink=attrs.type == 3,  # SFTP file type symlink
                        permissions=oct(attrs.permissions)[-3:],
                        owner=str(attrs.uid),
                        group=str(attrs.gid),
                        modified_time=datetime.fromtimestamp(attrs.mtime) if attrs.mtime else None,
                    ))
                except Exception:
                    # Skip files we can't stat
                    pass
                    
        except Exception as e:
            logger.error(f"Directory listing failed: {e}")
        
        return files
    
    async def file_exists(self, path: str) -> bool:
        """Check if file exists."""
        try:
            await self._sftp.stat(path)
            return True
        except Exception:
            return False
    
    async def read_file(
        self,
        path: str,
        offset: int = 0,
        limit: Optional[int] = None,
    ) -> str:
        """Read file contents via SFTP."""
        try:
            async with self._sftp.open(path, "r") as f:
                if offset > 0:
                    await f.seek(offset)
                
                if limit:
                    content = await f.read(limit)
                else:
                    content = await f.read()
                
                return content.decode("utf-8", errors="replace")
                
        except Exception as e:
            logger.error(f"File read failed: {e}")
            raise
    
    async def write_file(
        self,
        path: str,
        content: str,
        append: bool = False,
    ) -> bool:
        """Write content to file via SFTP."""
        try:
            mode = "a" if append else "w"
            async with self._sftp.open(path, mode) as f:
                await f.write(content.encode("utf-8"))
            
            return True
            
        except Exception as e:
            logger.error(f"File write failed: {e}")
            return False
    
    async def delete_file(self, path: str) -> bool:
        """Delete a file via SFTP."""
        try:
            await self._sftp.remove(path)
            return True
            
        except Exception as e:
            logger.error(f"File delete failed: {e}")
            return False
    
    async def create_directory(
        self,
        path: str,
        parents: bool = True,
    ) -> bool:
        """Create a directory via SFTP."""
        try:
            if parents:
                await self._sftp.makedirs(path)
            else:
                await self._sftp.mkdir(path)
            
            return True
            
        except Exception as e:
            logger.error(f"Directory creation failed: {e}")
            return False
    
    async def delete_directory(
        self,
        path: str,
        recursive: bool = False,
    ) -> bool:
        """Delete a directory via SFTP."""
        try:
            if recursive:
                await self._sftp.rmtree(path)
            else:
                await self._sftp.rmdir(path)
            
            return True
            
        except Exception as e:
            logger.error(f"Directory deletion failed: {e}")
            return False
    
    async def get_metrics(self) -> ServerMetrics:
        """Get server performance metrics."""
        metrics = ServerMetrics()
        
        try:
            # CPU info
            cpu_result = await self.execute_command(
                "cat /proc/stat | head -1 && nproc"
            )
            if cpu_result.success:
                lines = cpu_result.stdout.strip().split("\n")
                if len(lines) >= 2:
                    metrics.cpu_count = int(lines[1].strip())
            
            # CPU usage
            cpu_usage = await self.execute_command(
                "top -bn1 | grep 'Cpu(s)' | awk '{print $2}' | cut -d'%' -f1"
            )
            if cpu_usage.success:
                try:
                    metrics.cpu_percent = float(cpu_usage.stdout.strip())
                except ValueError:
                    pass
            
            # Load average
            load_result = await self.execute_command("cat /proc/loadavg")
            if load_result.success:
                parts = load_result.stdout.strip().split()
                if len(parts) >= 3:
                    metrics.load_average = (
                        float(parts[0]),
                        float(parts[1]),
                        float(parts[2]),
                    )
            
            # Memory info
            mem_result = await self.execute_command("cat /proc/meminfo")
            if mem_result.success:
                mem_info = {}
                for line in mem_result.stdout.strip().split("\n"):
                    if ":" in line:
                        key, value = line.split(":", 1)
                        mem_info[key.strip()] = int(value.strip().split()[0]) * 1024
                
                metrics.memory_total = mem_info.get("MemTotal", 0)
                metrics.memory_available = mem_info.get("MemAvailable", mem_info.get("MemFree", 0))
                metrics.memory_used = metrics.memory_total - metrics.memory_available
                
                if metrics.memory_total > 0:
                    metrics.memory_percent = (metrics.memory_used / metrics.memory_total) * 100
                
                metrics.swap_total = mem_info.get("SwapTotal", 0)
                metrics.swap_used = mem_info.get("SwapTotal", 0) - mem_info.get("SwapFree", 0)
                
                if metrics.swap_total > 0:
                    metrics.swap_percent = (metrics.swap_used / metrics.swap_total) * 100
            
            # Disk usage
            disk_result = await self.execute_command("df -B1 /")
            if disk_result.success:
                lines = disk_result.stdout.strip().split("\n")
                if len(lines) >= 2:
                    parts = lines[1].split()
                    if len(parts) >= 6:
                        metrics.disk_total = int(parts[1])
                        metrics.disk_used = int(parts[2])
                        metrics.disk_free = int(parts[3])
                        metrics.disk_percent = float(parts[4].replace("%", ""))
            
            # Disk partitions
            partitions_result = await self.execute_command("df -B1")
            if partitions_result.success:
                for line in partitions_result.stdout.strip().split("\n")[1:]:
                    parts = line.split()
                    if len(parts) >= 6:
                        metrics.disk_partitions.append({
                            "filesystem": parts[0],
                            "size": int(parts[1]),
                            "used": int(parts[2]),
                            "available": int(parts[3]),
                            "percent": float(parts[4].replace("%", "")),
                            "mount": parts[5],
                        })
            
            # Network stats
            net_result = await self.execute_command(
                "cat /proc/net/dev | grep -E 'eth|ens|enp' | head -1"
            )
            if net_result.success:
                line = net_result.stdout.strip()
                parts = line.split()
                if len(parts) >= 9:
                    metrics.network_bytes_recv = int(parts[1])
                    metrics.network_packets_recv = int(parts[2])
                    metrics.network_bytes_sent = int(parts[9])
                    metrics.network_packets_sent = int(parts[10])
            
            # Process count
            proc_result = await self.execute_command("ps aux | wc -l")
            if proc_result.success:
                metrics.process_count = int(proc_result.stdout.strip()) - 1
            
            # Zombie processes
            zombie_result = await self.execute_command(
                "ps aux | grep -c '<defunct>'"
            )
            if zombie_result.success:
                try:
                    metrics.zombie_processes = int(zombie_result.stdout.strip())
                except ValueError:
                    pass
            
            # Uptime
            uptime_result = await self.execute_command("cat /proc/uptime")
            if uptime_result.success:
                uptime_seconds = float(uptime_result.stdout.strip().split()[0])
                metrics.uptime_seconds = int(uptime_seconds)
                metrics.boot_time = datetime.utcnow() - __import__("datetime").timedelta(seconds=metrics.uptime_seconds)
            
        except Exception as e:
            logger.error(f"Failed to get metrics: {e}")
        
        return metrics
    
    async def get_processes(
        self,
        pattern: Optional[str] = None,
    ) -> List[ProcessInfo]:
        """Get running processes."""
        processes = []
        
        try:
            cmd = "ps aux"
            if pattern:
                cmd += f" | grep {pattern}"
            
            result = await self.execute_command(cmd)
            
            if result.success:
                lines = result.stdout.strip().split("\n")
                for line in lines[1:]:  # Skip header
                    parts = line.split()
                    if len(parts) >= 11:
                        try:
                            processes.append(ProcessInfo(
                                pid=int(parts[1]),
                                user=parts[0],
                                cpu_percent=float(parts[2]),
                                memory_percent=float(parts[3]),
                                memory_rss=int(parts[5]) * 1024,
                                memory_vms=0,  # Not available in ps aux
                                name=parts[10],
                                cmdline=" ".join(parts[10:]),
                                status=parts[7],
                                created_time=datetime.utcnow(),  # Would need more parsing
                            ))
                        except (ValueError, IndexError):
                            pass
                            
        except Exception as e:
            logger.error(f"Failed to get processes: {e}")
        
        return processes
    
    async def kill_process(
        self,
        pid: int,
        signal: int = 15,
    ) -> bool:
        """Kill a process."""
        result = await self.execute_command(f"kill -{signal} {pid}")
        return result.success
    
    async def tail_log(
        self,
        path: str,
        lines: int = 100,
        follow: bool = False,
    ) -> str:
        """Tail a log file."""
        try:
            if follow:
                # For follow mode, we'd need to stream
                # For now, just return last N lines
                result = await self.execute_command(f"tail -n {lines} {path}")
            else:
                result = await self.execute_command(f"tail -n {lines} {path}")
            
            return result.stdout
            
        except Exception as e:
            logger.error(f"Tail log failed: {e}")
            return ""
    
    async def find_files(
        self,
        path: str = ".",
        name: Optional[str] = None,
        pattern: Optional[str] = None,
        modified_within: Optional[int] = None,
    ) -> List[str]:
        """Find files matching criteria."""
        files = []
        
        try:
            cmd = f"find {path} -type f"
            
            if name:
                cmd += f" -name '{name}'"
            
            if modified_within:
                cmd += f" -mtime -{modified_within}"
            
            result = await self.execute_command(cmd)
            
            if result.success:
                files = [f.strip() for f in result.stdout.strip().split("\n") if f.strip()]
                
                if pattern:
                    import re
                    files = [f for f in files if re.search(pattern, f)]
                    
        except Exception as e:
            logger.error(f"Find files failed: {e}")
        
        return files
    
    async def get_disk_usage(self, path: str = "/") -> Dict[str, Any]:
        """Get disk usage for a path."""
        result = await self.execute_command(f"df -B1 {path}")
        
        if result.success:
            lines = result.stdout.strip().split("\n")
            if len(lines) >= 2:
                parts = lines[1].split()
                if len(parts) >= 6:
                    return {
                        "filesystem": parts[0],
                        "total": int(parts[1]),
                        "used": int(parts[2]),
                        "available": int(parts[3]),
                        "percent": float(parts[4].replace("%", "")),
                        "mount": parts[5],
                    }
        
        return {}
    
    async def get_health(self) -> ConnectionHealth:
        """Get connection health status."""
        if self._conn:
            is_alive = await self.is_connected()
            self._health.status = "healthy" if is_alive else "unhealthy"
            self._health.last_check = datetime.utcnow()
        
        return self._health
    
    async def test_connection(self) -> Tuple[bool, str]:
        """Test SSH connection."""
        try:
            result = await self.execute_command("whoami && hostname && uname -a")
            
            if result.success:
                lines = result.stdout.strip().split("\n")
                user = lines[0] if len(lines) > 0 else "unknown"
                hostname = lines[1] if len(lines) > 1 else "unknown"
                os_info = lines[2] if len(lines) > 2 else ""
                return True, f"Connected as {user}@{hostname} - {os_info[:50]}"
            else:
                return False, result.stderr
                
        except Exception as e:
            return False, str(e)
    
    async def _log_command(
        self,
        command: str,
        execution_time: float,
        success: bool,
        error: Optional[str] = None,
    ):
        """Log command execution for monitoring."""
        async with self._lock:
            self._command_history.append({
                "timestamp": datetime.utcnow().isoformat(),
                "command": command[:200],
                "execution_time": execution_time,
                "success": success,
                "error": error,
            })
            
            if len(self._command_history) > self._max_history:
                self._command_history = self._command_history[-self._max_history:]
    
    async def get_command_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get command execution history."""
        return self._command_history[-limit:]
    
    async def analyze_logs(
        self,
        path: str,
        pattern: str,
        since: Optional[datetime] = None,
        until: Optional[datetime] = None,
    ) -> List[Dict[str, Any]]:
        """Analyze logs for patterns."""
        matches = []
        
        try:
            cmd = f"grep -n '{pattern}' {path}"
            
            if since:
                since_str = since.strftime("%Y-%m-%d %H:%M:%S")
                cmd += f" | awk '$0 >= \"{since_str}\"'"
            
            result = await self.execute_command(cmd)
            
            if result.success:
                for line in result.stdout.strip().split("\n"):
                    if ":" in line:
                        line_num, content = line.split(":", 1)
                        matches.append({
                            "line_number": int(line_num),
                            "content": content.strip(),
                            "timestamp": datetime.utcnow(),  # Would need parsing
                        })
                        
        except Exception as e:
            logger.error(f"Log analysis failed: {e}")
        
        return matches
