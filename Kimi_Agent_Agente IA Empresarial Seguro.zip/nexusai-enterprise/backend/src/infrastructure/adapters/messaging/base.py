"""
NexusAI Enterprise - Base Messaging Adapter Interface
Defines the contract for all messaging adapters.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional


class MessageChannel(Enum):
    """Message channel enumeration."""
    TEAMS = "teams"
    TELEGRAM = "telegram"
    SLACK = "slack"
    EMAIL = "email"
    SMS = "sms"


class MessagePriority(Enum):
    """Message priority enumeration."""
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class Message:
    """Message data structure."""
    content: str
    recipient: str
    subject: Optional[str] = None
    attachments: List[Dict[str, Any]] = field(default_factory=list)
    priority: MessagePriority = MessagePriority.NORMAL
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.utcnow)


@dataclass
class MessageConfig:
    """Base message adapter configuration."""
    
    # API settings
    api_key: str = ""
    api_secret: Optional[str] = None
    webhook_url: Optional[str] = None
    
    # Connection settings
    timeout: int = 30
    max_retries: int = 3
    retry_delay: float = 1.0
    
    # Rate limiting
    rate_limit_per_minute: int = 60
    
    # Additional options
    options: Dict[str, Any] = field(default_factory=dict)


class IMessageAdapter(ABC):
    """
    Abstract base class for messaging adapters.
    
    All messaging adapters must implement this interface to ensure
    consistent behavior across different platforms.
    """
    
    def __init__(self):
        self._config: Optional[MessageConfig] = None
    
    @property
    @abstractmethod
    def channel_type(self) -> MessageChannel:
        """Return the channel type."""
        pass
    
    @abstractmethod
    async def initialize(self, config: MessageConfig) -> bool:
        """Initialize the adapter with configuration."""
        pass
    
    @abstractmethod
    async def send_message(self, message: Message) -> Dict[str, Any]:
        """Send a message."""
        pass
    
    @abstractmethod
    async def send_notification(
        self,
        recipient: str,
        title: str,
        message: str,
        priority: MessagePriority = MessagePriority.NORMAL,
    ) -> Dict[str, Any]:
        """Send a notification."""
        pass
    
    @abstractmethod
    async def send_alert(
        self,
        recipient: str,
        alert_type: str,
        message: str,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Send an alert."""
        pass
    
    @abstractmethod
    async def health_check(self) -> Dict[str, Any]:
        """Check adapter health."""
        pass
    
    async def format_code_block(self, code: str, language: str = "") -> str:
        """Format code for the messaging platform."""
        return f"```{language}\n{code}\n```"
    
    async def format_bold(self, text: str) -> str:
        """Format bold text for the messaging platform."""
        return f"**{text}**"
    
    async def format_italic(self, text: str) -> str:
        """Format italic text for the messaging platform."""
        return f"*{text}*"
    
    async def format_link(self, text: str, url: str) -> str:
        """Format a link for the messaging platform."""
        return f"[{text}]({url})"
