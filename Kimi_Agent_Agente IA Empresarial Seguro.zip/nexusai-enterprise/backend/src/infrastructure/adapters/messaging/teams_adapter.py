"""
NexusAI Enterprise - Microsoft Teams Adapter
Microsoft Teams messaging adapter using webhooks and Graph API.
"""
import json
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import aiohttp

from .base import IMessageAdapter, MessageConfig, Message, MessageChannel, MessagePriority

logger = logging.getLogger(__name__)


@dataclass
class TeamsConfig:
    """Microsoft Teams specific configuration."""
    
    # Webhook URL for incoming webhooks
    webhook_url: str = ""
    
    # Graph API settings (for advanced features)
    tenant_id: Optional[str] = None
    client_id: Optional[str] = None
    client_secret: Optional[str] = None
    
    # Default channel/team
    default_channel: Optional[str] = None
    default_team: Optional[str] = None
    
    # Timeout
    timeout: int = 30
    max_retries: int = 3
    
    # Rate limiting
    rate_limit_per_minute: int = 30
    
    # Additional options
    options: Dict[str, Any] = field(default_factory=dict)


class TeamsAdapter(IMessageAdapter):
    """
    Microsoft Teams messaging adapter.
    
    Supports:
    - Incoming webhooks
    - Adaptive Cards
    - Microsoft Graph API (for advanced features)
    - Mentions and formatting
    """
    
    def __init__(self):
        super().__init__()
        self._config: Optional[TeamsConfig] = None
        self._session: Optional[aiohttp.ClientSession] = None
    
    @property
    def channel_type(self) -> MessageChannel:
        return MessageChannel.TEAMS
    
    async def initialize(self, config: MessageConfig) -> bool:
        """Initialize Teams adapter."""
        try:
            teams_config = TeamsConfig(
                webhook_url=config.webhook_url or "",
                timeout=config.timeout,
                max_retries=config.max_retries,
                options=config.options or {},
            )
            
            if config.options:
                if "tenant_id" in config.options:
                    teams_config.tenant_id = config.options["tenant_id"]
                if "client_id" in config.options:
                    teams_config.client_id = config.options["client_id"]
                if "client_secret" in config.options:
                    teams_config.client_secret = config.options["client_secret"]
                if "default_channel" in config.options:
                    teams_config.default_channel = config.options["default_channel"]
                if "default_team" in config.options:
                    teams_config.default_team = config.options["default_team"]
            
            self._config = teams_config
            
            # Create HTTP session
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=teams_config.timeout),
            )
            
            logger.info("Teams adapter initialized")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize Teams adapter: {e}")
            raise
    
    def _build_adaptive_card(
        self,
        title: str,
        message: str,
        priority: MessagePriority = MessagePriority.NORMAL,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Build an Adaptive Card for Teams."""
        # Color based on priority
        color_map = {
            MessagePriority.LOW: "good",
            MessagePriority.NORMAL: "default",
            MessagePriority.HIGH: "warning",
            MessagePriority.CRITICAL: "attention",
        }
        color = color_map.get(priority, "default")
        
        card = {
            "type": "message",
            "attachments": [
                {
                    "contentType": "application/vnd.microsoft.card.adaptive",
                    "contentUrl": None,
                    "content": {
                        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                        "type": "AdaptiveCard",
                        "version": "1.4",
                        "body": [
                            {
                                "type": "TextBlock",
                                "text": title,
                                "weight": "Bolder",
                                "size": "Medium",
                                "color": color,
                            },
                            {
                                "type": "TextBlock",
                                "text": message,
                                "wrap": True,
                            },
                        ],
                        "actions": [],
                    },
                }
            ],
        }
        
        # Add details if provided
        if details:
            facts = []
            for key, value in details.items():
                facts.append({
                    "title": key,
                    "value": str(value),
                })
            
            card["attachments"][0]["content"]["body"].append({
                "type": "FactSet",
                "facts": facts,
            })
        
        return card
    
    async def send_message(self, message: Message) -> Dict[str, Any]:
        """Send a message to Teams."""
        try:
            card = self._build_adaptive_card(
                title=message.subject or "NexusAI Enterprise",
                message=message.content,
                priority=message.priority,
                details=message.metadata,
            )
            
            async with self._session.post(
                self._config.webhook_url,
                json=card,
                headers={"Content-Type": "application/json"},
            ) as response:
                if response.status == 200:
                    return {
                        "success": True,
                        "message_id": None,  # Teams doesn't return message ID for webhooks
                        "channel": self._config.default_channel,
                    }
                else:
                    text = await response.text()
                    raise Exception(f"Teams API error: {response.status} - {text}")
                    
        except Exception as e:
            logger.error(f"Failed to send Teams message: {e}")
            raise
    
    async def send_notification(
        self,
        recipient: str,
        title: str,
        message: str,
        priority: MessagePriority = MessagePriority.NORMAL,
    ) -> Dict[str, Any]:
        """Send a notification to Teams."""
        msg = Message(
            content=message,
            recipient=recipient,
            subject=title,
            priority=priority,
        )
        return await self.send_message(msg)
    
    async def send_alert(
        self,
        recipient: str,
        alert_type: str,
        message: str,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Send an alert to Teams."""
        priority = MessagePriority.HIGH
        if alert_type.lower() in ("critical", "error", "emergency"):
            priority = MessagePriority.CRITICAL
        
        msg = Message(
            content=message,
            recipient=recipient,
            subject=f"🚨 {alert_type.upper()}: NexusAI Alert",
            priority=priority,
            metadata=details or {},
        )
        return await self.send_message(msg)
    
    async def send_incident_card(
        self,
        recipient: str,
        incident_id: str,
        title: str,
        severity: str,
        description: str,
        affected_systems: List[str],
        action_items: List[str],
    ) -> Dict[str, Any]:
        """Send an incident card to Teams."""
        try:
            card = {
                "type": "message",
                "attachments": [
                    {
                        "contentType": "application/vnd.microsoft.card.adaptive",
                        "content": {
                            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                            "type": "AdaptiveCard",
                            "version": "1.4",
                            "body": [
                                {
                                    "type": "TextBlock",
                                    "text": f"🚨 Incident #{incident_id}",
                                    "weight": "Bolder",
                                    "size": "Large",
                                    "color": "attention",
                                },
                                {
                                    "type": "TextBlock",
                                    "text": title,
                                    "weight": "Bolder",
                                    "size": "Medium",
                                },
                                {
                                    "type": "FactSet",
                                    "facts": [
                                        {"title": "Severity:", "value": severity},
                                        {"title": "Incident ID:", "value": incident_id},
                                    ],
                                },
                                {
                                    "type": "TextBlock",
                                    "text": "Description",
                                    "weight": "Bolder",
                                },
                                {
                                    "type": "TextBlock",
                                    "text": description,
                                    "wrap": True,
                                },
                                {
                                    "type": "TextBlock",
                                    "text": "Affected Systems",
                                    "weight": "Bolder",
                                },
                                {
                                    "type": "TextBlock",
                                    "text": "\n".join([f"• {s}" for s in affected_systems]),
                                    "wrap": True,
                                },
                                {
                                    "type": "TextBlock",
                                    "text": "Action Items",
                                    "weight": "Bolder",
                                },
                                {
                                    "type": "TextBlock",
                                    "text": "\n".join([f"• {a}" for a in action_items]),
                                    "wrap": True,
                                },
                            ],
                        },
                    }
                ],
            }
            
            async with self._session.post(
                self._config.webhook_url,
                json=card,
                headers={"Content-Type": "application/json"},
            ) as response:
                if response.status == 200:
                    return {"success": True, "incident_id": incident_id}
                else:
                    text = await response.text()
                    raise Exception(f"Teams API error: {response.status} - {text}")
                    
        except Exception as e:
            logger.error(f"Failed to send incident card: {e}")
            raise
    
    async def health_check(self) -> Dict[str, Any]:
        """Check Teams adapter health."""
        try:
            # Try a simple request to validate webhook URL
            if self._config.webhook_url:
                # We can't really test without sending a message
                # Just validate the URL format
                from urllib.parse import urlparse
                parsed = urlparse(self._config.webhook_url)
                is_valid = all([parsed.scheme, parsed.netloc])
                
                return {
                    "status": "healthy" if is_valid else "unhealthy",
                    "channel": self.channel_type.value,
                    "webhook_configured": bool(self._config.webhook_url),
                    "graph_api_configured": all([
                        self._config.tenant_id,
                        self._config.client_id,
                        self._config.client_secret,
                    ]),
                }
            
            return {
                "status": "unhealthy",
                "channel": self.channel_type.value,
                "error": "Webhook URL not configured",
            }
            
        except Exception as e:
            return {
                "status": "error",
                "channel": self.channel_type.value,
                "error": str(e),
            }
    
    async def format_code_block(self, code: str, language: str = "") -> str:
        """Format code for Teams."""
        return f"```{language}\n{code}\n```"
    
    async def format_bold(self, text: str) -> str:
        """Format bold text for Teams."""
        return f"**{text}**"
    
    async def format_italic(self, text: str) -> str:
        """Format italic text for Teams."""
        return f"*{text}*"
