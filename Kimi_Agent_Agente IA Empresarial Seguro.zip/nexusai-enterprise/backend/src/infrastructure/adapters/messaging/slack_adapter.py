"""
NexusAI Enterprise - Slack Adapter
Slack messaging adapter using Web API and webhooks.
"""
import json
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import aiohttp

from .base import IMessageAdapter, MessageConfig, Message, MessageChannel, MessagePriority

logger = logging.getLogger(__name__)


@dataclass
class SlackConfig:
    """Slack specific configuration."""
    
    # Bot token (xoxb-...)
    bot_token: str = ""
    
    # Webhook URL for incoming webhooks
    webhook_url: Optional[str] = None
    
    # App-level token (xapp-...)
    app_token: Optional[str] = None
    
    # Default channel
    default_channel: Optional[str] = None
    
    # Signing secret for webhook verification
    signing_secret: Optional[str] = None
    
    # Timeout
    timeout: int = 30
    max_retries: int = 3
    
    # Rate limiting
    rate_limit_per_minute: int = 50
    
    # Additional options
    options: Dict[str, Any] = field(default_factory=dict)


class SlackAdapter(IMessageAdapter):
    """
    Slack messaging adapter.
    
    Supports:
    - Web API for posting messages
    - Incoming webhooks
    - Block Kit formatting
    - Interactive components
    - File uploads
    """
    
    API_BASE = "https://slack.com/api"
    
    def __init__(self):
        super().__init__()
        self._config: Optional[SlackConfig] = None
        self._session: Optional[aiohttp.ClientSession] = None
    
    @property
    def channel_type(self) -> MessageChannel:
        return MessageChannel.SLACK
    
    async def initialize(self, config: MessageConfig) -> bool:
        """Initialize Slack adapter."""
        try:
            slack_config = SlackConfig(
                bot_token=config.api_key,
                webhook_url=config.webhook_url,
                timeout=config.timeout,
                max_retries=config.max_retries,
                options=config.options or {},
            )
            
            if config.options:
                if "default_channel" in config.options:
                    slack_config.default_channel = config.options["default_channel"]
                if "app_token" in config.options:
                    slack_config.app_token = config.options["app_token"]
                if "signing_secret" in config.options:
                    slack_config.signing_secret = config.options["signing_secret"]
            
            self._config = slack_config
            
            # Create HTTP session
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=slack_config.timeout),
                headers={
                    "Authorization": f"Bearer {slack_config.bot_token}",
                    "Content-Type": "application/json",
                },
            )
            
            # Validate token
            await self._validate_token()
            
            logger.info("Slack adapter initialized")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize Slack adapter: {e}")
            raise
    
    async def _validate_token(self):
        """Validate bot token by calling auth.test."""
        try:
            result = await self._make_request("auth.test", {})
            
            if result.get("ok"):
                logger.info(f"Slack bot connected: {result.get('user')} in {result.get('team')}")
            else:
                raise Exception(f"Slack auth error: {result.get('error')}")
                
        except Exception as e:
            logger.error(f"Token validation failed: {e}")
            raise
    
    async def _make_request(self, method: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Make a request to Slack API."""
        url = f"{self.API_BASE}/{method}"
        
        async with self._session.post(url, json=payload) as response:
            data = await response.json()
            
            if response.status == 200 and data.get("ok"):
                return data
            else:
                error = data.get("error", "Unknown error")
                raise Exception(f"Slack API error: {error}")
    
    def _build_blocks(
        self,
        title: str,
        message: str,
        priority: MessagePriority = MessagePriority.NORMAL,
        details: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """Build Block Kit blocks for Slack."""
        # Color based on priority
        color_map = {
            MessagePriority.LOW: "#36a64f",  # Green
            MessagePriority.NORMAL: "#808080",  # Gray
            MessagePriority.HIGH: "#daa520",  # Gold
            MessagePriority.CRITICAL: "#ff0000",  # Red
        }
        color = color_map.get(priority, "#808080")
        
        blocks = [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": title,
                    "emoji": True,
                },
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": message,
                },
            },
        ]
        
        # Add details if provided
        if details:
            fields = []
            for key, value in details.items():
                fields.append({
                    "type": "mrkdwn",
                    "text": f"*{key}:*\n{value}",
                })
            
            blocks.append({
                "type": "section",
                "fields": fields,
            })
        
        # Add divider
        blocks.append({"type": "divider"})
        
        return blocks
    
    async def send_message(self, message: Message) -> Dict[str, Any]:
        """Send a message to Slack."""
        try:
            channel = message.recipient or self._config.default_channel
            
            if not channel:
                raise ValueError("No channel specified")
            
            # Build blocks
            blocks = self._build_blocks(
                title=message.subject or "NexusAI Enterprise",
                message=message.content,
                priority=message.priority,
                details=message.metadata,
            )
            
            payload = {
                "channel": channel,
                "blocks": blocks,
                "text": message.content,  # Fallback text
            }
            
            result = await self._make_request("chat.postMessage", payload)
            
            return {
                "success": True,
                "message_id": result.get("ts"),
                "channel": result.get("channel"),
            }
            
        except Exception as e:
            logger.error(f"Failed to send Slack message: {e}")
            raise
    
    async def send_notification(
        self,
        recipient: str,
        title: str,
        message: str,
        priority: MessagePriority = MessagePriority.NORMAL,
    ) -> Dict[str, Any]:
        """Send a notification to Slack."""
        msg = Message(
            content=message,
            recipient=recipient,
            subject=title,
            priority=priority,
        )
        return await self.send_message(msg)
    
    async def send_alert(
        self,
        recipient: str,
        alert_type: str,
        message: str,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Send an alert to Slack."""
        # Emoji based on alert type
        emoji_map = {
            "critical": "🚨",
            "error": "❌",
            "warning": "⚠️",
            "info": "ℹ️",
            "success": "✅",
        }
        emoji = emoji_map.get(alert_type.lower(), "🔔")
        
        priority = MessagePriority.HIGH if alert_type.lower() in ("critical", "error") else MessagePriority.NORMAL
        
        msg = Message(
            content=f"{emoji} {message}",
            recipient=recipient,
            subject=f"{alert_type.upper()}: NexusAI Alert",
            priority=priority,
            metadata=details or {},
        )
        return await self.send_message(msg)
    
    async def send_incident_message(
        self,
        channel: str,
        incident_id: str,
        title: str,
        severity: str,
        description: str,
        affected_systems: List[str],
        action_items: List[str],
    ) -> Dict[str, Any]:
        """Send an incident message to Slack."""
        try:
            # Color based on severity
            color_map = {
                "critical": "#ff0000",
                "high": "#ff8c00",
                "medium": "#daa520",
                "low": "#36a64f",
            }
            color = color_map.get(severity.lower(), "#808080")
            
            blocks = [
                {
                    "type": "header",
                    "text": {
                        "type": "plain_text",
                        "text": f"🚨 Incident #{incident_id}",
                        "emoji": True,
                    },
                },
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": f"*{title}*",
                    },
                },
                {
                    "type": "section",
                    "fields": [
                        {"type": "mrkdwn", "text": f"*Severity:*\n{severity.upper()}"},
                        {"type": "mrkdwn", "text": f"*Incident ID:*\n{incident_id}"},
                    ],
                },
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": f"*Description:*\n{description}",
                    },
                },
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": f"*Affected Systems:*\n" + "\n".join([f"• {s}" for s in affected_systems]),
                    },
                },
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": f"*Action Items:*\n" + "\n".join([f"• {a}" for a in action_items]),
                    },
                },
                {"type": "divider"},
            ]
            
            payload = {
                "channel": channel,
                "blocks": blocks,
                "text": f"Incident #{incident_id}: {title}",
                "attachments": [
                    {
                        "color": color,
                        "blocks": [],
                    }
                ],
            }
            
            result = await self._make_request("chat.postMessage", payload)
            
            return {
                "success": True,
                "message_id": result.get("ts"),
                "channel": result.get("channel"),
            }
            
        except Exception as e:
            logger.error(f"Failed to send incident message: {e}")
            raise
    
    async def upload_file(
        self,
        channel: str,
        file_path: str,
        title: Optional[str] = None,
        initial_comment: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Upload a file to Slack."""
        try:
            url = f"{self.API_BASE}/files.upload"
            
            data = aiohttp.FormData()
            data.add_field("channels", channel)
            
            if title:
                data.add_field("title", title)
            if initial_comment:
                data.add_field("initial_comment", initial_comment)
            
            with open(file_path, "rb") as f:
                data.add_field("file", f, filename=file_path.split("/")[-1])
                
                async with self._session.post(url, data=data) as response:
                    result = await response.json()
                    
                    if response.status == 200 and result.get("ok"):
                        file_info = result.get("file", {})
                        return {
                            "success": True,
                            "file_id": file_info.get("id"),
                            "file_url": file_info.get("url_private"),
                        }
                    else:
                        raise Exception(f"Slack API error: {result.get('error')}")
                        
        except Exception as e:
            logger.error(f"Failed to upload file: {e}")
            raise
    
    async def health_check(self) -> Dict[str, Any]:
        """Check Slack adapter health."""
        try:
            result = await self._make_request("auth.test", {})
            
            if result.get("ok"):
                return {
                    "status": "healthy",
                    "channel": self.channel_type.value,
                    "bot_user": result.get("user"),
                    "team": result.get("team"),
                    "user_id": result.get("user_id"),
                }
            else:
                return {
                    "status": "unhealthy",
                    "channel": self.channel_type.value,
                    "error": result.get("error"),
                }
            
        except Exception as e:
            return {
                "status": "error",
                "channel": self.channel_type.value,
                "error": str(e),
            }
    
    async def format_code_block(self, code: str, language: str = "") -> str:
        """Format code for Slack."""
        return f"```{language}\n{code}\n```"
    
    async def format_bold(self, text: str) -> str:
        """Format bold text for Slack."""
        return f"*{text}*"
    
    async def format_italic(self, text: str) -> str:
        """Format italic text for Slack."""
        return f"_{text}_"
    
    async def format_link(self, text: str, url: str) -> str:
        """Format a link for Slack."""
        return f"<{url}|{text}>"
    
    # Additional Slack-specific methods
    
    async def get_channel_info(self, channel: str) -> Dict[str, Any]:
        """Get channel information."""
        try:
            result = await self._make_request("conversations.info", {"channel": channel})
            return result.get("channel", {})
        except Exception as e:
            logger.error(f"Failed to get channel info: {e}")
            return {}
    
    async def get_user_info(self, user: str) -> Dict[str, Any]:
        """Get user information."""
        try:
            result = await self._make_request("users.info", {"user": user})
            return result.get("user", {})
        except Exception as e:
            logger.error(f"Failed to get user info: {e}")
            return {}
    
    async def list_channels(self, exclude_archived: bool = True) -> List[Dict[str, Any]]:
        """List channels."""
        try:
            result = await self._make_request(
                "conversations.list",
                {"exclude_archived": exclude_archived},
            )
            return result.get("channels", [])
        except Exception as e:
            logger.error(f"Failed to list channels: {e}")
            return []
