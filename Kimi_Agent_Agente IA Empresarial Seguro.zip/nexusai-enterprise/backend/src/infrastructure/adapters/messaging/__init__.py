"""
NexusAI Enterprise - Messaging Adapters Module
"""
from .base import IMessageAdapter, MessageConfig, Message, MessageChannel
from .teams_adapter import TeamsAdapter, TeamsConfig
from .telegram_adapter import TelegramAdapter, TelegramConfig
from .slack_adapter import SlackAdapter, SlackConfig

__all__ = [
    # Base
    "IMessageAdapter",
    "MessageConfig",
    "Message",
    "MessageChannel",
    # Adapters
    "TeamsAdapter",
    "TelegramAdapter",
    "SlackAdapter",
    # Configs
    "TeamsConfig",
    "TelegramConfig",
    "SlackConfig",
]


class MessagingAdapterFactory:
    """Factory for creating messaging adapters."""
    
    _adapters = {
        "teams": TeamsAdapter,
        "microsoft_teams": TeamsAdapter,
        "telegram": TelegramAdapter,
        "slack": SlackAdapter,
    }
    
    @classmethod
    def create(cls, adapter_type: str):
        """Create a messaging adapter by type."""
        adapter_type = adapter_type.lower()
        
        if adapter_type not in cls._adapters:
            raise ValueError(f"Unsupported messaging adapter type: {adapter_type}")
        
        return cls._adapters[adapter_type]()
    
    @classmethod
    def register(cls, adapter_type: str, adapter_class: type):
        """Register a new adapter type."""
        cls._adapters[adapter_type.lower()] = adapter_class
    
    @classmethod
    def supported_types(cls) -> list:
        """Get list of supported adapter types."""
        return list(cls._adapters.keys())
