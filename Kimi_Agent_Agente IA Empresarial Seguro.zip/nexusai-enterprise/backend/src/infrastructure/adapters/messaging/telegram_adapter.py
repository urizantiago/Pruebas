"""
NexusAI Enterprise - Telegram Adapter
Telegram Bot API messaging adapter.
"""
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import aiohttp

from .base import IMessageAdapter, MessageConfig, Message, MessageChannel, MessagePriority

logger = logging.getLogger(__name__)


@dataclass
class TelegramConfig:
    """Telegram specific configuration."""
    
    # Bot token from BotFather
    bot_token: str = ""
    
    # Default chat ID
    default_chat_id: Optional[str] = None
    
    # Parse mode
    parse_mode: str = "Markdown"  # Markdown, HTML, or MarkdownV2
    
    # Timeout
    timeout: int = 30
    max_retries: int = 3
    
    # Rate limiting
    rate_limit_per_minute: int = 30
    
    # Additional options
    options: Dict[str, Any] = field(default_factory=dict)


class TelegramAdapter(IMessageAdapter):
    """
    Telegram Bot API messaging adapter.
    
    Supports:
    - Text messages with Markdown/HTML formatting
    - Photo/document uploads
    - Inline keyboards
    - Message threading
    """
    
    API_BASE = "https://api.telegram.org/bot{token}"
    
    def __init__(self):
        super().__init__()
        self._config: Optional[TelegramConfig] = None
        self._session: Optional[aiohttp.ClientSession] = None
        self._api_url: str = ""
    
    @property
    def channel_type(self) -> MessageChannel:
        return MessageChannel.TELEGRAM
    
    async def initialize(self, config: MessageConfig) -> bool:
        """Initialize Telegram adapter."""
        try:
            telegram_config = TelegramConfig(
                bot_token=config.api_key,
                timeout=config.timeout,
                max_retries=config.max_retries,
                options=config.options or {},
            )
            
            if config.options:
                if "default_chat_id" in config.options:
                    telegram_config.default_chat_id = config.options["default_chat_id"]
                if "parse_mode" in config.options:
                    telegram_config.parse_mode = config.options["parse_mode"]
            
            self._config = telegram_config
            self._api_url = self.API_BASE.format(token=telegram_config.bot_token)
            
            # Create HTTP session
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=telegram_config.timeout),
            )
            
            # Validate bot token
            await self._validate_token()
            
            logger.info("Telegram adapter initialized")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize Telegram adapter: {e}")
            raise
    
    async def _validate_token(self):
        """Validate bot token by calling getMe."""
        try:
            async with self._session.get(f"{self._api_url}/getMe") as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("ok"):
                        bot_info = data.get("result", {})
                        logger.info(f"Telegram bot connected: @{bot_info.get('username')}")
                        return True
                    else:
                        raise Exception(f"Telegram API error: {data.get('description')}")
                else:
                    text = await response.text()
                    raise Exception(f"Telegram API error: {response.status} - {text}")
        except Exception as e:
            logger.error(f"Token validation failed: {e}")
            raise
    
    async def _make_request(self, method: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Make a request to Telegram API."""
        url = f"{self._api_url}/{method}"
        
        async with self._session.post(url, json=payload) as response:
            data = await response.json()
            
            if response.status == 200 and data.get("ok"):
                return data.get("result", {})
            else:
                error_description = data.get("description", "Unknown error")
                raise Exception(f"Telegram API error: {error_description}")
    
    async def send_message(self, message: Message) -> Dict[str, Any]:
        """Send a message to Telegram."""
        try:
            chat_id = message.recipient or self._config.default_chat_id
            
            if not chat_id:
                raise ValueError("No chat_id specified")
            
            # Escape special characters for MarkdownV2 if needed
            text = message.content
            if self._config.parse_mode == "MarkdownV2":
                text = self._escape_markdown_v2(text)
            
            payload = {
                "chat_id": chat_id,
                "text": text,
                "parse_mode": self._config.parse_mode,
                "disable_web_page_preview": True,
            }
            
            # Add notification priority
            if message.priority == MessagePriority.LOW:
                payload["disable_notification"] = True
            
            result = await self._make_request("sendMessage", payload)
            
            return {
                "success": True,
                "message_id": result.get("message_id"),
                "chat_id": result.get("chat", {}).get("id"),
            }
            
        except Exception as e:
            logger.error(f"Failed to send Telegram message: {e}")
            raise
    
    async def send_notification(
        self,
        recipient: str,
        title: str,
        message: str,
        priority: MessagePriority = MessagePriority.NORMAL,
    ) -> Dict[str, Any]:
        """Send a notification to Telegram."""
        # Format notification with title
        formatted_message = f"*{title}*\n\n{message}"
        
        msg = Message(
            content=formatted_message,
            recipient=recipient,
            subject=title,
            priority=priority,
        )
        return await self.send_message(msg)
    
    async def send_alert(
        self,
        recipient: str,
        alert_type: str,
        message: str,
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Send an alert to Telegram."""
        # Emoji based on alert type
        emoji_map = {
            "critical": "🚨",
            "error": "❌",
            "warning": "⚠️",
            "info": "ℹ️",
            "success": "✅",
        }
        emoji = emoji_map.get(alert_type.lower(), "🔔")
        
        # Build alert message
        formatted_message = f"{emoji} *{alert_type.upper()}*\n\n{message}"
        
        if details:
            formatted_message += "\n\n*Details:*"
            for key, value in details.items():
                formatted_message += f"\n• {key}: `{value}`"
        
        priority = MessagePriority.HIGH if alert_type.lower() in ("critical", "error") else MessagePriority.NORMAL
        
        msg = Message(
            content=formatted_message,
            recipient=recipient,
            subject=f"{alert_type.upper()} Alert",
            priority=priority,
            metadata=details or {},
        )
        return await self.send_message(msg)
    
    async def send_document(
        self,
        chat_id: str,
        document_path: str,
        caption: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Send a document to Telegram."""
        try:
            url = f"{self._api_url}/sendDocument"
            
            data = aiohttp.FormData()
            data.add_field("chat_id", chat_id)
            
            if caption:
                data.add_field("caption", caption)
                data.add_field("parse_mode", self._config.parse_mode)
            
            with open(document_path, "rb") as f:
                data.add_field("document", f, filename=document_path.split("/")[-1])
                
                async with self._session.post(url, data=data) as response:
                    result = await response.json()
                    
                    if response.status == 200 and result.get("ok"):
                        return {
                            "success": True,
                            "message_id": result.get("result", {}).get("message_id"),
                        }
                    else:
                        raise Exception(f"Telegram API error: {result.get('description')}")
                        
        except Exception as e:
            logger.error(f"Failed to send document: {e}")
            raise
    
    async def send_inline_keyboard(
        self,
        chat_id: str,
        text: str,
        buttons: List[List[Dict[str, str]]],
    ) -> Dict[str, Any]:
        """Send a message with inline keyboard."""
        try:
            # Format buttons
            keyboard = []
            for row in buttons:
                keyboard_row = []
                for button in row:
                    keyboard_row.append({
                        "text": button.get("text"),
                        "callback_data": button.get("callback_data"),
                        "url": button.get("url"),
                    })
                keyboard.append(keyboard_row)
            
            payload = {
                "chat_id": chat_id,
                "text": text,
                "parse_mode": self._config.parse_mode,
                "reply_markup": {
                    "inline_keyboard": keyboard,
                },
            }
            
            result = await self._make_request("sendMessage", payload)
            
            return {
                "success": True,
                "message_id": result.get("message_id"),
            }
            
        except Exception as e:
            logger.error(f"Failed to send inline keyboard: {e}")
            raise
    
    async def health_check(self) -> Dict[str, Any]:
        """Check Telegram adapter health."""
        try:
            bot_info = await self._make_request("getMe", {})
            
            return {
                "status": "healthy",
                "channel": self.channel_type.value,
                "bot_username": bot_info.get("username"),
                "bot_id": bot_info.get("id"),
                "is_bot": bot_info.get("is_bot"),
            }
            
        except Exception as e:
            return {
                "status": "unhealthy",
                "channel": self.channel_type.value,
                "error": str(e),
            }
    
    def _escape_markdown_v2(self, text: str) -> str:
        """Escape special characters for MarkdownV2."""
        escape_chars = r"_[]()~`>#+-=|{}.!"
        for char in escape_chars:
            text = text.replace(char, f"\\{char}")
        return text
    
    async def format_code_block(self, code: str, language: str = "") -> str:
        """Format code for Telegram."""
        return f"```{language}\n{code}\n```"
    
    async def format_bold(self, text: str) -> str:
        """Format bold text for Telegram."""
        return f"*{text}*"
    
    async def format_italic(self, text: str) -> str:
        """Format italic text for Telegram."""
        return f"_{text}_"
    
    async def format_link(self, text: str, url: str) -> str:
        """Format a link for Telegram."""
        return f"[{text}]({url})"
    
    # Bot command handlers
    
    async def set_webhook(self, url: str) -> bool:
        """Set webhook for receiving updates."""
        try:
            payload = {"url": url}
            await self._make_request("setWebhook", payload)
            return True
        except Exception as e:
            logger.error(f"Failed to set webhook: {e}")
            return False
    
    async def delete_webhook(self) -> bool:
        """Delete webhook."""
        try:
            await self._make_request("deleteWebhook", {})
            return True
        except Exception as e:
            logger.error(f"Failed to delete webhook: {e}")
            return False
    
    async def get_updates(self, offset: Optional[int] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """Get updates from Telegram."""
        try:
            payload = {"limit": limit}
            if offset:
                payload["offset"] = offset
            
            result = await self._make_request("getUpdates", payload)
            return result
            
        except Exception as e:
            logger.error(f"Failed to get updates: {e}")
            return []
