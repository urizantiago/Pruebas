"""
NexusAI Enterprise - Infrastructure Entities
=============================================
Servidores, bases de datos y otros recursos de infraestructura.
Con encriptación de credenciales y gestión de secretos.
"""
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Optional, List, Dict, Any
import uuid

from .tenant import TenantId


# ==================== SERVER ====================

class ServerStatus(Enum):
    """Estado del servidor."""
    ONLINE = auto()
    OFFLINE = auto()
    MAINTENANCE = auto()
    DEGRADED = auto()
    PROVISIONING = auto()
    DECOMMISSIONING = auto()


class ServerType(Enum):
    """Tipo de servidor."""
    PHYSICAL = "physical"
    VIRTUAL_MACHINE = "vm"
    CONTAINER = "container"
    BARE_METAL = "bare_metal"
    SERVERLESS = "serverless"


class OSType(Enum):
    """Sistema operativo."""
    WINDOWS_SERVER = "windows_server"
    REDHAT_ENTERPRISE = "rhel"
    UBUNTU = "ubuntu"
    DEBIAN = "debian"
    SUSE = "suse"
    AIX = "aix"
    SOLARIS = "solaris"
    VMWARE_ESXI = "esxi"


@dataclass
class ServerSpecs:
    """Especificaciones del servidor."""
    cpu_cores: int = 0
    cpu_model: Optional[str] = None
    memory_gb: float = 0.0
    disk_gb: float = 0.0
    disk_type: str = "ssd"  # ssd, hdd, nvme
    network_interfaces: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class ServerConnection:
    """Configuración de conexión (credenciales en Vault)."""
    host: str
    port: int
    protocol: str  # ssh, winrm, ipmi
    
    # Referencias a secretos en Vault (no credenciales reales)
    vault_secret_path: Optional[str] = None
    vault_role: Optional[str] = None
    
    # Configuración adicional
    connection_timeout: int = 30
    command_timeout: int = 300
    bastion_host: Optional[str] = None
    use_jump_host: bool = False


@dataclass
class Server:
    """Servidor físico o virtual."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    tenant_id: Optional[TenantId] = None
    
    # Identificación
    hostname: str = ""
    display_name: str = ""
    asset_tag: Optional[str] = None
    
    # Clasificación
    server_type: ServerType = ServerType.VIRTUAL_MACHINE
    os_type: OSType = OSType.UBUNTU
    os_version: str = ""
    
    # Conexión
    connection: Optional[ServerConnection] = None
    
    # Especificaciones
    specs: ServerSpecs = field(default_factory=ServerSpecs)
    
    # Estado
    status: ServerStatus = ServerStatus.OFFLINE
    last_seen: Optional[datetime] = None
    uptime_seconds: int = 0
    
    # Roles
    roles: List[str] = field(default_factory=list)  # web, app, db, cache
    
    # Monitoreo
    monitoring_agent_installed: bool = False
    prometheus_exporter: bool = False
    telegraf_agent: bool = False
    
    # Seguridad
    patch_management_enabled: bool = True
    last_patch_date: Optional[datetime] = None
    antivirus_installed: bool = False
    edr_installed: bool = False  # Endpoint Detection & Response
    
    # Metadata
    data_center: Optional[str] = None
    rack: Optional[str] = None
    region: Optional[str] = None
    availability_zone: Optional[str] = None
    
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    tags: List[str] = field(default_factory=list)
    
    def is_accessible(self) -> bool:
        """Verifica si el servidor está accesible."""
        return self.status in [ServerStatus.ONLINE, ServerStatus.DEGRADED]
    
    def get_safe_info(self) -> Dict[str, Any]:
        """Retorna información segura (sin credenciales)."""
        return {
            "id": self.id,
            "hostname": self.hostname,
            "display_name": self.display_name,
            "type": self.server_type.value,
            "os": self.os_type.value,
            "status": self.status.name,
            "roles": self.roles,
            "region": self.region
        }


# ==================== DATABASE ====================

class DatabaseType(Enum):
    """Tipo de base de datos."""
    POSTGRESQL = "postgresql"
    MYSQL = "mysql"
    MARIADB = "mariadb"
    SQL_SERVER = "sql_server"
    ORACLE = "oracle"
    DB2 = "db2"
    MONGODB = "mongodb"
    REDIS = "redis"
    ELASTICSEARCH = "elasticsearch"
    CASSANDRA = "cassandra"
    COCKROACHDB = "cockroachdb"
    SNOWFLAKE = "snowflake"
    BIGQUERY = "bigquery"
    REDSHIFT = "redshift"


class DatabaseStatus(Enum):
    """Estado de la base de datos."""
    ONLINE = auto()
    OFFLINE = auto()
    RECOVERING = auto()
    BACKUP_IN_PROGRESS = auto()
    MAINTENANCE = auto()
    READ_ONLY = auto()


@dataclass
class DatabaseConnection:
    """Configuración de conexión a BD."""
    host: str
    port: int
    database_name: str
    
    # Pool de conexiones
    pool_size: int = 5
    max_overflow: int = 10
    pool_timeout: int = 30
    
    # SSL/TLS
    ssl_mode: str = "require"  # disable, allow, prefer, require, verify-ca, verify-full
    ssl_root_cert_path: Optional[str] = None
    
    # Referencias a Vault
    vault_secret_path: Optional[str] = None
    
    # Performance
    query_timeout: int = 300
    statement_timeout: int = 60000


@dataclass
class Database:
    """Base de datos con configuración enterprise."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    tenant_id: Optional[TenantId] = None
    
    # Identificación
    name: str = ""
    display_name: str = ""
    db_type: DatabaseType = DatabaseType.POSTGRESQL
    version: Optional[str] = None
    
    # Conexión
    connection: Optional[DatabaseConnection] = None
    
    # Estado
    status: DatabaseStatus = DatabaseStatus.OFFLINE
    is_primary: bool = True
    replication_lag_ms: Optional[int] = None
    
    # Tamaño
    size_gb: Optional[float] = None
    
    # Performance
    max_connections: int = 100
    shared_buffers_mb: Optional[int] = None
    
    # Seguridad
    encryption_at_rest: bool = True
    encryption_in_transit: bool = True
    audit_logging_enabled: bool = True
    
    # Backup
    backup_enabled: bool = True
    backup_frequency: str = "daily"  # hourly, daily, weekly
    last_backup_at: Optional[datetime] = None
    
    # Metadata
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    tags: List[str] = field(default_factory=list)
    
    def get_safe_info(self) -> Dict[str, Any]:
        """Retorna información segura."""
        return {
            "id": self.id,
            "name": self.name,
            "display_name": self.display_name,
            "type": self.db_type.value,
            "status": self.status.name,
            "is_primary": self.is_primary,
            "size_gb": self.size_gb
        }


# ==================== API ENDPOINT ====================

@dataclass
class APIEndpoint:
    """Endpoint de API para monitoreo."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    url: str = ""
    method: str = "GET"
    
    # Health check
    health_check_enabled: bool = True
    health_check_path: str = "/health"
    expected_status_code: int = 200
    
    # Autenticación
    auth_type: str = "none"  # none, bearer, api_key, oauth
    auth_config: Dict[str, Any] = field(default_factory=dict)
    
    # Alertas
    alert_on_timeout: bool = True
    timeout_threshold_ms: int = 5000
    alert_on_error: bool = True
