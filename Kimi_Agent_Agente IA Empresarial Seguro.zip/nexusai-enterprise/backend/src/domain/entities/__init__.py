"""
NexusAI Enterprise - Domain Entities
=====================================
Entidades del dominio siguiendo DDD (Domain Driven Design).
"""

from .tenant import Tenant, TenantId, TenantStatus, TenantTier, TenantSettings
from .user import User, UserId, UserStatus, UserRole, MFAConfig, SSOConfig
from .application import Application, ApplicationId, ApplicationStatus, ApplicationCriticality
from .infrastructure import Server, Database, ServerStatus, DatabaseStatus
from .skill import Skill, SkillExecution, SkillCategory, SkillRiskLevel, SkillParameter
from .audit import AuditRecord, AuditEventType, AuditSeverity, AuditContext

__all__ = [
    # Tenant
    "Tenant", "TenantId", "TenantStatus", "TenantTier", "TenantSettings",
    
    # User
    "User", "UserId", "UserStatus", "UserRole", "MFAConfig", "SSOConfig",
    
    # Application
    "Application", "ApplicationId", "ApplicationStatus", "ApplicationCriticality",
    
    # Infrastructure
    "Server", "Database", "ServerStatus", "DatabaseStatus",
    
    # Skill
    "Skill", "SkillExecution", "SkillCategory", "SkillRiskLevel", "SkillParameter",
    
    # Audit
    "AuditRecord", "AuditEventType", "AuditSeverity", "AuditContext",
]
