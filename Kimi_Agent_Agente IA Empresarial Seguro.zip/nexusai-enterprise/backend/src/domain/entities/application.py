"""
NexusAI Enterprise - Entity: Application
=========================================
Aplicación empresarial con recursos asociados.
Soporta arquitecturas monolíticas, microservicios y serverless.
"""
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Optional, List, Dict, Any
import uuid

from .tenant import TenantId


class ApplicationStatus(Enum):
    """Estados del ciclo de vida de una aplicación."""
    DEVELOPMENT = auto()
    TESTING = auto()
    STAGING = auto()
    PRODUCTION = auto()
    MAINTENANCE = auto()
    DECOMMISSIONED = auto()
    ARCHIVED = auto()


class ApplicationCriticality(Enum):
    """Nivel crítico para el negocio."""
    TIER_1_MISSION_CRITICAL = 1  # Afecta operación, ingresos, cumplimiento
    TIER_2_BUSINESS_CRITICAL = 2  # Impacta productividad, clientes
    TIER_3_BUSINESS_STANDARD = 3  # Funcionalidad importante
    TIER_4_LOW_PRIORITY = 4  # Nice to have


class ApplicationType(Enum):
    """Tipo de arquitectura."""
    MONOLITH = "monolith"
    MICROSERVICES = "microservices"
    SERVERLESS = "serverless"
    MAINFRAME = "mainframe"
    LEGACY = "legacy"
    HYBRID = "hybrid"


@dataclass(frozen=True)
class ApplicationId:
    """Value Object para ID de aplicación."""
    value: str
    tenant_id: TenantId
    
    def __str__(self) -> str:
        return f"{self.tenant_id}:{self.value}"


@dataclass
class SLADefinition:
    """Definición de SLA para la aplicación."""
    availability_percent: float = 99.9
    max_downtime_minutes_monthly: int = 43  # 99.9%
    rto_minutes: int = 60  # Recovery Time Objective
    rpo_minutes: int = 15  # Recovery Point Objective
    
    response_time_p50_ms: int = 200
    response_time_p95_ms: int = 500
    response_time_p99_ms: int = 1000
    
    support_hours: str = "24/7"
    escalation_matrix: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class ApplicationResource:
    """Recurso asociado a la aplicación."""
    resource_type: str  # database, server, cache, queue, api
    resource_id: str
    role: str  # primary, replica, cache, etc.
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Application:
    """
    Entidad Application con capacidades enterprise:
    - Definición de SLA completo
    - Escalación automática
    - Monitoreo integrado
    - Documentación técnica
    """
    id: ApplicationId
    code: str  # Código único ej: "ERP_PROD", "CRM_API"
    name: str
    description: Optional[str] = None
    
    # Clasificación
    status: ApplicationStatus = ApplicationStatus.DEVELOPMENT
    criticality: ApplicationCriticality = ApplicationCriticality.TIER_3_BUSINESS_STANDARD
    app_type: ApplicationType = ApplicationType.MICROSERVICES
    
    # Propiedad
    owner_team: Optional[str] = None
    technical_owner: Optional[str] = None
    business_owner: Optional[str] = None
    support_group: Optional[str] = None
    
    # Tecnología
    primary_language: Optional[str] = None
    framework: Optional[str] = None
    runtime: Optional[str] = None  # JVM, Node.js, Python, .NET
    
    # Recursos
    resources: List[ApplicationResource] = field(default_factory=list)
    
    # SLA
    sla: SLADefinition = field(default_factory=SLADefinition)
    
    # Configuración
    config: Dict[str, Any] = field(default_factory=dict)
    secrets: Dict[str, str] = field(default_factory=dict)  # Referencias a Vault
    feature_flags: Dict[str, bool] = field(default_factory=dict)
    
    # Documentación
    documentation_url: Optional[str] = None
    runbook_url: Optional[str] = None
    architecture_diagram_url: Optional[str] = None
    
    # Monitoreo
    monitoring_enabled: bool = True
    alert_channels: List[str] = field(default_factory=list)
    custom_metrics: List[str] = field(default_factory=list)
    
    # Metadata
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    deployed_at: Optional[datetime] = None
    tags: List[str] = field(default_factory=list)
    
    def add_resource(self, resource_type: str, resource_id: str, role: str = "primary") -> None:
        """Agrega un recurso a la aplicación."""
        resource = ApplicationResource(
            resource_type=resource_type,
            resource_id=resource_id,
            role=role
        )
        self.resources.append(resource)
    
    def get_databases(self) -> List[ApplicationResource]:
        """Obtiene bases de datos asociadas."""
        return [r for r in self.resources if r.resource_type == "database"]
    
    def get_servers(self) -> List[ApplicationResource]:
        """Obtiene servidores asociados."""
        return [r for r in self.resources if r.resource_type == "server"]
    
    def is_production(self) -> bool:
        """Verifica si está en producción."""
        return self.status == ApplicationStatus.PRODUCTION
    
    def is_critical(self) -> bool:
        """Verifica si es misión crítica."""
        return self.criticality == ApplicationCriticality.TIER_1_MISSION_CRITICAL
    
    def requires_approval_for_changes(self) -> bool:
        """Determina si cambios requieren aprobación."""
        return self.is_production() or self.is_critical()
    
    def to_context_dict(self) -> Dict[str, Any]:
        """Convierte a diccionario para contexto de IA."""
        return {
            "code": self.code,
            "name": self.name,
            "type": self.app_type.value,
            "status": self.status.name,
            "criticality": self.criticality.name,
            "resources": {
                "databases": len(self.get_databases()),
                "servers": len(self.get_servers())
            },
            "sla": {
                "availability": self.sla.availability_percent,
                "rto": self.sla.rto_minutes
            }
        }
