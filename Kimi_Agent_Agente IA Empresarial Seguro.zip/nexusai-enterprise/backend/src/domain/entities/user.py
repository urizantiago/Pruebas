"""
NexusAI Enterprise - Entity: User
==================================
Usuario del sistema con autenticación empresarial.
Soporta SSO, MFA, y RBAC avanzado.
"""
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum, auto
from typing import Optional, List, Dict, Any, Set
import uuid

from .tenant import TenantId


class UserStatus(Enum):
    """Estados del usuario."""
    ACTIVE = auto()
    INACTIVE = auto()
    SUSPENDED = auto()
    PENDING_MFA_SETUP = auto()
    PASSWORD_EXPIRED = auto()
    LOCKED_OUT = auto()


class UserRole(Enum):
    """Roles predefinidos del sistema."""
    # Administración
    TENANT_ADMIN = "tenant_admin"           # Admin del tenant
    SYSTEM_ADMIN = "system_admin"           # Admin global (solo staff)
    
    # Operaciones
    SRE_ENGINEER = "sre_engineer"           # Site Reliability Engineer
    PLATFORM_ENGINEER = "platform_engineer" # Infraestructura
    DATABASE_ADMIN = "database_admin"       # Administrador BD
    SECURITY_ENGINEER = "security_engineer" # Seguridad
    
    # Soporte
    L1_SUPPORT = "l1_support"               # Soporte nivel 1
    L2_SUPPORT = "l2_support"               # Soporte nivel 2
    L3_SUPPORT = "l3_support"               # Soporte nivel 3 (experto)
    
    # Cumplimiento
    AUDITOR = "auditor"                     # Auditor interno/externo
    COMPLIANCE_OFFICER = "compliance_officer"  # Oficial de cumplimiento
    
    # Solo lectura
    READONLY = "readonly"                   # Acceso de solo lectura
    EXECUTIVE = "executive"                 # Dashboards y reportes


@dataclass(frozen=True)
class UserId:
    """Value Object para ID de usuario."""
    value: str
    tenant_id: TenantId
    
    def __str__(self) -> str:
        return f"{self.tenant_id}:{self.value}"


@dataclass
class MFAConfig:
    """Configuración de autenticación multifactor."""
    enabled: bool = False
    method: str = "totp"  # totp, sms, email, hardware_key, push
    secret: Optional[str] = None
    backup_codes: List[str] = field(default_factory=list)
    last_verified: Optional[datetime] = None
    devices: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class SSOConfig:
    """Configuración de Single Sign-On."""
    enabled: bool = False
    provider: Optional[str] = None  # azure_ad, okta, google_workspace
    external_id: Optional[str] = None
    last_sync: Optional[datetime] = None
    attributes: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SessionInfo:
    """Información de sesión activa."""
    session_id: str
    created_at: datetime
    expires_at: datetime
    ip_address: str
    user_agent: str
    mfa_verified: bool = False
    device_fingerprint: Optional[str] = None


@dataclass
class User:
    """
    Entidad User con capacidades enterprise:
    - Multi-tenant con aislamiento completo
    - SSO/SAML/OIDC integration
    - MFA con múltiples métodos
    - RBAC granular con permisos
    - Auditoría completa de acciones
    """
    id: UserId
    email: str
    username: str
    full_name: str
    
    # Perfil
    title: Optional[str] = None
    department: Optional[str] = None
    employee_id: Optional[str] = None
    avatar_url: Optional[str] = None
    timezone: str = "UTC"
    locale: str = "en-US"
    
    # Autenticación
    password_hash: Optional[str] = None
    password_changed_at: Optional[datetime] = None
    password_expires_at: Optional[datetime] = None
    mfa: MFAConfig = field(default_factory=MFAConfig)
    sso: SSOConfig = field(default_factory=SSOConfig)
    
    # Autorización
    roles: List[UserRole] = field(default_factory=list)
    custom_permissions: Set[str] = field(default_factory=set)
    forbidden_skills: Set[str] = field(default_factory=set)
    allowed_applications: List[str] = field(default_factory=list)
    
    # Estado
    status: UserStatus = UserStatus.PENDING_MFA_SETUP
    email_verified: bool = False
    last_login_at: Optional[datetime] = None
    last_login_ip: Optional[str] = None
    login_attempts: int = 0
    locked_until: Optional[datetime] = None
    
    # Sesiones
    active_sessions: List[SessionInfo] = field(default_factory=list)
    max_concurrent_sessions: int = 3
    
    # Auditoría
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    created_by: Optional[str] = None
    
    # Preferencias
    notification_preferences: Dict[str, Any] = field(default_factory=dict)
    dashboard_layout: Dict[str, Any] = field(default_factory=dict)
    
    def is_active(self) -> bool:
        """Verifica si el usuario está activo."""
        if self.status != UserStatus.ACTIVE:
            return False
        if self.locked_until and self.locked_until > datetime.utcnow():
            return False
        return True
    
    def has_role(self, role: UserRole) -> bool:
        """Verifica si el usuario tiene un rol."""
        return role in self.roles
    
    def has_any_role(self, roles: List[UserRole]) -> bool:
        """Verifica si tiene alguno de los roles."""
        return any(r in self.roles for r in roles)
    
    def has_permission(self, permission: str) -> bool:
        """Verifica permiso específico."""
        # Admin implícito tiene todos los permisos
        if UserRole.TENANT_ADMIN in self.roles or UserRole.SYSTEM_ADMIN in self.roles:
            return True
        return permission in self.custom_permissions
    
    def can_execute_skill(self, skill_code: str, skill_category: str, is_destructive: bool = False) -> bool:
        """Verifica si puede ejecutar un skill."""
        if not self.is_active():
            return False
        
        # Verificar forbiddens
        if skill_code in self.forbidden_skills:
            return False
        
        # Skills destructivos solo para roles específicos
        if is_destructive:
            allowed = [
                UserRole.TENANT_ADMIN,
                UserRole.SYSTEM_ADMIN,
                UserRole.SRE_ENGINEER,
                UserRole.DATABASE_ADMIN
            ]
            return self.has_any_role(allowed)
        
        # L1 solo puede ejecutar skills básicos
        if UserRole.L1_SUPPORT in self.roles:
            return skill_category in ["readonly", "monitoring", "basic_diagnostics"]
        
        # L2 puede más
        if UserRole.L2_SUPPORT in self.roles:
            return skill_category not in ["destructive", "security_critical"]
        
        # L3 puede casi todo
        if UserRole.L3_SUPPORT in self.roles:
            return True
        
        return True
    
    def can_access_application(self, app_code: str) -> bool:
        """Verifica acceso a aplicación."""
        if not self.allowed_applications:
            return True  # Sin restricciones = todas
        return app_code in self.allowed_applications
    
    def record_login(self, ip: str, user_agent: str, session_id: str) -> None:
        """Registra un login exitoso."""
        self.last_login_at = datetime.utcnow()
        self.last_login_ip = ip
        self.login_attempts = 0
        
        # Agregar sesión
        session = SessionInfo(
            session_id=session_id,
            created_at=datetime.utcnow(),
            expires_at=datetime.utcnow() + timedelta(hours=8),
            ip_address=ip,
            user_agent=user_agent
        )
        self.active_sessions.append(session)
        
        # Limitar sesiones concurrentes
        if len(self.active_sessions) > self.max_concurrent_sessions:
            self.active_sessions = self.active_sessions[-self.max_concurrent_sessions:]
    
    def record_failed_login(self) -> bool:
        """Registra intento fallido. Retorna True si debe bloquearse."""
        self.login_attempts += 1
        
        # Bloquear después de 5 intentos
        if self.login_attempts >= 5:
            self.locked_until = datetime.utcnow() + timedelta(minutes=30)
            self.status = UserStatus.LOCKED_OUT
            return True
        
        return False
    
    def to_audit_dict(self) -> Dict[str, Any]:
        """Convierte a diccionario para auditoría."""
        return {
            "user_id": str(self.id),
            "email": self.email,
            "username": self.username,
            "roles": [r.value for r in self.roles],
            "department": self.department,
            "tenant_id": str(self.id.tenant_id)
        }
