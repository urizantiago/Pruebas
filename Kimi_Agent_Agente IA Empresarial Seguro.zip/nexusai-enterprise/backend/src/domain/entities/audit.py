"""
NexusAI Enterprise - Entity: Audit
====================================
Sistema de auditoría inmutable para cumplimiento.
Cumple con ISO 27001, SOC 2, GDPR.
"""
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Optional, List, Dict, Any
import uuid
import hashlib
import json

from .tenant import TenantId


class AuditEventType(Enum):
    """Tipos de eventos auditables."""
    # Autenticación
    AUTH_LOGIN_SUCCESS = "auth.login.success"
    AUTH_LOGIN_FAILURE = "auth.login.failure"
    AUTH_LOGOUT = "auth.logout"
    AUTH_MFA_VERIFIED = "auth.mfa.verified"
    AUTH_MFA_FAILED = "auth.mfa.failed"
    AUTH_TOKEN_REFRESHED = "auth.token.refreshed"
    AUTH_SESSION_EXPIRED = "auth.session.expired"
    
    # Autorización
    ACCESS_DENIED = "access.denied"
    PERMISSION_GRANTED = "permission.granted"
    ROLE_ASSIGNED = "role.assigned"
    ROLE_REVOKED = "role.revoked"
    
    # Skills
    SKILL_EXECUTION_STARTED = "skill.execution.started"
    SKILL_EXECUTION_COMPLETED = "skill.execution.completed"
    SKILL_EXECUTION_FAILED = "skill.execution.failed"
    SKILL_APPROVAL_REQUESTED = "skill.approval.requested"
    SKILL_APPROVAL_GRANTED = "skill.approval.granted"
    SKILL_APPROVAL_DENIED = "skill.approval.denied"
    
    # Datos
    DATA_ACCESSED = "data.accessed"
    DATA_EXPORTED = "data.exported"
    DATA_MODIFIED = "data.modified"
    DATA_DELETED = "data.deleted"
    
    # Infraestructura
    SERVER_CONNECTED = "server.connected"
    SERVER_COMMAND_EXECUTED = "server.command.executed"
    DATABASE_QUERIED = "database.queried"
    DATABASE_MODIFIED = "database.modified"
    
    # Configuración
    CONFIG_CHANGED = "config.changed"
    USER_CREATED = "user.created"
    USER_UPDATED = "user.updated"
    USER_DELETED = "user.deleted"
    TENANT_CREATED = "tenant.created"
    
    # Seguridad
    SECURITY_ALERT = "security.alert"
    SUSPICIOUS_ACTIVITY = "security.suspicious"
    POLICY_VIOLATION = "security.policy_violation"


class AuditSeverity(Enum):
    """Severidad del evento."""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"
    SECURITY = "security"


class DataClassification(Enum):
    """Clasificación de datos involucrados."""
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"


@dataclass
class AuditContext:
    """Contexto del evento de auditoría."""
    # Ubicación
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    geolocation: Optional[Dict[str, Any]] = None
    
    # Dispositivo
    device_id: Optional[str] = None
    device_fingerprint: Optional[str] = None
    
    # Sesión
    session_id: Optional[str] = None
    correlation_id: Optional[str] = None
    request_id: Optional[str] = None
    
    # Entorno
    environment: str = "production"  # development, staging, production
    region: Optional[str] = None
    availability_zone: Optional[str] = None


@dataclass
class AuditData:
    """Datos del evento de auditoría."""
    # Entrada
    request_data: Dict[str, Any] = field(default_factory=dict)
    
    # Salida
    response_data: Dict[str, Any] = field(default_factory=dict)
    
    # Cambios
    changes: List[Dict[str, Any]] = field(default_factory=list)
    # Ej: [{"field": "status", "old": "active", "new": "inactive"}]
    
    # Metadatos
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # Clasificación
    data_classification: DataClassification = DataClassification.INTERNAL
    contains_pii: bool = False
    contains_phi: bool = False  # Protected Health Information (HIPAA)


@dataclass
class AuditRecord:
    """
    Registro de auditoría inmutable.
    
    Características:
    - Inmutabilidad: Una vez creado, no se puede modificar
    - Integridad: Hash criptográfico para detectar alteraciones
    - Cadena: Referencia al registro anterior (blockchain-like)
    - Retención: Configurable por políticas de cumplimiento
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    
    # Identificación
    event_type: AuditEventType = AuditEventType.DATA_ACCESSED
    severity: AuditSeverity = AuditSeverity.INFO
    
    # Tenant y Usuario
    tenant_id: Optional[TenantId] = None
    user_id: Optional[str] = None
    user_email: Optional[str] = None
    user_roles: List[str] = field(default_factory=list)
    impersonated_by: Optional[str] = None  # Para casos de suplantación
    
    # Recurso afectado
    resource_type: Optional[str] = None  # skill, server, database, user
    resource_id: Optional[str] = None
    resource_name: Optional[str] = None
    
    # Contexto
    context: AuditContext = field(default_factory=AuditContext)
    
    # Datos
    data: AuditData = field(default_factory=AuditData)
    
    # Timestamp
    timestamp: datetime = field(default_factory=datetime.utcnow)
    
    # Integridad
    previous_hash: Optional[str] = None  # Hash del registro anterior
    hash: Optional[str] = None  # Hash de este registro
    signature: Optional[str] = None  # Firma digital
    
    # Retención
    retention_until: Optional[datetime] = None
    
    def compute_hash(self) -> str:
        """Calcula hash criptográfico del registro."""
        # Crear representación canónica
        data = {
            "id": self.id,
            "event_type": self.event_type.value,
            "timestamp": self.timestamp.isoformat(),
            "tenant_id": str(self.tenant_id) if self.tenant_id else None,
            "user_id": self.user_id,
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "previous_hash": self.previous_hash
        }
        
        canonical = json.dumps(data, sort_keys=True, default=str)
        return hashlib.sha256(canonical.encode()).hexdigest()
    
    def verify_integrity(self) -> bool:
        """Verifica integridad del registro."""
        if not self.hash:
            return False
        return self.compute_hash() == self.hash
    
    def is_security_event(self) -> bool:
        """Verifica si es evento de seguridad."""
        return (
            self.severity in [AuditSeverity.CRITICAL, AuditSeverity.SECURITY]
            or self.event_type in [
                AuditEventType.AUTH_LOGIN_FAILURE,
                AuditEventType.ACCESS_DENIED,
                AuditEventType.SUSPICIOUS_ACTIVITY,
                AuditEventType.SECURITY_ALERT
            ]
        )
    
    def to_export_dict(self, include_sensitive: bool = False) -> Dict[str, Any]:
        """Convierte a diccionario para exportación."""
        result = {
            "id": self.id,
            "event_type": self.event_type.value,
            "severity": self.severity.value,
            "timestamp": self.timestamp.isoformat(),
            "resource_type": self.resource_type,
            "resource_name": self.resource_name,
            "hash": self.hash
        }
        
        if include_sensitive:
            result.update({
                "user_id": self.user_id,
                "user_email": self.user_email,
                "request_data": self.data.request_data,
                "response_data": self.data.response_data,
                "changes": self.data.changes
            })
        
        return result


@dataclass
class AuditRetentionPolicy:
    """Política de retención de auditoría."""
    name: str
    description: str
    
    # Reglas
    retention_days: int = 2555  # 7 años por defecto
    
    # Por severidad
    critical_retention_days: int = 3650  # 10 años
    security_retention_days: int = 3650
    error_retention_days: int = 2555
    warning_retention_days: int = 1095  # 3 años
    info_retention_days: int = 365  # 1 año
    
    # Archivado
    archive_after_days: int = 90
    archive_location: str = "s3://audit-archive/"
    
    # Eliminación
    allow_deletion: bool = False  # Compliance: nunca eliminar
    deletion_requires_approval: bool = True
