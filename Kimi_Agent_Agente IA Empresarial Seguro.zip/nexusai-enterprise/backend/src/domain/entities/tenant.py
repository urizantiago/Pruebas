"""
NexusAI Enterprise - Entity: Tenant
=====================================
Representa una organización/tenant en el sistema multi-tenant.
Cumple con requisitos de aislamiento de datos empresarial.
"""
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Optional, List, Dict, Any
import uuid


class TenantStatus(Enum):
    """Estados posibles de un tenant."""
    ACTIVE = auto()
    SUSPENDED = auto()
    PENDING_ONBOARDING = auto()
    GRACE_PERIOD = auto()
    TERMINATED = auto()


class TenantTier(Enum):
    """Niveles de servicio del tenant."""
    STARTUP = "startup"           # Hasta 10 usuarios
    BUSINESS = "business"         # Hasta 100 usuarios
    ENTERPRISE = "enterprise"     # Hasta 1000 usuarios
    MISSION_CRITICAL = "critical" # Ilimitado, SLA 99.999%


@dataclass(frozen=True)
class TenantId:
    """Value Object para identificación de tenant."""
    value: str
    
    def __post_init__(self):
        if not self.value or len(self.value) < 3:
            raise ValueError("Tenant ID debe tener al menos 3 caracteres")
    
    def __str__(self) -> str:
        return self.value


@dataclass
class TenantSettings:
    """Configuración específica del tenant."""
    # Seguridad
    mfa_required: bool = True
    password_policy: str = "enterprise"  # enterprise, standard, basic
    session_timeout_minutes: int = 30
    ip_whitelist_enabled: bool = False
    ip_whitelist: List[str] = field(default_factory=list)
    
    # AI
    ai_providers_allowed: List[str] = field(default_factory=lambda: ["azure-openai"])
    max_tokens_per_request: int = 4000
    rate_limit_requests_per_minute: int = 100
    
    # Skills
    allowed_skill_categories: List[str] = field(default_factory=list)
    forbidden_skills: List[str] = field(default_factory=list)
    require_approval_for: List[str] = field(default_factory=lambda: ["destructive", "data_modification"])
    
    # Auditoría
    audit_retention_days: int = 2555  # 7 años
    audit_real_time_alerts: bool = True
    
    # Notificaciones
    notification_channels: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Tenant:
    """
    Entidad raíz de agregado Tenant.
    
    Representa una organización completa con:
    - Aislamiento completo de datos
    - Configuración personalizada
    - Cuotas y límites
    - Auditoría independiente
    """
    id: TenantId
    name: str
    legal_name: str
    tax_id: Optional[str] = None
    
    # Contacto
    primary_contact_email: str = ""
    primary_contact_phone: Optional[str] = None
    technical_contact_email: Optional[str] = None
    security_contact_email: Optional[str] = None
    
    # Configuración
    tier: TenantTier = TenantTier.BUSINESS
    status: TenantStatus = TenantStatus.PENDING_ONBOARDING
    settings: TenantSettings = field(default_factory=TenantSettings)
    
    # Metadata
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    onboarded_at: Optional[datetime] = None
    billing_start_date: Optional[datetime] = None
    
    # Cuotas
    max_users: int = 100
    max_applications: int = 50
    max_database_connections: int = 100
    max_monthly_executions: int = 100000
    
    # Features
    features_enabled: List[str] = field(default_factory=list)
    custom_branding: Dict[str, Any] = field(default_factory=dict)
    
    # Compliance
    data_residency: str = "us-east-1"  # Región AWS/Azure/GCP
    compliance_frameworks: List[str] = field(default_factory=list)
    
    def is_active(self) -> bool:
        """Verifica si el tenant está activo."""
        return self.status == TenantStatus.ACTIVE
    
    def can_execute_skill(self, skill_category: str, skill_code: str) -> bool:
        """Verifica si el tenant puede ejecutar un skill específico."""
        if skill_code in self.settings.forbidden_skills:
            return False
        
        if self.settings.allowed_skill_categories:
            return skill_category in self.settings.allowed_skill_categories
        
        return True
    
    def requires_approval(self, action_type: str) -> bool:
        """Determina si una acción requiere aprobación."""
        return action_type in self.settings.require_approval_for
    
    def to_audit_dict(self) -> Dict[str, Any]:
        """Convierte a diccionario para auditoría."""
        return {
            "tenant_id": str(self.id),
            "name": self.name,
            "tier": self.tier.value,
            "status": self.status.name,
            "data_residency": self.data_residency
        }
