"""
NexusAI Enterprise - Entity: Skill
===================================
Habilidad/capacidad del agente de IA.
Sistema extensible de plugins con sandboxing.
"""
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Optional, List, Dict, Any, Callable
import uuid

from .tenant import TenantId


class SkillCategory(Enum):
    """Categorías de skills."""
    SERVER_OPERATIONS = "server_ops"
    DATABASE_OPERATIONS = "db_ops"
    NETWORK_OPERATIONS = "network_ops"
    SECURITY_OPERATIONS = "security_ops"
    MONITORING = "monitoring"
    TROUBLESHOOTING = "troubleshooting"
    AUTOMATION = "automation"
    COMPLIANCE = "compliance"
    REPORTING = "reporting"
    INTEGRATION = "integration"


class SkillLevel(Enum):
    """Nivel de complejidad."""
    L1_BASIC = 1
    L2_INTERMEDIATE = 2
    L3_ADVANCED = 3
    L4_EXPERT = 4


class SkillRiskLevel(Enum):
    """Nivel de riesgo de la operación."""
    NONE = "none"           # Solo lectura, no modifica nada
    LOW = "low"             # Cambios menores, reversibles
    MEDIUM = "medium"       # Cambios significativos
    HIGH = "high"           # Cambios críticos, puede afectar servicio
    CRITICAL = "critical"   # Cambios destructivos, requiere aprobación


class SkillStatus(Enum):
    """Estado del skill."""
    ACTIVE = auto()
    BETA = auto()
    DEPRECATED = auto()
    DISABLED = auto()
    PENDING_APPROVAL = auto()


@dataclass
class SkillParameter:
    """Parámetro de entrada del skill."""
    name: str
    type: str  # string, integer, float, boolean, array, object, enum
    description: str
    required: bool = True
    default: Any = None
    
    # Validación
    validation: Dict[str, Any] = field(default_factory=dict)
    # Ej: {"min": 1, "max": 100, "pattern": "^[a-z]+$"}
    
    # UI
    display_name: Optional[str] = None
    placeholder: Optional[str] = None
    help_text: Optional[str] = None
    
    # Opciones para enums
    options: List[Dict[str, Any]] = field(default_factory=list)
    # Ej: [{"value": "prod", "label": "Producción"}]


@dataclass
class SkillOutput:
    """Definición de salida del skill."""
    type: str  # json, table, text, chart, file
    schema: Optional[Dict[str, Any]] = None  # JSON Schema
    description: str = ""


@dataclass
class SkillPermissions:
    """Permisos requeridos para ejecutar el skill."""
    roles: List[str] = field(default_factory=list)
    permissions: List[str] = field(default_factory=list)
    
    # Restricciones
    forbidden_environments: List[str] = field(default_factory=list)
    allowed_tiers: List[str] = field(default_factory=list)
    
    # Aprobación
    requires_approval: bool = False
    approver_roles: List[str] = field(default_factory=list)


@dataclass
class Skill:
    """
    Entidad Skill con capacidades enterprise:
    - Versionado semántico
    - Sandbox de ejecución
    - Rollback automático
    - Métricas de performance
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    tenant_id: Optional[TenantId] = None
    
    # Identificación
    code: str = ""  # namespace.name ej: "server.analyze_logs"
    name: str = ""
    description: str = ""
    long_description: Optional[str] = None
    
    # Clasificación
    category: SkillCategory = SkillCategory.SERVER_OPERATIONS
    level: SkillLevel = SkillLevel.L2_INTERMEDIATE
    risk_level: SkillRiskLevel = SkillRiskLevel.NONE
    status: SkillStatus = SkillStatus.ACTIVE
    
    # Versionado
    version: str = "1.0.0"
    changelog: List[Dict[str, Any]] = field(default_factory=list)
    
    # Configuración
    parameters: List[SkillParameter] = field(default_factory=list)
    output: SkillOutput = field(default_factory=lambda: SkillOutput(type="json"))
    permissions: SkillPermissions = field(default_factory=SkillPermissions)
    
    # Ejecución
    timeout_seconds: int = 300
    max_retries: int = 3
    retry_delay_seconds: int = 5
    
    # Seguridad
    sandbox_enabled: bool = True
    allowed_network_access: bool = False
    allowed_file_system_access: bool = False
    allowed_environment_variables: List[str] = field(default_factory=list)
    
    # Recursos soportados
    supported_databases: List[str] = field(default_factory=list)
    supported_servers: List[str] = field(default_factory=list)
    
    # Documentación
    documentation_url: Optional[str] = None
    examples: List[Dict[str, Any]] = field(default_factory=list)
    
    # Metadata
    author: str = ""
    author_email: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    
    def is_active(self) -> bool:
        """Verifica si el skill está activo."""
        return self.status == SkillStatus.ACTIVE
    
    def is_read_only(self) -> bool:
        """Verifica si es de solo lectura."""
        return self.risk_level == SkillRiskLevel.NONE
    
    def requires_approval(self, environment: str) -> bool:
        """Determina si requiere aprobación."""
        if self.permissions.requires_approval:
            return True
        if self.risk_level in [SkillRiskLevel.HIGH, SkillRiskLevel.CRITICAL]:
            return True
        if environment in self.permissions.forbidden_environments:
            return True
        return False
    
    def validate_parameters(self, params: Dict[str, Any]) -> tuple[bool, Optional[str]]:
        """Valida parámetros de entrada."""
        for param in self.parameters:
            if param.required and param.name not in params:
                return False, f"Parámetro requerido '{param.name}' no proporcionado"
            
            if param.name in params:
                value = params[param.name]
                
                # Validar tipo
                if param.type == "integer" and not isinstance(value, int):
                    return False, f"'{param.name}' debe ser entero"
                elif param.type == "float" and not isinstance(value, (int, float)):
                    return False, f"'{param.name}' debe ser numérico"
                elif param.type == "boolean" and not isinstance(value, bool):
                    return False, f"'{param.name}' debe ser booleano"
                elif param.type == "array" and not isinstance(value, list):
                    return False, f"'{param.name}' debe ser lista"
                
                # Validar rango
                if "min" in param.validation and value < param.validation["min"]:
                    return False, f"'{param.name}' debe ser >= {param.validation['min']}"
                if "max" in param.validation and value > param.validation["max"]:
                    return False, f"'{param.name}' debe ser <= {param.validation['max']}"
                
                # Validar patrón
                if "pattern" in param.validation and isinstance(value, str):
                    import re
                    if not re.match(param.validation["pattern"], value):
                        return False, f"'{param.name}' no cumple el formato requerido"
        
        return True, None
    
    def get_info(self) -> Dict[str, Any]:
        """Retorna información pública del skill."""
        return {
            "id": self.id,
            "code": self.code,
            "name": self.name,
            "description": self.description,
            "category": self.category.value,
            "level": self.level.name,
            "risk_level": self.risk_level.value,
            "version": self.version,
            "parameters": [
                {
                    "name": p.name,
                    "type": p.type,
                    "description": p.description,
                    "required": p.required
                }
                for p in self.parameters
            ]
        }


@dataclass
class SkillExecution:
    """Registro de ejecución de un skill."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    skill_id: str = ""
    skill_code: str = ""
    
    # Contexto
    tenant_id: Optional[TenantId] = None
    user_id: Optional[str] = None
    application_code: Optional[str] = None
    
    # Entrada/Salida
    parameters: Dict[str, Any] = field(default_factory=dict)
    result: Any = None
    error: Optional[str] = None
    
    # Métricas
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    duration_ms: int = 0
    
    # Estado
    status: str = "pending"  # pending, running, completed, failed, cancelled
    retry_count: int = 0
    
    # Seguridad
    approved_by: Optional[str] = None
    approved_at: Optional[datetime] = None
    approval_notes: Optional[str] = None
