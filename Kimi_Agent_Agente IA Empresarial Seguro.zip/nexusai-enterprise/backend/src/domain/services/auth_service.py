"""
NexusAI Enterprise - Authentication & Authorization Service
===========================================================
Servicio de autenticación y autorización.
Soporta JWT, SSO/SAML, MFA, RBAC.
"""
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Tuple
import jwt
from enum import Enum

from ..entities.user import User, UserRole, UserStatus
from ..entities.tenant import Tenant
from .security_service import SecurityService


class AuthResult(Enum):
    """Resultados de autenticación."""
    SUCCESS = "success"
    INVALID_CREDENTIALS = "invalid_credentials"
    USER_INACTIVE = "user_inactive"
    USER_LOCKED = "user_locked"
    MFA_REQUIRED = "mfa_required"
    MFA_INVALID = "mfa_invalid"
    TOKEN_EXPIRED = "token_expired"
    TOKEN_INVALID = "token_invalid"
    PERMISSION_DENIED = "permission_denied"


class AuthService:
    """
    Servicio de autenticación y autorización enterprise.
    
    Características:
    - JWT tokens con expiración
    - Refresh tokens rotativos
    - MFA con TOTP/SMS/hardware keys
    - SSO/SAML/OIDC integration
    - RBAC granular
    """
    
    def __init__(
        self,
        security_service: SecurityService,
        jwt_private_key: str,
        jwt_public_key: str,
        algorithm: str = "RS256",
        access_token_ttl_minutes: int = 30,
        refresh_token_ttl_days: int = 7,
        mfa_issuer: str = "NexusAI Enterprise"
    ):
        self._security = security_service
        self._jwt_private_key = jwt_private_key
        self._jwt_public_key = jwt_public_key
        self._algorithm = algorithm
        self._access_token_ttl = access_token_ttl_minutes
        self._refresh_token_ttl = refresh_token_ttl_days
        self._mfa_issuer = mfa_issuer
    
    # ==================== JWT TOKENS ====================
    
    def create_access_token(
        self,
        user: User,
        tenant: Tenant,
        additional_claims: Optional[Dict[str, Any]] = None
    ) -> str:
        """Crea token de acceso JWT."""
        now = datetime.utcnow()
        expires = now + timedelta(minutes=self._access_token_ttl)
        
        payload = {
            "sub": str(user.id),
            "email": user.email,
            "username": user.username,
            "tenant_id": str(tenant.id),
            "roles": [r.value for r in user.roles],
            "iat": now,
            "exp": expires,
            "type": "access",
            "jti": self._security.generate_secure_token(16),
            "mfa_verified": user.mfa.enabled and user.mfa.last_verified is not None
        }
        
        if additional_claims:
            payload.update(additional_claims)
        
        return jwt.encode(
            payload,
            self._jwt_private_key,
            algorithm=self._algorithm
        )
    
    def create_refresh_token(self, user: User, tenant: Tenant) -> str:
        """Crea token de refresco."""
        now = datetime.utcnow()
        expires = now + timedelta(days=self._refresh_token_ttl)
        
        payload = {
            "sub": str(user.id),
            "tenant_id": str(tenant.id),
            "iat": now,
            "exp": expires,
            "type": "refresh",
            "jti": self._security.generate_secure_token(16)
        }
        
        return jwt.encode(
            payload,
            self._jwt_private_key,
            algorithm=self._algorithm
        )
    
    def decode_token(self, token: str) -> Tuple[Optional[Dict[str, Any]], AuthResult]:
        """Decodifica y valida token JWT."""
        try:
            payload = jwt.decode(
                token,
                self._jwt_public_key,
                algorithms=[self._algorithm]
            )
            return payload, AuthResult.SUCCESS
        except jwt.ExpiredSignatureError:
            return None, AuthResult.TOKEN_EXPIRED
        except jwt.InvalidTokenError:
            return None, AuthResult.TOKEN_INVALID
    
    def verify_token(self, token: str, expected_type: str = "access") -> Tuple[Optional[Dict], AuthResult]:
        """Verifica token completo."""
        payload, result = self.decode_token(token)
        
        if result != AuthResult.SUCCESS:
            return None, result
        
        # Verificar tipo
        if payload.get("type") != expected_type:
            return None, AuthResult.TOKEN_INVALID
        
        return payload, AuthResult.SUCCESS
    
    # ==================== AUTENTICACIÓN ====================
    
    async def authenticate_password(
        self,
        user: User,
        password: str
    ) -> Tuple[AuthResult, Optional[str]]:
        """Autentica con contraseña."""
        # Verificar estado
        if not user.is_active():
            if user.status == UserStatus.LOCKED_OUT:
                return AuthResult.USER_LOCKED, None
            return AuthResult.USER_INACTIVE, None
        
        # Verificar contraseña
        if not self._security.verify_password(password, user.password_hash or ""):
            # Registrar intento fallido
            should_lock = user.record_failed_login()
            if should_lock:
                return AuthResult.USER_LOCKED, None
            return AuthResult.INVALID_CREDENTIALS, None
        
        # Verificar MFA
        if user.mfa.enabled:
            return AuthResult.MFA_REQUIRED, None
        
        return AuthResult.SUCCESS, None
    
    async def verify_mfa(
        self,
        user: User,
        token: str
    ) -> bool:
        """Verifica token MFA (TOTP)."""
        if not user.mfa.enabled or not user.mfa.secret:
            return False
        
        # En producción, usar pyotp
        # import pyotp
        # totp = pyotp.TOTP(user.mfa.secret)
        # return totp.verify(token)
        
        # Placeholder
        return True
    
    async def authenticate_sso(
        self,
        tenant: Tenant,
        provider: str,
        sso_token: str,
        user_info: Dict[str, Any]
    ) -> Tuple[AuthResult, Optional[User]]:
        """Autentica con SSO."""
        # Verificar que SSO está habilitado para el tenant
        if not tenant.settings.mfa_required:  # Placeholder check
            pass
        
        # Buscar o crear usuario
        external_id = user_info.get("sub") or user_info.get("id")
        email = user_info.get("email")
        
        # En producción, buscar en repositorio
        # user = await self._user_repo.get_by_sso_id(tenant.id, provider, external_id)
        
        # Placeholder
        return AuthResult.SUCCESS, None
    
    # ==================== AUTORIZACIÓN ====================
    
    def has_permission(
        self,
        user: User,
        permission: str
    ) -> bool:
        """Verifica si usuario tiene permiso."""
        return user.has_permission(permission)
    
    def has_any_permission(
        self,
        user: User,
        permissions: List[str]
    ) -> bool:
        """Verifica si tiene alguno de los permisos."""
        return any(user.has_permission(p) for p in permissions)
    
    def can_execute_skill(
        self,
        user: User,
        skill_code: str,
        skill_category: str,
        is_destructive: bool,
        environment: str
    ) -> Tuple[bool, Optional[str]]:
        """
        Verifica si puede ejecutar skill.
        
        Returns:
            (permitido, razón_si_no)
        """
        # Verificar usuario activo
        if not user.is_active():
            return False, "Usuario no activo"
        
        # Verificar permisos de skill
        if not user.can_execute_skill(skill_code, skill_category, is_destructive):
            return False, "No tiene permisos para ejecutar este skill"
        
        # Verificar entorno
        if environment == "production" and is_destructive:
            if not user.has_role(UserRole.TENANT_ADMIN):
                return False, "Cambios destructivos en producción requieren rol de administrador"
        
        return True, None
    
    def can_access_application(self, user: User, app_code: str) -> bool:
        """Verifica acceso a aplicación."""
        return user.can_access_application(app_code)
    
    def get_effective_permissions(self, user: User) -> List[str]:
        """Obtiene permisos efectivos del usuario."""
        permissions = set(user.custom_permissions)
        
        # Agregar permisos por rol
        role_permissions = {
            UserRole.TENANT_ADMIN: ["*"],  # Todos los permisos
            UserRole.SYSTEM_ADMIN: ["*"],
            UserRole.SRE_ENGINEER: [
                "server:read", "server:execute",
                "database:read", "database:execute",
                "skill:execute", "monitoring:read"
            ],
            UserRole.DATABASE_ADMIN: [
                "database:*",
                "skill:execute"
            ],
            UserRole.L3_SUPPORT: [
                "server:read", "server:execute",
                "database:read", "database:execute",
                "skill:execute", "application:read"
            ],
            UserRole.AUDITOR: [
                "audit:read", "report:read"
            ],
        }
        
        for role in user.roles:
            if role in role_permissions:
                permissions.update(role_permissions[role])
        
        return list(permissions)
    
    # ==================== MFA ====================
    
    def generate_mfa_secret(self) -> str:
        """Genera secreto para MFA."""
        # En producción, usar pyotp
        # import pyotp
        # return pyotp.random_base32()
        return self._security.generate_secure_token(32)
    
    def generate_mfa_qr_uri(
        self,
        user: User,
        tenant: Tenant
    ) -> str:
        """Genera URI para QR de configuración MFA."""
        # En producción, usar pyotp
        # import pyotp
        # totp = pyotp.TOTP(user.mfa.secret)
        # return totp.provisioning_uri(
        #     name=user.email,
        #     issuer_name=f"{self._mfa_issuer} - {tenant.name}"
        # )
        return "otpauth://placeholder"
    
    def verify_mfa_backup_code(self, user: User, code: str) -> bool:
        """Verifica código de respaldo MFA."""
        if code in user.mfa.backup_codes:
            # Remover código usado
            user.mfa.backup_codes.remove(code)
            return True
        return False
