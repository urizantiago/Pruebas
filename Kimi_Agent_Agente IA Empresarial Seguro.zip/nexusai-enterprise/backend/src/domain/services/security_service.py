"""
NexusAI Enterprise - Security Service
======================================
Servicio de dominio para operaciones de seguridad.
Encriptación, validaciones, prevención de ataques.
"""
import re
import hashlib
import hmac
import secrets
from typing import Optional, Tuple, List, Dict, Any
from datetime import datetime

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import base64


class SecurityService:
    """
    Servicio de seguridad de grado empresarial.
    
    Características:
    - Encriptación AES-256-GCM (autenticada)
    - Hashing Argon2 para contraseñas
    - Prevención de inyección SQL/NoSQL
    - Prevención de command injection
    - Detección de datos sensibles
    """
    
    # Patrones de inyección SQL
    SQL_INJECTION_PATTERNS = [
        r"(\%27)|(\')|(\-\-)|(\%23)|(#)",
        r"((\%3D)|(=))[^\n]*((\%27)|(\')|(\-\-)|(\%3B)|(;))",
        r"\w*((\%27)|(\'))((\%6F)|o|(\%4F))((\%72)|r|(\%52))",
        r"((\%27)|(\'))union",
        r"exec(\s|\+)+(s|x)p\w+",
        r"UNION\s+SELECT",
        r"INSERT\s+INTO",
        r"DELETE\s+FROM",
        r"DROP\s+TABLE",
        r"ALTER\s+TABLE",
        r"TRUNCATE\s+TABLE",
        r";\s*SHUTDOWN",
        r";\s*DROP",
        r"--",
        r"/\*.*\*/",
        r"xp_cmdshell",
        r"sp_executesql",
        r"sp_oamethod",
        r"sp_oacreate",
        r"openrowset",
        r"bulk\s+insert",
        r"bcp\s+",
        r"';\s*EXEC",
        r"';\s*sp_",
    ]
    
    # Comandos peligrosos (command injection)
    DANGEROUS_COMMANDS = [
        r"\brm\s+-rf\b",
        r"\bdel\s+/[fqs]",
        r"\bformat\s+",
        r"\bfdisk\b",
        r"\bmkfs\.",
        r"\bdd\s+if=",
        r">\s*/dev/",
        r"\bshutdown\b",
        r"\breboot\b",
        r"\bpoweroff\b",
        r"\binit\s+0\b",
        r"\bwget\s+.*\|",
        r"\bcurl\s+.*\|",
        r"\bnc\s+-[el]",
        r"\bnetcat\b",
        r"\bpython\s+-c\b",
        r"\bperl\s+-e\b",
        r"\bruby\s+-e\b",
        r"\bbase64\s+-d\b",
        r"\beval\s*\(",
        r"\bexec\s*\(",
        r"\bsystem\s*\(",
        r"\bshell_exec\b",
        r"\bpopen\s*\(",
        r"\bpcntl_exec\b",
    ]
    
    # Patrones de datos sensibles (PII/PHI)
    SENSITIVE_PATTERNS = {
        "credit_card": r"\b(?:\d{4}[-\s]?){3}\d{4}\b",
        "ssn": r"\b\d{3}-\d{2}-\d{4}\b",
        "email": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b",
        "phone": r"\b(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b",
        "password": r"(?i)(password|passwd|pwd)\s*[=:]\s*['\"][^'\"]+['\"]",
        "api_key": r"(?i)(api[_-]?key|apikey)\s*[=:]\s*['\"][A-Za-z0-9]{20,}['\"]",
        "secret_key": r"(?i)(secret[_-]?key|secret)\s*[=:]\s*['\"][A-Za-z0-9]{20,}['\"]",
        "private_key": r"-----BEGIN (?:RSA |DSA |EC |OPENSSH )?PRIVATE KEY-----",
        "jwt_token": r"eyJ[A-Za-z0-9_-]*\.eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*",
    }
    
    def __init__(self, master_key: str):
        """
        Inicializa el servicio de seguridad.
        
        Args:
            master_key: Clave maestra de 32 bytes (base64 encoded)
        """
        if len(master_key) < 32:
            raise ValueError("Master key debe tener al menos 32 caracteres")
        
        self._master_key = master_key.encode()
        self._fernet = self._create_fernet(master_key)
        
        # Compilar patrones
        self._sql_patterns = [re.compile(p, re.IGNORECASE) for p in self.SQL_INJECTION_PATTERNS]
        self._cmd_patterns = [re.compile(p, re.IGNORECASE) for p in self.DANGEROUS_COMMANDS]
        self._sensitive_patterns = {k: re.compile(v) for k, v in self.SENSITIVE_PATTERNS.items()}
    
    def _create_fernet(self, key: str) -> Fernet:
        """Crea instancia Fernet."""
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=b"nexusai_enterprise_v1",
            iterations=310000,  # OWASP recommendation
        )
        key_bytes = base64.urlsafe_b64encode(kdf.derive(key.encode()))
        return Fernet(key_bytes)
    
    # ==================== ENCRIPTACIÓN ====================
    
    def encrypt(self, data: str, associated_data: Optional[bytes] = None) -> str:
        """
        Encripta datos usando AES-256-GCM.
        
        Args:
            data: Datos a encriptar
            associated_data: Datos asociados para autenticación
        
        Returns:
            String encriptado (base64)
        """
        if not data:
            return ""
        
        # Generar nonce aleatorio
        nonce = secrets.token_bytes(12)
        
        # Crear cipher
        key = hashlib.sha256(self._master_key).digest()
        aesgcm = AESGCM(key)
        
        # Encriptar
        ciphertext = aesgcm.encrypt(
            nonce,
            data.encode(),
            associated_data
        )
        
        # Formato: nonce + ciphertext (base64)
        combined = nonce + ciphertext
        return base64.urlsafe_b64encode(combined).decode()
    
    def decrypt(self, encrypted_data: str, associated_data: Optional[bytes] = None) -> str:
        """
        Desencripta datos.
        
        Args:
            encrypted_data: Datos encriptados (base64)
            associated_data: Datos asociados para autenticación
        
        Returns:
            Datos desencriptados
        """
        if not encrypted_data:
            return ""
        
        try:
            # Decodificar
            combined = base64.urlsafe_b64decode(encrypted_data.encode())
            
            # Separar nonce y ciphertext
            nonce = combined[:12]
            ciphertext = combined[12:]
            
            # Desencriptar
            key = hashlib.sha256(self._master_key).digest()
            aesgcm = AESGCM(key)
            plaintext = aesgcm.decrypt(nonce, ciphertext, associated_data)
            
            return plaintext.decode()
        except Exception:
            return ""
    
    def encrypt_field(self, data: Dict[str, Any], field: str) -> Dict[str, Any]:
        """Encripta un campo específico de un diccionario."""
        result = data.copy()
        if field in result and result[field]:
            result[field] = self.encrypt(str(result[field]))
        return result
    
    def hash_password(self, password: str) -> str:
        """
        Hashea contraseña usando Argon2 (recomendado) o bcrypt.
        
        En producción, usar passlib con Argon2:
        from passlib.hash import argon2
        return argon2.hash(password)
        """
        # Placeholder - usar passlib en producción
        import bcrypt
        salt = bcrypt.gensalt(rounds=12)
        return bcrypt.hashpw(password.encode(), salt).decode()
    
    def verify_password(self, password: str, hashed: str) -> bool:
        """Verifica contraseña."""
        import bcrypt
        return bcrypt.checkpw(password.encode(), hashed.encode())
    
    # ==================== VALIDACIÓN SQL ====================
    
    def detect_sql_injection(self, query: str) -> Tuple[bool, List[str]]:
        """
        Detecta posible inyección SQL.
        
        Returns:
            (es_seguro, patrones_detectados)
        """
        detected = []
        
        for pattern in self._sql_patterns:
            matches = pattern.findall(query)
            if matches:
                detected.append(pattern.pattern[:50])
        
        is_safe = len(detected) == 0
        return is_safe, detected
    
    def sanitize_sql_query(self, query: str) -> str:
        """Sanitiza consulta SQL."""
        # Remover comentarios
        query = re.sub(r"/\*.*?\*/", "", query, flags=re.DOTALL)
        query = re.sub(r"--.*?$", "", query, flags=re.MULTILINE)
        query = re.sub(r"#.*?$", "", query, flags=re.MULTILINE)
        
        # Normalizar espacios
        query = " ".join(query.split())
        
        return query.strip()
    
    def is_read_only_query(self, query: str) -> bool:
        """Verifica si es consulta de solo lectura."""
        query_upper = query.upper().strip()
        
        # Debe comenzar con SELECT, WITH, EXPLAIN, SHOW, DESCRIBE
        allowed_starts = ["SELECT", "WITH", "EXPLAIN", "SHOW", "DESCRIBE", "SET"]
        if not any(query_upper.startswith(s) for s in allowed_starts):
            return False
        
        # No debe contener palabras peligrosas
        dangerous = ["INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "CREATE", 
                     "TRUNCATE", "EXEC", "EXECUTE", "SP_", "XP_"]
        for word in dangerous:
            if word in query_upper:
                return False
        
        return True
    
    # ==================== VALIDACIÓN COMANDOS ====================
    
    def detect_command_injection(self, command: str) -> Tuple[bool, List[str]]:
        """
        Detecta comandos peligrosos.
        
        Returns:
            (es_seguro, comandos_detectados)
        """
        detected = []
        
        for pattern in self._cmd_patterns:
            if pattern.search(command):
                detected.append(pattern.pattern[:50])
        
        is_safe = len(detected) == 0
        return is_safe, detected
    
    def sanitize_command(self, command: str) -> str:
        """Sanitiza comando shell."""
        # Lista blanca de caracteres permitidos
        allowed_chars = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-./=:@ ")
        
        # Filtrar caracteres
        sanitized = "".join(c for c in command if c in allowed_chars)
        
        return sanitized.strip()
    
    # ==================== DATOS SENSIBLES ====================
    
    def detect_sensitive_data(self, text: str) -> Tuple[bool, Dict[str, List[str]]]:
        """
        Detecta datos sensibles en texto.
        
        Returns:
            (contiene_sensible, {tipo: [matches]})
        """
        detected = {}
        
        for data_type, pattern in self._sensitive_patterns.items():
            matches = pattern.findall(text)
            if matches:
                detected[data_type] = matches[:10]  # Limitar matches
        
        has_sensitive = len(detected) > 0
        return has_sensitive, detected
    
    def mask_sensitive_data(self, text: str) -> str:
        """Enmascara datos sensibles encontrados."""
        masked = text
        
        # Enmascarar tarjetas
        masked = re.sub(
            r"\b(\d{4})[-\s]?(\d{4})[-\s]?(\d{4})[-\s]?(\d{4})\b",
            r"\1-****-****-\4",
            masked
        )
        
        # Enmascarar SSN
        masked = re.sub(
            r"\b(\d{3})-(\d{2})-(\d{4})\b",
            r"XXX-XX-\4",
            masked
        )
        
        # Enmascarar contraseñas
        masked = re.sub(
            r"(?i)(password|passwd|pwd)\s*[=:]\s*['\"][^'\"]+['\"]",
            r"\1=\"***\"",
            masked
        )
        
        # Enmascarar API keys
        masked = re.sub(
            r"(?i)(api[_-]?key)\s*[=:]\s*['\"][A-Za-z0-9]{20,}['\"]",
            r"\1=\"***\"",
            masked
        )
        
        return masked
    
    # ==================== VALIDACIÓN INPUT ====================
    
    def validate_input(
        self,
        value: str,
        max_length: int = 1000,
        allowed_pattern: Optional[str] = None
    ) -> Tuple[bool, Optional[str]]:
        """Valida input de usuario."""
        if not value:
            return True, None
        
        if len(value) > max_length:
            return False, f"Input excede longitud máxima de {max_length}"
        
        if allowed_pattern:
            if not re.match(allowed_pattern, value):
                return False, "Input no cumple el patrón requerido"
        
        # Detectar posible XSS
        xss_patterns = ["<script", "javascript:", "onerror=", "onload=", "onclick="]
        for pattern in xss_patterns:
            if pattern in value.lower():
                return False, f"Posible ataque XSS detectado"
        
        return True, None
    
    # ==================== UTILIDADES ====================
    
    def generate_secure_token(self, length: int = 32) -> str:
        """Genera token seguro."""
        return secrets.token_urlsafe(length)
    
    def generate_request_hash(self, data: Dict[str, Any]) -> str:
        """Genera hash único de petición."""
        canonical = json.dumps(data, sort_keys=True, default=str)
        return hashlib.sha256(canonical.encode()).hexdigest()[:16]
    
    def constant_time_compare(self, a: str, b: str) -> bool:
        """Comparación en tiempo constante (previene timing attacks)."""
        return hmac.compare_digest(a.encode(), b.encode())
