"""
NexusAI Enterprise - Repository Interfaces
===========================================
Interfaces de repositorios para el dominio.
"""
from abc import abstractmethod
from typing import List, Optional, Dict, Any
from datetime import datetime

from .base import IRepository, ITenantScopedRepository
from ..entities.tenant import Tenant, TenantId
from ..entities.user import User, UserId, UserRole
from ..entities.application import Application, ApplicationId
from ..entities.infrastructure import Server, Database
from ..entities.skill import Skill, SkillExecution
from ..entities.audit import AuditRecord, AuditEventType, AuditSeverity


# ==================== TENANT ====================

class ITenantRepository(IRepository[Tenant, str]):
    """Repositorio de tenants."""
    
    @abstractmethod
    async def get_by_code(self, code: str) -> Optional[Tenant]:
        """Obtiene tenant por código."""
        pass
    
    @abstractmethod
    async def get_by_tax_id(self, tax_id: str) -> Optional[Tenant]:
        """Obtiene tenant por ID fiscal."""
        pass


# ==================== USER ====================

class IUserRepository(ITenantScopedRepository[User, str]):
    """Repositorio de usuarios."""
    
    @abstractmethod
    async def get_by_email(self, tenant_id: str, email: str) -> Optional[User]:
        """Obtiene usuario por email."""
        pass
    
    @abstractmethod
    async def get_by_username(self, tenant_id: str, username: str) -> Optional[User]:
        """Obtiene usuario por username."""
        pass
    
    @abstractmethod
    async def get_by_sso_id(self, tenant_id: str, provider: str, external_id: str) -> Optional[User]:
        """Obtiene usuario por ID externo SSO."""
        pass
    
    @abstractmethod
    async def list_by_role(self, tenant_id: str, role: UserRole) -> List[User]:
        """Lista usuarios por rol."""
        pass
    
    @abstractmethod
    async def list_active(self, tenant_id: str) -> List[User]:
        """Lista usuarios activos."""
        pass


# ==================== APPLICATION ====================

class IApplicationRepository(ITenantScopedRepository[Application, str]):
    """Repositorio de aplicaciones."""
    
    @abstractmethod
    async def get_by_code(self, tenant_id: str, code: str) -> Optional[Application]:
        """Obtiene aplicación por código."""
        pass
    
    @abstractmethod
    async def list_by_status(self, tenant_id: str, status: str) -> List[Application]:
        """Lista aplicaciones por estado."""
        pass
    
    @abstractmethod
    async def list_critical(self, tenant_id: str) -> List[Application]:
        """Lista aplicaciones críticas."""
        pass


# ==================== INFRASTRUCTURE ====================

class IServerRepository(ITenantScopedRepository[Server, str]):
    """Repositorio de servidores."""
    
    @abstractmethod
    async def get_by_hostname(self, tenant_id: str, hostname: str) -> Optional[Server]:
        """Obtiene servidor por hostname."""
        pass
    
    @abstractmethod
    async def list_by_application(self, tenant_id: str, app_id: str) -> List[Server]:
        """Lista servidores de una aplicación."""
        pass
    
    @abstractmethod
    async def list_online(self, tenant_id: str) -> List[Server]:
        """Lista servidores online."""
        pass


class IDatabaseRepository(ITenantScopedRepository[Database, str]):
    """Repositorio de bases de datos."""
    
    @abstractmethod
    async def get_by_name(self, tenant_id: str, name: str) -> Optional[Database]:
        """Obtiene BD por nombre."""
        pass
    
    @abstractmethod
    async def list_by_application(self, tenant_id: str, app_id: str) -> List[Database]:
        """Lista BDs de una aplicación."""
        pass
    
    @abstractmethod
    async def list_by_type(self, tenant_id: str, db_type: str) -> List[Database]:
        """Lista BDs por tipo."""
        pass


# ==================== SKILL ====================

class ISkillRepository(ITenantScopedRepository[Skill, str]):
    """Repositorio de skills."""
    
    @abstractmethod
    async def get_by_code(self, tenant_id: str, code: str) -> Optional[Skill]:
        """Obtiene skill por código."""
        pass
    
    @abstractmethod
    async def list_by_category(self, tenant_id: str, category: str) -> List[Skill]:
        """Lista skills por categoría."""
        pass
    
    @abstractmethod
    async def list_active(self, tenant_id: str) -> List[Skill]:
        """Lista skills activos."""
        pass
    
    @abstractmethod
    async def record_execution(self, execution: SkillExecution) -> SkillExecution:
        """Registra ejecución de skill."""
        pass


# ==================== AUDIT ====================

class IAuditRepository(IRepository[AuditRecord, str]):
    """Repositorio de auditoría (append-only)."""
    
    @abstractmethod
    async def search(
        self,
        tenant_id: Optional[str] = None,
        event_types: Optional[List[AuditEventType]] = None,
        severities: Optional[List[AuditSeverity]] = None,
        user_id: Optional[str] = None,
        resource_type: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        skip: int = 0,
        limit: int = 100
    ) -> List[AuditRecord]:
        """Busca registros de auditoría."""
        pass
    
    @abstractmethod
    async def get_security_events(
        self,
        tenant_id: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> List[AuditRecord]:
        """Obtiene eventos de seguridad."""
        pass
    
    @abstractmethod
    async def get_user_activity(
        self,
        tenant_id: str,
        user_id: str,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> List[AuditRecord]:
        """Obtiene actividad de un usuario."""
        pass
    
    @abstractmethod
    async def count_by_type(
        self,
        tenant_id: str,
        event_type: AuditEventType,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> int:
        """Cuenta eventos por tipo."""
        pass
    
    @abstractmethod
    async def get_chain_hash(self, tenant_id: str, last_n: int = 100) -> str:
        """Obtiene hash de la cadena de auditoría."""
        pass
