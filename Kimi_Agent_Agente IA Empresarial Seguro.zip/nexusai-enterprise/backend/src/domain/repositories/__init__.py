"""
NexusAI Enterprise - Repository Interfaces
===========================================
Puertos del dominio para persistencia.
Patrón Repository para abstraer la capa de datos.
"""

from .tenant_repository import ITenantRepository
from .user_repository import IUserRepository
from .application_repository import IApplicationRepository
from .infrastructure_repository import IServerRepository, IDatabaseRepository
from .skill_repository import ISkillRepository
from .audit_repository import IAuditRepository

__all__ = [
    "ITenantRepository",
    "IUserRepository",
    "IApplicationRepository",
    "IServerRepository",
    "IDatabaseRepository",
    "ISkillRepository",
    "IAuditRepository",
]
