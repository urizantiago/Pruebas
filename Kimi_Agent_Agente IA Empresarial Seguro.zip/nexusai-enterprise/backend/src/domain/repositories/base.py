"""
NexusAI Enterprise - Base Repository Interface
===============================================
Interfaz base para todos los repositorios.
"""
from abc import ABC, abstractmethod
from typing import TypeVar, Generic, List, Optional

T = TypeVar('T')
ID = TypeVar('ID')


class IRepository(ABC, Generic[T, ID]):
    """Interfaz base para repositorios."""
    
    @abstractmethod
    async def get_by_id(self, id: ID) -> Optional[T]:
        """Obtiene entidad por ID."""
        pass
    
    @abstractmethod
    async def create(self, entity: T) -> T:
        """Crea nueva entidad."""
        pass
    
    @abstractmethod
    async def update(self, entity: T) -> T:
        """Actualiza entidad existente."""
        pass
    
    @abstractmethod
    async def delete(self, id: ID) -> bool:
        """Elimina entidad."""
        pass
    
    @abstractmethod
    async def list_all(self, skip: int = 0, limit: int = 100) -> List[T]:
        """Lista todas las entidades."""
        pass
    
    @abstractmethod
    async def exists(self, id: ID) -> bool:
        """Verifica si existe."""
        pass


class ITenantScopedRepository(IRepository[T, ID], ABC):
    """Repositorio con scope de tenant (multi-tenant)."""
    
    @abstractmethod
    async def list_by_tenant(self, tenant_id: str, skip: int = 0, limit: int = 100) -> List[T]:
        """Lista entidades de un tenant."""
        pass
    
    @abstractmethod
    async def count_by_tenant(self, tenant_id: str) -> int:
        """Cuenta entidades de un tenant."""
        pass
