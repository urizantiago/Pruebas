"""
NexusAI Enterprise - Skills Module
L2/L3 Support skills for enterprise environments.
"""
from .base import ISkill, SkillConfig, SkillResult, SkillParameter, SkillCategory
from .server_skills import (
    AnalyzeLogsSkill,
    CheckResourcesSkill,
    RestartServiceSkill,
    CheckProcessesSkill,
    DiskCleanupSkill,
)
from .database_skills import (
    QueryDatabaseSkill,
    CheckDatabaseHealthSkill,
    OptimizeDatabaseSkill,
    BackupDatabaseSkill,
)
from .network_skills import (
    PingSkill,
    TracerouteSkill,
    CheckPortsSkill,
    DnsLookupSkill,
    CheckSslCertificateSkill,
)
from .security_skills import (
    CheckVulnerabilitiesSkill,
    AnalyzeSecurityLogsSkill,
    CheckPermissionsSkill,
    CheckComplianceSkill,
)

__all__ = [
    # Base
    "ISkill",
    "SkillConfig",
    "SkillResult",
    "SkillParameter",
    "SkillCategory",
    # Server Skills
    "AnalyzeLogsSkill",
    "CheckResourcesSkill",
    "RestartServiceSkill",
    "CheckProcessesSkill",
    "DiskCleanupSkill",
    # Database Skills
    "QueryDatabaseSkill",
    "CheckDatabaseHealthSkill",
    "OptimizeDatabaseSkill",
    "BackupDatabaseSkill",
    # Network Skills
    "PingSkill",
    "TracerouteSkill",
    "CheckPortsSkill",
    "DnsLookupSkill",
    "CheckSslCertificateSkill",
    # Security Skills
    "CheckVulnerabilitiesSkill",
    "AnalyzeSecurityLogsSkill",
    "CheckPermissionsSkill",
    "CheckComplianceSkill",
]


class SkillRegistry:
    """Registry for managing skills."""
    
    _skills: Dict[str, ISkill] = {}
    
    @classmethod
    def register(cls, skill: ISkill):
        """Register a skill."""
        cls._skills[skill.name] = skill
        logger.info(f"Registered skill: {skill.name}")
    
    @classmethod
    def get(cls, name: str) -> Optional[ISkill]:
        """Get a skill by name."""
        return cls._skills.get(name)
    
    @classmethod
    def list_skills(cls, category: Optional[SkillCategory] = None) -> List[ISkill]:
        """List all registered skills."""
        skills = list(cls._skills.values())
        if category:
            skills = [s for s in skills if s.category == category]
        return skills
    
    @classmethod
    def unregister(cls, name: str):
        """Unregister a skill."""
        if name in cls._skills:
            del cls._skills[name]


# Import logger
import logging
logger = logging.getLogger(__name__)
