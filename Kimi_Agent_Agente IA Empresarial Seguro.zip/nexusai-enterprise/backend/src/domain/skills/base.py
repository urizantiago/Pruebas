"""
NexusAI Enterprise - Base Skill Interface
Defines the contract for all skills.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Type


class SkillCategory(Enum):
    """Skill category enumeration."""
    SERVER = "server"
    DATABASE = "database"
    NETWORK = "network"
    SECURITY = "security"
    MONITORING = "monitoring"
    AUTOMATION = "automation"
    TROUBLESHOOTING = "troubleshooting"


class SkillParameterType(Enum):
    """Skill parameter type enumeration."""
    STRING = "string"
    INTEGER = "integer"
    FLOAT = "float"
    BOOLEAN = "boolean"
    ARRAY = "array"
    OBJECT = "object"
    SELECT = "select"


@dataclass
class SkillParameter:
    """Skill parameter definition."""
    name: str
    description: str
    type: SkillParameterType
    required: bool = True
    default: Any = None
    options: List[str] = field(default_factory=list)
    validation_regex: Optional[str] = None
    min_value: Optional[float] = None
    max_value: Optional[float] = None


@dataclass
class SkillResult:
    """Skill execution result."""
    success: bool
    message: str
    data: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    execution_time: float = 0.0
    timestamp: datetime = field(default_factory=datetime.utcnow)
    logs: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary."""
        return {
            "success": self.success,
            "message": self.message,
            "data": self.data,
            "error": self.error,
            "execution_time": self.execution_time,
            "timestamp": self.timestamp.isoformat(),
            "logs": self.logs,
            "recommendations": self.recommendations,
        }


@dataclass
class SkillConfig:
    """Skill configuration."""
    timeout: int = 300
    max_retries: int = 3
    retry_delay: float = 5.0
    dry_run: bool = False
    options: Dict[str, Any] = field(default_factory=dict)


class ISkill(ABC):
    """
    Abstract base class for all skills.
    
    Skills are reusable, composable units of functionality that can be
    executed by the AI agent to perform specific tasks.
    """
    
    def __init__(self):
        self._config: Optional[SkillConfig] = None
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Return the skill name."""
        pass
    
    @property
    @abstractmethod
    def description(self) -> str:
        """Return the skill description."""
        pass
    
    @property
    @abstractmethod
    def category(self) -> SkillCategory:
        """Return the skill category."""
        pass
    
    @property
    @abstractmethod
    def parameters(self) -> List[SkillParameter]:
        """Return the skill parameters."""
        pass
    
    @property
    def required_permissions(self) -> List[str]:
        """Return required permissions for this skill."""
        return []
    
    @property
    def is_dangerous(self) -> bool:
        """Return True if skill can modify system state."""
        return False
    
    @property
    def requires_confirmation(self) -> bool:
        """Return True if skill requires user confirmation."""
        return self.is_dangerous
    
    def configure(self, config: SkillConfig):
        """Configure the skill."""
        self._config = config
    
    @abstractmethod
    async def execute(self, **kwargs) -> SkillResult:
        """Execute the skill with given parameters."""
        pass
    
    def validate_parameters(self, **kwargs) -> List[str]:
        """Validate provided parameters."""
        errors = []
        
        for param in self.parameters:
            if param.required and param.name not in kwargs:
                errors.append(f"Missing required parameter: {param.name}")
                continue
            
            if param.name in kwargs:
                value = kwargs[param.name]
                
                # Type validation
                if param.type == SkillParameterType.INTEGER:
                    if not isinstance(value, int):
                        errors.append(f"Parameter {param.name} must be an integer")
                elif param.type == SkillParameterType.FLOAT:
                    if not isinstance(value, (int, float)):
                        errors.append(f"Parameter {param.name} must be a number")
                elif param.type == SkillParameterType.BOOLEAN:
                    if not isinstance(value, bool):
                        errors.append(f"Parameter {param.name} must be a boolean")
                elif param.type == SkillParameterType.STRING:
                    if not isinstance(value, str):
                        errors.append(f"Parameter {param.name} must be a string")
                
                # Range validation
                if param.min_value is not None and value < param.min_value:
                    errors.append(f"Parameter {param.name} must be >= {param.min_value}")
                if param.max_value is not None and value > param.max_value:
                    errors.append(f"Parameter {param.name} must be <= {param.max_value}")
                
                # Regex validation
                if param.validation_regex and isinstance(value, str):
                    import re
                    if not re.match(param.validation_regex, value):
                        errors.append(f"Parameter {param.name} format is invalid")
        
        return errors
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert skill to dictionary representation."""
        return {
            "name": self.name,
            "description": self.description,
            "category": self.category.value,
            "parameters": [
                {
                    "name": p.name,
                    "description": p.description,
                    "type": p.type.value,
                    "required": p.required,
                    "default": p.default,
                    "options": p.options,
                }
                for p in self.parameters
            ],
            "required_permissions": self.required_permissions,
            "is_dangerous": self.is_dangerous,
            "requires_confirmation": self.requires_confirmation,
        }
    
    def get_function_definition(self) -> Dict[str, Any]:
        """Get OpenAI function definition for this skill."""
        properties = {}
        required = []
        
        for param in self.parameters:
            param_def = {
                "type": param.type.value,
                "description": param.description,
            }
            
            if param.options:
                param_def["enum"] = param.options
            
            if param.default is not None:
                param_def["default"] = param.default
            
            properties[param.name] = param_def
            
            if param.required:
                required.append(param.name)
        
        return {
            "name": self.name,
            "description": self.description,
            "parameters": {
                "type": "object",
                "properties": properties,
                "required": required,
            },
        }
