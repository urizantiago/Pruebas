#!/usr/bin/env python3
"""
NexusAI Enterprise - Main Entry Point
======================================
Punto de entrada para la aplicación.
"""
import os
import sys
from pathlib import Path

# Agregar src al path
sys.path.insert(0, str(Path(__file__).parent / "src"))

import uvicorn
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()


def main():
    """Función principal."""
    # Configuración
    host = os.getenv("NEXUS_HOST", "0.0.0.0")
    port = int(os.getenv("NEXUS_PORT", "8000"))
    workers = int(os.getenv("NEXUS_WORKERS", "1"))
    reload = os.getenv("NEXUS_DEBUG", "false").lower() == "true"
    log_level = os.getenv("NEXUS_LOG_LEVEL", "info")
    
    print(f"""
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║   ███╗   ██╗███████╗██╗  ██╗██╗   ██╗███████╗ █████╗ ██╗          ║
║   ████╗  ██║██╔════╝╚██╗██╔╝██║   ██║██╔════╝██╔══██╗██║          ║
║   ██╔██╗ ██║█████╗   ╚███╔╝ ██║   ██║███████╗███████║██║          ║
║   ██║╚██╗██║██╔══╝   ██╔██╗ ██║   ██║╚════██║██╔══██║██║          ║
║   ██║ ╚████║███████╗██╔╝ ██╗╚██████╔╝███████║██║  ██║███████╗     ║
║   ╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝╚══════╝     ║
║                                                                   ║
║           Enterprise AI Agent for Mission-Critical Operations     ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝

    🚀 Starting server on {host}:{port}
    👷 Workers: {workers}
    🔄 Reload: {reload}
    📝 Log Level: {log_level}
    """)
    
    # Configurar Uvicorn
    config = uvicorn.Config(
        "src.interfaces.http.main:app",
        host=host,
        port=port,
        workers=workers if not reload else 1,
        reload=reload,
        log_level=log_level.lower(),
        access_log=True,
        proxy_headers=True,
        forwarded_allow_ips="*"
    )
    
    server = uvicorn.Server(config)
    server.run()


if __name__ == "__main__":
    main()
