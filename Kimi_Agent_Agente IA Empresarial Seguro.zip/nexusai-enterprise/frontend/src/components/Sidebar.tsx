import { NavLink } from 'react-router-dom'
import {
  HomeIcon,
  ServerIcon,
  CircleStackIcon,
  WrenchIcon,
  ExclamationTriangleIcon,
  UsersIcon,
  ClipboardDocumentListIcon,
  CpuChipIcon,
  PuzzlePieceIcon,
  Cog6ToothIcon,
} from '@heroicons/react/24/outline'

import { useAppSelector } from '../hooks/useAppSelector'

const navigation = [
  { name: 'Dashboard', href: '/dashboard', icon: HomeIcon },
  { name: 'Servers', href: '/servers', icon: ServerIcon },
  { name: 'Databases', href: '/databases', icon: CircleStackIcon },
  { name: 'Skills', href: '/skills', icon: WrenchIcon },
  { name: 'Incidents', href: '/incidents', icon: ExclamationTriangleIcon },
  { name: 'Users', href: '/users', icon: UsersIcon },
  { name: 'Audit Logs', href: '/audit-logs', icon: ClipboardDocumentListIcon },
  { name: 'AI Providers', href: '/ai-providers', icon: CpuChipIcon },
  { name: 'Integrations', href: '/integrations', icon: PuzzlePieceIcon },
  { name: 'Settings', href: '/settings', icon: Cog6ToothIcon },
]

export function Sidebar() {
  const { sidebarOpen } = useAppSelector((state) => state.ui)

  return (
    <aside
      className={`${
        sidebarOpen ? 'w-64' : 'w-0'
      } flex-shrink-0 bg-slate-900 border-r border-slate-800 transition-all duration-300 overflow-hidden`}
    >
      <div className="h-full flex flex-col">
        {/* Logo */}
        <div className="flex items-center h-16 px-6 border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-primary-500 to-primary-700 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">N</span>
            </div>
            <span className="text-lg font-semibold text-white">NexusAI</span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto scrollbar-thin">
          {navigation.map((item) => (
            <NavLink
              key={item.name}
              to={item.href}
              className={({ isActive }) =>
                `sidebar-link ${isActive ? 'active' : ''}`
              }
            >
              <item.icon className="sidebar-icon" />
              {item.name}
            </NavLink>
          ))}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center">
              <span className="text-sm font-medium text-slate-300">A</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-slate-200 truncate">
                Admin User
              </p>
              <p className="text-xs text-slate-500 truncate">admin@nexusai.com</p>
            </div>
          </div>
        </div>
      </div>
    </aside>
  )
}
