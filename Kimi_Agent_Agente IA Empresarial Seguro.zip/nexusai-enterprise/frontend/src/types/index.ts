// NexusAI Enterprise - Frontend Types

export interface User {
  id: string
  email: string
  name: string
  role: 'admin' | 'engineer' | 'viewer'
  permissions: string[]
  createdAt: string
  lastLoginAt?: string
  isActive: boolean
  mfaEnabled: boolean
}

export interface Server {
  id: string
  name: string
  hostname: string
  type: 'linux' | 'windows'
  status: 'online' | 'offline' | 'error' | 'maintenance'
  os?: string
  cpu?: {
    usage: number
    cores: number
  }
  memory?: {
    total: number
    used: number
    usage: number
  }
  disk?: {
    total: number
    used: number
    usage: number
  }
  lastCheckAt?: string
  createdAt: string
}

export interface Database {
  id: string
  name: string
  host: string
  port: number
  type: 'postgresql' | 'mysql' | 'sqlserver' | 'oracle'
  status: 'online' | 'offline' | 'error' | 'maintenance'
  version?: string
  size?: number
  connections?: {
    active: number
    max: number
  }
  performance?: {
    queriesPerSecond: number
    avgQueryTime: number
    cacheHitRatio: number
  }
  lastCheckAt?: string
  createdAt: string
}

export interface Skill {
  id: string
  name: string
  description: string
  category: 'server' | 'database' | 'network' | 'security' | 'monitoring' | 'automation' | 'troubleshooting'
  parameters: SkillParameter[]
  isDangerous: boolean
  requiresConfirmation: boolean
  requiredPermissions: string[]
}

export interface SkillParameter {
  name: string
  description: string
  type: 'string' | 'integer' | 'float' | 'boolean' | 'array' | 'object' | 'select'
  required: boolean
  default?: unknown
  options?: string[]
}

export interface Incident {
  id: string
  title: string
  description: string
  severity: 'critical' | 'high' | 'medium' | 'low'
  status: 'open' | 'in_progress' | 'resolved' | 'closed'
  source: 'manual' | 'auto' | 'alert'
  affectedSystems: string[]
  assignedTo?: string
  createdAt: string
  updatedAt: string
  resolvedAt?: string
  actionItems: ActionItem[]
  timeline: IncidentEvent[]
}

export interface ActionItem {
  id: string
  description: string
  status: 'pending' | 'in_progress' | 'completed'
  assignedTo?: string
  completedAt?: string
}

export interface IncidentEvent {
  id: string
  type: 'created' | 'updated' | 'comment' | 'action' | 'resolved'
  description: string
  userId?: string
  timestamp: string
  metadata?: Record<string, unknown>
}

export interface AIProvider {
  id: string
  name: string
  type: 'openai' | 'azure_openai' | 'anthropic'
  status: 'active' | 'inactive' | 'error'
  model: string
  config: Record<string, unknown>
  usageStats?: {
    requestsToday: number
    tokensToday: number
    costToday: number
  }
}

export interface Integration {
  id: string
  name: string
  type: 'teams' | 'telegram' | 'slack' | 'email' | 'webhook'
  status: 'active' | 'inactive' | 'error'
  config: Record<string, unknown>
  lastUsedAt?: string
}

export interface AuditLog {
  id: string
  action: string
  resource: string
  resourceId: string
  userId: string
  userName: string
  details: Record<string, unknown>
  ipAddress: string
  userAgent: string
  timestamp: string
}

export interface DashboardStats {
  servers: {
    total: number
    online: number
    offline: number
    error: number
  }
  databases: {
    total: number
    online: number
    offline: number
    error: number
  }
  incidents: {
    total: number
    open: number
    critical: number
    high: number
  }
  skills: {
    total: number
    executedToday: number
  }
}

export interface MetricData {
  timestamp: string
  value: number
  label?: string
}

export interface ChartData {
  name: string
  data: MetricData[]
}

export interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: {
    code: string
    message: string
    details?: Record<string, unknown>
  }
  meta?: {
    page: number
    perPage: number
    total: number
    totalPages: number
  }
}

export interface PaginatedResponse<T> {
  items: T[]
  total: number
  page: number
  perPage: number
  totalPages: number
}
