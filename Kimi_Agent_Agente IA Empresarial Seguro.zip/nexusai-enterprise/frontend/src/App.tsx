import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'

import { Layout } from './components/Layout'
import { ProtectedRoute } from './components/ProtectedRoute'

// Pages
import { Login } from './pages/Login'
import { Dashboard } from './pages/Dashboard'
import { Servers } from './pages/Servers'
import { Databases } from './pages/Databases'
import { Skills } from './pages/Skills'
import { Incidents } from './pages/Incidents'
import { Settings } from './pages/Settings'
import { Users } from './pages/Users'
import { AuditLogs } from './pages/AuditLogs'
import { AIProviders } from './pages/AIProviders'
import { Integrations } from './pages/Integrations'
import { NotFound } from './pages/NotFound'

function App() {
  return (
    <Router>
      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={<Login />} />
        
        {/* Protected Routes */}
        <Route element={<ProtectedRoute />}>
          <Route element={<Layout />}>
            <Route path="/" element={<Dashboard />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/servers" element={<Servers />} />
            <Route path="/databases" element={<Databases />} />
            <Route path="/skills" element={<Skills />} />
            <Route path="/incidents" element={<Incidents />} />
            <Route path="/users" element={<Users />} />
            <Route path="/audit-logs" element={<AuditLogs />} />
            <Route path="/ai-providers" element={<AIProviders />} />
            <Route path="/integrations" element={<Integrations />} />
            <Route path="/settings" element={<Settings />} />
          </Route>
        </Route>
        
        {/* 404 */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Router>
  )
}

export default App
