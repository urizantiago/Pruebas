import { ClipboardDocumentListIcon } from '@heroicons/react/24/outline'

export function AuditLogs() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Audit Logs</h1>
          <p className="text-slate-400 mt-1">
            View and search audit logs
          </p>
        </div>
        <button className="btn-secondary">Export Logs</button>
      </div>

      <div className="card p-12 text-center">
        <ClipboardDocumentListIcon className="w-16 h-16 text-slate-600 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-slate-300 mb-2">
          Audit Trail
        </h3>
        <p className="text-slate-500 max-w-md mx-auto">
          View comprehensive audit logs of all system activities.
          Track user actions, system changes, and security events.
        </p>
      </div>
    </div>
  )
}
