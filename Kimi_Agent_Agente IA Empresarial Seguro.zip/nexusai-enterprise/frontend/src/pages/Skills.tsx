import { useState, useEffect } from 'react'
import {
  WrenchIcon,
  PlayIcon,
  ChevronDownIcon,
  ChevronUpIcon,
  ServerIcon,
  CircleStackIcon,
  GlobeAltIcon,
  ShieldCheckIcon,
  ClockIcon,
  CheckCircleIcon,
  XCircleIcon,
  DocumentTextIcon,
  LightBulbIcon,
} from '@heroicons/react/24/outline'

interface Skill {
  name: string
  description: string
  category: string
  parameters: SkillParameter[]
  is_dangerous: boolean
  requires_confirmation: boolean
}

interface SkillParameter {
  name: string
  description: string
  type: string
  required: boolean
  default?: any
  options?: string[]
  min_value?: number
  max_value?: number
}

interface SkillExecution {
  id: string
  skill_name: string
  status: 'pending' | 'running' | 'completed' | 'failed'
  start_time: string
  end_time?: string
  result?: SkillResult
}

interface SkillResult {
  success: boolean
  message: string
  data: any
  error?: string
  execution_time: number
  logs: string[]
  recommendations: string[]
}

const skillCategories = [
  { id: 'all', name: 'All Skills', icon: WrenchIcon },
  { id: 'server', name: 'Server', icon: ServerIcon },
  { id: 'database', name: 'Database', icon: CircleStackIcon },
  { id: 'network', name: 'Network', icon: GlobeAltIcon },
  { id: 'security', name: 'Security', icon: ShieldCheckIcon },
]

const mockSkills: Skill[] = [
  {
    name: 'server.analyze_logs',
    description: 'Analyze server logs for errors, warnings, and patterns',
    category: 'server',
    parameters: [
      { name: 'log_path', description: 'Path to the log file', type: 'string', required: true },
      { name: 'pattern', description: 'Regex pattern to search for', type: 'string', required: false, default: 'ERROR|WARN|FATAL' },
      { name: 'lines', description: 'Number of lines to analyze', type: 'integer', required: false, default: 1000, min_value: 1, max_value: 10000 },
    ],
    is_dangerous: false,
    requires_confirmation: false,
  },
  {
    name: 'server.check_resources',
    description: 'Check server resource usage including CPU, memory, and disk',
    category: 'server',
    parameters: [
      { name: 'server_id', description: 'Server identifier', type: 'string', required: true },
      { name: 'include_processes', description: 'Include top processes', type: 'boolean', required: false, default: true },
    ],
    is_dangerous: false,
    requires_confirmation: false,
  },
  {
    name: 'server.restart_service',
    description: 'Restart a service on the server',
    category: 'server',
    parameters: [
      { name: 'server_id', description: 'Server identifier', type: 'string', required: true },
      { name: 'service_name', description: 'Name of the service', type: 'string', required: true },
      { name: 'wait_for_ready', description: 'Wait for service to be ready', type: 'boolean', required: false, default: true },
    ],
    is_dangerous: true,
    requires_confirmation: true,
  },
  {
    name: 'database.query',
    description: 'Execute a read-only query on a database',
    category: 'database',
    parameters: [
      { name: 'database_id', description: 'Database identifier', type: 'string', required: true },
      { name: 'query', description: 'SQL query to execute', type: 'string', required: true },
      { name: 'limit', description: 'Maximum rows to return', type: 'integer', required: false, default: 1000, min_value: 1, max_value: 10000 },
    ],
    is_dangerous: false,
    requires_confirmation: false,
  },
  {
    name: 'database.check_health',
    description: 'Check database health and performance metrics',
    category: 'database',
    parameters: [
      { name: 'database_id', description: 'Database identifier', type: 'string', required: true },
      { name: 'include_slow_queries', description: 'Include slow query analysis', type: 'boolean', required: false, default: true },
    ],
    is_dangerous: false,
    requires_confirmation: false,
  },
  {
    name: 'database.backup',
    description: 'Create a backup of the database',
    category: 'database',
    parameters: [
      { name: 'database_id', description: 'Database identifier', type: 'string', required: true },
      { name: 'backup_type', description: 'Type of backup', type: 'select', required: false, default: 'full', options: ['full', 'incremental', 'differential'] },
      { name: 'compress', description: 'Compress backup', type: 'boolean', required: false, default: true },
    ],
    is_dangerous: true,
    requires_confirmation: true,
  },
  {
    name: 'network.ping',
    description: 'Test network connectivity using ICMP ping',
    category: 'network',
    parameters: [
      { name: 'host', description: 'Target host', type: 'string', required: true },
      { name: 'count', description: 'Number of packets', type: 'integer', required: false, default: 4, min_value: 1, max_value: 100 },
      { name: 'timeout', description: 'Timeout in seconds', type: 'integer', required: false, default: 5, min_value: 1, max_value: 60 },
    ],
    is_dangerous: false,
    requires_confirmation: false,
  },
  {
    name: 'network.traceroute',
    description: 'Trace the network path to a destination',
    category: 'network',
    parameters: [
      { name: 'host', description: 'Target host', type: 'string', required: true },
      { name: 'max_hops', description: 'Maximum hops', type: 'integer', required: false, default: 30, min_value: 1, max_value: 255 },
    ],
    is_dangerous: false,
    requires_confirmation: false,
  },
  {
    name: 'network.check_ports',
    description: 'Scan ports on a target host',
    category: 'network',
    parameters: [
      { name: 'host', description: 'Target host', type: 'string', required: true },
      { name: 'ports', description: 'Ports to check', type: 'string', required: false, default: '22,80,443,3306,5432,8080' },
    ],
    is_dangerous: false,
    requires_confirmation: false,
  },
  {
    name: 'network.dns_lookup',
    description: 'Perform DNS lookup for a domain',
    category: 'network',
    parameters: [
      { name: 'domain', description: 'Domain name', type: 'string', required: true },
      { name: 'record_type', description: 'DNS record type', type: 'select', required: false, default: 'A', options: ['A', 'AAAA', 'CNAME', 'MX', 'NS', 'TXT', 'SOA'] },
    ],
    is_dangerous: false,
    requires_confirmation: false,
  },
  {
    name: 'network.check_ssl_certificate',
    description: 'Check SSL/TLS certificate validity',
    category: 'network',
    parameters: [
      { name: 'host', description: 'Host to check', type: 'string', required: true },
      { name: 'port', description: 'Port to connect', type: 'integer', required: false, default: 443, min_value: 1, max_value: 65535 },
    ],
    is_dangerous: false,
    requires_confirmation: false,
  },
  {
    name: 'security.check_vulnerabilities',
    description: 'Scan system for known vulnerabilities',
    category: 'security',
    parameters: [
      { name: 'target', description: 'Target to scan', type: 'string', required: true },
      { name: 'scan_type', description: 'Type of scan', type: 'select', required: false, default: 'full', options: ['full', 'quick', 'cve', 'configuration'] },
      { name: 'severity_filter', description: 'Minimum severity', type: 'select', required: false, default: 'medium', options: ['critical', 'high', 'medium', 'low', 'info'] },
    ],
    is_dangerous: false,
    requires_confirmation: false,
  },
  {
    name: 'security.analyze_logs',
    description: 'Analyze security logs for suspicious activity',
    category: 'security',
    parameters: [
      { name: 'log_source', description: 'Source of logs', type: 'string', required: true },
      { name: 'time_range', description: 'Time range in hours', type: 'integer', required: false, default: 24 },
    ],
    is_dangerous: false,
    requires_confirmation: false,
  },
  {
    name: 'security.check_permissions',
    description: 'Audit file and directory permissions',
    category: 'security',
    parameters: [
      { name: 'path', description: 'Path to check', type: 'string', required: true },
      { name: 'recursive', description: 'Check recursively', type: 'boolean', required: false, default: true },
    ],
    is_dangerous: false,
    requires_confirmation: false,
  },
  {
    name: 'security.check_compliance',
    description: 'Check system compliance against standards',
    category: 'security',
    parameters: [
      { name: 'standard', description: 'Compliance standard', type: 'select', required: true, options: ['ISO27001', 'SOC2', 'GDPR', 'HIPAA', 'NIST', 'PCI-DSS'] },
      { name: 'target', description: 'Target system', type: 'string', required: true },
    ],
    is_dangerous: false,
    requires_confirmation: false,
  },
]

const mockExecutionHistory: SkillExecution[] = [
  {
    id: 'exec-001',
    skill_name: 'server.check_resources',
    status: 'completed',
    start_time: '2024-01-15T10:30:00Z',
    end_time: '2024-01-15T10:30:05Z',
    result: {
      success: true,
      message: 'Resource check completed',
      data: { cpu: 45, memory: 60, disk: 70 },
      execution_time: 5.2,
      logs: ['Checking resources...', 'CPU: 45%', 'Memory: 60%'],
      recommendations: ['Monitor disk usage'],
    },
  },
  {
    id: 'exec-002',
    skill_name: 'network.ping',
    status: 'completed',
    start_time: '2024-01-15T10:25:00Z',
    end_time: '2024-01-15T10:25:04Z',
    result: {
      success: true,
      message: 'Ping successful',
      data: { avg_time: 18.5, packet_loss: 0 },
      execution_time: 4.1,
      logs: ['Pinging google.com...', 'Reply from 142.250.80.46'],
      recommendations: [],
    },
  },
  {
    id: 'exec-003',
    skill_name: 'database.check_health',
    status: 'failed',
    start_time: '2024-01-15T10:20:00Z',
    end_time: '2024-01-15T10:20:10Z',
    result: {
      success: false,
      message: 'Health check failed',
      data: {},
      error: 'Connection timeout',
      execution_time: 10.0,
      logs: ['Connecting to database...', 'Error: Connection timeout'],
      recommendations: ['Check database connectivity'],
    },
  },
]

export function Skills() {
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [selectedSkill, setSelectedSkill] = useState<Skill | null>(null)
  const [expandedSkill, setExpandedSkill] = useState<string | null>(null)
  const [parameterValues, setParameterValues] = useState<Record<string, any>>({})
  const [isExecuting, setIsExecuting] = useState(false)
  const [executionResult, setExecutionResult] = useState<SkillResult | null>(null)
  const [activeTab, setActiveTab] = useState<'catalog' | 'history'>('catalog')
  const [showConfirmation, setShowConfirmation] = useState(false)

  const filteredSkills = selectedCategory === 'all' 
    ? mockSkills 
    : mockSkills.filter(s => s.category === selectedCategory)

  const handleSkillSelect = (skill: Skill) => {
    setSelectedSkill(skill)
    setExpandedSkill(skill.name)
    // Initialize parameter values with defaults
    const defaults: Record<string, any> = {}
    skill.parameters.forEach(param => {
      defaults[param.name] = param.default
    })
    setParameterValues(defaults)
    setExecutionResult(null)
  }

  const handleExecute = async () => {
    if (!selectedSkill) return

    if (selectedSkill.requires_confirmation && !showConfirmation) {
      setShowConfirmation(true)
      return
    }

    setShowConfirmation(false)
    setIsExecuting(true)
    setExecutionResult(null)

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000))

    // Mock result
    const mockResult: SkillResult = {
      success: true,
      message: `${selectedSkill.name} executed successfully`,
      data: { timestamp: new Date().toISOString() },
      execution_time: 2.5,
      logs: ['Starting execution...', 'Processing...', 'Completed successfully'],
      recommendations: ['Review the results', 'Monitor for changes'],
    }

    setExecutionResult(mockResult)
    setIsExecuting(false)
  }

  const handleParameterChange = (name: string, value: any) => {
    setParameterValues(prev => ({ ...prev, [name]: value }))
  }

  const getCategoryIcon = (category: string) => {
    const cat = skillCategories.find(c => c.id === category)
    return cat ? cat.icon : WrenchIcon
  }

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      server: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
      database: 'text-green-400 bg-green-500/10 border-green-500/20',
      network: 'text-purple-400 bg-purple-500/10 border-purple-500/20',
      security: 'text-red-400 bg-red-500/10 border-red-500/20',
    }
    return colors[category] || 'text-slate-400 bg-slate-500/10 border-slate-500/20'
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Skills</h1>
          <p className="text-slate-400 mt-1">
            Execute AI-powered skills for infrastructure management
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex space-x-1 border-b border-slate-800">
        {[
          { id: 'catalog', label: 'Skill Catalog', icon: WrenchIcon },
          { id: 'history', label: 'Execution History', icon: ClockIcon },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center space-x-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
              activeTab === tab.id
                ? 'border-primary-500 text-primary-400'
                : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {activeTab === 'catalog' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Skills List */}
          <div className="lg:col-span-1 space-y-4">
            {/* Category Filter */}
            <div className="flex flex-wrap gap-2">
              {skillCategories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    selectedCategory === cat.id
                      ? 'bg-primary-500/20 text-primary-400 border border-primary-500/30'
                      : 'bg-slate-800 text-slate-400 border border-slate-700 hover:bg-slate-700'
                  }`}
                >
                  <cat.icon className="w-4 h-4" />
                  <span>{cat.name}</span>
                </button>
              ))}
            </div>

            {/* Skills */}
            <div className="space-y-2 max-h-[600px] overflow-y-auto">
              {filteredSkills.map((skill) => {
                const Icon = getCategoryIcon(skill.category)
                const isExpanded = expandedSkill === skill.name
                
                return (
                  <div
                    key={skill.name}
                    className={`card p-4 cursor-pointer transition-all ${
                      isExpanded ? 'border-primary-500/50 ring-1 ring-primary-500/20' : 'hover:border-slate-600'
                    }`}
                    onClick={() => handleSkillSelect(skill)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-3">
                        <div className={`p-2 rounded-lg ${getCategoryColor(skill.category)}`}>
                          <Icon className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="text-sm font-medium text-slate-200">{skill.name}</h3>
                          <p className="text-xs text-slate-500 mt-1 line-clamp-2">{skill.description}</p>
                          <div className="flex items-center space-x-2 mt-2">
                            <span className={`badge ${getCategoryColor(skill.category)}`}>
                              {skill.category}
                            </span>
                            {skill.is_dangerous && (
                              <span className="badge badge-danger">dangerous</span>
                            )}
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          setExpandedSkill(isExpanded ? null : skill.name)
                        }}
                        className="text-slate-500 hover:text-slate-300"
                      >
                        {isExpanded ? (
                          <ChevronUpIcon className="w-5 h-5" />
                        ) : (
                          <ChevronDownIcon className="w-5 h-5" />
                        )}
                      </button>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Execution Panel */}
          <div className="lg:col-span-2">
            {selectedSkill ? (
              <div className="space-y-6">
                {/* Skill Header */}
                <div className="card p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-4">
                      {(() => {
                        const Icon = getCategoryIcon(selectedSkill.category)
                        return (
                          <div className={`p-3 rounded-xl ${getCategoryColor(selectedSkill.category)}`}>
                            <Icon className="w-8 h-8" />
                          </div>
                        )
                      })()}
                      <div>
                        <h2 className="text-xl font-semibold text-white">{selectedSkill.name}</h2>
                        <p className="text-slate-400 mt-1">{selectedSkill.description}</p>
                        <div className="flex items-center space-x-2 mt-3">
                          <span className={`badge ${getCategoryColor(selectedSkill.category)}`}>
                            {selectedSkill.category}
                          </span>
                          {selectedSkill.is_dangerous && (
                            <span className="badge badge-danger flex items-center space-x-1">
                              <ShieldCheckIcon className="w-3 h-3" />
                              <span>Requires Confirmation</span>
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Parameters Form */}
                <div className="card p-6">
                  <h3 className="text-lg font-medium text-white mb-4">Parameters</h3>
                  <div className="space-y-4">
                    {selectedSkill.parameters.map((param) => (
                      <div key={param.name}>
                        <label className="block text-sm font-medium text-slate-300 mb-1">
                          {param.name}
                          {param.required && <span className="text-red-400 ml-1">*</span>}
                        </label>
                        <p className="text-xs text-slate-500 mb-2">{param.description}</p>
                        
                        {param.type === 'select' ? (
                          <select
                            value={parameterValues[param.name] || ''}
                            onChange={(e) => handleParameterChange(param.name, e.target.value)}
                            className="input w-full"
                          >
                            {param.options?.map((opt) => (
                              <option key={opt} value={opt}>{opt}</option>
                            ))}
                          </select>
                        ) : param.type === 'boolean' ? (
                          <label className="flex items-center space-x-3 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={parameterValues[param.name] || false}
                              onChange={(e) => handleParameterChange(param.name, e.target.checked)}
                              className="w-4 h-4 rounded border-slate-600 bg-slate-700 text-primary-500 focus:ring-primary-500"
                            />
                            <span className="text-sm text-slate-400">Enabled</span>
                          </label>
                        ) : param.type === 'integer' ? (
                          <input
                            type="number"
                            value={parameterValues[param.name] || ''}
                            onChange={(e) => handleParameterChange(param.name, parseInt(e.target.value))}
                            min={param.min_value}
                            max={param.max_value}
                            className="input w-full"
                            placeholder={param.default?.toString()}
                          />
                        ) : (
                          <input
                            type="text"
                            value={parameterValues[param.name] || ''}
                            onChange={(e) => handleParameterChange(param.name, e.target.value)}
                            className="input w-full"
                            placeholder={param.default?.toString()}
                          />
                        )}
                      </div>
                    ))}
                  </div>

                  {/* Execute Button */}
                  <div className="mt-6">
                    <button
                      onClick={handleExecute}
                      disabled={isExecuting}
                      className="btn-primary w-full flex items-center justify-center space-x-2"
                    >
                      {isExecuting ? (
                        <>
                          <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          <span>Executing...</span>
                        </>
                      ) : (
                        <>
                          <PlayIcon className="w-5 h-5" />
                          <span>Execute Skill</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Execution Result */}
                {executionResult && (
                  <div className={`card p-6 ${executionResult.success ? 'border-green-500/30' : 'border-red-500/30'}`}>
                    <div className="flex items-center space-x-3 mb-4">
                      {executionResult.success ? (
                        <CheckCircleIcon className="w-6 h-6 text-green-400" />
                      ) : (
                        <XCircleIcon className="w-6 h-6 text-red-400" />
                      )}
                      <h3 className="text-lg font-medium text-white">
                        {executionResult.success ? 'Execution Successful' : 'Execution Failed'}
                      </h3>
                    </div>

                    <p className="text-slate-300 mb-4">{executionResult.message}</p>

                    {executionResult.error && (
                      <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 mb-4">
                        <p className="text-red-400 text-sm">{executionResult.error}</p>
                      </div>
                    )}

                    {/* Execution Logs */}
                    {executionResult.logs.length > 0 && (
                      <div className="mb-4">
                        <h4 className="text-sm font-medium text-slate-300 mb-2 flex items-center space-x-2">
                          <DocumentTextIcon className="w-4 h-4" />
                          <span>Execution Logs</span>
                        </h4>
                        <div className="bg-slate-900 rounded-lg p-4 font-mono text-sm max-h-40 overflow-y-auto">
                          {executionResult.logs.map((log, i) => (
                            <div key={i} className="text-slate-400">{log}</div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Recommendations */}
                    {executionResult.recommendations.length > 0 && (
                      <div>
                        <h4 className="text-sm font-medium text-slate-300 mb-2 flex items-center space-x-2">
                          <LightBulbIcon className="w-4 h-4" />
                          <span>Recommendations</span>
                        </h4>
                        <ul className="space-y-2">
                          {executionResult.recommendations.map((rec, i) => (
                            <li key={i} className="flex items-start space-x-2 text-sm text-slate-400">
                              <span className="text-primary-400 mt-1">•</span>
                              <span>{rec}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Result Data */}
                    {Object.keys(executionResult.data).length > 0 && (
                      <div className="mt-4">
                        <h4 className="text-sm font-medium text-slate-300 mb-2">Result Data</h4>
                        <pre className="bg-slate-900 rounded-lg p-4 text-xs text-slate-400 overflow-x-auto">
                          {JSON.stringify(executionResult.data, null, 2)}
                        </pre>
                      </div>
                    )}

                    <div className="mt-4 text-xs text-slate-500">
                      Execution time: {executionResult.execution_time.toFixed(2)}s
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="card p-12 text-center">
                <WrenchIcon className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-slate-300 mb-2">
                  Select a Skill
                </h3>
                <p className="text-slate-500 max-w-md mx-auto">
                  Choose a skill from the catalog to configure parameters and execute it.
                </p>
              </div>
            )}
          </div>
        </div>
      ) : (
        /* Execution History */
        <div className="card">
          <div className="p-6 border-b border-slate-800">
            <h2 className="text-lg font-semibold text-white">Recent Executions</h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {mockExecutionHistory.map((execution) => (
                <div
                  key={execution.id}
                  className="flex items-center justify-between p-4 bg-slate-800/50 rounded-lg"
                >
                  <div className="flex items-center space-x-4">
                    {execution.status === 'completed' && execution.result?.success ? (
                      <CheckCircleIcon className="w-5 h-5 text-green-400" />
                    ) : execution.status === 'failed' ? (
                      <XCircleIcon className="w-5 h-5 text-red-400" />
                    ) : (
                      <div className="w-5 h-5 border-2 border-primary-500/30 border-t-primary-500 rounded-full animate-spin" />
                    )}
                    <div>
                      <p className="text-sm font-medium text-slate-200">{execution.skill_name}</p>
                      <p className="text-xs text-slate-500">
                        {new Date(execution.start_time).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    {execution.result && (
                      <span className="text-xs text-slate-500">
                        {execution.result.execution_time.toFixed(2)}s
                      </span>
                    )}
                    <span className={`badge ${
                      execution.status === 'completed' && execution.result?.success
                        ? 'badge-success'
                        : execution.status === 'failed'
                        ? 'badge-danger'
                        : 'badge-info'
                    }`}>
                      {execution.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      {showConfirmation && selectedSkill && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="card p-6 max-w-md w-full mx-4">
            <div className="flex items-center space-x-3 mb-4">
              <ShieldCheckIcon className="w-8 h-8 text-amber-400" />
              <h3 className="text-lg font-semibold text-white">Confirm Execution</h3>
            </div>
            <p className="text-slate-300 mb-4">
              This skill <strong>{selectedSkill.name}</strong> may modify system state. 
              Are you sure you want to proceed?
            </p>
            <div className="flex space-x-3">
              <button
                onClick={() => setShowConfirmation(false)}
                className="btn-secondary flex-1"
              >
                Cancel
              </button>
              <button
                onClick={handleExecute}
                className="btn-danger flex-1"
              >
                Confirm Execute
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
