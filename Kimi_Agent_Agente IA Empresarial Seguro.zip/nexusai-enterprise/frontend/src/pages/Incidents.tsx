import { ExclamationTriangleIcon } from '@heroicons/react/24/outline'

export function Incidents() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Incidents</h1>
          <p className="text-slate-400 mt-1">
            Track and manage IT incidents
          </p>
        </div>
        <button className="btn-primary">Create Incident</button>
      </div>

      <div className="card p-12 text-center">
        <ExclamationTriangleIcon className="w-16 h-16 text-slate-600 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-slate-300 mb-2">
          Incident Management
        </h3>
        <p className="text-slate-500 max-w-md mx-auto">
          Track, manage, and resolve IT incidents. Collaborate with your team
          and maintain service level agreements.
        </p>
      </div>
    </div>
  )
}
