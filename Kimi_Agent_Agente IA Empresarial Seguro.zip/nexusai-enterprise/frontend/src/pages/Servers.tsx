import { useState } from 'react'
import {
  ServerIcon,
  CpuChipIcon,
  CircleStackIcon,
  PlayIcon,
  StopIcon,
  ArrowPathIcon,
} from '@heroicons/react/24/outline'

interface Server {
  id: string
  name: string
  hostname: string
  type: 'linux' | 'windows'
  status: 'online' | 'offline' | 'error' | 'maintenance'
  cpu: number
  memory: number
  disk: number
  os: string
}

const servers: Server[] = [
  {
    id: '1',
    name: 'web-server-01',
    hostname: 'web01.prod.nexusai.local',
    type: 'linux',
    status: 'online',
    cpu: 45,
    memory: 62,
    disk: 78,
    os: 'Ubuntu 22.04 LTS',
  },
  {
    id: '2',
    name: 'app-server-01',
    hostname: 'app01.prod.nexusai.local',
    type: 'linux',
    status: 'online',
    cpu: 32,
    memory: 48,
    disk: 65,
    os: 'Ubuntu 22.04 LTS',
  },
  {
    id: '3',
    name: 'db-server-01',
    hostname: 'db01.prod.nexusai.local',
    type: 'linux',
    status: 'error',
    cpu: 95,
    memory: 89,
    disk: 92,
    os: 'RHEL 8.8',
  },
  {
    id: '4',
    name: 'windows-server-01',
    hostname: 'win01.prod.nexusai.local',
    type: 'windows',
    status: 'online',
    cpu: 28,
    memory: 55,
    disk: 45,
    os: 'Windows Server 2022',
  },
  {
    id: '5',
    name: 'cache-server-01',
    hostname: 'cache01.prod.nexusai.local',
    type: 'linux',
    status: 'maintenance',
    cpu: 0,
    memory: 0,
    disk: 30,
    os: 'Ubuntu 22.04 LTS',
  },
]

export function Servers() {
  const [selectedServers, setSelectedServers] = useState<string[]>([])

  const toggleSelection = (id: string) => {
    setSelectedServers((prev) =>
      prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]
    )
  }

  const getStatusBadge = (status: Server['status']) => {
    const styles = {
      online: 'badge-success',
      offline: 'badge-danger',
      error: 'badge-danger',
      maintenance: 'badge-warning',
    }
    return <span className={`badge ${styles[status]}`}>{status}</span>
  }

  const getResourceBar = (value: number, color: string) => (
    <div className="w-full bg-slate-700 rounded-full h-2">
      <div
        className={`h-2 rounded-full ${color}`}
        style={{ width: `${value}%` }}
      ></div>
    </div>
  )

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Servers</h1>
          <p className="text-slate-400 mt-1">
            Manage and monitor your server infrastructure
          </p>
        </div>
        <div className="flex space-x-3">
          <button className="btn-secondary">
            <ArrowPathIcon className="w-5 h-5 mr-2" />
            Refresh
          </button>
          <button className="btn-primary">Add Server</button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="card p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-green-500/10 rounded-lg">
              <ServerIcon className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">12</p>
              <p className="text-sm text-slate-500">Total Servers</p>
            </div>
          </div>
        </div>
        <div className="card p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-green-500/10 rounded-lg">
              <PlayIcon className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">10</p>
              <p className="text-sm text-slate-500">Online</p>
            </div>
          </div>
        </div>
        <div className="card p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-red-500/10 rounded-lg">
              <StopIcon className="w-5 h-5 text-red-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">1</p>
              <p className="text-sm text-slate-500">Offline/Error</p>
            </div>
          </div>
        </div>
        <div className="card p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-yellow-500/10 rounded-lg">
              <ArrowPathIcon className="w-5 h-5 text-yellow-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">1</p>
              <p className="text-sm text-slate-500">Maintenance</p>
            </div>
          </div>
        </div>
      </div>

      {/* Servers Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="table">
            <thead>
              <tr>
                <th className="w-10">
                  <input
                    type="checkbox"
                    className="rounded border-slate-700 bg-slate-800"
                  />
                </th>
                <th>Server</th>
                <th>Type</th>
                <th>Status</th>
                <th>CPU</th>
                <th>Memory</th>
                <th>Disk</th>
                <th>OS</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {servers.map((server) => (
                <tr key={server.id}>
                  <td>
                    <input
                      type="checkbox"
                      checked={selectedServers.includes(server.id)}
                      onChange={() => toggleSelection(server.id)}
                      className="rounded border-slate-700 bg-slate-800"
                    />
                  </td>
                  <td>
                    <div>
                      <p className="font-medium text-white">{server.name}</p>
                      <p className="text-xs text-slate-500">{server.hostname}</p>
                    </div>
                  </td>
                  <td>
                    <span className="flex items-center">
                      {server.type === 'linux' ? (
                        <>
                          <CpuChipIcon className="w-4 h-4 mr-1 text-slate-400" />
                          Linux
                        </>
                      ) : (
                        <>
                          <CircleStackIcon className="w-4 h-4 mr-1 text-slate-400" />
                          Windows
                        </>
                      )}
                    </span>
                  </td>
                  <td>{getStatusBadge(server.status)}</td>
                  <td className="w-32">
                    {getResourceBar(
                      server.cpu,
                      server.cpu > 80 ? 'bg-red-500' : 'bg-green-500'
                    )}
                    <span className="text-xs text-slate-500">{server.cpu}%</span>
                  </td>
                  <td className="w-32">
                    {getResourceBar(
                      server.memory,
                      server.memory > 80 ? 'bg-red-500' : 'bg-blue-500'
                    )}
                    <span className="text-xs text-slate-500">{server.memory}%</span>
                  </td>
                  <td className="w-32">
                    {getResourceBar(
                      server.disk,
                      server.disk > 80 ? 'bg-red-500' : 'bg-yellow-500'
                    )}
                    <span className="text-xs text-slate-500">{server.disk}%</span>
                  </td>
                  <td className="text-slate-400">{server.os}</td>
                  <td>
                    <div className="flex space-x-2">
                      <button className="text-primary-400 hover:text-primary-300 text-sm">
                        View
                      </button>
                      <button className="text-slate-400 hover:text-slate-300 text-sm">
                        Connect
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
