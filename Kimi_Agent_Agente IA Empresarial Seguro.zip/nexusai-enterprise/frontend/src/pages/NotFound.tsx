import { Link } from 'react-router-dom'
import { ExclamationTriangleIcon, HomeIcon } from '@heroicons/react/24/outline'

export function NotFound() {
  return (
    <div className="min-h-[60vh] flex items-center justify-center">
      <div className="text-center">
        <div className="flex justify-center mb-6">
          <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-full">
            <ExclamationTriangleIcon className="w-12 h-12 text-yellow-400" />
          </div>
        </div>
        
        <h1 className="text-6xl font-bold text-white mb-4">404</h1>
        <h2 className="text-2xl font-semibold text-slate-300 mb-4">
          Page Not Found
        </h2>
        <p className="text-slate-500 mb-8 max-w-md mx-auto">
          The page you're looking for doesn't exist or has been moved.
        </p>
        
        <Link
          to="/dashboard"
          className="inline-flex items-center btn-primary"
        >
          <HomeIcon className="w-5 h-5 mr-2" />
          Back to Dashboard
        </Link>
      </div>
    </div>
  )
}
