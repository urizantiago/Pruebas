import { useState, useEffect } from 'react'
import {
  ServerIcon,
  CircleStackIcon,
  ExclamationTriangleIcon,
  WrenchIcon,
  ArrowTrendingUpIcon,
  ArrowTrendingDownIcon,
  CpuChipIcon,
  ChartBarIcon,
  ShieldCheckIcon,
  GlobeAltIcon,
} from '@heroicons/react/24/outline'

// Simple chart components
function LineChart({ data, color }: { data: number[]; color: string }) {
  const max = Math.max(...data)
  const min = Math.min(...data)
  const range = max - min || 1
  
  const points = data.map((value, i) => {
    const x = (i / (data.length - 1)) * 100
    const y = 100 - ((value - min) / range) * 100
    return `${x},${y}`
  }).join(' ')
  
  return (
    <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-full">
      <polyline
        points={points}
        fill="none"
        stroke={color}
        strokeWidth="2"
        vectorEffect="non-scaling-stroke"
      />
      <polygon
        points={`0,100 ${points} 100,100`}
        fill={color}
        fillOpacity="0.1"
      />
    </svg>
  )
}

function BarChart({ data, colors }: { data: { label: string; value: number }[]; colors: string[] }) {
  const max = Math.max(...data.map(d => d.value))
  
  return (
    <div className="flex items-end justify-between h-full space-x-2">
      {data.map((item, i) => (
        <div key={item.label} className="flex-1 flex flex-col items-center">
          <div
            className="w-full rounded-t transition-all duration-500"
            style={{
              height: `${(item.value / max) * 100}%`,
              backgroundColor: colors[i % colors.length],
            }}
          />
          <span className="text-[10px] text-slate-500 mt-1 truncate w-full text-center">{item.label}</span>
        </div>
      ))}
    </div>
  )
}

function DonutChart({ data }: { data: { label: string; value: number; color: string }[] }) {
  const total = data.reduce((sum, item) => sum + item.value, 0)
  let cumulativePercent = 0
  
  return (
    <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
      {data.map((item, i) => {
        const percent = (item.value / total) * 100
        const dashArray = `${percent * 2.83} ${283 - percent * 2.83}`
        const dashOffset = -cumulativePercent * 2.83
        cumulativePercent += percent
        
        return (
          <circle
            key={item.label}
            cx="50"
            cy="50"
            r="45"
            fill="none"
            stroke={item.color}
            strokeWidth="10"
            strokeDasharray={dashArray}
            strokeDashoffset={dashOffset}
          />
        )
      })}
      <circle cx="50" cy="50" r="35" fill="#1e293b" />
    </svg>
  )
}

const stats = [
  {
    name: 'Servers',
    value: '12',
    subtext: '10 online, 2 offline',
    change: '+2',
    changeType: 'positive',
    icon: ServerIcon,
    color: 'text-blue-400',
    bgColor: 'bg-blue-500/10',
    borderColor: 'border-blue-500/20',
  },
  {
    name: 'Databases',
    value: '8',
    subtext: '7 online, 1 error',
    change: '0',
    changeType: 'neutral',
    icon: CircleStackIcon,
    color: 'text-green-400',
    bgColor: 'bg-green-500/10',
    borderColor: 'border-green-500/20',
  },
  {
    name: 'Open Incidents',
    value: '3',
    subtext: '1 critical, 2 high',
    change: '-1',
    changeType: 'positive',
    icon: ExclamationTriangleIcon,
    color: 'text-red-400',
    bgColor: 'bg-red-500/10',
    borderColor: 'border-red-500/20',
  },
  {
    name: 'Skills Executed',
    value: '156',
    subtext: 'Today',
    change: '+23',
    changeType: 'positive',
    icon: WrenchIcon,
    color: 'text-purple-400',
    bgColor: 'bg-purple-500/10',
    borderColor: 'border-purple-500/20',
  },
]

const recentIncidents = [
  {
    id: 'INC-001',
    title: 'Database Connection Timeout',
    severity: 'critical',
    status: 'open',
    time: '5 minutes ago',
  },
  {
    id: 'INC-002',
    title: 'High CPU Usage on Server-03',
    severity: 'high',
    status: 'in_progress',
    time: '15 minutes ago',
  },
  {
    id: 'INC-003',
    title: 'Disk Space Warning',
    severity: 'high',
    status: 'open',
    time: '1 hour ago',
  },
]

const recentActivities = [
  { action: 'Server restart completed', user: 'admin@nexusai.com', time: '2 minutes ago' },
  { action: 'Database backup created', user: 'system', time: '15 minutes ago' },
  { action: 'Skill executed: server.check_resources', user: 'admin@nexusai.com', time: '30 minutes ago' },
  { action: 'New incident created: INC-001', user: 'system', time: '1 hour ago' },
]

const skillExecutionData = [45, 52, 48, 65, 72, 68, 85, 92, 88, 95, 102, 110, 125, 118, 135, 142, 138, 145, 152, 156]
const serverLoadData = [35, 42, 38, 45, 52, 48, 55, 62, 58, 65, 72, 68, 75, 82, 78, 85, 92, 88, 95, 85]

const skillCategoryData = [
  { label: 'Server', value: 45 },
  { label: 'DB', value: 32 },
  { label: 'Net', value: 28 },
  { label: 'Sec', value: 18 },
  { label: 'Mon', value: 15 },
]

const incidentStatusData = [
  { label: 'Open', value: 3, color: '#ef4444' },
  { label: 'In Progress', value: 5, color: '#f59e0b' },
  { label: 'Resolved', value: 24, color: '#22c55e' },
  { label: 'Closed', value: 48, color: '#64748b' },
]

const topServersData = [
  { name: 'web-server-01', cpu: 78, memory: 65, status: 'healthy' },
  { name: 'db-server-01', cpu: 45, memory: 82, status: 'warning' },
  { name: 'app-server-02', cpu: 32, memory: 48, status: 'healthy' },
  { name: 'cache-server-01', cpu: 25, memory: 35, status: 'healthy' },
  { name: 'worker-01', cpu: 88, memory: 72, status: 'critical' },
]

export function Dashboard() {
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000)
    return () => clearInterval(timer)
  }, [])

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard</h1>
          <p className="text-slate-400 mt-1">
            Overview of your infrastructure and recent activity
          </p>
        </div>
        <div className="text-right">
          <p className="text-sm text-slate-400">Last updated</p>
          <p className="text-sm font-medium text-slate-300">
            {currentTime.toLocaleTimeString()}
          </p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <div key={stat.name} className={`card p-6 border ${stat.borderColor}`}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-400">{stat.name}</p>
                <p className="text-3xl font-bold text-white mt-2">{stat.value}</p>
                <div className="flex items-center space-x-2 mt-1">
                  <p className="text-sm text-slate-500">{stat.subtext}</p>
                  {stat.change !== '0' && (
                    <span className={`flex items-center text-xs ${
                      stat.changeType === 'positive' ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {stat.changeType === 'positive' ? (
                        <ArrowTrendingUpIcon className="w-3 h-3 mr-0.5" />
                      ) : (
                        <ArrowTrendingDownIcon className="w-3 h-3 mr-0.5" />
                      )}
                      {stat.change}
                    </span>
                  )}
                </div>
              </div>
              <div className={`p-3 rounded-lg ${stat.bgColor}`}>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Analytics Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Skill Execution Trend */}
        <div className="card p-6 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 rounded-lg bg-purple-500/10">
                <ChartBarIcon className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white">Skill Executions</h3>
                <p className="text-sm text-slate-500">Last 24 hours</p>
              </div>
            </div>
            <span className="text-2xl font-bold text-purple-400">156</span>
          </div>
          <div className="h-48">
            <LineChart data={skillExecutionData} color="#a855f7" />
          </div>
          <div className="flex justify-between mt-4 text-xs text-slate-500">
            <span>00:00</span>
            <span>06:00</span>
            <span>12:00</span>
            <span>18:00</span>
            <span>Now</span>
          </div>
        </div>

        {/* Incident Status */}
        <div className="card p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-2 rounded-lg bg-red-500/10">
              <ShieldCheckIcon className="w-5 h-5 text-red-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white">Incidents</h3>
              <p className="text-sm text-slate-500">By status</p>
            </div>
          </div>
          <div className="h-40">
            <DonutChart data={incidentStatusData} />
          </div>
          <div className="grid grid-cols-2 gap-2 mt-4">
            {incidentStatusData.map((item) => (
              <div key={item.label} className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-xs text-slate-400">{item.label}: {item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Analytics Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Server Load */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <CpuChipIcon className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white">Server Load Average</h3>
                <p className="text-sm text-slate-500">CPU utilization %</p>
              </div>
            </div>
            <span className="text-2xl font-bold text-blue-400">62%</span>
          </div>
          <div className="h-40">
            <LineChart data={serverLoadData} color="#3b82f6" />
          </div>
        </div>

        {/* Skill Categories */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 rounded-lg bg-green-500/10">
                <WrenchIcon className="w-5 h-5 text-green-400" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white">Skills by Category</h3>
                <p className="text-sm text-slate-500">Execution count</p>
              </div>
            </div>
          </div>
          <div className="h-40">
            <BarChart 
              data={skillCategoryData} 
              colors={['#3b82f6', '#22c55e', '#a855f7', '#ef4444', '#f59e0b']} 
            />
          </div>
        </div>
      </div>

      {/* Top Servers Performance */}
      <div className="card">
        <div className="p-6 border-b border-slate-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <ServerIcon className="w-5 h-5 text-blue-400" />
              </div>
              <h2 className="text-lg font-semibold text-white">Top Servers by Load</h2>
            </div>
            <button className="text-sm text-primary-400 hover:text-primary-300">View All</button>
          </div>
        </div>
        <div className="p-6">
          <div className="space-y-4">
            {topServersData.map((server) => (
              <div key={server.name} className="flex items-center space-x-4">
                <div className="w-32">
                  <p className="text-sm font-medium text-slate-300">{server.name}</p>
                </div>
                <div className="flex-1 space-y-2">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs text-slate-500 w-12">CPU</span>
                    <div className="flex-1 bg-slate-700 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full transition-all duration-500 ${
                          server.cpu > 80 ? 'bg-red-500' : server.cpu > 60 ? 'bg-amber-500' : 'bg-green-500'
                        }`}
                        style={{ width: `${server.cpu}%` }}
                      />
                    </div>
                    <span className="text-xs text-slate-400 w-10">{server.cpu}%</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs text-slate-500 w-12">RAM</span>
                    <div className="flex-1 bg-slate-700 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full transition-all duration-500 ${
                          server.memory > 80 ? 'bg-red-500' : server.memory > 60 ? 'bg-amber-500' : 'bg-green-500'
                        }`}
                        style={{ width: `${server.memory}%` }}
                      />
                    </div>
                    <span className="text-xs text-slate-400 w-10">{server.memory}%</span>
                  </div>
                </div>
                <span className={`badge ${
                  server.status === 'healthy' ? 'badge-success' :
                  server.status === 'warning' ? 'badge-warning' : 'badge-danger'
                }`}>
                  {server.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Incidents */}
        <div className="card">
          <div className="p-6 border-b border-slate-800">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-white">Recent Incidents</h2>
              <button className="text-sm text-primary-400 hover:text-primary-300">View All</button>
            </div>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {recentIncidents.map((incident) => (
                <div
                  key={incident.id}
                  className="flex items-center justify-between p-4 bg-slate-800/50 rounded-lg hover:bg-slate-800 transition-colors"
                >
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-medium text-slate-300">{incident.id}</span>
                      <span className={`badge ${
                        incident.severity === 'critical' ? 'badge-danger' :
                        incident.severity === 'high' ? 'badge-warning' : 'badge-info'
                      }`}>
                        {incident.severity}
                      </span>
                      <span className={`badge ${
                        incident.status === 'open' ? 'badge-danger' : 'badge-info'
                      }`}>
                        {incident.status}
                      </span>
                    </div>
                    <p className="text-sm text-slate-400 mt-1">{incident.title}</p>
                  </div>
                  <span className="text-xs text-slate-500">{incident.time}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="card">
          <div className="p-6 border-b border-slate-800">
            <h2 className="text-lg font-semibold text-white">Recent Activity</h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {recentActivities.map((activity, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="w-2 h-2 mt-2 rounded-full bg-primary-500" />
                  <div className="flex-1">
                    <p className="text-sm text-slate-300">{activity.action}</p>
                    <div className="flex items-center space-x-2 mt-1">
                      <span className="text-xs text-slate-500">{activity.user}</span>
                      <span className="text-xs text-slate-600">•</span>
                      <span className="text-xs text-slate-500">{activity.time}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="card">
        <div className="p-6 border-b border-slate-800">
          <h2 className="text-lg font-semibold text-white">Quick Actions</h2>
        </div>
        <div className="p-6">
          <div className="flex flex-wrap gap-3">
            <button className="btn-primary flex items-center space-x-2">
              <ServerIcon className="w-4 h-4" />
              <span>Check All Servers</span>
            </button>
            <button className="btn-secondary flex items-center space-x-2">
              <CircleStackIcon className="w-4 h-4" />
              <span>Run Health Check</span>
            </button>
            <button className="btn-secondary flex items-center space-x-2">
              <GlobeAltIcon className="w-4 h-4" />
              <span>Network Diagnostics</span>
            </button>
            <button className="btn-secondary flex items-center space-x-2">
              <ShieldCheckIcon className="w-4 h-4" />
              <span>Security Scan</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
