import { PuzzlePieceIcon } from '@heroicons/react/24/outline'

export function Integrations() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Integrations</h1>
          <p className="text-slate-400 mt-1">
            Configure messaging and notification integrations
          </p>
        </div>
        <button className="btn-primary">Add Integration</button>
      </div>

      <div className="card p-12 text-center">
        <PuzzlePieceIcon className="w-16 h-16 text-slate-600 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-slate-300 mb-2">
          Messaging Integrations
        </h3>
        <p className="text-slate-500 max-w-md mx-auto">
          Connect Microsoft Teams, Telegram, and Slack for notifications
          and alerts. Configure webhooks and custom integrations.
        </p>
      </div>
    </div>
  )
}
