import { CpuChipIcon } from '@heroicons/react/24/outline'

export function AIProviders() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">AI Providers</h1>
          <p className="text-slate-400 mt-1">
            Configure and manage AI service providers
          </p>
        </div>
        <button className="btn-primary">Add Provider</button>
      </div>

      <div className="card p-12 text-center">
        <CpuChipIcon className="w-16 h-16 text-slate-600 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-slate-300 mb-2">
          AI Service Providers
        </h3>
        <p className="text-slate-500 max-w-md mx-auto">
          Configure OpenAI, Azure OpenAI, and Anthropic providers.
          Manage API keys, models, and usage tracking.
        </p>
      </div>
    </div>
  )
}
