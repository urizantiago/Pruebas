import { UsersIcon } from '@heroicons/react/24/outline'

export function Users() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Users</h1>
          <p className="text-slate-400 mt-1">
            Manage users and permissions
          </p>
        </div>
        <button className="btn-primary">Add User</button>
      </div>

      <div className="card p-12 text-center">
        <UsersIcon className="w-16 h-16 text-slate-600 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-slate-300 mb-2">
          User Management
        </h3>
        <p className="text-slate-500 max-w-md mx-auto">
          Manage user accounts, roles, and permissions. Control access to
          resources and audit user activity.
        </p>
      </div>
    </div>
  )
}
