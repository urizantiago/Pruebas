import { Cog6ToothIcon } from '@heroicons/react/24/outline'

export function Settings() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Settings</h1>
          <p className="text-slate-400 mt-1">
            Configure system settings and preferences
          </p>
        </div>
      </div>

      <div className="card p-12 text-center">
        <Cog6ToothIcon className="w-16 h-16 text-slate-600 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-slate-300 mb-2">
          System Settings
        </h3>
        <p className="text-slate-500 max-w-md mx-auto">
          Configure global settings, security policies, notification preferences,
          and system-wide configurations.
        </p>
      </div>
    </div>
  )
}
