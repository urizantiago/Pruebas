# NexusAI Enterprise

**AI-Powered Enterprise IT Support Agent**

NexusAI Enterprise is a next-generation AI agent designed for L2/L3 enterprise support, featuring clean architecture, multi-tenant support, enterprise-grade security, and comprehensive integrations.

## Features

### Core Capabilities

- **Multi-Tenant Architecture**: Complete data isolation between organizations
- **Enterprise Security**: AES-256-GCM encryption, TLS 1.3, JWT tokens, MFA support
- **Compliance Standards**: ISO 27001, SOC 2, GDPR, HIPAA ready
- **Cloud-Native**: Docker, Kubernetes, auto-scaling support
- **Full Observability**: Prometheus, Grafana, Jaeger, ELK stack integration

### AI Providers

- **OpenAI**: GPT-4, GPT-3.5 Turbo, Embeddings
- **Azure OpenAI**: Enterprise-grade OpenAI with private endpoints
- **Anthropic**: Claude 3 (Opus, Sonnet, Haiku)

### Database Connectors

- PostgreSQL (with asyncpg)
- MySQL/MariaDB (with aiomysql)
- SQL Server (with aioodbc)
- Oracle (with cx_Oracle)

### Server Connectors

- SSH (with asyncssh)
- WinRM for Windows servers

### Messaging Integrations

- Microsoft Teams (Adaptive Cards)
- Telegram Bot API
- Slack (Block Kit)

### Skills for L2/L3 Support

- **Server Skills**: analyze_logs, check_resources, restart_service, check_processes, disk_cleanup
- **Database Skills**: query, check_health, optimize, backup
- **Network Skills**: ping, traceroute, check_ports, dns_lookup
- **Security Skills**: check_vulnerabilities, analyze_security_logs, check_permissions

## Architecture

```
nexusai-enterprise/
├── backend/                    # FastAPI Python backend
│   ├── src/
│   │   ├── domain/            # Domain entities and business logic
│   │   ├── application/       # Use cases and services
│   │   ├── infrastructure/    # Adapters and external services
│   │   └── interface/         # API controllers and middleware
│   ├── tests/
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/                   # React + TypeScript + Tailwind CSS
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── hooks/
│   │   ├── store/
│   │   ├── types/
│   │   └── utils/
│   ├── package.json
│   └── Dockerfile
├── .github/workflows/          # CI/CD pipelines
├── k8s/                        # Kubernetes manifests
└── docker-compose.yml
```

## Quick Start

### Prerequisites

- Python 3.11+
- Node.js 20+
- Docker & Docker Compose
- PostgreSQL 15+
- Redis 7+

### Local Development

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-org/nexusai-enterprise.git
   cd nexusai-enterprise
   ```

2. **Start infrastructure services**
   ```bash
   docker-compose up -d postgres redis
   ```

3. **Setup backend**
   ```bash
   cd backend
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

4. **Configure environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

5. **Run database migrations**
   ```bash
   alembic upgrade head
   ```

6. **Start backend server**
   ```bash
   uvicorn src.main:app --reload --host 0.0.0.0 --port 8000
   ```

7. **Setup frontend**
   ```bash
   cd ../frontend
   npm install
   npm run dev
   ```

8. **Access the application**
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:8000
   - API Documentation: http://localhost:8000/docs

### Docker Deployment

```bash
# Build and start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

### Kubernetes Deployment

```bash
# Apply manifests
kubectl apply -k k8s/overlays/production

# Check status
kubectl get pods -n nexusai
```

## Configuration

### Environment Variables

#### Backend

| Variable | Description | Default |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection string | - |
| `REDIS_URL` | Redis connection string | - |
| `SECRET_KEY` | JWT secret key | - |
| `ENCRYPTION_KEY` | Data encryption key | - |
| `OPENAI_API_KEY` | OpenAI API key | - |
| `AZURE_OPENAI_KEY` | Azure OpenAI key | - |
| `ANTHROPIC_API_KEY` | Anthropic API key | - |

#### Frontend

| Variable | Description | Default |
|----------|-------------|---------|
| `VITE_API_URL` | Backend API URL | http://localhost:8000 |
| `VITE_WS_URL` | WebSocket URL | ws://localhost:8000 |

## API Documentation

The API documentation is available at `/docs` when running the backend server.

### Authentication

All API endpoints (except `/health` and `/auth/*`) require authentication via Bearer token:

```bash
curl -H "Authorization: Bearer <token>" http://localhost:8000/api/v1/servers
```

### Key Endpoints

- `POST /auth/login` - User login
- `GET /api/v1/servers` - List servers
- `GET /api/v1/databases` - List databases
- `POST /api/v1/skills/execute` - Execute a skill
- `GET /api/v1/incidents` - List incidents
- `GET /api/v1/audit-logs` - View audit logs

## Skills Usage

### Execute a Skill

```bash
curl -X POST http://localhost:8000/api/v1/skills/execute \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "skill_name": "server.check_resources",
    "parameters": {
      "server_id": "server-001",
      "include_processes": true
    }
  }'
```

### Available Skills

| Skill | Category | Description |
|-------|----------|-------------|
| `server.analyze_logs` | Server | Analyze server logs for errors |
| `server.check_resources` | Server | Check CPU, memory, disk usage |
| `server.restart_service` | Server | Restart a service (dangerous) |
| `database.query` | Database | Execute read-only queries |
| `database.check_health` | Database | Check database health |
| `database.optimize` | Database | Optimize database (dangerous) |

## Security

### Authentication & Authorization

- JWT-based authentication with refresh tokens
- Role-based access control (RBAC)
- Multi-factor authentication (MFA) support
- API key authentication for service accounts

### Data Protection

- AES-256-GCM encryption for sensitive data
- TLS 1.3 for all communications
- HashiCorp Vault integration for secrets management
- Automatic key rotation

### Audit & Compliance

- Comprehensive audit logging
- Immutable log storage
- GDPR data export/deletion
- SOC 2 compliance controls

## Monitoring

### Metrics

- Prometheus metrics at `/metrics`
- Custom business metrics
- Infrastructure metrics
- AI provider usage metrics

### Logging

- Structured JSON logging
- Log levels: DEBUG, INFO, WARNING, ERROR, CRITICAL
- Centralized log aggregation (ELK stack)

### Tracing

- OpenTelemetry distributed tracing
- Jaeger integration
- Request correlation IDs

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Development Guidelines

- Follow PEP 8 for Python code
- Use TypeScript strict mode
- Write tests for new features
- Update documentation

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For support, email support@nexusai.example.com or join our Slack channel.

## Acknowledgments

- Built with [FastAPI](https://fastapi.tiangolo.com/)
- Frontend powered by [React](https://reactjs.org/)
- Styled with [Tailwind CSS](https://tailwindcss.com/)
- Icons by [Heroicons](https://heroicons.com/)
