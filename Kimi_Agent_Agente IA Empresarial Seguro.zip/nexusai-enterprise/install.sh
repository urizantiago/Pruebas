#!/bin/bash

# NexusAI Enterprise - Installation Script
# ==========================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[OK]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

echo ""
echo "╔═══════════════════════════════════════════════════════════════════╗"
echo "║                                                                   ║"
echo "║   ███╗   ██╗███████╗██╗  ██╗██╗   ██╗███████╗ █████╗ ██╗          ║"
echo "║   ████╗  ██║██╔════╝╚██╗██╔╝██║   ██║██╔════╝██╔══██╗██║          ║"
echo "║   ██╔██╗ ██║█████╗   ╚███╔╝ ██║   ██║███████╗███████║██║          ║"
echo "║   ██║╚██╗██║██╔══╝   ██╔██╗ ██║   ██║╚════██║██╔══██║██║          ║"
echo "║   ██║ ╚████║███████╗██╔╝ ██╗╚██████╔╝███████║██║  ██║███████╗     ║"
echo "║   ╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝╚══════╝     ║"
echo "║                                                                   ║"
echo "║              Enterprise AI Agent Installation                     ║"
echo "║                                                                   ║"
echo "╚═══════════════════════════════════════════════════════════════════╝"
echo ""

# Check requirements
check_requirements() {
    print_status "Checking requirements..."
    
    # Docker
    if command -v docker &> /dev/null; then
        DOCKER_VERSION=$(docker --version | cut -d' ' -f3 | cut -d',' -f1)
        print_success "Docker $DOCKER_VERSION found"
    else
        print_error "Docker not found. Please install Docker 24.0+"
        exit 1
    fi
    
    # Docker Compose
    if command -v docker-compose &> /dev/null; then
        COMPOSE_VERSION=$(docker-compose --version | cut -d' ' -f3 | cut -d',' -f1)
        print_success "Docker Compose $COMPOSE_VERSION found"
    else
        print_error "Docker Compose not found. Please install Docker Compose 2.20+"
        exit 1
    fi
    
    # OpenSSL
    if command -v openssl &> /dev/null; then
        print_success "OpenSSL found"
    else
        print_error "OpenSSL not found. Please install OpenSSL"
        exit 1
    fi
}

# Setup directories
setup_directories() {
    print_status "Setting up directories..."
    
    mkdir -p backend/certs
    mkdir -p backend/logs
    mkdir -p backend/data
    mkdir -p docker/volumes
    
    print_success "Directories created"
}

# Generate certificates
generate_certs() {
    print_status "Generating JWT certificates..."
    
    if [ ! -f "backend/certs/jwt-private.pem" ]; then
        openssl genrsa -out backend/certs/jwt-private.pem 2048
        openssl rsa -in backend/certs/jwt-private.pem -pubout -out backend/certs/jwt-public.pem
        print_success "JWT certificates generated"
    else
        print_warning "JWT certificates already exist"
    fi
}

# Setup environment
setup_env() {
    print_status "Setting up environment..."
    
    if [ ! -f "backend/.env" ]; then
        cp backend/.env.example backend/.env
        
        # Generate master key
        MASTER_KEY=$(openssl rand -base64 32)
        
        # Update .env
        if [[ "$OSTYPE" == "darwin"* ]]; then
            # macOS
            sed -i '' "s/NEXUS_MASTER_KEY=.*/NEXUS_MASTER_KEY=$MASTER_KEY/" backend/.env
        else
            # Linux
            sed -i "s/NEXUS_MASTER_KEY=.*/NEXUS_MASTER_KEY=$MASTER_KEY/" backend/.env
        fi
        
        print_success "Environment file created"
        print_warning "Please review and update backend/.env with your settings"
    else
        print_warning "Environment file already exists"
    fi
}

# Start services
start_services() {
    print_status "Starting services..."
    
    cd docker
    
    # Create network if not exists
    docker network create nexusai-network 2>/dev/null || true
    
    # Start services
    docker-compose up -d
    
    print_success "Services started"
    
    # Wait for services
    print_status "Waiting for services to be ready..."
    sleep 10
    
    # Check health
    if curl -s http://localhost:8000/health > /dev/null; then
        print_success "API is healthy"
    else
        print_warning "API may still be starting. Check logs with: docker-compose logs -f api"
    fi
    
    cd ..
}

# Show info
show_info() {
    echo ""
    echo -e "${GREEN}╔═══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║                    INSTALLATION COMPLETE                          ║${NC}"
    echo -e "${GREEN}╚═══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo "Services:"
    echo "  • API:           http://localhost:8000"
    echo "  • API Docs:      http://localhost:8000/docs"
    echo "  • Grafana:       http://localhost:3001 (admin/admin)"
    echo "  • Prometheus:    http://localhost:9090"
    echo "  • Jaeger:        http://localhost:16686"
    echo "  • Vault:         http://localhost:8200 (nexusai-dev-token)"
    echo ""
    echo "Next steps:"
    echo "  1. Review configuration: vim backend/.env"
    echo "  2. Create tenant and admin user (see docs/QUICKSTART.md)"
    echo "  3. Configure AI provider (Azure OpenAI recommended)"
    echo ""
    echo "Useful commands:"
    echo "  cd docker && docker-compose logs -f api"
    echo "  cd docker && docker-compose ps"
    echo "  cd docker && docker-compose down"
    echo ""
}

# Main
main() {
    check_requirements
    setup_directories
    generate_certs
    setup_env
    start_services
    show_info
}

main "$@"
