# NexusAI Enterprise - Windows Server Deployment Guide

## Overview

This guide provides step-by-step instructions for deploying NexusAI Enterprise on Windows Server in an on-premise environment.

## System Requirements

### Minimum Requirements
- **Operating System**: Windows Server 2016 or higher (2019/2022 recommended)
- **Processor**: 4 cores (8 cores recommended)
- **Memory**: 8 GB RAM (16 GB recommended)
- **Storage**: 50 GB free disk space (SSD recommended)
- **Network**: Static IP address, ports 8000, 5432, 6379 available

### Software Prerequisites
- PowerShell 5.1 or higher
- .NET Framework 4.7.2 or higher
- Internet connection (for initial setup only)

## Installation Methods

### Method 1: PowerShell Script (Recommended for Quick Setup)

1. **Download the installer package**
   ```powershell
   # Extract the NexusAI Enterprise package to C:\Temp\nexusai
   ```

2. **Run PowerShell as Administrator**
   - Right-click on PowerShell
   - Select "Run as Administrator"

3. **Execute the installation script**
   ```powershell
   cd C:\Temp\nexusai\installer\windows
   .\install.ps1 -InstallPath "C:\Program Files\NexusAI" -Port 8000
   ```

4. **Installation Parameters**
   | Parameter | Default | Description |
   |-----------|---------|-------------|
   | `-InstallPath` | `C:\Program Files\NexusAI` | Installation directory |
   | `-DataPath` | `C:\ProgramData\NexusAI` | Data storage directory |
   | `-Port` | `8000` | HTTP port for the application |
   | `-Silent` | `$false` | Run without user interaction |

### Method 2: MSI Installer (Recommended for Production)

1. **Download the MSI installer**
   ```
   NexusAI-Enterprise-Setup-v1.0.0.exe
   ```

2. **Run the installer as Administrator**
   - Double-click the installer
   - Follow the wizard prompts

3. **Configuration Options**
   - HTTP Port: Default 8000
   - Database Port: Default 5432
   - Redis Port: Default 6379
   - Database credentials

4. **Post-Installation**
   - The installer automatically creates the Windows Service
   - Firewall rules are configured
   - Database is initialized
   - Service is started

## Post-Installation Configuration

### 1. Access the Admin Dashboard

Open your browser and navigate to:
```
http://localhost:8000
```

Or use the server IP address:
```
http://<server-ip>:8000
```

### 2. Initial Setup

1. **Create Admin Account**
   - Navigate to `http://localhost:8000/setup`
   - Enter organization details
   - Create the first admin user
   - Set a strong password

2. **Configure AI Providers**
   - Go to Settings → AI Providers
   - Add your API keys for:
     - OpenAI (optional)
     - Azure OpenAI (optional)
     - Anthropic Claude (optional)

3. **Add Infrastructure**
   - Servers: Settings → Servers → Add Server
   - Databases: Settings → Databases → Add Database

### 3. SSL/TLS Configuration (Production)

For production environments, configure HTTPS:

1. **Obtain SSL Certificate**
   - Use a certificate from a trusted CA
   - Or use Let's Encrypt

2. **Configure Reverse Proxy**
   ```powershell
   # Install IIS or use nginx
   # Configure SSL binding
   ```

3. **Update Configuration**
   Edit `C:\Program Files\NexusAI\config\config.yaml`:
   ```yaml
   server:
     ssl:
       enabled: true
       cert_file: "C:\\certs\\server.crt"
       key_file: "C:\\certs\\server.key"
   ```

## Service Management

### Using PowerShell

```powershell
# Check service status
Get-Service NexusAI-Enterprise

# Start service
Start-Service NexusAI-Enterprise

# Stop service
Stop-Service NexusAI-Enterprise

# Restart service
Restart-Service NexusAI-Enterprise

# View service logs
Get-Content "C:\Program Files\NexusAI\logs\service.log" -Tail 50
```

### Using Services Console

1. Open `services.msc`
2. Find "NexusAI Enterprise"
3. Right-click for options (Start, Stop, Restart)

## Database Management

### PostgreSQL

```powershell
# Connect to database
psql -U nexusai -d nexusai

# Backup database
pg_dump -U nexusai nexusai > C:\backups\nexusai_backup.sql

# Restore database
psql -U nexusai -d nexusai < C:\backups\nexusai_backup.sql
```

### Automated Backups

Edit `C:\Program Files\NexusAI\config\config.yaml`:
```yaml
backup:
  enabled: true
  schedule: "0 2 * * *"  # Daily at 2 AM
  retention_days: 30
  path: "C:\\ProgramData\\NexusAI\\backups"
```

## Security Configuration

### 1. Windows Firewall

The installer automatically creates firewall rules. To verify:

```powershell
# List NexusAI firewall rules
Get-NetFirewallRule -DisplayName "NexusAI*"
```

### 2. Authentication

Enable Multi-Factor Authentication:

1. Go to Settings → Security → MFA
2. Enable MFA
3. Configure TOTP provider

### 3. Role-Based Access Control

Create roles and assign permissions:

1. Go to Settings → Users → Roles
2. Create roles (Admin, Engineer, Viewer)
3. Assign permissions to each role
4. Assign users to roles

## Monitoring and Logging

### Application Logs

```powershell
# View application logs
Get-Content "C:\Program Files\NexusAI\logs\nexusai.log" -Tail 100

# View error logs
Get-Content "C:\Program Files\NexusAI\logs\service-error.log" -Tail 100

# View audit logs
Get-Content "C:\ProgramData\NexusAI\logs\audit.log" -Tail 100
```

### Performance Monitoring

1. **Windows Performance Monitor**
   - Add counters for:
     - Processor Time
     - Memory Usage
     - Disk I/O
     - Network I/O

2. **Application Metrics**
   - Access Prometheus metrics at: `http://localhost:8000/metrics`

### Health Check Endpoint

```powershell
# Check application health
Invoke-RestMethod -Uri "http://localhost:8000/health" -Method GET
```

## Troubleshooting

### Common Issues

#### 1. Service Won't Start

```powershell
# Check service status
Get-Service NexusAI-Enterprise

# View error logs
Get-Content "C:\Program Files\NexusAI\logs\service-error.log"

# Check port availability
Test-NetConnection -ComputerName localhost -Port 8000

# Check if port is in use
Get-Process -Id (Get-NetTCPConnection -LocalPort 8000).OwningProcess
```

#### 2. Database Connection Issues

```powershell
# Check PostgreSQL service
Get-Service postgresql*

# Test database connection
psql -U nexusai -d nexusai -c "SELECT 1;"

# Check database logs
Get-Content "C:\Program Files\PostgreSQL\15\data\log\*.log" -Tail 50
```

#### 3. High Memory Usage

```powershell
# Check process memory
Get-Process python | Select-Object Name, Id, WorkingSet

# Restart service if needed
Restart-Service NexusAI-Enterprise
```

### Log Analysis

```powershell
# Search for errors
Select-String -Path "C:\Program Files\NexusAI\logs\*.log" -Pattern "ERROR" -Context 2

# Search for specific patterns
Select-String -Path "C:\Program Files\NexusAI\logs\*.log" -Pattern "authentication failed"
```

## Backup and Recovery

### Full System Backup

1. **Stop Services**
   ```powershell
   Stop-Service NexusAI-Enterprise
   Stop-Service postgresql*
   ```

2. **Backup Files**
   ```powershell
   # Backup application
   Compress-Archive -Path "C:\Program Files\NexusAI" -DestinationPath "C:\backups\nexusai-app.zip"
   
   # Backup data
   Compress-Archive -Path "C:\ProgramData\NexusAI" -DestinationPath "C:\backups\nexusai-data.zip"
   ```

3. **Backup Database**
   ```powershell
   pg_dump -U nexusai nexusai > C:\backups\nexusai-db.sql
   ```

4. **Restart Services**
   ```powershell
   Start-Service postgresql*
   Start-Service NexusAI-Enterprise
   ```

### Disaster Recovery

1. **Restore Application**
   ```powershell
   Expand-Archive -Path "C:\backups\nexusai-app.zip" -DestinationPath "C:\Program Files\NexusAI"
   ```

2. **Restore Data**
   ```powershell
   Expand-Archive -Path "C:\backups\nexusai-data.zip" -DestinationPath "C:\ProgramData\NexusAI"
   ```

3. **Restore Database**
   ```powershell
   psql -U postgres -c "DROP DATABASE IF EXISTS nexusai;"
   psql -U postgres -c "CREATE DATABASE nexusai OWNER nexusai;"
   psql -U nexusai -d nexusai < C:\backups\nexusai-db.sql
   ```

## Updating NexusAI Enterprise

### In-Place Upgrade

1. **Backup Current Installation**
   ```powershell
   # Create backup
   Compress-Archive -Path "C:\Program Files\NexusAI" -DestinationPath "C:\backups\nexusai-before-upgrade.zip"
   ```

2. **Stop Service**
   ```powershell
   Stop-Service NexusAI-Enterprise
   ```

3. **Run Upgrade Script**
   ```powershell
   cd C:\Temp\nexusai-new-version\installer\windows
   .\install.ps1 -Upgrade
   ```

4. **Verify Installation**
   ```powershell
   Get-Service NexusAI-Enterprise
   Invoke-RestMethod -Uri "http://localhost:8000/health"
   ```

## Uninstallation

### Method 1: PowerShell

```powershell
cd "C:\Program Files\NexusAI\installer\windows"
.\install.ps1 -Uninstall
```

### Method 2: Control Panel

1. Open "Add or Remove Programs"
2. Find "NexusAI Enterprise"
3. Click "Uninstall"

### Manual Cleanup

```powershell
# Remove service
sc.exe delete NexusAI-Enterprise

# Remove directories
Remove-Item -Path "C:\Program Files\NexusAI" -Recurse -Force
Remove-Item -Path "C:\ProgramData\NexusAI" -Recurse -Force

# Remove firewall rules
Remove-NetFirewallRule -DisplayName "NexusAI*"
```

## Support and Resources

- **Documentation**: https://docs.nexusai.io
- **Support Portal**: https://support.nexusai.io
- **Community Forum**: https://community.nexusai.io
- **GitHub**: https://github.com/nexusai/enterprise

## License

NexusAI Enterprise is licensed under the Enterprise License Agreement.

---

**Version**: 1.0.0  
**Last Updated**: 2024-01-15  
**Support**: support@nexusai.io
