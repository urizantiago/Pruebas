# NexusAI Enterprise - Windows Service Wrapper
# This script is called by NSSM to run the application as a Windows Service

param(
    [string]$InstallPath = $PSScriptRoot
)

# Set environment variables
$env:PYTHONPATH = "$InstallPath\backend"
$env:NEXUSAI_CONFIG_PATH = "$InstallPath\config\config.yaml"
$env:NEXUSAI_ENV = "production"

# Change to backend directory
Set-Location "$InstallPath\backend"

# Log startup
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
Add-Content -Path "$InstallPath\logs\service.log" -Value "[$timestamp] NexusAI Enterprise Service Starting..."

# Check if Python is available
$pythonPath = Get-Command python -ErrorAction SilentlyContinue
if (-not $pythonPath) {
    Add-Content -Path "$InstallPath\logs\service-error.log" -Value "[$timestamp] ERROR: Python not found in PATH"
    exit 1
}

# Start the application
try {
    & python -m uvicorn src.interfaces.http.main:app `
        --host 0.0.0.0 `
        --port 8000 `
        --workers 4 `
        --log-level info `
        --access-log `
        --use-colors
}
catch {
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path "$InstallPath\logs\service-error.log" -Value "[$timestamp] ERROR: $_"
    exit 1
}
