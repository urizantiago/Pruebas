# NexusAI Enterprise - Windows Server Installer
# =============================================
# This script installs NexusAI Enterprise on Windows Server
# Run as Administrator

param(
    [string]$InstallPath = "C:\Program Files\NexusAI",
    [string]$DataPath = "C:\ProgramData\NexusAI",
    [string]$ServiceName = "NexusAI-Enterprise",
    [string]$Port = "8000",
    [switch]$Silent = $false,
    [switch]$Uninstall = $false,
    [switch]$Upgrade = $false
)

# Requires Administrator privileges
if (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Error "This script must be run as Administrator. Please right-click and select 'Run as Administrator'."
    exit 1
}

# Configuration
$ScriptVersion = "1.0.0"
$RequiredPowerShellVersion = 5.1
$DownloadUrl = "https://github.com/nexusai/enterprise/releases/latest/download/nexusai-enterprise.zip"
$PythonVersion = "3.11.0"
$NodeVersion = "18.17.0"

# Colors for output
function Write-Info { param($Message) Write-Host "[INFO] $Message" -ForegroundColor Cyan }
function Write-Success { param($Message) Write-Host "[SUCCESS] $Message" -ForegroundColor Green }
function Write-Warning { param($Message) Write-Host "[WARNING] $Message" -ForegroundColor Yellow }
function Write-Error { param($Message) Write-Host "[ERROR] $Message" -ForegroundColor Red }

# Progress indicator
function Show-Progress {
    param($Activity, $Status, $PercentComplete)
    if (-not $Silent) {
        Write-Progress -Activity $Activity -Status $Status -PercentComplete $PercentComplete
    }
}

# Check prerequisites
function Test-Prerequisites {
    Write-Info "Checking prerequisites..."
    
    # Check PowerShell version
    if ($PSVersionTable.PSVersion -lt [Version]$RequiredPowerShellVersion) {
        Write-Error "PowerShell $RequiredPowerShellVersion or higher is required. Current version: $($PSVersionTable.PSVersion)"
        return $false
    }
    
    # Check Windows version (Windows Server 2016 or higher)
    $osInfo = Get-CimInstance Win32_OperatingSystem
    $osVersion = [Version]$osInfo.Version
    if ($osVersion -lt [Version]"10.0.14393") {
        Write-Error "Windows Server 2016 or higher is required."
        return $false
    }
    
    Write-Success "Prerequisites check passed"
    return $true
}

# Install Chocolatey package manager
function Install-Chocolatey {
    Write-Info "Installing Chocolatey package manager..."
    
    if (Get-Command choco -ErrorAction SilentlyContinue) {
        Write-Success "Chocolatey is already installed"
        return
    }
    
    try {
        Set-ExecutionPolicy Bypass -Scope Process -Force
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
        Invoke-Expression ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
        
        # Refresh environment
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
        
        Write-Success "Chocolatey installed successfully"
    }
    catch {
        Write-Error "Failed to install Chocolatey: $_"
        exit 1
    }
}

# Install Python
function Install-Python {
    Write-Info "Installing Python $PythonVersion..."
    
    $pythonPath = "C:\Python311\python.exe"
    if (Test-Path $pythonPath) {
        Write-Success "Python is already installed"
        return
    }
    
    try {
        choco install python --version=$PythonVersion -y --force
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
        Write-Success "Python installed successfully"
    }
    catch {
        Write-Error "Failed to install Python: $_"
        exit 1
    }
}

# Install Node.js
function Install-NodeJS {
    Write-Info "Installing Node.js $NodeVersion..."
    
    if (Get-Command node -ErrorAction SilentlyContinue) {
        $currentVersion = node --version
        Write-Success "Node.js is already installed: $currentVersion"
        return
    }
    
    try {
        choco install nodejs --version=$NodeVersion -y
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
        Write-Success "Node.js installed successfully"
    }
    catch {
        Write-Error "Failed to install Node.js: $_"
        exit 1
    }
}

# Install PostgreSQL
function Install-PostgreSQL {
    Write-Info "Installing PostgreSQL..."
    
    $pgPath = "C:\Program Files\PostgreSQL\15"
    if (Test-Path $pgPath) {
        Write-Success "PostgreSQL is already installed"
        return
    }
    
    try {
        choco install postgresql15 -y --params '/Password:nexusai123!'
        Write-Success "PostgreSQL installed successfully"
    }
    catch {
        Write-Warning "Failed to install PostgreSQL. You may need to install it manually."
    }
}

# Install Redis
function Install-Redis {
    Write-Info "Installing Redis..."
    
    try {
        choco install redis-64 -y
        Write-Success "Redis installed successfully"
    }
    catch {
        Write-Warning "Failed to install Redis. You may need to install it manually."
    }
}

# Create directories
function Initialize-Directories {
    Write-Info "Creating directories..."
    
    $directories = @(
        $InstallPath,
        "$InstallPath\backend",
        "$InstallPath\frontend",
        "$InstallPath\logs",
        "$InstallPath\config",
        $DataPath,
        "$DataPath\data",
        "$DataPath\backups",
        "$DataPath\uploads"
    )
    
    foreach ($dir in $directories) {
        if (-not (Test-Path $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
        }
    }
    
    Write-Success "Directories created"
}

# Download and extract application files
function Install-Application {
    Write-Info "Installing NexusAI Enterprise..."
    
    Show-Progress -Activity "Installing NexusAI Enterprise" -Status "Downloading application files..." -PercentComplete 20
    
    # In a real scenario, download from release URL
    # For on-premise deployment, files should be copied from distribution media
    $sourcePath = $PSScriptRoot
    
    if (Test-Path "$sourcePath\..\..\backend") {
        Write-Info "Copying backend files..."
        Copy-Item -Path "$sourcePath\..\..\backend\*" -Destination "$InstallPath\backend" -Recurse -Force
    }
    
    if (Test-Path "$sourcePath\..\..\frontend") {
        Write-Info "Copying frontend files..."
        Copy-Item -Path "$sourcePath\..\..\frontend\*" -Destination "$InstallPath\frontend" -Recurse -Force
    }
    
    if (Test-Path "$sourcePath\..\..\docker-compose.yml") {
        Copy-Item -Path "$sourcePath\..\..\docker-compose.yml" -Destination "$InstallPath\" -Force
    }
    
    Show-Progress -Activity "Installing NexusAI Enterprise" -Status "Installing Python dependencies..." -PercentComplete 50
    
    # Install Python dependencies
    Set-Location "$InstallPath\backend"
    & python -m pip install --upgrade pip
    & pip install -r requirements.txt
    
    Show-Progress -Activity "Installing NexusAI Enterprise" -Status "Building frontend..." -PercentComplete 70
    
    # Build frontend
    Set-Location "$InstallPath\frontend"
    & npm install
    & npm run build
    
    Show-Progress -Activity "Installing NexusAI Enterprise" -Status "Finalizing installation..." -PercentComplete 90
    
    Write-Success "Application files installed"
}

# Create configuration files
function New-Configuration {
    Write-Info "Creating configuration files..."
    
    $configContent = @"
# NexusAI Enterprise - Windows Configuration
app:
  name: "NexusAI Enterprise"
  version: "1.0.0"
  environment: "production"
  debug: false

server:
  host: "0.0.0.0"
  port: $Port
  workers: 4
  reload: false

security:
  secret_key: "$(-join ((65..90) + (97..122) + (48..57) | Get-Random -Count 64 | ForEach-Object { [char]$_ }))"
  jwt_algorithm: "HS256"
  access_token_expire_minutes: 30
  refresh_token_expire_days: 7
  encryption_key: "$(-join ((65..90) + (97..122) + (48..57) | Get-Random -Count 32 | ForEach-Object { [char]$_ }))"
  mfa_enabled: true
  password_policy:
    min_length: 12
    require_uppercase: true
    require_lowercase: true
    require_numbers: true
    require_special: true

database:
  type: "postgresql"
  host: "localhost"
  port: 5432
  name: "nexusai"
  user: "nexusai"
  password: "nexusai123!"
  pool_size: 20
  max_overflow: 10
  ssl_mode: "prefer"

redis:
  host: "localhost"
  port: 6379
  db: 0
  password: null

logging:
  level: "INFO"
  format: "json"
  file: "$DataPath\logs\nexusai.log"
  max_size: "100MB"
  max_files: 10

audit:
  enabled: true
  retention_days: 365
  log_file: "$DataPath\logs\audit.log"

ai_providers:
  openai:
    enabled: false
    api_key: ""
    model: "gpt-4"
  azure_openai:
    enabled: false
    api_key: ""
    endpoint: ""
    deployment_name: ""
  anthropic:
    enabled: false
    api_key: ""
    model: "claude-3-opus-20240229"

messaging:
  teams:
    enabled: false
    webhook_url: ""
  slack:
    enabled: false
    bot_token: ""
  telegram:
    enabled: false
    bot_token: ""
    chat_id: ""

compliance:
  iso27001:
    enabled: true
  soc2:
    enabled: true
  gdpr:
    enabled: true
  hipaa:
    enabled: false

backup:
  enabled: true
  schedule: "0 2 * * *"
  retention_days: 30
  path: "$DataPath\backups"
"@
    
    $configContent | Out-File -FilePath "$InstallPath\config\config.yaml" -Encoding UTF8
    
    # Create environment file
    $envContent = @"
# NexusAI Enterprise Environment Variables
NEXUSAI_ENV=production
NEXUSAI_CONFIG_PATH=$InstallPath\config\config.yaml
NEXUSAI_DATA_PATH=$DataPath
NEXUSAI_LOG_LEVEL=INFO
NEXUSAI_PORT=$Port
"@
    
    $envContent | Out-File -FilePath "$InstallPath\.env" -Encoding UTF8
    
    Write-Success "Configuration files created"
}

# Create Windows Service
function Install-Service {
    Write-Info "Creating Windows Service..."
    
    # Remove existing service if present
    $existingService = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if ($existingService) {
        Write-Warning "Service already exists. Stopping and removing..."
        Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
        sc.exe delete $ServiceName | Out-Null
        Start-Sleep -Seconds 2
    }
    
    # Create service executable wrapper
    $serviceWrapper = @"
@echo off
set PYTHONPATH=$InstallPath\backend
set CONFIG_PATH=$InstallPath\config\config.yaml
cd /d $InstallPath\backend
python -m uvicorn src.interfaces.http.main:app --host 0.0.0.0 --port $Port --workers 4
"@
    
    $serviceWrapper | Out-File -FilePath "$InstallPath\nexusai-service.bat" -Encoding ASCII
    
    # Install NSSM (Non-Sucking Service Manager)
    if (-not (Test-Path "$InstallPath\nssm.exe")) {
        Write-Info "Downloading NSSM..."
        $nssmUrl = "https://nssm.cc/release/nssm-2.24.zip"
        $nssmZip = "$env:TEMP\nssm.zip"
        Invoke-WebRequest -Uri $nssmUrl -OutFile $nssmZip
        Expand-Archive -Path $nssmZip -DestinationPath "$env:TEMP\nssm" -Force
        Copy-Item -Path "$env:TEMP\nssm\nssm-2.24\win64\nssm.exe" -Destination "$InstallPath\nssm.exe" -Force
    }
    
    # Create service
    & "$InstallPath\nssm.exe" install $ServiceName "$InstallPath\nexusai-service.bat"
    & "$InstallPath\nssm.exe" set $ServiceName DisplayName "NexusAI Enterprise"
    & "$InstallPath\nssm.exe" set $ServiceName Description "AI-Powered Enterprise Support Agent"
    & "$InstallPath\nssm.exe" set $ServiceName Start SERVICE_AUTO_START
    & "$InstallPath\nssm.exe" set $ServiceName AppStdout "$InstallPath\logs\service.log"
    & "$InstallPath\nssm.exe" set $ServiceName AppStderr "$InstallPath\logs\service-error.log"
    
    Write-Success "Windows Service created: $ServiceName"
}

# Configure Windows Firewall
function Initialize-Firewall {
    Write-Info "Configuring Windows Firewall..."
    
    # Remove existing rules
    Remove-NetFirewallRule -DisplayName "NexusAI Enterprise*" -ErrorAction SilentlyContinue
    
    # Add inbound rule for NexusAI
    New-NetFirewallRule -DisplayName "NexusAI Enterprise - HTTP" `
        -Direction Inbound `
        -Protocol TCP `
        -LocalPort $Port `
        -Action Allow `
        -Profile Any `
        -Description "Allow inbound connections to NexusAI Enterprise"
    
    # Add rule for PostgreSQL if needed
    New-NetFirewallRule -DisplayName "NexusAI Enterprise - PostgreSQL" `
        -Direction Inbound `
        -Protocol TCP `
        -LocalPort 5432 `
        -Action Allow `
        -Profile Domain,Private `
        -Description "Allow PostgreSQL connections"
    
    Write-Success "Firewall rules configured"
}

# Initialize database
function Initialize-Database {
    Write-Info "Initializing database..."
    
    try {
        # Wait for PostgreSQL to be ready
        $pgReady = $false
        $retries = 30
        
        while (-not $pgReady -and $retries -gt 0) {
            try {
                $result = & psql -U postgres -c "SELECT 1;" 2>$null
                if ($result -match "1") {
                    $pgReady = $true
                }
            }
            catch {
                Start-Sleep -Seconds 2
                $retries--
            }
        }
        
        if (-not $pgReady) {
            Write-Warning "PostgreSQL is not ready. Database initialization skipped."
            return
        }
        
        # Create database and user
        & psql -U postgres -c "CREATE USER nexusai WITH PASSWORD 'nexusai123!';" 2>$null
        & psql -U postgres -c "CREATE DATABASE nexusai OWNER nexusai;" 2>$null
        & psql -U postgres -c "GRANT ALL PRIVILEGES ON DATABASE nexusai TO nexusai;" 2>$null
        
        Write-Success "Database initialized"
    }
    catch {
        Write-Warning "Database initialization may have failed: $_"
    }
}

# Start services
function Start-Services {
    Write-Info "Starting services..."
    
    # Start Redis
    try {
        Start-Service -Name "Redis" -ErrorAction SilentlyContinue
    }
    catch {
        Write-Warning "Could not start Redis service"
    }
    
    # Start PostgreSQL
    try {
        Start-Service -Name "postgresql-x64-15" -ErrorAction SilentlyContinue
    }
    catch {
        Write-Warning "Could not start PostgreSQL service"
    }
    
    # Start NexusAI service
    Start-Service -Name $ServiceName -ErrorAction SilentlyContinue
    
    Write-Success "Services started"
}

# Create uninstaller
function New-Uninstaller {
    Write-Info "Creating uninstaller..."
    
    $uninstallScript = @"
# NexusAI Enterprise Uninstaller
# Run as Administrator

Write-Host "Uninstalling NexusAI Enterprise..." -ForegroundColor Yellow

# Stop and remove service
`$service = Get-Service -Name "$ServiceName" -ErrorAction SilentlyContinue
if (`$service) {
    Stop-Service -Name "$ServiceName" -Force
    sc.exe delete "$ServiceName" | Out-Null
    Write-Host "Service removed" -ForegroundColor Green
}

# Remove firewall rules
Remove-NetFirewallRule -DisplayName "NexusAI Enterprise*" -ErrorAction SilentlyContinue
Write-Host "Firewall rules removed" -ForegroundColor Green

# Remove directories
`$paths = @(
    "$InstallPath",
    "$DataPath"
)

foreach (`$path in `$paths) {
    if (Test-Path `$path) {
        Remove-Item -Path `$path -Recurse -Force
        Write-Host "Removed: `$path" -ForegroundColor Green
    }
}

Write-Host "NexusAI Enterprise has been uninstalled" -ForegroundColor Green
pause
"@
    
    $uninstallScript | Out-File -FilePath "$InstallPath\uninstall.ps1" -Encoding UTF8
    
    Write-Success "Uninstaller created"
}

# Create desktop shortcuts
function New-Shortcuts {
    Write-Info "Creating shortcuts..."
    
    $WshShell = New-Object -ComObject WScript.Shell
    
    # Admin Dashboard shortcut
    $shortcut = $WshShell.CreateShortcut("$env:PUBLIC\Desktop\NexusAI Admin.lnk")
    $shortcut.TargetPath = "http://localhost:$Port"
    $shortcut.IconLocation = "$InstallPath\favicon.ico,0"
    $shortcut.Description = "NexusAI Enterprise Admin Dashboard"
    $shortcut.Save()
    
    Write-Success "Shortcuts created"
}

# Main installation flow
function Install-NexusAI {
    Write-Host @"
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║              NexusAI Enterprise Installer                    ║
║                     Version $ScriptVersion                          ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
"@ -ForegroundColor Cyan
    
    Write-Info "Starting installation..."
    Write-Info "Install Path: $InstallPath"
    Write-Info "Data Path: $DataPath"
    Write-Info "Service Port: $Port"
    
    if (-not (Test-Prerequisites)) {
        exit 1
    }
    
    Install-Chocolatey
    Install-Python
    Install-NodeJS
    Install-PostgreSQL
    Install-Redis
    Initialize-Directories
    Install-Application
    New-Configuration
    Install-Service
    Initialize-Firewall
    Initialize-Database
    New-Uninstaller
    New-Shortcuts
    Start-Services
    
    Show-Progress -Activity "Installing NexusAI Enterprise" -Status "Complete" -PercentComplete 100
    
    Write-Host @"

╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║              Installation Complete!                          ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝

NexusAI Enterprise has been successfully installed!

Access Information:
  - Admin Dashboard: http://localhost:$Port
  - API Endpoint: http://localhost:$Port/api/v1
  - Documentation: http://localhost:$Port/docs

Default Credentials:
  - Username: admin@nexusai.local
  - Password: (set during first login)

Service Information:
  - Service Name: $ServiceName
  - Install Path: $InstallPath
  - Data Path: $DataPath
  - Logs: $InstallPath\logs

To manage the service:
  - Start:   Start-Service $ServiceName
  - Stop:    Stop-Service $ServiceName
  - Restart: Restart-Service $ServiceName
  - Status:  Get-Service $ServiceName

To uninstall:
  Run: $InstallPath\uninstall.ps1 as Administrator

For support, visit: https://docs.nexusai.io
"@ -ForegroundColor Green
}

# Uninstall function
function Uninstall-NexusAI {
    Write-Host "Uninstalling NexusAI Enterprise..." -ForegroundColor Yellow
    
    # Stop and remove service
    $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if ($service) {
        Stop-Service -Name $ServiceName -Force
        sc.exe delete $ServiceName | Out-Null
        Write-Success "Service removed"
    }
    
    # Remove firewall rules
    Remove-NetFirewallRule -DisplayName "NexusAI Enterprise*" -ErrorAction SilentlyContinue
    Write-Success "Firewall rules removed"
    
    # Remove directories
    $paths = @($InstallPath, $DataPath)
    foreach ($path in $paths) {
        if (Test-Path $path) {
            Remove-Item -Path $path -Recurse -Force
            Write-Success "Removed: $path"
        }
    }
    
    # Remove shortcuts
    Remove-Item -Path "$env:PUBLIC\Desktop\NexusAI*.lnk" -ErrorAction SilentlyContinue
    
    Write-Success "NexusAI Enterprise has been uninstalled"
}

# Main execution
if ($Uninstall) {
    Uninstall-NexusAI
}
else {
    Install-NexusAI
}
