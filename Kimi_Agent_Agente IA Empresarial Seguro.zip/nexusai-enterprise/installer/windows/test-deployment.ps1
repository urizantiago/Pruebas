# NexusAI Enterprise - Deployment Testing Script
# =============================================
# This script tests the NexusAI Enterprise deployment on Windows Server
# Run as Administrator after installation

param(
    [string]$ServerUrl = "http://localhost:8000",
    [string]$InstallPath = "C:\Program Files\NexusAI",
    [switch]$Detailed = $false
)

# Colors for output
function Write-Header { param($Message) Write-Host "`n=== $Message ===" -ForegroundColor Cyan }
function Write-Pass { param($Message) Write-Host "  [PASS] $Message" -ForegroundColor Green }
function Write-Fail { param($Message) Write-Host "  [FAIL] $Message" -ForegroundColor Red }
function Write-Warn { param($Message) Write-Host "  [WARN] $Message" -ForegroundColor Yellow }
function Write-Info { param($Message) Write-Host "  [INFO] $Message" -ForegroundColor Gray }

# Test results
$TestResults = @{
    Passed = 0
    Failed = 0
    Warnings = 0
}

function Test-Condition {
    param($Condition, $TestName, $Critical = $true)
    
    if ($Condition) {
        Write-Pass $TestName
        $TestResults.Passed++
        return $true
    }
    else {
        if ($Critical) {
            Write-Fail $TestName
            $TestResults.Failed++
        }
        else {
            Write-Warn $TestName
            $TestResults.Warnings++
        }
        return $false
    }
}

Write-Host @"
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║         NexusAI Enterprise - Deployment Test                 ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
"@ -ForegroundColor Cyan

Write-Info "Testing deployment at: $ServerUrl"
Write-Info "Installation path: $InstallPath"
Write-Info "Start time: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"

# ============================================
# Test 1: Service Status
# ============================================
Write-Header "1. Windows Service Status"

$service = Get-Service -Name "NexusAI-Enterprise" -ErrorAction SilentlyContinue
Test-Condition ($service -ne $null) "Service exists"
if ($service) {
    Test-Condition ($service.Status -eq 'Running') "Service is running"
    Test-Condition ($service.StartType -eq 'Automatic') "Service is set to auto-start"
    Write-Info "Service status: $($service.Status)"
}

# ============================================
# Test 2: File System
# ============================================
Write-Header "2. File System Check"

$requiredPaths = @(
    "$InstallPath",
    "$InstallPath\backend",
    "$InstallPath\frontend",
    "$InstallPath\config",
    "$InstallPath\logs",
    "$InstallPath\nssm.exe"
)

foreach ($path in $requiredPaths) {
    Test-Condition (Test-Path $path) "Path exists: $path"
}

# Check configuration file
$configFile = "$InstallPath\config\config.yaml"
Test-Condition (Test-Path $configFile) "Configuration file exists"

if (Test-Path $configFile) {
    $config = Get-Content $configFile -Raw
    Test-Condition ($config -match 'app:') "Configuration is valid YAML"
}

# ============================================
# Test 3: Network Connectivity
# ============================================
Write-Header "3. Network Connectivity"

# Parse URL
$uri = [System.Uri]$ServerUrl
$port = $uri.Port
$hostName = $uri.Host

# Test port binding
$portInUse = Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue
Test-Condition ($portInUse -ne $null) "Port $port is bound"

if ($portInUse) {
    $process = Get-Process -Id $portInUse.OwningProcess -ErrorAction SilentlyContinue
    Test-Condition ($process -ne $null) "Process using port: $($process.ProcessName)"
}

# Test HTTP connectivity
try {
    $response = Invoke-WebRequest -Uri "$ServerUrl/health" -Method GET -TimeoutSec 10 -ErrorAction Stop
    Test-Condition ($response.StatusCode -eq 200) "HTTP endpoint responds (Status: $($response.StatusCode))"
    
    if ($Detailed -and $response.Content) {
        Write-Info "Health response: $($response.Content)"
    }
}
catch {
    Write-Fail "HTTP endpoint not responding: $_"
}

# Test firewall rules
$firewallRule = Get-NetFirewallRule -DisplayName "NexusAI*" -ErrorAction SilentlyContinue
Test-Condition ($firewallRule -ne $null) "Firewall rules exist" -Critical $false

# ============================================
# Test 4: Database Connectivity
# ============================================
Write-Header "4. Database Connectivity"

# Check PostgreSQL service
$pgService = Get-Service -Name "postgresql*" -ErrorAction SilentlyContinue | Select-Object -First 1
Test-Condition ($pgService -ne $null) "PostgreSQL service exists" -Critical $false

if ($pgService) {
    Test-Condition ($pgService.Status -eq 'Running') "PostgreSQL is running" -Critical $false
}

# Test database connection
$psqlPaths = @(
    "C:\Program Files\PostgreSQL\15\bin\psql.exe",
    "C:\Program Files\PostgreSQL\14\bin\psql.exe",
    "C:\Program Files\PostgreSQL\13\bin\psql.exe"
)

$psqlPath = $psqlPaths | Where-Object { Test-Path $_ } | Select-Object -First 1

if ($psqlPath) {
    try {
        $dbResult = & $psqlPath -U nexusai -d nexusai -c "SELECT 1;" 2>&1
        Test-Condition ($dbResult -match "1") "Database connection successful"
    }
    catch {
        Write-Fail "Database connection failed: $_"
    }
}
else {
    Write-Warn "PostgreSQL client not found"
}

# ============================================
# Test 5: Redis Connectivity
# ============================================
Write-Header "5. Cache/Redis Connectivity"

$redisService = Get-Service -Name "Redis" -ErrorAction SilentlyContinue
Test-Condition ($redisService -ne $null) "Redis service exists" -Critical $false

if ($redisService) {
    Test-Condition ($redisService.Status -eq 'Running') "Redis is running" -Critical $false
}

# ============================================
# Test 6: API Endpoints
# ============================================
Write-Header "6. API Endpoints"

$endpoints = @(
    @{ Path = "/health"; ExpectedStatus = 200 },
    @{ Path = "/api/v1/health"; ExpectedStatus = 200 },
    @{ Path = "/docs"; ExpectedStatus = 200 },
    @{ Path = "/api/v1/skills"; ExpectedStatus = 200 }
)

foreach ($endpoint in $endpoints) {
    try {
        $url = "$ServerUrl$($endpoint.Path)"
        $response = Invoke-WebRequest -Uri $url -Method GET -TimeoutSec 5 -ErrorAction Stop
        Test-Condition ($response.StatusCode -eq $endpoint.ExpectedStatus) "Endpoint: $($endpoint.Path)"
    }
    catch {
        Write-Fail "Endpoint failed: $($endpoint.Path) - $_"
    }
}

# ============================================
# Test 7: Log Files
# ============================================
Write-Header "7. Log Files"

$logFiles = @(
    "$InstallPath\logs\service.log",
    "$InstallPath\logs\service-error.log"
)

foreach ($logFile in $logFiles) {
    if (Test-Path $logFile) {
        $logSize = (Get-Item $logFile).Length
        Test-Condition ($logSize -gt 0) "Log file exists and has content: $(Split-Path $logFile -Leaf)"
        
        # Check for errors
        $errors = Select-String -Path $logFile -Pattern "ERROR|FATAL|CRITICAL" -SimpleMatch -ErrorAction SilentlyContinue
        if ($errors) {
            Write-Warn "Found $($errors.Count) errors in log: $(Split-Path $logFile -Leaf)"
            if ($Detailed) {
                $errors | Select-Object -First 5 | ForEach-Object { Write-Info "  - $($_.Line)" }
            }
        }
    }
    else {
        Write-Warn "Log file not found: $(Split-Path $logFile -Leaf)"
    }
}

# ============================================
# Test 8: System Resources
# ============================================
Write-Header "8. System Resources"

# CPU
$cpu = Get-Counter '\Processor(_Total)\% Processor Time' -SampleInterval 1 -MaxSamples 1
$cpuUsage = [math]::Round($cpu.CounterSamples.CookedValue, 2)
Test-Condition ($cpuUsage -lt 80) "CPU usage is normal: $cpuUsage%" -Critical $false

# Memory
$memory = Get-CimInstance Win32_OperatingSystem
$totalMemory = [math]::Round($memory.TotalVisibleMemorySize / 1MB, 2)
$freeMemory = [math]::Round($memory.FreePhysicalMemory / 1MB, 2)
$memoryUsage = [math]::Round((($totalMemory - $freeMemory) / $totalMemory) * 100, 2)
Test-Condition ($memoryUsage -lt 90) "Memory usage is normal: $memoryUsage%" -Critical $false
Write-Info "Total Memory: $totalMemory GB, Free: $freeMemory GB"

# Disk
$disk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
$freeSpace = [math]::Round($disk.FreeSpace / 1GB, 2)
$totalSpace = [math]::Round($disk.Size / 1GB, 2)
$diskUsage = [math]::Round((($totalSpace - $freeSpace) / $totalSpace) * 100, 2)
Test-Condition ($diskUsage -lt 85) "Disk usage is normal: $diskUsage%" -Critical $false
Write-Info "Total Disk: $totalSpace GB, Free: $freeSpace GB"

# ============================================
# Test 9: Security Configuration
# ============================================
Write-Header "9. Security Configuration"

# Check if running as service (not user)
$nexusaiProcess = Get-Process -Name "python" -ErrorAction SilentlyContinue | Where-Object { 
    $_.Path -like "*$InstallPath*" 
}
if ($nexusaiProcess) {
    Write-Info "NexusAI process running as PID: $($nexusaiProcess.Id)"
}

# Check SSL/TLS (if configured)
try {
    $httpsResponse = Invoke-WebRequest -Uri "https://$hostName`:$port" -Method GET -TimeoutSec 5 -ErrorAction Stop
    Write-Pass "HTTPS is configured and responding"
}
catch {
    Write-Warn "HTTPS not configured or not responding (HTTP only mode)"
}

# ============================================
# Test 10: Performance Test
# ============================================
Write-Header "10. Performance Test"

if ($Detailed) {
    Write-Info "Running performance tests..."
    
    # Test response time
    $responseTimes = @()
    for ($i = 0; $i -lt 5; $i++) {
        $sw = [System.Diagnostics.Stopwatch]::StartNew()
        try {
            Invoke-WebRequest -Uri "$ServerUrl/health" -Method GET -TimeoutSec 5 | Out-Null
            $sw.Stop()
            $responseTimes += $sw.ElapsedMilliseconds
        }
        catch {
            $sw.Stop()
            $responseTimes += -1
        }
        Start-Sleep -Milliseconds 100
    }
    
    $avgResponseTime = ($responseTimes | Where-Object { $_ -gt 0 } | Measure-Object -Average).Average
    if ($avgResponseTime) {
        Test-Condition ($avgResponseTime -lt 1000) "Average response time: $([math]::Round($avgResponseTime, 2)) ms"
    }
}

# ============================================
# Test Summary
# ============================================
Write-Header "Test Summary"

$totalTests = $TestResults.Passed + $TestResults.Failed + $TestResults.Warnings
$passRate = if ($totalTests -gt 0) { [math]::Round(($TestResults.Passed / $totalTests) * 100, 2) } else { 0 }

Write-Host "`nResults:" -ForegroundColor White
Write-Host "  Total Tests: $totalTests" -ForegroundColor White
Write-Host "  Passed: $($TestResults.Passed)" -ForegroundColor Green
Write-Host "  Failed: $($TestResults.Failed)" -ForegroundColor Red
Write-Host "  Warnings: $($TestResults.Warnings)" -ForegroundColor Yellow
Write-Host "  Pass Rate: $passRate%" -ForegroundColor White

if ($TestResults.Failed -eq 0) {
    Write-Host "`n" -NoNewline
    Write-Host "╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Green
    Write-Host "║                                                              ║" -ForegroundColor Green
    Write-Host "║         ALL CRITICAL TESTS PASSED!                           ║" -ForegroundColor Green
    Write-Host "║         NexusAI Enterprise is ready for use.                 ║" -ForegroundColor Green
    Write-Host "║                                                              ║" -ForegroundColor Green
    Write-Host "╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Green
    exit 0
}
else {
    Write-Host "`n" -NoNewline
    Write-Host "╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Red
    Write-Host "║                                                              ║" -ForegroundColor Red
    Write-Host "║         SOME TESTS FAILED!                                   ║" -ForegroundColor Red
    Write-Host "║         Please review the failures above.                    ║" -ForegroundColor Red
    Write-Host "║                                                              ║" -ForegroundColor Red
    Write-Host "╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Red
    exit 1
}
