# NexusAI Enterprise - Database Initialization Script
# This script initializes the PostgreSQL database for NexusAI

param(
    [string]$InstallPath = "C:\Program Files\NexusAI",
    [string]$DataPath = "C:\ProgramData\NexusAI"
)

# Logging function
function Write-Log {
    param($Message, $Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Level] $Message"
    Write-Host $logMessage
    
    $logDir = "$InstallPath\logs"
    if (-not (Test-Path $logDir)) {
        New-Item -ItemType Directory -Path $logDir -Force | Out-Null
    }
    Add-Content -Path "$logDir\db-init.log" -Value $logMessage
}

Write-Log "Starting database initialization..."

# Check if PostgreSQL is installed
$pgPaths = @(
    "C:\Program Files\PostgreSQL\15\bin\psql.exe",
    "C:\Program Files\PostgreSQL\14\bin\psql.exe",
    "C:\Program Files\PostgreSQL\13\bin\psql.exe",
    "C:\Program Files\PostgreSQL\12\bin\psql.exe"
)

$psqlPath = $null
foreach ($path in $pgPaths) {
    if (Test-Path $path) {
        $psqlPath = $path
        break
    }
}

if (-not $psqlPath) {
    Write-Log "PostgreSQL not found. Database initialization skipped." "WARNING"
    exit 0
}

Write-Log "Found PostgreSQL at: $psqlPath"

# Wait for PostgreSQL service to be ready
Write-Log "Waiting for PostgreSQL service..."
$retries = 30
$connected = $false

while ($retries -gt 0 -and -not $connected) {
    try {
        $result = & $psqlPath -U postgres -c "SELECT 1;" 2>&1
        if ($result -match "1") {
            $connected = $true
            Write-Log "PostgreSQL is ready"
        }
    }
    catch {
        Write-Log "Waiting for PostgreSQL... ($retries retries left)" "DEBUG"
        Start-Sleep -Seconds 2
        $retries--
    }
}

if (-not $connected) {
    Write-Log "Could not connect to PostgreSQL. Database initialization failed." "ERROR"
    exit 1
}

# Create database user and database
Write-Log "Creating database user and database..."

try {
    # Check if user exists
    $userExists = & $psqlPath -U postgres -t -c "SELECT 1 FROM pg_roles WHERE rolname='nexusai';" 2>$null
    
    if (-not $userExists) {
        Write-Log "Creating database user 'nexusai'..."
        & $psqlPath -U postgres -c "CREATE USER nexusai WITH PASSWORD 'nexusai123!';" 2>&1 | Out-Null
        & $psqlPath -U postgres -c "ALTER USER nexusai WITH SUPERUSER;" 2>&1 | Out-Null
        Write-Log "Database user created"
    }
    else {
        Write-Log "Database user 'nexusai' already exists"
    }
    
    # Check if database exists
    $dbExists = & $psqlPath -U postgres -t -c "SELECT 1 FROM pg_database WHERE datname='nexusai';" 2>$null
    
    if (-not $dbExists) {
        Write-Log "Creating database 'nexusai'..."
        & $psqlPath -U postgres -c "CREATE DATABASE nexusai OWNER nexusai;" 2>&1 | Out-Null
        & $psqlPath -U postgres -c "GRANT ALL PRIVILEGES ON DATABASE nexusai TO nexusai;" 2>&1 | Out-Null
        Write-Log "Database created"
    }
    else {
        Write-Log "Database 'nexusai' already exists"
    }
    
    # Create extensions
    Write-Log "Creating PostgreSQL extensions..."
    & $psqlPath -U nexusai -d nexusai -c "CREATE EXTENSION IF NOT EXISTS \"uuid-ossp\";" 2>&1 | Out-Null
    & $psqlPath -U nexusai -d nexusai -c "CREATE EXTENSION IF NOT EXISTS pgcrypto;" 2>&1 | Out-Null
    Write-Log "Extensions created"
    
    # Run database migrations (if migration script exists)
    $migrateScript = "$InstallPath\backend\scripts\migrate.py"
    if (Test-Path $migrateScript) {
        Write-Log "Running database migrations..."
        Set-Location "$InstallPath\backend"
        & python $migrateScript 2>&1
        Write-Log "Migrations completed"
    }
    
    Write-Log "Database initialization completed successfully"
}
catch {
    Write-Log "Error during database initialization: $_" "ERROR"
    exit 1
}
