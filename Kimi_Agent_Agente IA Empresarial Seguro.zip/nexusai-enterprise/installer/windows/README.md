# NexusAI Enterprise - Windows Installer

This directory contains the Windows Server installer components for NexusAI Enterprise.

## Files

| File | Description |
|------|-------------|
| `install.ps1` | PowerShell installation script (recommended for quick setup) |
| `setup.iss` | Inno Setup script for creating MSI installer |
| `service-wrapper.ps1` | Windows Service wrapper script |
| `db-init.ps1` | Database initialization script |
| `test-deployment.ps1` | Post-installation testing script |
| `DEPLOYMENT_GUIDE.md` | Comprehensive deployment guide |

## Quick Start

### Option 1: PowerShell Script (Recommended)

1. Open PowerShell as Administrator
2. Run the installation script:
   ```powershell
   .\install.ps1
   ```

### Option 2: MSI Installer

1. Build the installer using Inno Setup:
   ```powershell
   iscc setup.iss
   ```
2. Run the generated `NexusAI-Enterprise-Setup-v1.0.0.exe`

## Testing

After installation, run the test script:

```powershell
.\test-deployment.ps1 -Detailed
```

## Requirements

- Windows Server 2016 or higher
- PowerShell 5.1+
- Administrator privileges

## Support

For detailed instructions, see `DEPLOYMENT_GUIDE.md`.
