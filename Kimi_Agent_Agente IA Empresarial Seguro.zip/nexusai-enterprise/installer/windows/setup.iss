; NexusAI Enterprise - Inno Setup Script
; Creates a professional Windows installer
; Requires Inno Setup 6.2 or higher

#define MyAppName "NexusAI Enterprise"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "NexusAI Technologies"
#define MyAppURL "https://nexusai.io"
#define MyAppExeName "nexusai-service.exe"
#define MyAppServiceName "NexusAI-Enterprise"

[Setup]
AppId={{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}/support
AppUpdatesURL={#MyAppURL}/updates
DefaultDirName=C:\Program Files\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
LicenseFile=..\..\LICENSE
OutputDir=..\..\dist
OutputBaseFilename=NexusAI-Enterprise-Setup-v{#MyAppVersion}
SetupIconFile=..\..\assets\icon.ico
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64
MinVersion=10.0.14393
UninstallDisplayIcon={app}\icon.ico
UninstallDisplayName={#MyAppName}
VersionInfoVersion={#MyAppVersion}
VersionInfoCompany={#MyAppPublisher}
VersionInfoDescription=AI-Powered Enterprise Support Agent
VersionInfoCopyright=Copyright (C) 2024 {#MyAppPublisher}
VersionInfoProductName={#MyAppName}
VersionInfoProductVersion={#MyAppVersion}

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"
Name: "spanish"; MessagesFile: "compiler:Languages\\Spanish.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked
Name: "installpostgres"; Description: "Install PostgreSQL (recommended)"; GroupDescription: "Database:"; Flags: checked
Name: "installredis"; Description: "Install Redis (recommended)"; GroupDescription: "Cache:"; Flags: checked
Name: "firewall"; Description: "Configure Windows Firewall rules"; GroupDescription: "Security:"; Flags: checked

[Files]
; Application files
Source: "..\..\backend\*"; DestDir: "{app}\backend"; Flags: ignoreversion recursesubdirs
Source: "..\..\frontend\*"; DestDir: "{app}\frontend"; Flags: ignoreversion recursesubdirs
Source: "..\..\config\*"; DestDir: "{app}\config"; Flags: ignoreversion recursesubdirs
Source: "..\..\docker-compose.yml"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\README.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\LICENSE"; DestDir: "{app}"; Flags: ignoreversion

; Icons and assets
Source: "..\..\assets\icon.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\assets\banner.bmp"; DestDir: "{tmp}"; Flags: dontcopy
Source: "..\..\assets\wizard-small.bmp"; DestDir: "{tmp}"; Flags: dontcopy

; NSSM (Non-Sucking Service Manager)
Source: "nssm.exe"; DestDir: "{app}"; Flags: ignoreversion

; PowerShell scripts
Source: "service-wrapper.ps1"; DestDir: "{app}"; Flags: ignoreversion
Source: "db-init.ps1"; DestDir: "{app}"; Flags: ignoreversion

[Dirs]
Name: "{app}\logs"; Permissions: everyone-modify
Name: "{app}\data"; Permissions: everyone-modify
Name: "{app}\backups"; Permissions: everyone-modify
Name: "{commonappdata}\{#MyAppName}"; Permissions: everyone-modify

[Icons]
Name: "{group}\{#MyAppName} Admin"; Filename: "http://localhost:8000"; IconFilename: "{app}\icon.ico"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName} Admin"; Filename: "http://localhost:8000"; IconFilename: "{app}\icon.ico"; Tasks: desktopicon

[Run]
; Install dependencies
Filename: "powershell.exe"; Parameters: "-ExecutionPolicy Bypass -File ""{app}\db-init.ps1"" -InstallPath ""{app}"""; Description: "Initializing database..."; Flags: runhidden waituntilterminated

; Create Windows Service
Filename: "{app}\nssm.exe"; Parameters: "install {#MyAppServiceName} ""powershell.exe"" ""-ExecutionPolicy Bypass -File ""{app}\service-wrapper.ps1"""""; Description: "Creating Windows Service..."; Flags: runhidden waituntilterminated
Filename: "{app}\nssm.exe"; Parameters: "set {#MyAppServiceName} DisplayName ""{#MyAppName}"""; Flags: runhidden waituntilterminated
Filename: "{app}\nssm.exe"; Parameters: "set {#MyAppServiceName} Description ""AI-Powered Enterprise Support Agent"""; Flags: runhidden waituntilterminated
Filename: "{app}\nssm.exe"; Parameters: "set {#MyAppServiceName} Start SERVICE_AUTO_START"; Flags: runhidden waituntilterminated
Filename: "{app}\nssm.exe"; Parameters: "set {#MyAppServiceName} AppStdout ""{app}\logs\service.log"""; Flags: runhidden waituntilterminated
Filename: "{app}\nssm.exe"; Parameters: "set {#MyAppServiceName} AppStderr ""{app}\logs\service-error.log"""; Flags: runhidden waituntilterminated
Filename: "{app}\nssm.exe"; Parameters: "set {#MyAppServiceName} AppRotateFiles 1"; Flags: runhidden waituntilterminated
Filename: "{app}\nssm.exe"; Parameters: "set {#MyAppServiceName} AppRotateBytes 10485760"; Flags: runhidden waituntilterminated

; Configure firewall
Filename: "netsh.exe"; Parameters: "advfirewall firewall add rule name=""{#MyAppName} - HTTP"" dir=in action=allow protocol=TCP localport=8000"; Description: "Configuring firewall..."; Flags: runhidden waituntilterminated; Tasks: firewall

; Start service
Filename: "net.exe"; Parameters: "start {#MyAppServiceName}"; Description: "Starting service..."; Flags: runhidden waituntilterminated

; Open browser
Filename: "http://localhost:8000"; Description: "Open Admin Dashboard"; Flags: postinstall skipifsilent shellexec

[UninstallRun]
; Stop and remove service
Filename: "net.exe"; Parameters: "stop {#MyAppServiceName}"; Flags: runhidden waituntilterminated
Filename: "sc.exe"; Parameters: "delete {#MyAppServiceName}"; Flags: runhidden waituntilterminated

; Remove firewall rules
Filename: "netsh.exe"; Parameters: "advfirewall firewall delete rule name=""{#MyAppName} - HTTP"""; Flags: runhidden waituntilterminated

[UninstallDelete]
Type: filesandordirs; Name: "{app}\logs"
Type: filesandordirs; Name: "{app}\data"
Type: filesandordirs; Name: "{commonappdata}\{#MyAppName}"

[Code]
var
  PortPage: TInputQueryWizardPage;
  DbPage: TInputQueryWizardPage;
  ProgressPage: TOutputProgressWizardPage;

procedure InitializeWizard;
begin
  { Create custom pages }
  
  { Port Configuration Page }
  PortPage := CreateInputQueryPage(wpSelectTasks,
    'Network Configuration',
    'Configure network ports for NexusAI Enterprise',
    'Please specify the ports to use for the application:');
  
  PortPage.Add('HTTP Port:', False);
  PortPage.Add('Database Port:', False);
  PortPage.Add('Redis Port:', False);
  
  PortPage.Values[0] := '8000';
  PortPage.Values[1] := '5432';
  PortPage.Values[2] := '6379';
  
  { Database Configuration Page }
  DbPage := CreateInputQueryPage(PortPage.ID,
    'Database Configuration',
    'Configure the PostgreSQL database connection',
    'Please specify the database settings:');
  
  DbPage.Add('Database Host:', False);
  DbPage.Add('Database Name:', False);
  DbPage.Add('Database User:', False);
  DbPage.Add('Database Password:', True);
  
  DbPage.Values[0] := 'localhost';
  DbPage.Values[1] := 'nexusai';
  DbPage.Values[2] := 'nexusai';
  DbPage.Values[3] := '';
  
  { Progress Page }
  ProgressPage := CreateOutputProgressPage('Installing NexusAI Enterprise',
    'Please wait while the installation completes...');
end;

function NextButtonClick(CurPageID: Integer): Boolean;
var
  Port: Integer;
  ErrorCode: Integer;
begin
  Result := True;
  
  if CurPageID = PortPage.ID then
  begin
    { Validate port numbers }
    if not TryStrToInt(PortPage.Values[0], Port) or (Port < 1) or (Port > 65535) then
    begin
      MsgBox('Please enter a valid HTTP port number (1-65535).', mbError, MB_OK);
      Result := False;
    end;
  end;
end;

function UpdateReadyMemo(Space, NewLine, MemoUserInfoInfo, MemoDirInfo, MemoTypeInfo, MemoComponentsInfo, MemoGroupInfo, MemoTasksInfo: String): String;
var
  S: String;
begin
  S := '';
  S := S + MemoTasksInfo + NewLine + NewLine;
  S := S + 'Network Configuration:' + NewLine;
  S := S + Space + 'HTTP Port: ' + PortPage.Values[0] + NewLine;
  S := S + Space + 'Database Port: ' + PortPage.Values[1] + NewLine;
  S := S + Space + 'Redis Port: ' + PortPage.Values[2] + NewLine + NewLine;
  S := S + 'Database Configuration:' + NewLine;
  S := S + Space + 'Host: ' + DbPage.Values[0] + NewLine;
  S := S + Space + 'Database: ' + DbPage.Values[1] + NewLine;
  S := S + Space + 'User: ' + DbPage.Values[2] + NewLine;
  
  Result := S;
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then
  begin
    { Save configuration after installation }
    SaveConfigToFile;
  end;
end;

procedure SaveConfigToFile;
var
  ConfigFile: String;
  ConfigContent: String;
begin
  ConfigFile := ExpandConstant('{app}\config\config.yaml');
  
  ConfigContent := 
    '# NexusAI Enterprise Configuration' + #13#10 +
    '# Generated by installer on ' + GetDateTimeString('yyyy-mm-dd hh:nn:ss', '-', ':') + #13#10 +
    #13#10 +
    'app:' + #13#10 +
    '  name: "NexusAI Enterprise"' + #13#10 +
    '  version: "1.0.0"' + #13#10 +
    '  environment: "production"' + #13#10 +
    #13#10 +
    'server:' + #13#10 +
    '  host: "0.0.0.0"' + #13#10 +
    '  port: ' + PortPage.Values[0] + #13#10 +
    '  workers: 4' + #13#10 +
    #13#10 +
    'database:' + #13#10 +
    '  type: "postgresql"' + #13#10 +
    '  host: "' + DbPage.Values[0] + '"' + #13#10 +
    '  port: ' + PortPage.Values[1] + #13#10 +
    '  name: "' + DbPage.Values[1] + '"' + #13#10 +
    '  user: "' + DbPage.Values[2] + '"' + #13#10 +
    '  password: "' + DbPage.Values[3] + '"' + #13#10 +
    '  pool_size: 20' + #13#10 +
    #13#10 +
    'redis:' + #13#10 +
    '  host: "localhost"' + #13#10 +
    '  port: ' + PortPage.Values[2] + #13#10 +
    '  db: 0' + #13#10;
  
  SaveStringToFile(ConfigFile, ConfigContent, False);
end;

function InitializeSetup: Boolean;
var
  Version: String;
begin
  { Check Windows version }
  if not IsWindowsServer then
  begin
    if MsgBox('NexusAI Enterprise is designed for Windows Server. Continue anyway?', mbConfirmation, MB_YESNO) = IDNO then
    begin
      Result := False;
      Exit;
    end;
  end;
  
  { Check if already installed }
  if RegQueryStringValue(HKLM, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{#MyAppName}_is1', 'DisplayVersion', Version) then
  begin
    if MsgBox('NexusAI Enterprise version ' + Version + ' is already installed.' + #13#10 + 
              'Do you want to upgrade to version {#MyAppVersion}?', mbConfirmation, MB_YESNO) = IDNO then
    begin
      Result := False;
      Exit;
    end;
  end;
  
  Result := True;
end;

function IsWindowsServer: Boolean;
var
  ProductType: DWORD;
begin
  if RegQueryDWordValue(HKLM, 'SYSTEM\CurrentControlSet\Control\ProductOptions', 'ProductType', ProductType) then
  begin
    Result := (ProductType = 2) or (ProductType = 3); { Server or Domain Controller }
  end
  else
  begin
    Result := False;
  end;
end;
