"""
Tests de ClawSphere AMS
"""
