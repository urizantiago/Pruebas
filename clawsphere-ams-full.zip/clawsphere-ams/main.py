#!/usr/bin/env python3
"""
ClawSphere AMS - Main Application Entry Point

Agente de Inteligencia Artificial Empresarial para Soporte L2/L3
"""

import asyncio
import logging
import sys
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

# Configurar logging primero
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('logs/clawsphere.log')
    ]
)
logger = logging.getLogger(__name__)

# Importar componentes del sistema
try:
    from core.config import settings
    from core.events import event_bus
    from api.rest import create_rest_api
    from api.websocket import create_websocket_router
    from monitoring.metrics import setup_metrics
    from monitoring.health import health_checker
    from plugins.manager import PluginManager
    from tenant.manager import TenantManager
    logger.info("All modules imported successfully")
except ImportError as e:
    logger.error(f"Error importing modules: {e}")
    logger.error("Please ensure all dependencies are installed: pip install -r requirements.txt")
    sys.exit(1)


# Instancias globales
plugin_manager: PluginManager = None
tenant_manager: TenantManager = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Gestión del ciclo de vida de la aplicación.
    """
    global plugin_manager, tenant_manager
    
    # Startup
    logger.info("=" * 60)
    logger.info("ClawSphere AMS Starting...")
    logger.info("=" * 60)
    
    try:
        # Inicializar Tenant Manager
        logger.info("Initializing Tenant Manager...")
        tenant_manager = TenantManager()
        await tenant_manager.initialize()
        logger.info("Tenant Manager initialized")
        
        # Inicializar Plugin Manager
        logger.info("Initializing Plugin Manager...")
        plugin_manager = PluginManager()
        await plugin_manager.initialize()
        logger.info("Plugin Manager initialized")
        
        # Descubrir e instalar plugins nuevos
        logger.info("Discovering plugins...")
        discovery_results = await plugin_manager.discover_and_install(auto_enable=True)
        for result in discovery_results:
            if result.get('success'):
                logger.info(f"Plugin installed: {result.get('plugin_id')}")
            else:
                logger.warning(f"Plugin install failed: {result.get('error')}")
        
        # Inicializar métricas
        logger.info("Setting up metrics...")
        setup_metrics(app)
        
        # Inicializar health checks
        logger.info("Setting up health checks...")
        await health_checker.initialize()
        
        # Ejecutar hook de sistema iniciado
        await plugin_manager.execute_hook('system.startup')
        
        logger.info("=" * 60)
        logger.info("ClawSphere AMS Started Successfully!")
        logger.info(f"API Docs: http://{settings.HOST}:{settings.PORT}/docs")
        logger.info("=" * 60)
        
    except Exception as e:
        logger.error(f"Error during startup: {e}", exc_info=True)
        raise
    
    yield
    
    # Shutdown
    logger.info("=" * 60)
    logger.info("ClawSphere AMS Shutting Down...")
    logger.info("=" * 60)
    
    try:
        # Ejecutar hook de sistema detenido
        if plugin_manager:
            await plugin_manager.execute_hook('system.shutdown')
        
        # Cerrar plugin manager
        if plugin_manager:
            for plugin_id in list(plugin_manager._plugins.keys()):
                if plugin_manager._plugins[plugin_id].status.value == 'enabled':
                    await plugin_manager.disable_plugin(plugin_id)
        
        logger.info("ClawSphere AMS Stopped")
        
    except Exception as e:
        logger.error(f"Error during shutdown: {e}", exc_info=True)


def create_app() -> FastAPI:
    """
    Crea y configura la aplicación FastAPI.
    """
    app = FastAPI(
        title="ClawSphere AMS",
        description="Agente de Inteligencia Artificial Empresarial para Soporte L2/L3",
        version="1.0.0",
        lifespan=lifespan,
        docs_url="/docs" if settings.DEBUG else None,
        redoc_url="/redoc" if settings.DEBUG else None,
    )
    
    # CORS Middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Montar archivos estáticos del frontend
    try:
        app.mount("/static", StaticFiles(directory="frontend/dist"), name="static")
    except RuntimeError:
        logger.warning("Frontend dist directory not found, skipping static files mount")
    
    # Incluir routers
    app.include_router(create_rest_api(), prefix="/api/v1")
    app.include_router(create_websocket_router(), prefix="/ws")
    
    # Health check endpoint
    @app.get("/health")
    async def health_check():
        """Endpoint de health check."""
        status = await health_checker.check_all()
        return {
            "status": "healthy" if all(s.status.value == "healthy" for s in status.values()) else "degraded",
            "checks": {name: check.to_dict() for name, check in status.items()},
            "timestamp": datetime.now().isoformat()
        }
    
    # Root endpoint
    @app.get("/")
    async def root():
        """Endpoint raíz."""
        return {
            "name": "ClawSphere AMS",
            "version": "1.0.0",
            "description": "Agente de Inteligencia Artificial Empresarial para Soporte L2/L3",
            "docs": "/docs",
            "health": "/health"
        }
    
    return app


def main():
    """
    Punto de entrada principal.
    """
    import os
    from datetime import datetime
    
    # Crear directorios necesarios
    os.makedirs("logs", exist_ok=True)
    os.makedirs("data", exist_ok=True)
    os.makedirs("plugins", exist_ok=True)
    
    # Crear aplicación
    app = create_app()
    
    # Iniciar servidor
    uvicorn.run(
        app,
        host=settings.HOST,
        port=settings.PORT,
        log_level="info",
        access_log=True,
        reload=settings.DEBUG
    )


if __name__ == "__main__":
    main()
