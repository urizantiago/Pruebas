# ClawSphere AMS - Guía Rápida para Windows

## 🚀 Inicio Rápido (3 Pasos)

### Paso 1: Instalar
Haz doble clic en **`install-windows.bat`**

### Paso 2: Configurar
Edita el archivo `.env` con Notepad:
```cmd
notepad .env
```

Cambia las claves de seguridad y configura tu proveedor de IA.

### Paso 3: Iniciar
Haz doble clic en **`start-windows.bat`**

O en CMD:
```cmd
venv\Scripts\activate
python main.py
```

---

## 📋 Requisitos

- Windows 10/11 (64 bits)
- Python 3.9 o superior
- 4 GB RAM mínimo

---

## 🔧 Solución de Problemas

### Si algo falla, ejecuta:
```cmd
diagnose-windows.bat
```

### Tests de verificación:
```cmd
venv\Scripts\activate
python tests\test_windows_setup.py
```

---

## 📁 Archivos Importantes

| Archivo | Descripción |
|---------|-------------|
| `install-windows.bat` | Instala todo automáticamente |
| `start-windows.bat` | Inicia el servidor |
| `diagnose-windows.bat` | Diagnostica problemas |
| `.env.windows` | Configuración de ejemplo |
| `requirements-windows.txt` | Dependencias para Windows |
| `docs/WINDOWS_INSTALL_GUIDE.md` | Guía completa detallada |

---

## 🌐 Acceder a la aplicación

Una vez iniciado:
- **API**: http://localhost:7550
- **Documentación**: http://localhost:7550/docs
- **Health Check**: http://localhost:7550/health

---

## 📖 Documentación Completa

Ver: `docs/WINDOWS_INSTALL_GUIDE.md`

---

**¿Problemas?** Ejecuta `diagnose-windows.bat` y comparte el resultado.
