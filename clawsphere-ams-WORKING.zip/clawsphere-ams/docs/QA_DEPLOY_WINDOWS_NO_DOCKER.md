# Guía de Despliegue QA - Windows (Sin Docker)

Esta guía explica cómo desplegar ClawSphere AMS en un servidor Windows para ambientes de QA sin utilizar Docker ni servicios externos que requieran cuenta.

---

## Requisitos

### Hardware Mínimo
- **CPU**: 4 cores
- **RAM**: 8 GB
- **Disco**: 50 GB disponibles
- **OS**: Windows Server 2019/2022 o Windows 10/11

### Software Requerido
- Python 3.9 o superior
- Node.js 18 o superior
- Git para Windows
- SQLite (incluido con Python)
- Redis para Windows (opcional, para caché)

---

## Paso 1: Preparar el Servidor

### 1.1 Instalar Python

```powershell
# Descargar Python desde python.org
# URL: https://www.python.org/downloads/windows/

# Durante la instalación, marcar:
# ☑ Add Python to PATH
# ☑ Install pip

# Verificar instalación
python --version
pip --version
```

### 1.2 Instalar Node.js

```powershell
# Descargar desde nodejs.org
# URL: https://nodejs.org/en/download/

# Verificar instalación
node --version
npm --version
```

### 1.3 Instalar Git

```powershell
# Descargar desde git-scm.com
# URL: https://git-scm.com/download/win

# Verificar instalación
git --version
```

### 1.4 Instalar Redis (Opcional pero recomendado)

```powershell
# Opción 1: Usar Chocolatey
# Primero instalar Chocolatey:
Set-ExecutionPolicy Bypass -Scope Process -Force
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))

# Luego instalar Redis
choco install redis-64

# Opción 2: Descargar manualmente desde:
# https://github.com/microsoftarchive/redis/releases

# Iniciar Redis
redis-server
```

---

## Paso 2: Descargar el Código

```powershell
# Crear directorio para la aplicación
mkdir C:\ClawSphereAMS
cd C:\ClawSphereAMS

# Clonar el repositorio
git clone https://github.com/tu-org/clawsphere-ams.git .

# O si tienes el código en ZIP, extraerlo aquí
```

---

## Paso 3: Configurar el Backend

### 3.1 Crear Entorno Virtual

```powershell
# Crear entorno virtual
python -m venv venv

# Activar entorno virtual
.\venv\Scripts\activate

# Verificar que está activado (debería mostrar (venv) al inicio)
```

### 3.2 Instalar Dependencias

```powershell
# Asegurarse de estar en el entorno virtual
.\venv\Scripts\activate

# Instalar dependencias principales
pip install -r requirements.txt

# Si hay errores con alguna dependencia, instalar individualmente:
pip install fastapi uvicorn sqlalchemy pydantic
pip install aiohttp aiofiles python-jose passlib
pip install prometheus-client psutil
```

### 3.3 Configurar Variables de Entorno

```powershell
# Crear archivo .env en el directorio raíz
notepad .env
```

Contenido del archivo `.env`:

```env
# ============================================
# Configuración QA - Windows (Sin Docker)
# ============================================

# Entorno
ENVIRONMENT=qa
DEBUG=true
LOG_LEVEL=INFO

# Servidor
HOST=0.0.0.0
PORT=8000
WORKERS=2

# Base de datos (SQLite para QA local)
DATABASE_URL=sqlite:///C:/ClawSphereAMS/data/clawsphere.db
DATABASE_ECHO=false

# Seguridad
SECRET_KEY=qa-secret-key-cambiar-en-produccion
ENCRYPTION_KEY=qa-encryption-key-32-characters
ACCESS_TOKEN_EXPIRE_MINUTES=480

# AI (Usar Ollama local para QA)
DEFAULT_AI_PROVIDER=ollama
OLLAMA_URL=http://localhost:11434
OLLAMA_MODEL=llama2

# Deshabilitar servicios cloud
OPENAI_API_KEY=
ANTHROPIC_API_KEY=
AZURE_OPENAI_KEY=

# Prometheus (local)
PROMETHEUS_ENABLED=true
PROMETHEUS_PORT=9090
METRICS_PORT=8001

# Redis (local, opcional)
REDIS_ENABLED=true
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_DB=0
REDIS_PASSWORD=

# Mensajería (deshabilitar para QA)
TEAMS_WEBHOOK_URL=
TELEGRAM_BOT_TOKEN=
WHATSAPP_ENABLED=false

# Auto-remediación
AUTO_REMEDIATION_ENABLED=true
AUTO_REMEDIATION_DRY_RUN=false

# ML
ML_MODELS_PATH=C:/ClawSphereAMS/data/ml_models
ML_TRAINING_ENABLED=true

# Workflows
WORKFLOW_ENGINE_ENABLED=true
MAX_CONCURRENT_WORKFLOWS=5

# Multi-tenant (deshabilitar para QA simple)
MULTI_TENANT_ENABLED=false
DEFAULT_TENANT_ID=qa-tenant

# Límites
MAX_REQUESTS_PER_MINUTE=100
MAX_ALERTS_PER_DAY=1000

# Paths
DATA_PATH=C:/ClawSphereAMS/data
LOGS_PATH=C:/ClawSphereAMS/logs
TEMP_PATH=C:/ClawSphereAMS/temp
BACKUP_PATH=C:/ClawSphereAMS/backups
```

### 3.4 Crear Directorios Necesarios

```powershell
# Crear estructura de directorios
mkdir C:\ClawSphereAMS\data
mkdir C:\ClawSphereAMS\data\ml_models
mkdir C:\ClawSphereAMS\data\tenants
mkdir C:\ClawSphereAMS\logs
mkdir C:\ClawSphereAMS\temp
mkdir C:\ClawSphereAMS\backups
mkdir C:\ClawSphereAMS\config
mkdir C:\ClawSphereAMS\config\workflows
```

### 3.5 Inicializar Base de Datos

```powershell
# Asegurarse de estar en el entorno virtual
.\venv\Scripts\activate

# Ejecutar script de inicialización
python scripts\init_db.py

# O crear las tablas manualmente
python -c "
from core.config.database import init_db
import asyncio
asyncio.run(init_db())
"
```

---

## Paso 4: Configurar el Frontend

### 4.1 Instalar Dependencias

```powershell
# Navegar al directorio del frontend
cd C:\ClawSphereAMS\frontend

# Instalar dependencias
npm install

# Si hay errores, usar legacy peer deps
npm install --legacy-peer-deps
```

### 4.2 Configurar Variables de Entorno

```powershell
# Crear archivo .env.local
notepad .env.local
```

Contenido del archivo `.env.local`:

```env
# Frontend QA Configuration
VITE_API_URL=http://localhost:8000
VITE_WS_URL=ws://localhost:8000
VITE_APP_NAME=ClawSphere AMS QA
VITE_APP_VERSION=1.0.0-qa
VITE_ENVIRONMENT=qa
VITE_ENABLE_DEBUG=true
```

### 4.3 Compilar Frontend

```powershell
# Compilar para producción
npm run build

# Los archivos compilados estarán en dist/
```

---

## Paso 5: Configurar Servicios de Windows

### 5.1 Crear Script de Inicio del Backend

Crear archivo `C:\ClawSphereAMS\start_backend.ps1`:

```powershell
# start_backend.ps1
$ErrorActionPreference = "Stop"

# Cambiar al directorio de la aplicación
Set-Location C:\ClawSphereAMS

# Activar entorno virtual
.\venv\Scripts\activate

# Configurar variables de entorno
$env:PYTHONPATH = "C:\ClawSphereAMS"

# Iniciar servidor
Write-Host "Iniciando ClawSphere AMS Backend..."
python -m uvicorn api.rest.main:app --host 0.0.0.0 --port 8000 --workers 2
```

### 5.2 Crear Script de Inicio del Frontend

Crear archivo `C:\ClawSphereAMS\start_frontend.ps1`:

```powershell
# start_frontend.ps1
$ErrorActionPreference = "Stop"

# Cambiar al directorio del frontend
Set-Location C:\ClawSphereAMS\frontend

# Iniciar servidor de archivos estáticos
Write-Host "Iniciando ClawSphere AMS Frontend..."
npx serve dist -l 3000
```

### 5.3 Crear Servicio de Windows con NSSM

```powershell
# Descargar NSSM (Non-Sucking Service Manager)
# URL: https://nssm.cc/download

# Extraer nssm.exe a C:\Windows\System32\ o agregar al PATH

# Crear servicio para el backend
nssm install ClawSphereAMS-Backend

# En la ventana de NSSM:
# Path: C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe
# Startup directory: C:\ClawSphereAMS
# Arguments: -ExecutionPolicy Bypass -File C:\ClawSphereAMS\start_backend.ps1

# Crear servicio para el frontend
nssm install ClawSphereAMS-Frontend

# En la ventana de NSSM:
# Path: C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe
# Startup directory: C:\ClawSphereAMS
# Arguments: -ExecutionPolicy Bypass -File C:\ClawSphereAMS\start_frontend.ps1

# Iniciar servicios
nssm start ClawSphereAMS-Backend
nssm start ClawSphereAMS-Frontend

# Verificar estado
nssm status ClawSphereAMS-Backend
nssm status ClawSphereAMS-Frontend
```

### 5.4 Alternativa: Usar Tarea Programada

```powershell
# Crear tarea programada para inicio automático
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-ExecutionPolicy Bypass -File C:\ClawSphereAMS\start_backend.ps1"
$trigger = New-ScheduledTaskTrigger -AtStartup
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable

Register-ScheduledTask -TaskName "ClawSphereAMS-Backend" -Action $action -Trigger $trigger -Principal $principal -Settings $settings

# Crear tarea para el frontend
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-ExecutionPolicy Bypass -File C:\ClawSphereAMS\start_frontend.ps1"
Register-ScheduledTask -TaskName "ClawSphereAMS-Frontend" -Action $action -Trigger $trigger -Principal $principal -Settings $settings

# Iniciar tareas
Start-ScheduledTask -TaskName "ClawSphereAMS-Backend"
Start-ScheduledTask -TaskName "ClawSphereAMS-Frontend"
```

---

## Paso 6: Configurar Firewall

```powershell
# Abrir puertos en el firewall
New-NetFirewallRule -DisplayName "ClawSphereAMS-Backend" -Direction Inbound -Protocol TCP -LocalPort 8000 -Action Allow
New-NetFirewallRule -DisplayName "ClawSphereAMS-Frontend" -Direction Inbound -Protocol TCP -LocalPort 3000 -Action Allow
New-NetFirewallRule -DisplayName "ClawSphereAMS-Metrics" -Direction Inbound -Protocol TCP -LocalPort 8001 -Action Allow
New-NetFirewallRule -DisplayName "ClawSphereAMS-Prometheus" -Direction Inbound -Protocol TCP -LocalPort 9090 -Action Allow

# Verificar reglas
Get-NetFirewallRule -DisplayName "ClawSphereAMS*"
```

---

## Paso 7: Verificar Instalación

### 7.1 Verificar Backend

```powershell
# Probar health check
Invoke-RestMethod -Uri "http://localhost:8000/health" -Method GET

# Debería retornar: {"status": "healthy", ...}
```

### 7.2 Verificar Frontend

```powershell
# Abrir navegador y navegar a:
Start-Process "http://localhost:3000"
```

### 7.3 Verificar API Documentation

```powershell
# Swagger UI
Start-Process "http://localhost:8000/docs"

# ReDoc
Start-Process "http://localhost:8000/redoc"
```

---

## Paso 8: Configurar Monitoreo Básico

### 8.1 Script de Health Check

Crear `C:\ClawSphereAMS\health_check.ps1`:

```powershell
# health_check.ps1
$backend = Invoke-RestMethod -Uri "http://localhost:8000/health" -Method GET -ErrorAction SilentlyContinue
$frontend = Invoke-WebRequest -Uri "http://localhost:3000" -Method GET -ErrorAction SilentlyContinue

$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

if ($backend.status -eq "healthy" -and $frontend.StatusCode -eq 200) {
    Write-Host "[$timestamp] ✅ Todos los servicios están funcionando"
    exit 0
} else {
    Write-Host "[$timestamp] ❌ Algunos servicios no responden"
    exit 1
}
```

### 8.2 Configurar Monitoreo con Tarea Programada

```powershell
# Crear tarea para health check cada 5 minutos
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-ExecutionPolicy Bypass -File C:\ClawSphereAMS\health_check.ps1"
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration (New-TimeSpan -Days 365)

Register-ScheduledTask -TaskName "ClawSphereAMS-HealthCheck" -Action $action -Trigger $trigger
```

---

## Paso 9: Backup y Restore

### 9.1 Script de Backup

Crear `C:\ClawSphereAMS\backup.ps1`:

```powershell
# backup.ps1
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backupDir = "C:\ClawSphereAMS\backups\$timestamp"

# Crear directorio de backup
New-Item -ItemType Directory -Path $backupDir -Force

# Backup de base de datos
Copy-Item "C:\ClawSphereAMS\data\clawsphere.db" "$backupDir\clawsphere.db"

# Backup de configuración
Copy-Item "C:\ClawSphereAMS\.env" "$backupDir\.env"
Copy-Item "C:\ClawSphereAMS\config" "$backupDir\config" -Recurse

# Backup de datos
Copy-Item "C:\ClawSphereAMS\data" "$backupDir\data" -Recurse

# Comprimir
Compress-Archive -Path $backupDir -DestinationPath "$backupDir.zip"
Remove-Item $backupDir -Recurse

Write-Host "Backup completado: $backupDir.zip"
```

### 9.2 Script de Restore

Crear `C:\ClawSphereAMS\restore.ps1`:

```powershell
# restore.ps1
param([string]$BackupFile)

if (-not $BackupFile) {
    Write-Host "Uso: .\restore.ps1 -BackupFile <ruta-del-backup.zip>"
    exit 1
}

# Detener servicios
Stop-ScheduledTask -TaskName "ClawSphereAMS-Backend" -ErrorAction SilentlyContinue
Stop-ScheduledTask -TaskName "ClawSphereAMS-Frontend" -ErrorAction SilentlyContinue

# Extraer backup
$tempDir = "C:\ClawSphereAMS\temp\restore"
Expand-Archive -Path $BackupFile -DestinationPath $tempDir -Force

# Restaurar archivos
$backupContent = Get-ChildItem $tempDir | Select-Object -First 1
Copy-Item "$($backupContent.FullName)\clawsphere.db" "C:\ClawSphereAMS\data\clawsphere.db" -Force
Copy-Item "$($backupContent.FullName)\.env" "C:\ClawSphereAMS\.env" -Force

# Limpiar
Remove-Item $tempDir -Recurse -Force

# Iniciar servicios
Start-ScheduledTask -TaskName "ClawSphereAMS-Backend"
Start-ScheduledTask -TaskName "ClawSphereAMS-Frontend"

Write-Host "Restore completado desde: $BackupFile"
```

---

## Troubleshooting

### Problema: El backend no inicia

```powershell
# Verificar logs
Get-Content C:\ClawSphereAMS\logs\clawsphere.log -Tail 50

# Verificar que el entorno virtual esté activado
.\venv\Scripts\activate

# Reinstalar dependencias
pip install -r requirements.txt --force-reinstall
```

### Problema: El frontend no carga

```powershell
# Verificar que los archivos existan
Test-Path C:\ClawSphereAMS\frontend\dist\index.html

# Recompilar
cd C:\ClawSphereAMS\frontend
npm run build
```

### Problema: Error de permisos

```powershell
# Asignar permisos al directorio
icacls "C:\ClawSphereAMS" /grant Everyone:F /T

# O ejecutar como administrador
Start-Process powershell -Verb RunAs
```

---

## Comandos Útiles

```powershell
# Ver logs en tiempo real
Get-Content C:\ClawSphereAMS\logs\clawsphere.log -Wait

# Reiniciar servicios
Restart-ScheduledTask -TaskName "ClawSphereAMS-Backend"
Restart-ScheduledTask -TaskName "ClawSphereAMS-Frontend"

# Ver procesos
Get-Process | Where-Object {$_.ProcessName -like "*python*" -or $_.ProcessName -like "*node*"}

# Detener todos los procesos
Stop-Process -Name "python" -Force
Stop-Process -Name "node" -Force
```

---

## Notas Importantes

1. **Seguridad**: Cambiar las claves secretas en el archivo `.env` antes de usar en producción
2. **Backups**: Configurar backups automáticos diarios
3. **Logs**: Monitorear el espacio en disco ocupado por logs
4. **Actualizaciones**: Probar actualizaciones en QA antes de producción
