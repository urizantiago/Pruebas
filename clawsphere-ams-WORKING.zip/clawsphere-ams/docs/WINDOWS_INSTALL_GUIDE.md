# Guía de Instalación en Windows (Sin Docker)

## ClawSphere AMS - Paso a Paso Detallado

---

## 📋 ÍNDICE

1. [Requisitos Previos](#1-requisitos-previos)
2. [Instalación de Python](#2-instalación-de-python)
3. [Descargar el Proyecto](#3-descargar-el-proyecto)
4. [Crear Entorno Virtual](#4-crear-entorno-virtual)
5. [Instalar Dependencias](#5-instalar-dependencias)
6. [Configurar Variables de Entorno](#6-configurar-variables-de-entorno)
7. [Crear Estructura de Directorios](#7-crear-estructura-de-directorios)
8. [Configurar Base de Datos](#8-configurar-base-de-datos)
9. [Configurar Proveedor de IA](#9-configurar-proveedor-de-ia)
10. [Iniciar el Servidor](#10-iniciar-el-servidor)
11. [Verificar Funcionamiento](#11-verificar-funcionamiento)
12. [Solución de Problemas](#12-solución-de-problemas)

---

## 1. REQUISITOS PREVIOS

### Hardware Mínimo
- **RAM**: 4 GB (8 GB recomendado)
- **Disco**: 2 GB de espacio libre
- **Procesador**: 2 cores

### Software Requerido
- Windows 10/11 (64 bits)
- Python 3.9 o superior
- Git (opcional, para clonar)

---

## 2. INSTALACIÓN DE PYTHON

### Paso 2.1: Descargar Python
1. Ve a: https://python.org/downloads
2. Descarga **Python 3.11.x** (versión recomendada para Windows)
3. Ejecuta el instalador

### Paso 2.2: Instalar Python CORRECTAMENTE
⚠️ **IMPORTANTE**: Marca estas opciones durante la instalación:

```
☑️ Add Python to PATH (AGREGAR AL PATH)
☑️ Install for all users
☑️ Associate files with Python
```

Haz clic en **"Customize installation"** y asegúrate de:
```
☑️ pip
☑️ tcl/tk and IDLE
☑️ Python test suite
☑️ py launcher
☑️ for all users
```

### Paso 2.3: Verificar Instalación
Abre **CMD** o **PowerShell** como Administrador:

```cmd
python --version
```

Debe mostrar: `Python 3.11.x`

```cmd
pip --version
```

Debe mostrar la versión de pip.

---

## 3. DESCARGAR EL PROYECTO

### Opción A: Descargar ZIP
1. Descarga `clawsphere-ams-full.zip`
2. Extrae en: `C:\clawsphere-ams\`

### Opción B: Clonar con Git
```cmd
cd C:\
git clone https://github.com/tu-repo/clawsphere-ams.git
```

### Verificar estructura
```cmd
cd C:\clawsphere-ams
dir
```

Debes ver estos archivos:
```
main.py
requirements.txt
.env.example
README.md
```

---

## 4. CREAR ENTORNO VIRTUAL

### Paso 4.1: Abrir CMD como Administrador
Presiona `Win + R`, escribe `cmd`, presiona `Ctrl + Shift + Enter`

### Paso 4.2: Ir al directorio del proyecto
```cmd
cd C:\clawsphere-ams
```

### Paso 4.3: Crear entorno virtual
```cmd
python -m venv venv
```

### Paso 4.4: Activar entorno virtual
```cmd
venv\Scripts\activate
```

Verás: `(venv) C:\clawsphere-ams>`

⚠️ **IMPORTANTE**: Debes activar el entorno virtual CADA VEZ que abras una nueva terminal.

---

## 5. INSTALAR DEPENDENCIAS

### Paso 5.1: Actualizar pip
```cmd
python -m pip install --upgrade pip
```

### Paso 5.2: Instalar dependencias básicas PRIMERO
```cmd
pip install wheel setuptools
```

### Paso 5.3: Instalar dependencias principales (SIN PROBLEMAS)
Crea un archivo `requirements-windows.txt`:

```
# Web Framework
fastapi==0.109.0
uvicorn[standard]==0.27.0
python-multipart==0.0.6
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4

# Async
aiofiles==23.2.1
aiohttp==3.9.1
httpx==0.26.0

# Database (SQLite para Windows)
sqlalchemy[asyncio]==2.0.25
aiosqlite==0.19.0

# AI
openai==1.10.0
ollama==0.1.7

# Validation
pydantic==2.6.0
pydantic-settings==2.1.0
email-validator==2.1.0

# Utilities
pyyaml==6.0.1
python-dotenv==1.0.0
tenacity==8.2.3
jinja2==3.1.3
click==8.1.7
croniter==2.0.1

# Testing
pytest==8.0.0
pytest-asyncio==0.23.4

# Security
cryptography==42.0.2
pyjwt==2.8.0
```

Instala:
```cmd
pip install -r requirements-windows.txt
```

### Paso 5.4: Instalar dependencias OPCIONALES (si fallan, no es crítico)

**Para PostgreSQL (opcional):**
```cmd
pip install asyncpg==0.29.0
```
Si falla, usa SQLite que ya está incluido.

**Para SQL Server (opcional):**
```cmd
pip install pyodbc==5.0.1
```
Requiere: Microsoft ODBC Driver 17 for SQL Server

**Para SSH (opcional):**
```cmd
pip install paramiko==3.4.0
```

**Para WinRM (opcional):**
```cmd
pip install pywinrm==0.4.3
```

---

## 6. CONFIGURAR VARIABLES DE ENTORNO

### Paso 6.1: Crear archivo .env
```cmd
copy .env.example .env
```

### Paso 6.2: Editar .env con Notepad
```cmd
notepad .env
```

### Paso 6.3: Configuración MÍNIMA para Windows

Reemplaza TODO el contenido con esto:

```env
# ============================================
# ClawSphere AMS - Windows Configuration
# ============================================

# App
CLAWSPHERE_DEBUG=true
CLAWSPHERE_HOST=0.0.0.0
CLAWSPHERE_PORT=7550
CLAWSPHERE_CORS_ORIGINS=["*"]

# Security (CAMBIA ESTAS CLAVES!)
CLAWSPHERE_SECURITY_SECRET_KEY=tu-clave-secreta-32-caracteres-cambia-esto
CLAWSPHERE_SECURITY_ENCRYPTION_KEY=tu-clave-encriptacion-32-caracteres-cambia

# Database (SQLite para Windows)
CLAWSPHERE_DATABASE_URL=sqlite+aiosqlite:///data/clawsphere.db

# Redis (opcional, dejar así si no tienes Redis)
CLAWSPHERE_REDIS_URL=redis://localhost:6379/0

# AI Provider
CLAWSPHERE_AI_DEFAULT_PROVIDER=ollama
CLAWSPHERE_AI_FALLBACK_PROVIDERS=[]

# Ollama (descargar de https://ollama.com)
CLAWSPHERE_AI_OLLAMA_BASE_URL=http://localhost:11434
CLAWSPHERE_AI_OLLAMA_MODEL=qwen2.5-coder:14b

# OpenAI (opcional - si tienes API key)
# CLAWSPHERE_AI_OPENAI_API_KEY=sk-tu-api-key-aqui
# CLAWSPHERE_AI_OPENAI_MODEL=gpt-3.5-turbo

# Prometheus
CLAWSPHERE_PROMETHEUS_ENABLED=false

# Alerting
CLAWSPHERE_ALERT_ENABLED=false

# Multi-Tenant
CLAWSPHERE_MULTI_TENANT_ENABLED=false

# Auto-Remediation
CLAWSPHERE_AUTO_REMEDIATION_ENABLED=false

# ML
CLAWSPHERE_ML_ENABLED=false

# Logging
CLAWSPHERE_LOG_LEVEL=INFO
```

### Paso 6.4: Guardar y cerrar
- `Ctrl + S` para guardar
- Cierra Notepad

---

## 7. CREAR ESTRUCTURA DE DIRECTORIOS

### Paso 7.1: Crear directorios necesarios
```cmd
mkdir data
mkdir logs
mkdir plugins
mkdir data\models
mkdir data\backups
```

### Verificar:
```cmd
dir
```

Debes ver:
```
data/
logs/
plugins/
venv/
main.py
requirements.txt
.env
```

---

## 8. CONFIGURAR BASE DE DATOS

### Paso 8.1: SQLite (ya configurado)
No necesitas hacer nada más. SQLite crea el archivo automáticamente.

### Paso 8.2: Inicializar tablas (opcional)
El sistema creará las tablas automáticamente al iniciar.

---

## 9. CONFIGURAR PROVEEDOR DE IA

### Opción A: Ollama (Recomendado - GRATIS)

#### Paso 9.1.1: Descargar Ollama
1. Ve a: https://ollama.com/download/windows
2. Descarga e instala Ollama para Windows
3. Reinicia tu computadora

#### Paso 9.1.2: Verificar Ollama
Abre una nueva terminal (CMD) y ejecuta:
```cmd
ollama --version
```

#### Paso 9.1.3: Descargar modelo
```cmd
ollama pull qwen2.5-coder:14b
```

Esto descarga ~9GB. Espera a que termine.

#### Paso 9.1.4: Verificar que Ollama está corriendo
```cmd
ollama list
```

Debe mostrar: `qwen2.5-coder:14b`

### Opción B: OpenAI (PAGO - pero más fácil)

#### Paso 9.2.1: Obtener API Key
1. Ve a: https://platform.openai.com/api-keys
2. Crea una nueva API key
3. Copia la key

#### Paso 9.2.2: Configurar en .env
Edita `.env`:
```cmd
notepad .env
```

Cambia:
```env
CLAWSPHERE_AI_DEFAULT_PROVIDER=openai
CLAWSPHERE_AI_OPENAI_API_KEY=sk-tu-api-key-real-aqui
```

---

## 10. INICIAR EL SERVIDOR

### Paso 10.1: Asegurar que estás en el directorio correcto
```cmd
cd C:\clawsphere-ams
```

### Paso 10.2: Activar entorno virtual
```cmd
venv\Scripts\activate
```

Debes ver: `(venv)` al inicio de la línea

### Paso 10.3: Ejecutar tests de verificación
```cmd
python tests\test_windows_setup.py
```

Si todos los tests pasan, continúa.

### Paso 10.4: Iniciar el servidor
```cmd
python main.py
```

Debes ver:
```
============================================================
  ClawSphere AMS Starting...
============================================================
...
============================================================
  ClawSphere AMS Started Successfully!
  API Docs: http://0.0.0.0:7550/docs
============================================================
```

### Paso 10.5: Abrir en navegador
Abre: http://localhost:7550/docs

---

## 11. VERIFICAR FUNCIONAMIENTO

### Test 1: Health Check
En navegador o CMD:
```cmd
curl http://localhost:7550/health
```

Debe retornar:
```json
{"status": "healthy", ...}
```

### Test 2: API Docs
Abre: http://localhost:7550/docs

Debes ver la interfaz Swagger con todos los endpoints.

### Test 3: Chat
En Swagger:
1. Ve a POST /api/v1/chat
2. Click "Try it out"
3. Body:
```json
{
  "message": "hola",
  "application_context": "test"
}
```
4. Click "Execute"

Debe retornar una respuesta.

---

## 12. SOLUCIÓN DE PROBLEMAS

### Error: "python no se reconoce como comando"
**Causa**: Python no está en el PATH

**Solución**:
1. Reinstala Python marcando "Add to PATH"
2. O agrega manualmente:
   ```
   C:\Users\TU_USUARIO\AppData\Local\Programs\Python\Python311
   C:\Users\TU_USUARIO\AppData\Local\Programs\Python\Python311\Scripts
   ```

### Error: "No module named 'xxx'"
**Causa**: Dependencia no instalada

**Solución**:
```cmd
pip install nombre-del-modulo
```

### Error: "Permission denied"
**Causa**: No tienes permisos

**Solución**: Ejecuta CMD como Administrador

### Error: "Port 7550 is in use"
**Causa**: Otro programa usa el puerto

**Solución A**: Cambia el puerto en `.env`:
```env
CLAWSPHERE_PORT=7551
```

**Solución B**: Encuentra y mata el proceso:
```cmd
netstat -ano | findstr :7550
taskkill /PID NUMERO_PID /F
```

### Error: "ImportError: cannot import name 'xxx'"
**Causa**: Import circular o módulo no encontrado

**Solución**:
```cmd
pip install --force-reinstall -r requirements-windows.txt
```

### Error: "Failed to connect to Ollama"
**Causa**: Ollama no está corriendo

**Solución**:
1. Abre nueva terminal
2. Ejecuta: `ollama serve`
3. Deja esa terminal abierta
4. En otra terminal, ejecuta ClawSphere

### Error: "No module named 'core'"
**Causa**: No estás en el directorio correcto

**Solución**:
```cmd
cd C:\clawsphere-ams
python main.py
```

### Error: "SyntaxError" o "IndentationError"
**Causa**: Archivos corruptos o mal copiados

**Solución**: Re-descarga el ZIP y extrae de nuevo.

### Error: "Out of memory" al cargar modelo
**Causa**: No hay suficiente RAM

**Solución**: Usa un modelo más pequeño:
```cmd
ollama pull qwen2.5-coder:7b
```

Y cambia en `.env`:
```env
CLAWSPHERE_AI_OLLAMA_MODEL=qwen2.5-coder:7b
```

---

## 🆘 SOPORTE

Si sigues teniendo problemas:

1. Ejecuta el test de diagnóstico:
   ```cmd
   python tests\test_windows_setup.py > diagnostico.txt
   ```

2. Comparte el archivo `diagnostico.txt`

3. Revisa los logs en: `logs\clawsphere.log`

---

## ✅ CHECKLIST FINAL

Antes de iniciar, verifica:

- [ ] Python 3.9+ instalado y en PATH
- [ ] Entorno virtual creado y activado
- [ ] Dependencias instaladas sin errores
- [ ] Archivo `.env` creado y configurado
- [ ] Directorios `data/`, `logs/`, `plugins/` creados
- [ ] Ollama instalado y modelo descargado (o OpenAI API key)
- [ ] Puerto 7550 disponible
- [ ] Ejecutando desde `C:\clawsphere-ams`

---

**¡Listo! Si seguiste todos los pasos, ClawSphere AMS debería estar funcionando.**
