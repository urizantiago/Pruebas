# Guía del Desarrollador - ClawSphere AMS

## Índice
1. [Introducción](#introducción)
2. [Configuración del Entorno](#configuración-del-entorno)
3. [Arquitectura del Proyecto](#arquitectura-del-proyecto)
4. [Desarrollo de Nuevas Integraciones](#desarrollo-de-nuevas-integraciones)
5. [Testing](#testing)
6. [Buenas Prácticas](#buenas-prácticas)

---

## Introducción

Bienvenido al equipo de desarrollo de ClawSphere AMS. Esta guía te ayudará a entender la arquitectura del proyecto y cómo contribuir con nuevas integraciones.

### ¿Qué es ClawSphere AMS?

ClawSphere AMS es un agente de Inteligencia Artificial empresarial para soporte de aplicaciones L2/L3 (Application Management Services) que proporciona:

- Gestión autónoma de servidores y bases de datos
- Auto-remediación de problemas
- Predicción de incidentes usando Machine Learning
- Orquestación de workflows
- Soporte multi-tenant

---

## Configuración del Entorno

### Requisitos Previos

- Python 3.9+
- Node.js 18+ (para frontend)
- Git
- Visual Studio Code (recomendado)

### Paso 1: Clonar el Repositorio

```bash
git clone https://github.com/tu-org/clawsphere-ams.git
cd clawsphere-ams
```

### Paso 2: Crear Entorno Virtual

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Linux/Mac
python3 -m venv venv
source venv/bin/activate
```

### Paso 3: Instalar Dependencias

```bash
# Dependencias principales
pip install -r requirements.txt

# Dependencias de desarrollo
pip install -r requirements-dev.txt

# Dependencias de testing
pip install -r requirements-test.txt
```

### Paso 4: Configurar Variables de Entorno

```bash
cp .env.example .env
```

Edita el archivo `.env` con tus configuraciones:

```env
# Base de datos
DATABASE_URL=sqlite:///./clawsphere.db

# Seguridad
SECRET_KEY=tu-clave-secreta-aqui
ENCRYPTION_KEY=tu-clave-de-encriptacion

# AI Adapters
OPENAI_API_KEY=tu-api-key
ANTHROPIC_API_KEY=tu-api-key

# Prometheus
PROMETHEUS_URL=http://localhost:9090
```

### Paso 5: Inicializar la Base de Datos

```bash
python scripts/init_db.py
```

### Paso 6: Ejecutar el Servidor de Desarrollo

```bash
# Backend
python -m api.rest.main

# Frontend (en otra terminal)
cd frontend
npm install
npm run dev
```

---

## Arquitectura del Proyecto

### Estructura de Directorios

```
clawsphere-ams/
├── adapters/           # Adaptadores para servicios externos
│   ├── ai/            # OpenAI, Anthropic, Ollama
│   ├── databases/     # SQL Server, PostgreSQL, MongoDB, etc.
│   ├── messaging/     # Teams, Telegram, WhatsApp
│   └── servers/       # SSH, WinRM
├── api/               # API REST y WebSocket
│   ├── rest/         # Endpoints REST
│   ├── websocket/    # WebSocket handlers
│   └── middleware/   # Middleware (auth, logging, etc.)
├── auto_remediation/  # Sistema de auto-remediación
├── core/              # Núcleo del sistema
│   ├── config/       # Configuración
│   ├── events/       # Sistema de eventos
│   ├── orchestrator/ # Orquestador del agente
│   ├── plugins/      # Sistema de plugins
│   └── state/        # Gestión de estado
├── ml_prediction/     # Machine Learning
│   └── models/       # Modelos (IsolationForest, Prophet, LSTM)
├── skills/            # Skills L2/L3
├── tenant/            # Soporte multi-tenant
├── workflow/          # Workflow Engine
└── tests/             # Tests
```

### Patrones de Diseño

#### 1. Adaptador (Adapter Pattern)

Los adaptadores permiten conectar con diferentes servicios externos:

```python
# adapters/databases/base.py
class BaseDatabaseAdapter(ABC):
    @abstractmethod
    async def connect(self): pass
    
    @abstractmethod
    async def execute_query(self, query: str): pass

# adapters/databases/postgresql.py
class PostgreSQLAdapter(BaseDatabaseAdapter):
    async def connect(self):
        # Implementación específica
        pass
```

#### 2. Plugin (Plugin Pattern)

Los skills son plugins que extienden las capacidades del agente:

```python
# core/plugins/base.py
class BaseSkill(ABC):
    name: str = ""
    description: str = ""
    
    @abstractmethod
    async def execute(self, context: SkillContext, **params) -> SkillResult:
        pass
```

#### 3. Observer (Event Bus)

El sistema de eventos permite comunicación desacoplada:

```python
# Publicar evento
await event_bus.publish(Event(
    type=EventType.ALERT_RECEIVED,
    data={"alert": alert_data},
    source="prometheus"
))

# Suscribirse a eventos
event_bus.subscribe(EventType.ALERT_RECEIVED, handle_alert)
```

---

## Desarrollo de Nuevas Integraciones

### Crear un Nuevo Adaptador de Base de Datos

#### Paso 1: Crear el Archivo del Adaptador

```python
# adapters/databases/cassandra.py

from typing import Dict, Any, List, Optional
from .base import BaseDatabaseAdapter, QueryResult, ConnectionConfig

class CassandraAdapter(BaseDatabaseAdapter):
    """Adaptador para Apache Cassandra."""
    
    db_type = "cassandra"
    
    def __init__(self, config: ConnectionConfig):
        super().__init__(config)
        self._cluster = None
        self._session = None
    
    async def connect(self) -> bool:
        """Establece conexión con Cassandra."""
        try:
            from cassandra.cluster import Cluster
            
            self._cluster = Cluster(
                contact_points=self.config.hosts,
                port=self.config.port or 9042
            )
            self._session = self._cluster.connect(self.config.database)
            
            # Autenticación si es necesaria
            if self.config.username and self.config.password:
                from cassandra.auth import PlainTextAuthProvider
                auth_provider = PlainTextAuthProvider(
                    username=self.config.username,
                    password=self.config.password
                )
                self._cluster.auth_provider = auth_provider
            
            self._connected = True
            return True
            
        except Exception as e:
            self._last_error = str(e)
            return False
    
    async def disconnect(self) -> bool:
        """Cierra la conexión."""
        if self._cluster:
            self._cluster.shutdown()
        self._connected = False
        return True
    
    async def execute_query(
        self, 
        query: str, 
        parameters: tuple = None
    ) -> QueryResult:
        """Ejecuta una consulta CQL."""
        if not self._connected:
            await self.connect()
        
        try:
            start_time = datetime.utcnow()
            
            if parameters:
                result = self._session.execute(query, parameters)
            else:
                result = self._session.execute(query)
            
            execution_time = (datetime.utcnow() - start_time).total_seconds()
            
            # Convertir resultados a lista de diccionarios
            rows = [dict(row._asdict()) for row in result]
            
            return QueryResult(
                success=True,
                data=rows,
                row_count=len(rows),
                execution_time_ms=execution_time * 1000
            )
            
        except Exception as e:
            return QueryResult(
                success=False,
                error=str(e),
                data=[]
            )
    
    async def test_connection(self) -> bool:
        """Prueba la conexión."""
        try:
            result = await self.execute_query("SELECT now() FROM system.local")
            return result.success
        except:
            return False
```

#### Paso 2: Registrar el Adaptador en la Factory

```python
# adapters/databases/factory.py

from .cassandra import CassandraAdapter

class DatabaseAdapterFactory:
    def __init__(self):
        self._adapters = {
            # ... adaptadores existentes
            "cassandra": CassandraAdapter,
        }
```

#### Paso 3: Agregar Tests

```python
# tests/unit/test_cassandra_adapter.py

import pytest
from adapters.databases.cassandra import CassandraAdapter

class TestCassandraAdapter:
    @pytest.mark.asyncio
    async def test_connection(self):
        config = ConnectionConfig(
            host="localhost",
            port=9042,
            database="test"
        )
        adapter = CassandraAdapter(config)
        
        result = await adapter.test_connection()
        assert result is True
```

### Crear un Nuevo Skill

#### Paso 1: Crear el Skill

```python
# skills/cassandra_management.py

from core.plugins.base import BaseSkill, SkillContext, SkillResult, RiskLevel, SkillCategory

class CassandraOptimizeSkill(BaseSkill):
    """Skill para optimizar tablas de Cassandra."""
    
    name = "cassandra_optimize"
    description = "Optimiza tablas de Cassandra con compaction y repair"
    category = SkillCategory.DATABASE_MANAGEMENT
    risk_level = RiskLevel.HIGH
    requires_approval = True
    
    async def execute(
        self, 
        context: SkillContext, 
        **params
    ) -> SkillResult:
        """Ejecuta la optimización."""
        try:
            keyspace = params.get("keyspace")
            table = params.get("table")
            
            # Obtener adaptador
            from adapters.databases.factory import database_adapter_factory
            adapter = await database_adapter_factory.get_adapter(
                params.get("instance"), 
                keyspace
            )
            
            # Ejecutar compaction
            compaction_result = await adapter.execute_query(
                f"ALTER TABLE {keyspace}.{table} WITH compaction = {{...}}"
            )
            
            return SkillResult.success_result(
                data={"compaction": compaction_result.success},
                message=f"Tabla {table} optimizada exitosamente"
            )
            
        except Exception as e:
            return SkillResult.error_result(
                error=str(e),
                message="Error optimizando tabla"
            )
```

#### Paso 2: Registrar el Skill

```python
# skills/__init__.py

from .cassandra_management import CassandraOptimizeSkill

__all__ = [
    # ... skills existentes
    'CassandraOptimizeSkill',
]
```

### Crear un Nuevo Modelo de ML

```python
# ml_prediction/models/random_forest.py

from typing import Dict, Any, List, Optional
import numpy as np
from .base import BaseMLModel

class RandomForestModel(BaseMLModel):
    """Modelo Random Forest para clasificación."""
    
    name = "random_forest"
    version = "1.0.0"
    description = "Clasificación usando Random Forest"
    
    def __init__(self, model_path: Optional[str] = None, n_estimators: int = 100):
        super().__init__(model_path)
        self.n_estimators = n_estimators
    
    async def train(
        self, 
        data: List[Dict[str, Any]], 
        **kwargs
    ) -> Dict[str, Any]:
        """Entrena el modelo."""
        from sklearn.ensemble import RandomForestClassifier
        
        # Preparar datos
        X, y = self._prepare_data(data)
        
        # Entrenar
        self._model = RandomForestClassifier(
            n_estimators=self.n_estimators,
            **kwargs
        )
        self._model.fit(X, y)
        self._is_trained = True
        
        return {
            "status": "success",
            "samples": len(data),
            "features": X.shape[1]
        }
    
    async def predict(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Realiza predicción."""
        X = self._extract_features(data)
        prediction = self._model.predict([X])[0]
        probability = self._model.predict_proba([X])[0]
        
        return {
            "prediction": int(prediction),
            "confidence": float(max(probability)),
            "probabilities": probability.tolist()
        }
```

---

## Testing

### Ejecutar Tests

```bash
# Todos los tests
pytest

# Solo tests unitarios
pytest -m unit

# Solo tests de integración
pytest -m integration

# Con coverage
pytest --cov=clawsphere --cov-report=html

# Tests específicos
pytest tests/unit/test_tenant_manager.py

# Tests con verbose
pytest -vvs
```

### Escribir Tests

```python
# tests/unit/test_nuevo_modulo.py

import pytest
from unittest.mock import Mock, AsyncMock

class TestNuevoModulo:
    """Tests para el nuevo módulo."""
    
    @pytest.fixture
    def mock_dependency(self):
        """Fixture para dependencia mock."""
        mock = AsyncMock()
        mock.execute.return_value = {"success": True}
        return mock
    
    @pytest.mark.asyncio
    async def test_funcion_principal(self, mock_dependency):
        """Test la función principal."""
        # Arrange
        modulo = NuevoModulo(mock_dependency)
        
        # Act
        result = await modulo.funcion_principal()
        
        # Assert
        assert result["success"] is True
        mock_dependency.execute.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_manejo_errores(self):
        """Test manejo de errores."""
        modulo = NuevoModulo()
        
        with pytest.raises(ValueError, match="parámetro requerido"):
            await modulo.funcion_principal(parametro=None)
```

---

## Buenas Prácticas

### 1. Código Limpio

```python
# ✅ Bueno
def calculate_disk_usage_percentage(used: int, total: int) -> float:
    """Calcula el porcentaje de uso de disco.
    
    Args:
        used: Bytes usados
        total: Bytes totales
        
    Returns:
        Porcentaje de uso (0-100)
    """
    if total == 0:
        return 0.0
    return (used / total) * 100

# ❌ Malo
def calc(a, b):
    return (a/b)*100
```

### 2. Manejo de Errores

```python
# ✅ Bueno
try:
    result = await adapter.execute_query(query)
except DatabaseConnectionError as e:
    logger.error(f"Error de conexión: {e}")
    raise ServiceUnavailableError("Database unavailable")
except Exception as e:
    logger.exception("Error inesperado")
    raise

# ❌ Malo
try:
    result = await adapter.execute_query(query)
except:
    pass
```

### 3. Async/Await

```python
# ✅ Bueno
async def process_alerts(alerts: List[Alert]):
    tasks = [process_alert(alert) for alert in alerts]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    return results

# ❌ Malo
async def process_alerts(alerts: List[Alert]):
    results = []
    for alert in alerts:
        results.append(await process_alert(alert))  # Secuencial
    return results
```

### 4. Type Hints

```python
# ✅ Bueno
from typing import Dict, List, Optional

def get_user(
    user_id: str, 
    include_inactive: bool = False
) -> Optional[Dict[str, Any]]:
    ...

# ❌ Malo
def get_user(user_id, include_inactive=False):
    ...
```

### 5. Documentación

```python
class AlertManager:
    """Gestiona alertas del sistema.
    
    Esta clase proporciona métodos para crear, actualizar y
    consultar alertas de monitoreo.
    
    Attributes:
        max_alerts: Número máximo de alertas a mantener en memoria
        retention_days: Días de retención de alertas
    
    Example:
        >>> manager = AlertManager(max_alerts=1000)
        >>> await manager.create_alert(
        ...     name="High CPU",
        ...     severity="warning",
        ...     message="CPU > 80%"
        ... )
    """
    
    async def create_alert(
        self, 
        name: str, 
        severity: str, 
        message: str
    ) -> Alert:
        """Crea una nueva alerta.
        
        Args:
            name: Nombre identificador de la alerta
            severity: Nivel de severidad (info, warning, critical)
            message: Descripción detallada
            
        Returns:
            La alerta creada
            
        Raises:
            ValueError: Si la severidad no es válida
            QuotaExceededError: Si se excede el límite de alertas
        """
        ...
```

---

## Recursos Adicionales

- [Documentación de FastAPI](https://fastapi.tiangolo.com/)
- [Documentación de SQLAlchemy](https://docs.sqlalchemy.org/)
- [Guía de Python Async](https://docs.python.org/3/library/asyncio.html)
- [Patrones de Diseño](https://refactoring.guru/design-patterns)

---

## Contacto

- **Slack**: #clawsphere-dev
- **Email**: dev-team@clawsphere.com
- **Wiki**: https://wiki.clawsphere.com
