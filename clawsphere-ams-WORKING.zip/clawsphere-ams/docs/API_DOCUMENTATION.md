# Documentación API - ClawSphere AMS

## Índice
- [Introducción](#introducción)
- [Autenticación](#autenticación)
- [Endpoints](#endpoints)
- [Modelos](#modelos)
- [Errores](#errores)
- [WebSockets](#websockets)

---

## Introducción

La API de ClawSphere AMS está construida con FastAPI y sigue los principios REST. Toda la comunicación se realiza en JSON sobre HTTPS.

### URL Base
```
https://api.clawsphere.com/v1
```

### Versión Actual
```
v1.0.0
```

### Content-Type
```
Content-Type: application/json
```

---

## Autenticación

La API utiliza autenticación JWT (JSON Web Tokens). Incluye el token en el header de cada petición:

```http
Authorization: Bearer <tu-token-jwt>
```

### Obtener Token

```http
POST /auth/login
Content-Type: application/json

{
  "username": "tu-usuario",
  "password": "tu-password"
}
```

**Respuesta exitosa (200):**
```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "token_type": "bearer",
  "expires_in": 480,
  "refresh_token": "dGhpcyBpcyBhIHJlZnJlc2ggdG9rZW4..."
}
```

### Refrescar Token

```http
POST /auth/refresh
Content-Type: application/json

{
  "refresh_token": "dGhpcyBpcyBhIHJlZnJlc2ggdG9rZW4..."
}
```

---

## Endpoints

### Health Check

#### GET /health
Verifica el estado del sistema.

**Respuesta (200):**
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "timestamp": "2024-01-15T10:30:00Z",
  "services": {
    "database": "connected",
    "redis": "connected",
    "ai_engine": "ready"
  }
}
```

---

### Tenants

#### GET /tenants
Lista todos los tenants (requiere rol admin).

**Parámetros de query:**
- `status` (opcional): Filtrar por estado (active, suspended, pending)
- `plan` (opcional): Filtrar por plan (free, starter, professional, enterprise)
- `page` (opcional): Número de página (default: 1)
- `limit` (opcional): Resultados por página (default: 20, max: 100)

**Respuesta (200):**
```json
{
  "tenants": [
    {
      "id": "tenant-001",
      "name": "Acme Corporation",
      "slug": "acme-corp",
      "status": "active",
      "plan": "enterprise",
      "created_at": "2024-01-01T00:00:00Z",
      "updated_at": "2024-01-15T10:30:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150,
    "pages": 8
  }
}
```

#### POST /tenants
Crea un nuevo tenant.

**Request body:**
```json
{
  "name": "Nueva Empresa",
  "slug": "nueva-empresa",
  "contact_email": "admin@nuevaempresa.com",
  "contact_phone": "+1234567890",
  "plan": "starter"
}
```

**Respuesta (201):**
```json
{
  "id": "tenant-new-001",
  "name": "Nueva Empresa",
  "slug": "nueva-empresa",
  "status": "active",
  "plan": "starter",
  "api_key": "cs_live_abc123xyz",
  "created_at": "2024-01-15T10:30:00Z"
}
```

#### GET /tenants/{tenant_id}
Obtiene detalles de un tenant específico.

**Respuesta (200):**
```json
{
  "id": "tenant-001",
  "name": "Acme Corporation",
  "slug": "acme-corp",
  "contact_email": "admin@acme.com",
  "contact_phone": "+1234567890",
  "status": "active",
  "plan": "enterprise",
  "limits": {
    "max_users": -1,
    "max_servers": -1,
    "max_applications": -1,
    "max_workflows": -1,
    "data_retention_days": 365
  },
  "usage": {
    "users": 45,
    "servers": 12,
    "applications": 23,
    "workflows": 18
  },
  "settings": {
    "require_mfa": true,
    "sso_enabled": false
  },
  "created_at": "2024-01-01T00:00:00Z",
  "updated_at": "2024-01-15T10:30:00Z"
}
```

#### PATCH /tenants/{tenant_id}
Actualiza un tenant.

**Request body:**
```json
{
  "name": "Acme Corp Updated",
  "plan": "professional",
  "settings": {
    "require_mfa": true
  }
}
```

#### DELETE /tenants/{tenant_id}
Elimina un tenant.

**Respuesta (204):** No content

---

### Skills

#### GET /skills
Lista todos los skills disponibles.

**Respuesta (200):**
```json
{
  "skills": [
    {
      "name": "check_server_status",
      "description": "Verifica el estado de un servidor",
      "category": "server_management",
      "risk_level": "low",
      "requires_approval": false,
      "parameters": {
        "server": {
          "type": "string",
          "required": true,
          "description": "Nombre o IP del servidor"
        }
      }
    },
    {
      "name": "restart_service",
      "description": "Reinicia un servicio en un servidor",
      "category": "server_management",
      "risk_level": "high",
      "requires_approval": true,
      "parameters": {
        "server": {
          "type": "string",
          "required": true
        },
        "service": {
          "type": "string",
          "required": true
        }
      }
    }
  ]
}
```

#### POST /skills/execute
Ejecuta un skill.

**Request body:**
```json
{
  "skill_name": "check_server_status",
  "parameters": {
    "server": "prod-server-01"
  },
  "context": {
    "user_id": "user-001",
    "user_roles": ["admin"],
    "session_id": "session-001",
    "application_context": "Production"
  },
  "requires_approval": false
}
```

**Respuesta (200):**
```json
{
  "success": true,
  "data": {
    "status": "online",
    "cpu_usage": 45.2,
    "memory_usage": 62.1,
    "disk_usage": 78.5,
    "uptime": "15d 3h 24m"
  },
  "message": "Servidor prod-server-01 está online",
  "execution_time_ms": 1250,
  "approval_required": false
}
```

---

### Workflows

#### GET /workflows
Lista todos los workflows.

**Respuesta (200):**
```json
{
  "workflows": [
    {
      "id": "incident-response-v1",
      "name": "Incident Response",
      "description": "Workflow automatizado para respuesta a incidentes",
      "version": "1.0.0",
      "trigger": "alert",
      "enabled": true,
      "steps_count": 8,
      "created_at": "2024-01-01T00:00:00Z"
    }
  ]
}
```

#### GET /workflows/{workflow_id}
Obtiene detalles de un workflow.

**Respuesta (200):**
```json
{
  "id": "incident-response-v1",
  "name": "Incident Response",
  "description": "Workflow automatizado para respuesta a incidentes",
  "version": "1.0.0",
  "trigger": "alert",
  "trigger_config": {
    "alert_name": "HighCPUUsage"
  },
  "steps": [
    {
      "id": "notify_team",
      "name": "Notify Team",
      "step_type": "notification",
      "next_steps": ["assess_impact"]
    },
    {
      "id": "assess_impact",
      "name": "Assess Impact",
      "step_type": "action",
      "action": "assess_incident_impact",
      "on_success": "check_severity",
      "on_failure": "escalate"
    }
  ],
  "enabled": true,
  "created_at": "2024-01-01T00:00:00Z"
}
```

#### POST /workflows
Crea un nuevo workflow.

**Request body:**
```json
{
  "name": "Custom Workflow",
  "description": "Mi workflow personalizado",
  "trigger": "manual",
  "steps": [
    {
      "id": "step1",
      "name": "First Step",
      "step_type": "action",
      "action": "check_server_status",
      "parameters": {"server": "localhost"},
      "next_steps": ["step2"]
    },
    {
      "id": "step2",
      "name": "Second Step",
      "step_type": "notification",
      "parameters": {"message": "Workflow completed"}
    }
  ]
}
```

#### POST /workflows/{workflow_id}/execute
Ejecuta un workflow.

**Request body:**
```json
{
  "input_data": {
    "alert_id": "alert-001",
    "severity": "high"
  },
  "created_by": "user-001"
}
```

**Respuesta (202):**
```json
{
  "instance_id": "wf-instance-001",
  "workflow_id": "incident-response-v1",
  "status": "running",
  "started_at": "2024-01-15T10:30:00Z",
  "message": "Workflow iniciado exitosamente"
}
```

#### GET /workflows/instances/{instance_id}
Obtiene el estado de una instancia de workflow.

**Respuesta (200):**
```json
{
  "instance_id": "wf-instance-001",
  "workflow_id": "incident-response-v1",
  "workflow_name": "Incident Response",
  "status": "completed",
  "current_step_id": null,
  "executed_steps": ["notify_team", "assess_impact", "auto_remediate"],
  "step_results": {
    "notify_team": {
      "status": "success",
      "output": {"message_sent": true},
      "execution_time_ms": 500
    }
  },
  "started_at": "2024-01-15T10:30:00Z",
  "completed_at": "2024-01-15T10:32:15Z"
}
```

---

### Alertas

#### GET /alerts
Lista todas las alertas.

**Parámetros de query:**
- `status` (opcional): active, resolved, silenced
- `severity` (opcional): info, warning, critical
- `service` (opcional): Filtrar por servicio
- `from` (opcional): Fecha inicio (ISO 8601)
- `to` (opcional): Fecha fin (ISO 8601)

**Respuesta (200):**
```json
{
  "alerts": [
    {
      "id": "alert-001",
      "name": "HighCPUUsage",
      "severity": "warning",
      "status": "active",
      "message": "CPU usage is above 80%",
      "service": "api-gateway",
      "instance": "server-01",
      "value": 85.5,
      "started_at": "2024-01-15T10:30:00Z",
      "acknowledged_by": null,
      "acknowledged_at": null
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150
  }
}
```

#### POST /alerts
Crea una nueva alerta.

**Request body:**
```json
{
  "name": "CustomAlert",
  "severity": "warning",
  "message": "Custom alert message",
  "service": "my-service",
  "instance": "server-01",
  "value": 75.5,
  "labels": {
    "environment": "production"
  },
  "annotations": {
    "summary": "Summary of the alert",
    "runbook_url": "https://wiki/runbook"
  }
}
```

#### POST /alerts/{alert_id}/acknowledge
Reconoce una alerta.

**Request body:**
```json
{
  "notes": "Investigando el problema"
}
```

#### POST /alerts/{alert_id}/resolve
Resuelve una alerta.

**Request body:**
```json
{
  "resolution": "Servicio reiniciado exitosamente"
}
```

---

### Métricas

#### GET /metrics
Obtiene métricas del sistema.

**Respuesta (200):**
```json
{
  "metrics": [
    {
      "name": "cpu_usage",
      "value": 45.2,
      "unit": "percent",
      "timestamp": "2024-01-15T10:30:00Z",
      "labels": {
        "instance": "server-01"
      }
    },
    {
      "name": "memory_usage",
      "value": 62.1,
      "unit": "percent",
      "timestamp": "2024-01-15T10:30:00Z",
      "labels": {
        "instance": "server-01"
      }
    }
  ]
}
```

#### GET /metrics/{metric_name}
Obtiene una métrica específica.

**Parámetros de query:**
- `instance` (opcional): Filtrar por instancia
- `from` (opcional): Fecha inicio
- `to` (opcional): Fecha fin
- `aggregation` (opcional): avg, min, max, sum

**Respuesta (200):**
```json
{
  "name": "cpu_usage",
  "values": [
    {"timestamp": "2024-01-15T10:00:00Z", "value": 45.2},
    {"timestamp": "2024-01-15T10:05:00Z", "value": 47.1},
    {"timestamp": "2024-01-15T10:10:00Z", "value": 44.8}
  ],
  "statistics": {
    "avg": 45.7,
    "min": 44.8,
    "max": 47.1
  }
}
```

---

### Auto-Remediación

#### GET /remediation/policies
Lista políticas de remediación.

**Respuesta (200):**
```json
{
  "policies": [
    {
      "id": "srv-restart-on-high-memory",
      "name": "Restart Service on High Memory",
      "enabled": true,
      "action_name": "restart_service",
      "severity": "medium",
      "requires_approval": false,
      "cooldown_minutes": 10
    }
  ]
}
```

#### GET /remediation/history
Obtiene historial de remediaciones.

**Respuesta (200):**
```json
{
  "remediations": [
    {
      "remediation_id": "rem-001",
      "alert_id": "alert-001",
      "action_name": "restart_service",
      "status": "success",
      "success": true,
      "message": "Servicio reiniciado exitosamente",
      "started_at": "2024-01-15T10:30:00Z",
      "completed_at": "2024-01-15T10:30:05Z",
      "execution_time_ms": 5000
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 500
  }
}
```

#### POST /remediation/execute
Ejecuta una remediación manual.

**Request body:**
```json
{
  "action_name": "clear_disk_space",
  "alert_id": "alert-001",
  "parameters": {
    "mount_point": "/",
    "target_free_percent": 20
  },
  "dry_run": false
}
```

---

### ML Predicciones

#### GET /ml/anomalies
Obtiene anomalías detectadas.

**Respuesta (200):**
```json
{
  "anomalies": [
    {
      "detection_id": "anom-001",
      "metric_name": "cpu_usage",
      "timestamp": "2024-01-15T10:30:00Z",
      "is_anomaly": true,
      "severity": "high",
      "anomaly_score": -0.65,
      "current_value": 95.5,
      "expected_range": [30, 70]
    }
  ]
}
```

#### GET /ml/predictions/incidents
Obtiene predicciones de incidentes.

**Respuesta (200):**
```json
{
  "predictions": [
    {
      "prediction_id": "pred-001",
      "incident_type": "performance_degradation",
      "service": "api-gateway",
      "probability": 0.75,
      "confidence": "high",
      "predicted_time": "2024-01-15T12:00:00Z",
      "contributing_factors": [
        {
          "factor": "cpu_usage",
          "current_value": 85.5,
          "contribution_score": 0.8
        }
      ],
      "recommended_actions": [
        "Scale up service",
        "Investigate bottlenecks"
      ]
    }
  ]
}
```

---

## Modelos

### User
```json
{
  "id": "string",
  "username": "string",
  "email": "string",
  "full_name": "string",
  "roles": ["string"],
  "tenant_id": "string",
  "is_active": true,
  "last_login": "2024-01-15T10:30:00Z",
  "created_at": "2024-01-01T00:00:00Z"
}
```

### Tenant
```json
{
  "id": "string",
  "name": "string",
  "slug": "string",
  "contact_email": "string",
  "status": "active | suspended | pending | cancelled",
  "plan": "free | starter | professional | enterprise",
  "limits": {
    "max_users": 0,
    "max_servers": 0,
    "max_applications": 0
  },
  "created_at": "2024-01-01T00:00:00Z"
}
```

### Alert
```json
{
  "id": "string",
  "name": "string",
  "severity": "info | warning | critical",
  "status": "active | resolved | silenced",
  "message": "string",
  "service": "string",
  "instance": "string",
  "value": 0.0,
  "started_at": "2024-01-15T10:30:00Z",
  "resolved_at": "2024-01-15T11:00:00Z",
  "acknowledged_by": "string",
  "labels": {},
  "annotations": {}
}
```

---

## Errores

### Formatos de Error

**400 Bad Request:**
```json
{
  "error": "validation_error",
  "message": "Invalid request parameters",
  "details": [
    {
      "field": "email",
      "message": "Invalid email format"
    }
  ]
}
```

**401 Unauthorized:**
```json
{
  "error": "unauthorized",
  "message": "Invalid or expired token"
}
```

**403 Forbidden:**
```json
{
  "error": "forbidden",
  "message": "Insufficient permissions"
}
```

**404 Not Found:**
```json
{
  "error": "not_found",
  "message": "Resource not found"
}
```

**429 Rate Limited:**
```json
{
  "error": "rate_limited",
  "message": "Too many requests",
  "retry_after": 60
}
```

**500 Internal Server Error:**
```json
{
  "error": "internal_error",
  "message": "An unexpected error occurred",
  "request_id": "req-001"
}
```

### Códigos de Error Comunes

| Código | Descripción |
|--------|-------------|
| `validation_error` | Parámetros de entrada inválidos |
| `unauthorized` | Token inválido o expirado |
| `forbidden` | Permisos insuficientes |
| `not_found` | Recurso no encontrado |
| `conflict` | Conflicto con estado actual |
| `rate_limited` | Límite de peticiones excedido |
| `quota_exceeded` | Cuota del tenant excedida |
| `service_unavailable` | Servicio temporalmente no disponible |

---

## WebSockets

### Conexión

```javascript
const ws = new WebSocket('wss://api.clawsphere.com/v1/ws');

ws.onopen = () => {
  // Autenticar
  ws.send(JSON.stringify({
    type: 'auth',
    token: 'tu-token-jwt'
  }));
};

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('Received:', data);
};
```

### Eventos

#### Alerta Recibida
```json
{
  "type": "alert_received",
  "data": {
    "alert_id": "alert-001",
    "name": "HighCPUUsage",
    "severity": "warning",
    "message": "CPU usage is above 80%"
  },
  "timestamp": "2024-01-15T10:30:00Z"
}
```

#### Workflow Completado
```json
{
  "type": "workflow_completed",
  "data": {
    "instance_id": "wf-instance-001",
    "workflow_id": "incident-response-v1",
    "status": "completed"
  },
  "timestamp": "2024-01-15T10:32:15Z"
}
```

#### Métrica en Tiempo Real
```json
{
  "type": "metric_update",
  "data": {
    "name": "cpu_usage",
    "value": 85.5,
    "instance": "server-01",
    "timestamp": "2024-01-15T10:30:00Z"
  }
}
```

---

## Rate Limiting

- **Límite general**: 1000 peticiones por minuto
- **Límite por tenant**: 100 peticiones por minuto
- **Límite de autenticación**: 5 intentos por minuto

Los headers de respuesta incluyen información sobre el rate limiting:

```http
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1642249200
```

---

## SDKs Oficiales

- [Python SDK](https://github.com/clawsphere/clawsphere-python-sdk)
- [JavaScript SDK](https://github.com/clawsphere/clawsphere-js-sdk)
- [Go SDK](https://github.com/clawsphere/clawsphere-go-sdk)

---

## Soporte

- **Documentación**: https://docs.clawsphere.com
- **Soporte técnico**: support@clawsphere.com
- **Status page**: https://status.clawsphere.com
