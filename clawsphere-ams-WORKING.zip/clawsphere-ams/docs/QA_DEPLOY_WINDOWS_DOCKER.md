# Guía de Despliegue QA - Windows (Con Docker)

Esta guía explica cómo desplegar ClawSphere AMS en un servidor Windows usando Docker y Docker Compose.

---

## Requisitos

### Hardware Mínimo
- **CPU**: 4 cores
- **RAM**: 8 GB (16 GB recomendado)
- **Disco**: 50 GB disponibles
- **OS**: Windows 10/11 Pro o Windows Server 2019/2022

### Software Requerido
- Docker Desktop para Windows
- Docker Compose (incluido con Docker Desktop)
- Git para Windows

---

## Paso 1: Instalar Docker Desktop

### 1.1 Descargar e Instalar

```powershell
# Descargar desde:
# https://docs.docker.com/desktop/install/windows-install/

# O usar Chocolatey
choco install docker-desktop
```

### 1.2 Configurar Docker Desktop

1. Abrir Docker Desktop
2. Ir a Settings > General
3. ☑ Enable Docker Compose V2
4. ☑ Use the WSL 2 based engine (recomendado)
5. Aplicar cambios y reiniciar

### 1.3 Verificar Instalación

```powershell
# Verificar Docker
docker --version
docker-compose --version

# Probar Docker
docker run hello-world
```

---

## Paso 2: Preparar el Entorno

### 2.1 Crear Estructura de Directorios

```powershell
# Crear directorio principal
mkdir C:\ClawSphereAMS
cd C:\ClawSphereAMS

# Crear subdirectorios
mkdir data
mkdir data\ml_models
mkdir data\tenants
mkdir logs
mkdir backups
mkdir config
mkdir config\workflows
mkdir prometheus
mkdir prometheus\rules
mkdir grafana
mkdir grafana\dashboards
mkdir grafana\provisioning
```

### 2.2 Clonar el Repositorio

```powershell
# Clonar código
git clone https://github.com/tu-org/clawsphere-ams.git source

# O extraer ZIP si no hay acceso a Git
```

---

## Paso 3: Configurar Docker Compose

### 3.1 Crear docker-compose.yml

Crear archivo `C:\ClawSphereAMS\docker-compose.yml`:

```yaml
version: '3.8'

services:
  # ============================================
  # Base de datos PostgreSQL
  # ============================================
  postgres:
    image: postgres:15-alpine
    container_name: clawsphere-postgres
    restart: unless-stopped
    environment:
      POSTGRES_USER: clawsphere
      POSTGRES_PASSWORD: qa_password_123
      POSTGRES_DB: clawsphere_qa
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./backups:/backups
    ports:
      - "5432:5432"
    networks:
      - clawsphere-network
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U clawsphere"]
      interval: 10s
      timeout: 5s
      retries: 5

  # ============================================
  # Redis para caché
  # ============================================
  redis:
    image: redis:7-alpine
    container_name: clawsphere-redis
    restart: unless-stopped
    command: redis-server --appendonly yes
    volumes:
      - redis_data:/data
    ports:
      - "6379:6379"
    networks:
      - clawsphere-network
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5

  # ============================================
  # Backend API
  # ============================================
  backend:
    build:
      context: ./source
      dockerfile: Dockerfile
    container_name: clawsphere-backend
    restart: unless-stopped
    environment:
      # Base de datos
      DATABASE_URL: postgresql://clawsphere:qa_password_123@postgres:5432/clawsphere_qa
      
      # Redis
      REDIS_URL: redis://redis:6379/0
      
      # Seguridad
      SECRET_KEY: ${SECRET_KEY:-qa-secret-key-change-me}
      ENCRYPTION_KEY: ${ENCRYPTION_KEY:-qa-encryption-key-32-chars}
      
      # Entorno
      ENVIRONMENT: qa
      DEBUG: "true"
      LOG_LEVEL: INFO
      
      # AI (Ollama local)
      DEFAULT_AI_PROVIDER: ollama
      OLLAMA_URL: http://ollama:11434
      
      # Prometheus
      PROMETHEUS_ENABLED: "true"
      
      # Features
      AUTO_REMEDIATION_ENABLED: "true"
      WORKFLOW_ENGINE_ENABLED: "true"
      MULTI_TENANT_ENABLED: "false"
      
      # Paths
      DATA_PATH: /app/data
      ML_MODELS_PATH: /app/data/ml_models
    volumes:
      - ./data:/app/data
      - ./logs:/app/logs
      - ./config:/app/config
    ports:
      - "8000:8000"
    networks:
      - clawsphere-network
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

  # ============================================
  # Frontend
  # ============================================
  frontend:
    build:
      context: ./source/frontend
      dockerfile: Dockerfile
    container_name: clawsphere-frontend
    restart: unless-stopped
    environment:
      VITE_API_URL: http://localhost:8000
      VITE_WS_URL: ws://localhost:8000
      VITE_ENVIRONMENT: qa
    ports:
      - "3000:80"
    networks:
      - clawsphere-network
    depends_on:
      - backend

  # ============================================
  # Prometheus para métricas
  # ============================================
  prometheus:
    image: prom/prometheus:v2.47.0
    container_name: clawsphere-prometheus
    restart: unless-stopped
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--web.console.libraries=/usr/share/prometheus/console_libraries'
      - '--web.console.templates=/usr/share/prometheus/consoles'
      - '--web.enable-lifecycle'
    volumes:
      - ./prometheus/prometheus.yml:/etc/prometheus/prometheus.yml:ro
      - ./prometheus/rules:/etc/prometheus/rules:ro
      - prometheus_data:/prometheus
    ports:
      - "9090:9090"
    networks:
      - clawsphere-network

  # ============================================
  # Grafana para dashboards
  # ============================================
  grafana:
    image: grafana/grafana:10.1.0
    container_name: clawsphere-grafana
    restart: unless-stopped
    environment:
      GF_SECURITY_ADMIN_USER: admin
      GF_SECURITY_ADMIN_PASSWORD: admin123
      GF_USERS_ALLOW_SIGN_UP: "false"
      GF_INSTALL_PLUGINS: grafana-clock-panel,grafana-simple-json-datasource
    volumes:
      - grafana_data:/var/lib/grafana
      - ./grafana/provisioning:/etc/grafana/provisioning:ro
      - ./grafana/dashboards:/var/lib/grafana/dashboards:ro
    ports:
      - "3001:3000"
    networks:
      - clawsphere-network
    depends_on:
      - prometheus

  # ============================================
  # Ollama para AI local
  # ============================================
  ollama:
    image: ollama/ollama:latest
    container_name: clawsphere-ollama
    restart: unless-stopped
    volumes:
      - ollama_data:/root/.ollama
    ports:
      - "11434:11434"
    networks:
      - clawsphere-network
    # Descargar modelo al iniciar
    entrypoint: >
      sh -c "
        ollama serve &
        sleep 10
        ollama pull llama2
        wait
      "

  # ============================================
  # Node Exporter para métricas del host
  # ============================================
  node-exporter:
    image: prom/node-exporter:v1.6.1
    container_name: clawsphere-node-exporter
    restart: unless-stopped
    volumes:
      - /proc:/host/proc:ro
      - /sys:/host/sys:ro
      - /:/rootfs:ro
    command:
      - '--path.procfs=/host/proc'
      - '--path.rootfs=/rootfs'
      - '--path.sysfs=/host/sys'
      - '--collector.filesystem.mount-points-exclude=^/(sys|proc|dev|host|etc)($$|/)'
    ports:
      - "9100:9100"
    networks:
      - clawsphere-network

  # ============================================
  # Cadvisor para métricas de contenedores
  # ============================================
  cadvisor:
    image: gcr.io/cadvisor/cadvisor:v0.47.2
    container_name: clawsphere-cadvisor
    restart: unless-stopped
    privileged: true
    volumes:
      - /:/rootfs:ro
      - /var/run:/var/run:ro
      - /sys:/sys:ro
      - /var/lib/docker/:/var/lib/docker:ro
      - /dev/disk/:/dev/disk:ro
    ports:
      - "8080:8080"
    networks:
      - clawsphere-network

  # ============================================
  # AlertManager para alertas
  # ============================================
  alertmanager:
    image: prom/alertmanager:v0.26.0
    container_name: clawsphere-alertmanager
    restart: unless-stopped
    volumes:
      - ./prometheus/alertmanager.yml:/etc/alertmanager/alertmanager.yml:ro
      - alertmanager_data:/alertmanager
    command:
      - '--config.file=/etc/alertmanager/alertmanager.yml'
      - '--storage.path=/alertmanager'
    ports:
      - "9093:9093"
    networks:
      - clawsphere-network

volumes:
  postgres_data:
  redis_data:
  prometheus_data:
  grafana_data:
  ollama_data:
  alertmanager_data:

networks:
  clawsphere-network:
    driver: bridge
```

### 3.2 Crear Configuración de Prometheus

Crear `C:\ClawSphereAMS\prometheus\prometheus.yml`:

```yaml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

alerting:
  alertmanagers:
    - static_configs:
        - targets:
          - alertmanager:9093

rule_files:
  - /etc/prometheus/rules/*.yml

scrape_configs:
  - job_name: 'prometheus'
    static_configs:
      - targets: ['localhost:9090']

  - job_name: 'backend'
    static_configs:
      - targets: ['backend:8000']
    metrics_path: /metrics

  - job_name: 'node-exporter'
    static_configs:
      - targets: ['node-exporter:9100']

  - job_name: 'cadvisor'
    static_configs:
      - targets: ['cadvisor:8080']
```

### 3.3 Crear Configuración de AlertManager

Crear `C:\ClawSphereAMS\prometheus\alertmanager.yml`:

```yaml
global:
  smtp_smarthost: 'localhost:587'
  smtp_from: 'alerts@clawsphere.local'

route:
  group_by: ['alertname']
  group_wait: 10s
  group_interval: 10s
  repeat_interval: 1h
  receiver: 'web.hook'

receivers:
  - name: 'web.hook'
    webhook_configs:
      - url: 'http://backend:8000/api/v1/alerts/webhook'
        send_resolved: true

inhibit_rules:
  - source_match:
      severity: 'critical'
    target_match:
      severity: 'warning'
    equal: ['alertname', 'dev', 'instance']
```

### 3.4 Crear Dockerfile del Backend

Crear `C:\ClawSphereAMS\source\Dockerfile`:

```dockerfile
FROM python:3.11-slim

# Instalar dependencias del sistema
RUN apt-get update && apt-get install -y \
    gcc \
    postgresql-client \
    curl \
    && rm -rf /var/lib/apt/lists/*

# Crear directorio de la aplicación
WORKDIR /app

# Copiar requirements primero para aprovechar caché
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copiar código fuente
COPY . .

# Crear directorios necesarios
RUN mkdir -p /app/data /app/logs /app/config

# Exponer puerto
EXPOSE 8000

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=40s --retries=3 \
    CMD curl -f http://localhost:8000/health || exit 1

# Comando de inicio
CMD ["uvicorn", "api.rest.main:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "2"]
```

### 3.5 Crear Dockerfile del Frontend

Crear `C:\ClawSphereAMS\source\frontend\Dockerfile`:

```dockerfile
# Etapa de build
FROM node:18-alpine AS builder

WORKDIR /app

# Copiar package files
COPY package*.json ./
RUN npm ci

# Copiar código fuente y compilar
COPY . .
RUN npm run build

# Etapa de producción
FROM nginx:alpine

# Copiar configuración de nginx
COPY nginx.conf /etc/nginx/conf.d/default.conf

# Copiar archivos compilados
COPY --from=builder /app/dist /usr/share/nginx/html

# Exponer puerto
EXPOSE 80

# Health check
HEALTHCHECK --interval=30s --timeout=10s --retries=3 \
    CMD wget --no-verbose --tries=1 --spider http://localhost/ || exit 1

CMD ["nginx", "-g", "daemon off;"]
```

### 3.6 Crear Configuración de Nginx

Crear `C:\ClawSphereAMS\source\frontend\nginx.conf`:

```nginx
server {
    listen 80;
    server_name localhost;
    root /usr/share/nginx/html;
    index index.html;

    # Compresión
    gzip on;
    gzip_types text/plain text/css application/json application/javascript;

    # Cache para archivos estáticos
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # SPA - redirigir todo a index.html
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Health check
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
}
```

---

## Paso 4: Iniciar los Servicios

### 4.1 Construir e Iniciar

```powershell
cd C:\ClawSphereAMS

# Construir imágenes
docker-compose build

# Iniciar servicios
docker-compose up -d

# Verificar estado
docker-compose ps

# Ver logs
docker-compose logs -f
```

### 4.2 Verificar Servicios

```powershell
# Backend
Invoke-RestMethod -Uri "http://localhost:8000/health" -Method GET

# Frontend
Invoke-RestMethod -Uri "http://localhost:3000" -Method GET

# Prometheus
Start-Process "http://localhost:9090"

# Grafana
Start-Process "http://localhost:3001"
# Login: admin / admin123
```

---

## Paso 5: Configurar Grafana

### 5.1 Acceder a Grafana

1. Abrir http://localhost:3001
2. Login: `admin` / `admin123`

### 5.2 Configurar Data Source

1. Ir a Configuration > Data Sources
2. Agregar Prometheus
3. URL: `http://prometheus:9090`
4. Save & Test

### 5.3 Importar Dashboards

Crear `C:\ClawSphereAMS\grafana\dashboards\clawsphere-dashboard.json`:

```json
{
  "dashboard": {
    "title": "ClawSphere AMS - Overview",
    "panels": [
      {
        "title": "Backend Requests",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(http_requests_total[5m])",
            "legendFormat": "{{method}} {{endpoint}}"
          }
        ]
      },
      {
        "title": "CPU Usage",
        "type": "gauge",
        "targets": [
          {
            "expr": "100 - (avg by (instance) (irate(node_cpu_seconds_total{mode=\"idle\"}[5m])) * 100)"
          }
        ]
      },
      {
        "title": "Memory Usage",
        "type": "stat",
        "targets": [
          {
            "expr": "node_memory_MemTotal_bytes - node_memory_MemAvailable_bytes"
          }
        ]
      }
    ]
  }
}
```

---

## Paso 6: Comandos Útiles

```powershell
# Ver logs de un servicio específico
docker-compose logs -f backend

# Reiniciar un servicio
docker-compose restart backend

# Escalar servicios
docker-compose up -d --scale backend=3

# Ejecutar comandos en un contenedor
docker-compose exec backend python -c "print('Hello')"

# Backup de base de datos
docker-compose exec postgres pg_dump -U clawsphere clawsphere_qa > backup.sql

# Restaurar base de datos
docker-compose exec -T postgres psql -U clawsphere clawsphere_qa < backup.sql

# Actualizar imágenes
docker-compose pull
docker-compose up -d

# Limpiar volúmenes no utilizados
docker volume prune

# Ver uso de recursos
docker stats
```

---

## Paso 7: Troubleshooting

### Problema: Contenedores no inician

```powershell
# Ver logs detallados
docker-compose logs --tail=100

# Verificar configuración
docker-compose config

# Reconstruir sin caché
docker-compose build --no-cache
```

### Problema: Error de permisos en volúmenes

```powershell
# En Windows, los volúmenes pueden tener problemas de permisos
# Solución: Usar volúmenes nombrados en lugar de bind mounts
# O ejecutar Docker Desktop como administrador
```

### Problema: Puerto ya en uso

```powershell
# Encontrar proceso usando el puerto
netstat -ano | findstr :8000

# Matar proceso
Stop-Process -Id <PID>

# O cambiar puerto en docker-compose.yml
```

---

## Paso 8: Backup y Restore

### 8.1 Script de Backup

Crear `C:\ClawSphereAMS\backup.ps1`:

```powershell
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backupDir = "C:\ClawSphereAMS\backups\$timestamp"

New-Item -ItemType Directory -Path $backupDir

# Backup de base de datos
docker-compose exec -T postgres pg_dump -U clawsphere clawsphere_qa > "$backupDir\database.sql"

# Backup de volúmenes
docker run --rm -v clawsphereams_postgres_data:/data -v "$backupDir\postgres:/backup" alpine tar czf /backup/postgres.tar.gz -C /data .
docker run --rm -v clawsphereams_redis_data:/data -v "$backupDir\redis:/backup" alpine tar czf /backup/redis.tar.gz -C /data .

# Backup de configuración
Copy-Item .env "$backupDir\.env"
Copy-Item docker-compose.yml "$backupDir\docker-compose.yml"
Copy-Item -Recurse config "$backupDir\config"
Copy-Item -Recurse prometheus "$backupDir\prometheus"

# Comprimir todo
Compress-Archive -Path $backupDir -DestinationPath "$backupDir.zip"
Remove-Item $backupDir -Recurse

Write-Host "Backup completado: $backupDir.zip"
```

### 8.2 Script de Restore

```powershell
param([string]$BackupFile)

# Detener servicios
docker-compose down

# Extraer backup
$tempDir = "C:\ClawSphereAMS\temp\restore"
Expand-Archive -Path $BackupFile -DestinationPath $tempDir

$backupContent = Get-ChildItem $tempDir | Select-Object -First 1

# Restaurar configuración
Copy-Item "$($backupContent.FullName)\.env" .\.env -Force
Copy-Item "$($backupContent.FullName)\docker-compose.yml" .\docker-compose.yml -Force

# Restaurar volúmenes
docker run --rm -v clawsphereams_postgres_data:/data -v "$($backupContent.FullName)\postgres:/backup" alpine sh -c "cd /data && tar xzf /backup/postgres.tar.gz"
docker run --rm -v clawsphereams_redis_data:/data -v "$($backupContent.FullName)\redis:/backup" alpine sh -c "cd /data && tar xzf /backup/redis.tar.gz"

# Restaurar base de datos
docker-compose up -d postgres
Start-Sleep -Seconds 10
docker-compose exec -T postgres psql -U clawsphere -d clawsphere_qa < "$($backupContent.FullName)\database.sql"

# Iniciar todos los servicios
docker-compose up -d

# Limpiar
Remove-Item $tempDir -Recurse -Force

Write-Host "Restore completado"
```

---

## Recursos Adicionales

- [Documentación de Docker](https://docs.docker.com/)
- [Docker Compose Reference](https://docs.docker.com/compose/compose-file/)
- [Grafana Documentation](https://grafana.com/docs/)
- [Prometheus Documentation](https://prometheus.io/docs/)
