# ClawSphere AMS

**Agente de Inteligencia Artificial Empresarial para Soporte de Aplicaciones L2 y L3**

[![Python](https://img.shields.io/badge/Python-3.9+-blue.svg)](https://python.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.109+-green.svg)](https://fastapi.tiangolo.com)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

## 🎯 Visión General

ClawSphere AMS es un agente de IA empresarial diseñado para revolucionar el soporte de aplicaciones de nivel L2 y L3. Proporciona una arquitectura limpia, extensible y segura que permite a los equipos de soporte interactuar con sistemas complejos mediante lenguaje natural.

### Características Principales

- 🔐 **Seguridad 360°**: Encriptación end-to-end, autenticación AD/LDAP, RBAC granular
- 🤖 **Multi-IA**: Soporte para Ollama, OpenAI, Anthropic, Google, DeepSeek, LM Studio, GPT4All, vLLM
- 🗄️ **Multi-Base de Datos**: SQL Server, PostgreSQL, Oracle, DB2, Informix, BigQuery
- 🖥️ **Multi-Servidor**: Linux, Windows, AIX via SSH y WinRM
- 💬 **Multi-Canal**: Microsoft Teams, Telegram, WhatsApp
- 🔌 **Arquitectura Limpia**: Sistema de plugins para extensibilidad sin modificar código

## 🏗️ Arquitectura

```
clawsphere-ams/
├── core/                    # Núcleo del sistema
│   ├── orchestrator/        # Orquestador del agente
│   ├── plugins/             # Sistema de plugins
│   ├── config/              # Configuración
│   ├── state/               # Gestión de estado
│   └── events/              # Bus de eventos
├── adapters/                # Adaptadores externos
│   ├── ai/                  # Proveedores de IA
│   ├── databases/           # Bases de datos
│   ├── servers/             # Servidores (SSH/WinRM)
│   └── messaging/           # Mensajería
├── skills/                  # Plugins de skills
│   ├── server_management/   # Gestión de servidores
│   ├── database_management/ # Gestión de BD
│   ├── api_management/      # Gestión de APIs
│   ├── security_management/ # Gestión de seguridad
│   ├── monitoring/          # Monitoreo
│   └── automation/          # Automatización
├── security/                # Capa de seguridad
│   ├── auth/                # Autenticación
│   ├── encryption/          # Encriptación
│   ├── rbac/                # Control de acceso
│   └── audit/               # Auditoría
├── api/                     # APIs
│   └── rest/                # API REST
└── config/                  # Configuraciones
    └── apps/                # Configuración por app
```

## 🚀 Instalación

### Requisitos

- Python 3.9+
- pip
- Virtualenv (recomendado)

### Pasos

1. **Clonar el repositorio**
```bash
git clone https://github.com/company/clawsphere-ams.git
cd clawsphere-ams
```

2. **Crear entorno virtual**
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# o
venv\Scripts\activate  # Windows
```

3. **Instalar dependencias**
```bash
pip install -r requirements.txt
```

4. **Configurar variables de entorno**
```bash
cp .env.example .env
# Editar .env con tus configuraciones
```

5. **Iniciar el servidor**
```bash
python main.py
```

## ⚙️ Configuración

### Variables de Entorno Principales

```bash
# Seguridad
CLAWSPHERE_SECURITY_SECRET_KEY=tu-clave-secreta-32-caracteres!!
CLAWSPHERE_SECURITY_ENCRYPTION_KEY=tu-clave-encriptacion-32-chars!!

# IA (Ollama por defecto)
CLAWSPHERE_AI_DEFAULT_PROVIDER=ollama
CLAWSPHERE_AI_OLLAMA_BASE_URL=http://localhost:11434

# O usar OpenAI
CLAWSPHERE_AI_DEFAULT_PROVIDER=openai
CLAWSPHERE_AI_OPENAI_API_KEY=sk-...

# Active Directory (opcional)
CLAWSPHERE_SECURITY_LDAP_SERVER=ldap.company.com
CLAWSPHERE_SECURITY_LDAP_BIND_DN=CN=ServiceAccount,DC=company,DC=com
```

### Configuración de Aplicaciones

Las aplicaciones se configuran en `config/apps/`:

```yaml
# config/apps/ventas.yaml
name: Ventas
description: Sistema de ventas

servers:
  - name: VENTAS-APP01
    type: windows
    
databases:
  - name: VentasDB
    type: sqlserver
    connection_string: "..."
```

## 📖 Uso

### API REST

#### Autenticación
```bash
curl -X POST http://localhost:7550/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin", "password": "password"}'
```

#### Chat con el Agente
```bash
curl -X POST http://localhost:7550/api/chat \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "message": "estado del servidor VENTAS-APP01",
    "application_context": "Ventas"
  }'
```

#### Consulta a Base de Datos
```bash
curl -X POST http://localhost:7550/api/chat \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "message": "trae las últimas 10 transacciones de recargas telcel",
    "application_context": "Telefonia"
  }'
```

### Interfaz Web

La documentación interactiva está disponible en:
- Swagger UI: http://localhost:7550/docs
- ReDoc: http://localhost:7550/redoc

## 🔒 Seguridad

### Roles y Permisos

| Rol | Permisos |
|-----|----------|
| **admin** | Acceso total, aprobación de operaciones críticas |
| **ingeniero** | Ejecución de skills de diagnóstico y lectura |
| **seguridad** | Auditoría, aprobación de operaciones sensibles |
| **auditor** | Solo lectura de logs y reportes |

### Aprobaciones Requeridas

Operaciones que requieren aprobación de admin:
- Modificaciones en bases de datos (INSERT, UPDATE, DELETE)
- Reinicio de servicios
- Ejecución de comandos en servidores
- Cambios de configuración
- Acceso a datos sensibles

### Encriptación

- **Datos en tránsito**: TLS 1.2+
- **Datos en reposo**: AES-256-GCM
- **Contraseñas**: bcrypt
- **Tokens**: JWT con expiración configurable

## 🔌 Sistema de Plugins

### Crear un Nuevo Skill

```python
from core.plugins.base import BaseSkill, SkillContext, SkillResult, SkillCategory

class MiSkill(BaseSkill):
    name = "mi_skill"
    description = "Descripción de mi skill"
    category = SkillCategory.CUSTOM
    required_roles = ["ingeniero"]
    
    async def execute(self, context: SkillContext, **params) -> SkillResult:
        # Implementación
        return SkillResult.success_result(
            data={"result": "exito"},
            message="Operación completada"
        )
```

### Registrar Plugin

```python
from core.plugins.base import BasePlugin

class MiPlugin(BasePlugin):
    name = "mi_plugin"
    description = "Mi plugin personalizado"
    
    def register_skills(self):
        return [MiSkill()]
```

## 🤖 Proveedores de IA Soportados

| Proveedor | Modelos | Local/Cloud |
|-----------|---------|-------------|
| **Ollama** | Qwen, Llama, Mistral, CodeLlama | Local |
| **LM Studio** | Cualquier modelo GGUF | Local |
| **GPT4All** | Variados | Local |
| **vLLM** | Cualquier modelo compatible | Local |
| **OpenAI** | GPT-4, GPT-3.5 | Cloud |
| **Anthropic** | Claude 3 Opus/Sonnet/Haiku | Cloud |
| **Google** | Gemini Pro/Ultra | Cloud |
| **DeepSeek** | DeepSeek-R1, DeepSeek-V3 | Cloud |

## 📊 Monitoreo

### Métricas Disponibles

- Tiempo de respuesta de skills
- Tasa de éxito/error
- Uso por usuario/rol
- Consultas a bases de datos
- Eventos de seguridad

### Health Check

```bash
curl http://localhost:7550/health
```

## 📝 Logging y Auditoría

Los logs se almacenan en:
- `logs/clawsphere.log`: Logs generales
- `logs/audit.log`: Logs de auditoría

Rotación automática: 10MB por archivo, 10 archivos de backup.

## 🤝 Integraciones

### Microsoft Teams
```bash
# Configurar en .env
CLAWSPHERE_MSG_TEAMS_APP_ID=...
CLAWSPHERE_MSG_TEAMS_APP_PASSWORD=...
```

### Telegram
```bash
# Configurar en .env
CLAWSPHERE_MSG_TELEGRAM_BOT_TOKEN=...
```

### WhatsApp
```bash
# Configurar en .env
CLAWSPHERE_MSG_TWILIO_ACCOUNT_SID=...
CLAWSPHERE_MSG_TWILIO_AUTH_TOKEN=...
```

## 🧪 Testing

```bash
# Ejecutar tests
pytest tests/

# Con cobertura
pytest --cov=clawsphere tests/
```

## 🚢 Despliegue

### Docker

```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

CMD ["python", "main.py"]
```

### Kubernetes

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: clawsphere-ams
spec:
  replicas: 3
  selector:
    matchLabels:
      app: clawsphere-ams
  template:
    metadata:
      labels:
        app: clawsphere-ams
    spec:
      containers:
      - name: clawsphere
        image: company/clawsphere-ams:latest
        ports:
        - containerPort: 7550
```

## 📚 Documentación Adicional

- [Guía de Usuario](docs/user-guide.md)
- [Guía de Desarrollo](docs/dev-guide.md)
- [API Reference](docs/api-reference.md)
- [Seguridad](docs/security.md)

## 🤝 Contribuir

1. Fork el repositorio
2. Crea una rama (`git checkout -b feature/nueva-funcionalidad`)
3. Commit tus cambios (`git commit -am 'Agregar nueva funcionalidad'`)
4. Push a la rama (`git push origin feature/nueva-funcionalidad`)
5. Abre un Pull Request

## 📄 Licencia

Este proyecto está licenciado bajo MIT License - ver [LICENSE](LICENSE) para detalles.

## 🆘 Soporte

- 📧 Email: soporte@company.com
- 💬 Teams: [ClawSphere AMS Support](https://teams.microsoft.com/...)
- 🐛 Issues: [GitHub Issues](https://github.com/company/clawsphere-ams/issues)

---

**Desarrollado con ❤️ por el equipo de ClawSphere AMS**
