@echo off
chcp 65001 >nul
title ClawSphere AMS - Diagnostico

echo ============================================
echo   CLAWSPHERE AMS - DIAGNOSTICO
echo ============================================
echo.
echo Este script verificara tu instalacion
echo y mostrara posibles problemas.
echo.
pause
echo.

REM Verificar Python
echo [1] Verificando Python...
python --version 2>nul
if errorlevel 1 (
    echo     [X] ERROR: Python no encontrado
    echo         Solucion: Instala Python 3.9+ desde https://python.org
    echo         IMPORTANTE: Marca "Add Python to PATH"
) else (
    echo     [OK] Python instalado
)
echo.

REM Verificar pip
echo [2] Verificando pip...
pip --version 2>nul
if errorlevel 1 (
    echo     [X] ERROR: pip no encontrado
) else (
    echo     [OK] pip instalado
)
echo.

REM Verificar entorno virtual
echo [3] Verificando entorno virtual...
if exist "venv\Scripts\python.exe" (
    echo     [OK] Entorno virtual encontrado
    venv\Scripts\python --version
) else (
    echo     [X] ERROR: Entorno virtual no encontrado
    echo         Solucion: Ejecuta install-windows.bat
)
echo.

REM Verificar archivos principales
echo [4] Verificando archivos principales...
if exist "main.py" (
    echo     [OK] main.py
) else (
    echo     [X] ERROR: main.py no encontrado
)

if exist "requirements-windows.txt" (
    echo     [OK] requirements-windows.txt
) else (
    echo     [X] ERROR: requirements-windows.txt no encontrado
)

if exist ".env" (
    echo     [OK] .env
) else (
    echo     [X] WARNING: .env no encontrado
    echo         Solucion: copy .env.windows .env
)
echo.

REM Verificar directorios
echo [5] Verificando directorios...
if exist "data" (
    echo     [OK] data/
) else (
    echo     [X] WARNING: data/ no existe
)

if exist "logs" (
    echo     [OK] logs/
) else (
    echo     [X] WARNING: logs/ no existe
)

if exist "plugins" (
    echo     [OK] plugins/
) else (
    echo     [X] WARNING: plugins/ no existe
)
echo.

REM Verificar dependencias
echo [6] Verificando dependencias instaladas...
call venv\Scripts\activate 2>nul
python -c "import fastapi; print('    [OK] fastapi')" 2>nul || echo     [X] fastapi no instalado
python -c "import uvicorn; print('    [OK] uvicorn')" 2>nul || echo     [X] uvicorn no instalado
python -c "import pydantic; print('    [OK] pydantic')" 2>nul || echo     [X] pydantic no instalado
python -c "import sqlalchemy; print('    [OK] sqlalchemy')" 2>nul || echo     [X] sqlalchemy no instalado
python -c "import aiohttp; print('    [OK] aiohttp')" 2>nul || echo     [X] aiohttp no instalado
echo.

REM Verificar Ollama
echo [7] Verificando Ollama...
curl -s http://localhost:11434/api/tags >nul 2>&1
if errorlevel 1 (
    echo     [X] Ollama no responde
    echo         Si usas Ollama, asegurate de ejecutar: ollama serve
    echo         Si usas OpenAI, ignora este mensaje
) else (
    echo     [OK] Ollama responde
    echo     Modelos disponibles:
    curl -s http://localhost:11434/api/tags 2>nul | findstr "name"
)
echo.

REM Verificar puerto
echo [8] Verificando puerto 7550...
netstat -ano | findstr ":7550" >nul
if errorlevel 1 (
    echo     [OK] Puerto 7550 disponible
) else (
    echo     [X] Puerto 7550 en uso
    echo         Solucion: Cambia el puerto en .env o mata el proceso
)
echo.

REM Ejecutar test Python
echo [9] Ejecutando tests de Python...
if exist "tests\test_windows_setup.py" (
    python tests\test_windows_setup.py
) else (
    echo     [X] tests\test_windows_setup.py no encontrado
)
echo.

echo ============================================
echo   DIAGNOSTICO COMPLETADO
echo ============================================
echo.
echo Si ves errores arriba, sigue las soluciones indicadas.
echo.
echo Para mas ayuda, revisa:
echo   docs\WINDOWS_INSTALL_GUIDE.md
echo.

pause
