"""
Adaptadores de IA para ClawSphere AMS
"""

from .base import BaseAIProvider, AIResponse
from .ollama import OllamaProvider
from .openai import OpenAIProvider

__all__ = [
    'BaseAIProvider',
    'AIResponse',
    'OllamaProvider',
    'OpenAIProvider'
]
