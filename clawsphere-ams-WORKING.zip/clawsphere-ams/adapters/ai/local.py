"""
Adaptador para servidores de IA locales compatibles con OpenAI API.
Soporta: LM Studio, GPT4All, vLLM, DeepSeek, etc.
"""

import aiohttp
import logging
from typing import Dict, Any, Optional, AsyncGenerator

from .base import BaseAIAdapter

logger = logging.getLogger(__name__)


class LocalAIAdapter(BaseAIAdapter):
    """
    Adaptador para servidores de IA locales.
    Compatible con cualquier servidor que use OpenAI API format.
    """
    
    name = "local"
    description = "Servidor IA Local (LM Studio, GPT4All, vLLM, DeepSeek)"
    supports_streaming = True
    supports_functions = False
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = config.get("base_url", "http://localhost:1234/v1")
        self.api_key = config.get("api_key", "not-needed")
        self.default_model = config.get("default_model", "local-model")
        self.timeout = config.get("timeout", 120)
        self._session: Optional[aiohttp.ClientSession] = None
    
    async def initialize(self) -> None:
        """Inicializa la sesión HTTP."""
        self._session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=self.timeout),
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
        )
        self._initialized = True
        logger.info(f"LocalAIAdapter inicializado - URL: {self.base_url}")
    
    async def generate_response(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        model: Optional[str] = None,
        **kwargs
    ) -> str:
        """Genera respuesta usando servidor local."""
        if not self._session:
            await self.initialize()
        
        model = model or self.default_model
        
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "stream": False
        }
        
        if max_tokens:
            payload["max_tokens"] = max_tokens
        
        try:
            async with self._session.post(
                f"{self.base_url}/chat/completions",
                json=payload
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise Exception(f"Local AI error {response.status}: {error_text}")
                
                data = await response.json()
                return data["choices"][0]["message"]["content"].strip()
                
        except Exception as e:
            logger.error(f"Error en Local AI: {e}")
            raise
    
    async def generate_stream(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        model: Optional[str] = None,
        **kwargs
    ) -> AsyncGenerator[str, None]:
        """Genera respuesta en streaming."""
        if not self._session:
            await self.initialize()
        
        model = model or self.default_model
        
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "stream": True
        }
        
        try:
            async with self._session.post(
                f"{self.base_url}/chat/completions",
                json=payload
            ) as response:
                async for line in response.content:
                    line = line.decode('utf-8').strip()
                    if line.startswith("data: "):
                        data = line[6:]
                        if data == "[DONE]":
                            break
                        try:
                            import json
                            chunk = json.loads(data)
                            if chunk["choices"][0]["delta"].get("content"):
                                yield chunk["choices"][0]["delta"]["content"]
                        except:
                            pass
        except Exception as e:
            logger.error(f"Error en streaming Local AI: {e}")
            raise
    
    async def is_available(self) -> bool:
        """Verifica si el servidor local está disponible."""
        if not self._session:
            await self.initialize()
        
        try:
            async with self._session.get(
                f"{self.base_url}/models",
                timeout=aiohttp.ClientTimeout(total=5)
            ) as response:
                return response.status == 200
        except:
            return False
    
    async def list_models(self) -> list:
        """Lista modelos disponibles."""
        if not self._session:
            await self.initialize()
        
        try:
            async with self._session.get(f"{self.base_url}/models") as response:
                if response.status == 200:
                    data = await response.json()
                    return [m["id"] for m in data.get("data", [])]
                return []
        except:
            return []


class LMStudioAdapter(LocalAIAdapter):
    """Adaptador específico para LM Studio."""
    
    name = "lmstudio"
    description = "LM Studio - Servidor local de IA"
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__({
            **config,
            "base_url": config.get("base_url", "http://localhost:1234/v1")
        })


class GPT4AllAdapter(LocalAIAdapter):
    """Adaptador específico para GPT4All."""
    
    name = "gpt4all"
    description = "GPT4All - Servidor local de IA"
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__({
            **config,
            "base_url": config.get("base_url", "http://localhost:4891/v1")
        })


class VLLMAdapter(LocalAIAdapter):
    """Adaptador específico para vLLM."""
    
    name = "vllm"
    description = "vLLM - Servidor de alta performance para LLMs"
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__({
            **config,
            "base_url": config.get("base_url", "http://localhost:8000/v1")
        })


class DeepSeekAdapter(LocalAIAdapter):
    """Adaptador específico para DeepSeek API."""
    
    name = "deepseek"
    description = "DeepSeek AI (DeepSeek-R1, DeepSeek-V3)"
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__({
            **config,
            "base_url": config.get("base_url", "https://api.deepseek.com/v1"),
            "default_model": config.get("default_model", "deepseek-chat")
        })


class GoogleAdapter(BaseAIAdapter):
    """Adaptador para Google Gemini."""
    
    name = "google"
    description = "Google Gemini (Gemini Pro, Gemini Ultra)"
    supports_streaming = True
    supports_functions = True
    supports_vision = True
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_key = config.get("api_key", "")
        self.default_model = config.get("default_model", "gemini-pro")
        self._client = None
    
    async def initialize(self) -> None:
        """Inicializa el cliente Gemini."""
        import google.generativeai as genai
        genai.configure(api_key=self.api_key)
        self._client = genai
        self._initialized = True
        logger.info("GoogleAdapter inicializado")
    
    async def generate_response(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        model: Optional[str] = None,
        **kwargs
    ) -> str:
        """Genera respuesta usando Gemini."""
        if not self._client:
            await self.initialize()
        
        model_name = model or self.default_model
        
        try:
            model = self._client.GenerativeModel(model_name)
            
            # Configuración de generación
            generation_config = {
                "temperature": temperature,
            }
            if max_tokens:
                generation_config["max_output_tokens"] = max_tokens
            
            # Construir prompt
            full_prompt = prompt
            if system_prompt:
                full_prompt = f"{system_prompt}\n\n{prompt}"
            
            response = model.generate_content(
                full_prompt,
                generation_config=generation_config
            )
            
            return response.text
            
        except Exception as e:
            logger.error(f"Error en Google Gemini: {e}")
            raise
    
    async def generate_stream(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        model: Optional[str] = None,
        **kwargs
    ) -> AsyncGenerator[str, None]:
        """Genera respuesta en streaming."""
        if not self._client:
            await self.initialize()
        
        model_name = model or self.default_model
        
        try:
            model = self._client.GenerativeModel(model_name)
            
            full_prompt = prompt
            if system_prompt:
                full_prompt = f"{system_prompt}\n\n{prompt}"
            
            response = model.generate_content(
                full_prompt,
                stream=True
            )
            
            for chunk in response:
                if chunk.text:
                    yield chunk.text
                    
        except Exception as e:
            logger.error(f"Error en streaming Google: {e}")
            raise
    
    async def is_available(self) -> bool:
        """Verifica si Gemini está disponible."""
        if not self._client:
            await self.initialize()
        
        try:
            # Listar modelos
            models = list(self._client.list_models())
            return len(models) > 0
        except:
            return False
