"""
Adaptador para OpenAI
"""

import logging
from typing import Any, Dict, List, Optional

import httpx

from .base import BaseAIProvider, AIResponse

logger = logging.getLogger(__name__)


class OpenAIProvider(BaseAIProvider):
    """Proveedor de IA usando OpenAI API."""
    
    name = "openai"
    supports_streaming = True
    supports_functions = True
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_key = config.get('api_key')
        self.base_url = config.get('base_url', 'https://api.openai.com/v1')
        self.default_model = config.get('model', 'gpt-4')
        self.timeout = config.get('timeout', 60)
        self._client: Optional[httpx.AsyncClient] = None
    
    async def initialize(self) -> bool:
        """Inicializa el proveedor verificando la API key."""
        if not self.api_key:
            logger.warning("OpenAI API key not provided")
            return False
        
        try:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                timeout=self.timeout
            )
            
            # Verificar conexión listando modelos
            response = await self._client.get("/models")
            if response.status_code == 200:
                self.is_available = True
                logger.info(f"OpenAI provider initialized with model: {self.default_model}")
                return True
            else:
                logger.warning(f"OpenAI returned status {response.status_code}")
                return False
                
        except Exception as e:
            logger.error(f"Failed to initialize OpenAI: {e}")
            return False
    
    async def chat(
        self,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> AIResponse:
        """Envía un chat a OpenAI."""
        if not self.is_available:
            return AIResponse(
                content="",
                model=model or self.default_model,
                provider=self.name,
                error="OpenAI provider not available"
            )
        
        model = model or self.default_model
        
        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature
        }
        
        if max_tokens:
            payload["max_tokens"] = max_tokens
        
        # Agregar funciones si se proporcionan
        if 'functions' in kwargs:
            payload["functions"] = kwargs['functions']
        
        if 'function_call' in kwargs:
            payload["function_call"] = kwargs['function_call']
        
        try:
            response = await self._client.post("/chat/completions", json=payload)
            
            if response.status_code == 200:
                data = response.json()
                choice = data['choices'][0]
                message = choice['message']
                
                return AIResponse(
                    content=message.get('content', ''),
                    model=model,
                    provider=self.name,
                    tokens_used=data.get('usage', {}).get('total_tokens'),
                    metadata={
                        'finish_reason': choice.get('finish_reason'),
                        'function_call': message.get('function_call')
                    }
                )
            else:
                error_data = response.json()
                error_msg = error_data.get('error', {}).get('message', 'Unknown error')
                return AIResponse(
                    content="",
                    model=model,
                    provider=self.name,
                    error=f"OpenAI error {response.status_code}: {error_msg}"
                )
                
        except Exception as e:
            logger.error(f"Error calling OpenAI: {e}")
            return AIResponse(
                content="",
                model=model,
                provider=self.name,
                error=str(e)
            )
    
    async def is_healthy(self) -> bool:
        """Verifica si OpenAI está saludable."""
        if not self._client:
            return False
        
        try:
            response = await self._client.get(
                "/models",
                timeout=5.0
            )
            return response.status_code == 200
        except Exception:
            return False
    
    async def close(self):
        """Cierra el cliente HTTP."""
        if self._client:
            await self._client.aclose()
            self._client = None
