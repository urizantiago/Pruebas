"""
Clase base para proveedores de IA
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class AIResponse:
    """Respuesta de un proveedor de IA."""
    content: str
    model: str
    provider: str
    tokens_used: Optional[int] = None
    confidence: float = 1.0
    metadata: Dict[str, Any] = None
    error: Optional[str] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}
    
    @property
    def is_error(self) -> bool:
        """Indica si la respuesta contiene un error."""
        return self.error is not None


class BaseAIProvider(ABC):
    """Clase base para proveedores de IA."""
    
    name: str = "base"
    supports_streaming: bool = False
    supports_functions: bool = False
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.is_available = False
    
    @abstractmethod
    async def initialize(self) -> bool:
        """Inicializa el proveedor."""
        pass
    
    @abstractmethod
    async def chat(
        self,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> AIResponse:
        """Envía un chat al modelo."""
        pass
    
    @abstractmethod
    async def is_healthy(self) -> bool:
        """Verifica si el proveedor está saludable."""
        pass
    
    async def close(self):
        """Cierra recursos del proveedor."""
        pass
