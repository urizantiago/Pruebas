"""
Factory para crear adaptadores de IA.
Permite cambiar entre proveedores de forma transparente.
"""

import logging
from typing import Dict, Any, Type, Optional

from .base import BaseAIAdapter
from .ollama import OllamaAdapter
from .openai import OpenAIAdapter
from .anthropic import AnthropicAdapter
from .local import (
    LocalAIAdapter, LMStudioAdapter, GPT4AllAdapter, 
    VLLMAdapter, DeepSeekAdapter, GoogleAdapter
)

logger = logging.getLogger(__name__)


class AIAdapterFactory:
    """
    Factory para crear adaptadores de IA.
    Soporta múltiples proveedores y permite failover.
    """
    
    # Registro de adaptadores disponibles
    _adapters: Dict[str, Type[BaseAIAdapter]] = {
        # Locales
        "ollama": OllamaAdapter,
        "lmstudio": LMStudioAdapter,
        "gpt4all": GPT4AllAdapter,
        "vllm": VLLMAdapter,
        
        # Cloud
        "openai": OpenAIAdapter,
        "anthropic": AnthropicAdapter,
        "google": GoogleAdapter,
        "deepseek": DeepSeekAdapter,
        
        # Genérico
        "local": LocalAIAdapter
    }
    
    # Instancias cacheadas
    _instances: Dict[str, BaseAIAdapter] = {}
    
    # Configuración
    _config: Dict[str, Any] = {}
    _default_provider: str = "ollama"
    
    @classmethod
    def configure(cls, config: Dict[str, Any]) -> None:
        """
        Configura la factory con settings globales.
        
        Args:
            config: Configuración de IA
        """
        cls._config = config
        cls._default_provider = config.get("default_provider", "ollama")
        logger.info(f"AIAdapterFactory configurado - Default: {cls._default_provider}")
    
    @classmethod
    def register_adapter(
        cls, 
        name: str, 
        adapter_class: Type[BaseAIAdapter]
    ) -> None:
        """
        Registra un nuevo adaptador.
        
        Args:
            name: Nombre del adaptador
            adapter_class: Clase del adaptador
        """
        cls._adapters[name] = adapter_class
        logger.info(f"Adaptador registrado: {name}")
    
    @classmethod
    def create_adapter(
        cls, 
        provider: str, 
        config: Dict[str, Any] = None
    ) -> BaseAIAdapter:
        """
        Crea un adaptador para el proveedor especificado.
        
        Args:
            provider: Nombre del proveedor
            config: Configuración específica (opcional)
            
        Returns:
            Instancia del adaptador
            
        Raises:
            ValueError: Si el proveedor no está soportado
        """
        if provider not in cls._adapters:
            raise ValueError(
                f"Proveedor '{provider}' no soportado. "
                f"Disponibles: {list(cls._adapters.keys())}"
            )
        
        # Usar config proporcionada o la global
        adapter_config = config or cls._get_provider_config(provider)
        
        # Crear instancia
        adapter_class = cls._adapters[provider]
        adapter = adapter_class(adapter_config)
        
        return adapter
    
    @classmethod
    async def get_adapter(cls, provider: str = None) -> BaseAIAdapter:
        """
        Obtiene un adaptador (cacheado o nuevo).
        
        Args:
            provider: Nombre del proveedor (None = default)
            
        Returns:
            Instancia del adaptador inicializado
        """
        provider = provider or cls._default_provider
        
        # Verificar caché
        if provider in cls._instances:
            return cls._instances[provider]
        
        # Crear nuevo
        adapter = cls.create_adapter(provider)
        await adapter.initialize()
        
        # Cachear
        cls._instances[provider] = adapter
        
        return adapter
    
    @classmethod
    def get_default_adapter(cls) -> BaseAIAdapter:
        """
        Obtiene el adaptador por defecto (síncrono).
        Usar get_adapter() para versión async.
        """
        if cls._default_provider in cls._instances:
            return cls._instances[cls._default_provider]
        
        # Crear sin inicializar (inicialización async requerida)
        return cls.create_adapter(cls._default_provider)
    
    @classmethod
    async def get_available_adapters(cls) -> Dict[str, bool]:
        """
        Verifica qué adaptadores están disponibles.
        
        Returns:
            Dict con nombre -> disponible
        """
        availability = {}
        
        for name in cls._adapters.keys():
            try:
                adapter = await cls.get_adapter(name)
                availability[name] = await adapter.is_available()
            except Exception as e:
                availability[name] = False
                logger.debug(f"Adaptador {name} no disponible: {e}")
        
        return availability
    
    @classmethod
    async def get_best_available_adapter(cls) -> Optional[BaseAIAdapter]:
        """
        Encuentra el mejor adaptador disponible.
        
        Returns:
            Adaptador disponible o None
        """
        # Orden de preferencia
        preferred_order = [
            cls._default_provider,
            "ollama",
            "lmstudio",
            "gpt4all",
            "openai",
            "anthropic",
            "deepseek",
            "google"
        ]
        
        for provider in preferred_order:
            try:
                adapter = await cls.get_adapter(provider)
                if await adapter.is_available():
                    return adapter
            except:
                continue
        
        return None
    
    @classmethod
    def _get_provider_config(cls, provider: str) -> Dict[str, Any]:
        """Obtiene la configuración para un proveedor."""
        ai_config = cls._config
        
        configs = {
            "ollama": {
                "base_url": ai_config.get("OLLAMA_BASE_URL", "http://localhost:11434"),
                "default_model": ai_config.get("OLLAMA_DEFAULT_MODEL", "qwen2.5-coder"),
                "timeout": ai_config.get("OLLAMA_TIMEOUT", 180)
            },
            "openai": {
                "api_key": ai_config.get("OPENAI_API_KEY", ""),
                "default_model": ai_config.get("OPENAI_DEFAULT_MODEL", "gpt-4"),
                "timeout": ai_config.get("OPENAI_TIMEOUT", 60)
            },
            "anthropic": {
                "api_key": ai_config.get("ANTHROPIC_API_KEY", ""),
                "default_model": ai_config.get("ANTHROPIC_DEFAULT_MODEL", "claude-3-opus-20240229"),
                "timeout": ai_config.get("ANTHROPIC_TIMEOUT", 60)
            },
            "google": {
                "api_key": ai_config.get("GOOGLE_API_KEY", ""),
                "default_model": ai_config.get("GOOGLE_DEFAULT_MODEL", "gemini-pro")
            },
            "deepseek": {
                "api_key": ai_config.get("DEEPSEEK_API_KEY", ""),
                "default_model": ai_config.get("DEEPSEEK_DEFAULT_MODEL", "deepseek-chat")
            },
            "lmstudio": {
                "base_url": ai_config.get("LMSTUDIO_BASE_URL", "http://localhost:1234/v1"),
                "default_model": "local-model"
            },
            "gpt4all": {
                "base_url": ai_config.get("GPT4ALL_BASE_URL", "http://localhost:4891/v1"),
                "default_model": "local-model"
            },
            "vllm": {
                "base_url": ai_config.get("VLLM_BASE_URL", "http://localhost:8000/v1"),
                "default_model": "local-model"
            }
        }
        
        return configs.get(provider, {})
    
    @classmethod
    def list_adapters(cls) -> Dict[str, str]:
        """Lista los adaptadores disponibles."""
        return {
            name: adapter_class.description 
            for name, adapter_class in cls._adapters.items()
        }
    
    @classmethod
    def clear_cache(cls) -> None:
        """Limpia el caché de adaptadores."""
        cls._instances.clear()
        logger.info("Caché de adaptadores limpiado")
