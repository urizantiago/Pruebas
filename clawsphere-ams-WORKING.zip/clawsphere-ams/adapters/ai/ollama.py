"""
Adaptador para Ollama (modelos locales)
"""

import logging
from typing import Any, Dict, List, Optional

import aiohttp

from .base import BaseAIProvider, AIResponse

logger = logging.getLogger(__name__)


class OllamaProvider(BaseAIProvider):
    """Proveedor de IA usando Ollama."""
    
    name = "ollama"
    supports_streaming = True
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = config.get('base_url', 'http://localhost:11434')
        self.default_model = config.get('model', 'qwen2.5-coder:14b')
        self.timeout = config.get('timeout', 120)
        self._session: Optional[aiohttp.ClientSession] = None
    
    async def initialize(self) -> bool:
        """Inicializa el proveedor verificando conexión con Ollama."""
        try:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=self.timeout)
            )
            
            # Verificar conexión
            async with self._session.get(f"{self.base_url}/api/tags") as response:
                if response.status == 200:
                    self.is_available = True
                    logger.info(f"Ollama provider initialized with model: {self.default_model}")
                    return True
                else:
                    logger.warning(f"Ollama returned status {response.status}")
                    return False
                    
        except Exception as e:
            logger.error(f"Failed to initialize Ollama: {e}")
            return False
    
    async def chat(
        self,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> AIResponse:
        """Envía un chat al modelo de Ollama."""
        if not self.is_available:
            return AIResponse(
                content="",
                model=model or self.default_model,
                provider=self.name,
                error="Ollama provider not available"
            )
        
        model = model or self.default_model
        
        # Formatear mensajes para Ollama
        prompt = self._format_messages(messages)
        
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": temperature
            }
        }
        
        if max_tokens:
            payload["options"]["num_predict"] = max_tokens
        
        try:
            async with self._session.post(
                f"{self.base_url}/api/generate",
                json=payload
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    return AIResponse(
                        content=data.get('response', ''),
                        model=model,
                        provider=self.name,
                        tokens_used=data.get('eval_count', 0),
                        metadata={
                            'total_duration': data.get('total_duration'),
                            'load_duration': data.get('load_duration')
                        }
                    )
                else:
                    error_text = await response.text()
                    return AIResponse(
                        content="",
                        model=model,
                        provider=self.name,
                        error=f"Ollama error {response.status}: {error_text}"
                    )
                    
        except Exception as e:
            logger.error(f"Error calling Ollama: {e}")
            return AIResponse(
                content="",
                model=model,
                provider=self.name,
                error=str(e)
            )
    
    def _format_messages(self, messages: List[Dict[str, str]]) -> str:
        """Formatea mensajes para Ollama."""
        formatted = []
        for msg in messages:
            role = msg.get('role', 'user')
            content = msg.get('content', '')
            
            if role == 'system':
                formatted.append(f"System: {content}")
            elif role == 'user':
                formatted.append(f"User: {content}")
            elif role == 'assistant':
                formatted.append(f"Assistant: {content}")
        
        return "\n\n".join(formatted) + "\n\nAssistant:"
    
    async def is_healthy(self) -> bool:
        """Verifica si Ollama está saludable."""
        if not self._session:
            return False
        
        try:
            async with self._session.get(
                f"{self.base_url}/api/tags",
                timeout=aiohttp.ClientTimeout(total=5)
            ) as response:
                return response.status == 200
        except Exception:
            return False
    
    async def close(self):
        """Cierra la sesión HTTP."""
        if self._session:
            await self._session.close()
            self._session = None
