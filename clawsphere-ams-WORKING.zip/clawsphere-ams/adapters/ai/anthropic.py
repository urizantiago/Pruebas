"""
Adaptador para Anthropic (Claude).
"""

import anthropic
import logging
from typing import Dict, Any, Optional, AsyncGenerator

from .base import BaseAIAdapter

logger = logging.getLogger(__name__)


class AnthropicAdapter(BaseAIAdapter):
    """
    Adaptador para Anthropic Claude.
    Soporta: Claude 3 Opus, Sonnet, Haiku.
    """
    
    name = "anthropic"
    description = "Anthropic Claude (Claude 3 Opus, Sonnet, Haiku)"
    supports_streaming = True
    supports_functions = False
    supports_vision = True
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_key = config.get("api_key", "")
        self.default_model = config.get("default_model", "claude-3-opus-20240229")
        self.timeout = config.get("timeout", 60)
        self._client: Optional[anthropic.AsyncAnthropic] = None
    
    async def initialize(self) -> None:
        """Inicializa el cliente Anthropic."""
        self._client = anthropic.AsyncAnthropic(
            api_key=self.api_key,
            timeout=self.timeout
        )
        self._initialized = True
        logger.info("AnthropicAdapter inicializado")
    
    async def generate_response(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        model: Optional[str] = None,
        **kwargs
    ) -> str:
        """Genera respuesta usando Claude."""
        if not self._client:
            await self.initialize()
        
        model = model or self.default_model
        max_tokens = max_tokens or 4096
        
        try:
            message = await self._client.messages.create(
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
                system=system_prompt or "",
                messages=[
                    {"role": "user", "content": prompt}
                ],
                **kwargs
            )
            
            return message.content[0].text if message.content else ""
            
        except Exception as e:
            logger.error(f"Error en Anthropic: {e}")
            raise
    
    async def generate_stream(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        model: Optional[str] = None,
        **kwargs
    ) -> AsyncGenerator[str, None]:
        """Genera respuesta en streaming."""
        if not self._client:
            await self.initialize()
        
        model = model or self.default_model
        
        try:
            async with self._client.messages.stream(
                model=model,
                max_tokens=4096,
                temperature=temperature,
                system=system_prompt or "",
                messages=[
                    {"role": "user", "content": prompt}
                ],
                **kwargs
            ) as stream:
                async for text in stream.text_stream:
                    yield text
                    
        except Exception as e:
            logger.error(f"Error en streaming Anthropic: {e}")
            raise
    
    async def is_available(self) -> bool:
        """Verifica si Anthropic está disponible."""
        if not self._client:
            await self.initialize()
        
        try:
            # Intentar una llamada simple
            await self._client.messages.create(
                model="claude-3-haiku-20240307",
                max_tokens=1,
                messages=[{"role": "user", "content": "Hi"}]
            )
            return True
        except:
            return False
