"""
Adaptador SSH para servidores Linux/AIX
"""

import logging
import time
from typing import Any, Dict, Optional

import paramiko

from .base import BaseServerAdapter, CommandResult, ServerType

logger = logging.getLogger(__name__)


class SSHAdapter(BaseServerAdapter):
    """Adaptador SSH para servidores Linux y AIX."""
    
    name = "ssh"
    server_type = ServerType.LINUX
    
    def __init__(self, hostname: str, config: Optional[Dict[str, Any]] = None):
        super().__init__(hostname, config)
        self.username = config.get('username') if config else None
        self.password = config.get('password') if config else None
        self.key_file = config.get('key_file') if config else None
        self.port = config.get('port', 22) if config else 22
        self.timeout = config.get('timeout', 30) if config else 30
        self._client: Optional[paramiko.SSHClient] = None
    
    async def connect(self) -> bool:
        """Establece conexión SSH."""
        try:
            self._client = paramiko.SSHClient()
            self._client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            connect_kwargs = {
                'hostname': self.hostname,
                'port': self.port,
                'username': self.username,
                'timeout': self.timeout
            }
            
            if self.key_file:
                connect_kwargs['key_filename'] = self.key_file
            elif self.password:
                connect_kwargs['password'] = self.password
            
            self._client.connect(**connect_kwargs)
            self.is_connected = True
            
            logger.info(f"SSH connected to {self.hostname}")
            return True
            
        except Exception as e:
            logger.error(f"SSH connection failed to {self.hostname}: {e}")
            return False
    
    async def disconnect(self):
        """Cierra la conexión SSH."""
        if self._client:
            self._client.close()
            self._client = None
            self.is_connected = False
            logger.info(f"SSH disconnected from {self.hostname}")
    
    async def execute(
        self,
        command: str,
        timeout: Optional[int] = None,
        sudo: bool = False
    ) -> CommandResult:
        """Ejecuta un comando vía SSH."""
        if not self.is_connected or not self._client:
            return CommandResult(
                success=False,
                stdout="",
                stderr="",
                exit_code=-1,
                execution_time_ms=0,
                error="Not connected to server"
            )
        
        start_time = time.time()
        
        try:
            # Agregar sudo si es necesario
            if sudo and self.password:
                command = f"echo '{self.password}' | sudo -S {command}"
            elif sudo:
                command = f"sudo {command}"
            
            stdin, stdout, stderr = self._client.exec_command(
                command,
                timeout=timeout or self.timeout
            )
            
            exit_code = stdout.channel.recv_exit_status()
            stdout_data = stdout.read().decode('utf-8', errors='replace')
            stderr_data = stderr.read().decode('utf-8', errors='replace')
            
            execution_time = (time.time() - start_time) * 1000
            
            return CommandResult(
                success=exit_code == 0,
                stdout=stdout_data,
                stderr=stderr_data,
                exit_code=exit_code,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            execution_time = (time.time() - start_time) * 1000
            logger.error(f"Command execution error: {e}")
            return CommandResult(
                success=False,
                stdout="",
                stderr="",
                exit_code=-1,
                execution_time_ms=execution_time,
                error=str(e)
            )
    
    async def get_system_info(self) -> Dict[str, Any]:
        """Obtiene información del sistema."""
        info = {
            'hostname': self.hostname,
            'os': None,
            'kernel': None,
            'cpu_count': None,
            'memory_total': None,
            'disk_usage': None
        }
        
        try:
            # Obtener OS
            result = await self.execute("cat /etc/os-release | grep PRETTY_NAME")
            if result.success:
                info['os'] = result.stdout.strip().split('=')[1].strip('"')
            
            # Obtener kernel
            result = await self.execute("uname -r")
            if result.success:
                info['kernel'] = result.stdout.strip()
            
            # Obtener CPUs
            result = await self.execute("nproc")
            if result.success:
                info['cpu_count'] = int(result.stdout.strip())
            
            # Obtener memoria
            result = await self.execute("free -m | grep Mem | awk '{print $2}'")
            if result.success:
                info['memory_total'] = f"{result.stdout.strip()} MB"
            
            # Obtener uso de disco
            result = await self.execute("df -h / | tail -1 | awk '{print $5}'")
            if result.success:
                info['disk_usage'] = result.stdout.strip()
                
        except Exception as e:
            logger.error(f"Error getting system info: {e}")
        
        return info
