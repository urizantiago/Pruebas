"""
Adaptador WinRM para servidores Windows
"""

import logging
import time
from typing import Any, Dict, Optional

from winrm import Session

from .base import BaseServerAdapter, CommandResult, ServerType

logger = logging.getLogger(__name__)


class WinRMAdapter(BaseServerAdapter):
    """Adaptador WinRM para servidores Windows."""
    
    name = "winrm"
    server_type = ServerType.WINDOWS
    
    def __init__(self, hostname: str, config: Optional[Dict[str, Any]] = None):
        super().__init__(hostname, config)
        self.username = config.get('username') if config else None
        self.password = config.get('password') if config else None
        self.port = config.get('port', 5985) if config else 5985
        self.use_ssl = config.get('use_ssl', False) if config else False
        self.timeout = config.get('timeout', 30) if config else 30
        self._session: Optional[Session] = None
    
    async def connect(self) -> bool:
        """Establece conexión WinRM."""
        try:
            protocol = 'https' if self.use_ssl else 'http'
            endpoint = f"{protocol}://{self.hostname}:{self.port}/wsman"
            
            self._session = Session(
                endpoint,
                auth=(self.username, self.password),
                transport='ntlm'
            )
            
            # Probar conexión
            result = self._session.run_ps("Get-ComputerInfo")
            if result.status_code == 0:
                self.is_connected = True
                logger.info(f"WinRM connected to {self.hostname}")
                return True
            else:
                logger.error(f"WinRM connection test failed: {result.std_err}")
                return False
                
        except Exception as e:
            logger.error(f"WinRM connection failed to {self.hostname}: {e}")
            return False
    
    async def disconnect(self):
        """Cierra la conexión WinRM."""
        self._session = None
        self.is_connected = False
        logger.info(f"WinRM disconnected from {self.hostname}")
    
    async def execute(
        self,
        command: str,
        timeout: Optional[int] = None,
        sudo: bool = False
    ) -> CommandResult:
        """Ejecuta un comando vía WinRM."""
        if not self.is_connected or not self._session:
            return CommandResult(
                success=False,
                stdout="",
                stderr="",
                exit_code=-1,
                execution_time_ms=0,
                error="Not connected to server"
            )
        
        start_time = time.time()
        
        try:
            # Ejecutar comando PowerShell
            result = self._session.run_ps(command)
            
            execution_time = (time.time() - start_time) * 1000
            
            return CommandResult(
                success=result.status_code == 0,
                stdout=result.std_out.decode('utf-8', errors='replace'),
                stderr=result.std_err.decode('utf-8', errors='replace'),
                exit_code=result.status_code,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            execution_time = (time.time() - start_time) * 1000
            logger.error(f"Command execution error: {e}")
            return CommandResult(
                success=False,
                stdout="",
                stderr="",
                exit_code=-1,
                execution_time_ms=execution_time,
                error=str(e)
            )
    
    async def execute_cmd(self, command: str, timeout: Optional[int] = None) -> CommandResult:
        """Ejecuta un comando CMD (no PowerShell)."""
        if not self.is_connected or not self._session:
            return CommandResult(
                success=False,
                stdout="",
                stderr="",
                exit_code=-1,
                execution_time_ms=0,
                error="Not connected to server"
            )
        
        start_time = time.time()
        
        try:
            result = self._session.run_cmd(command)
            
            execution_time = (time.time() - start_time) * 1000
            
            return CommandResult(
                success=result.status_code == 0,
                stdout=result.std_out.decode('utf-8', errors='replace'),
                stderr=result.std_err.decode('utf-8', errors='replace'),
                exit_code=result.status_code,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            execution_time = (time.time() - start_time) * 1000
            return CommandResult(
                success=False,
                stdout="",
                stderr="",
                exit_code=-1,
                execution_time_ms=execution_time,
                error=str(e)
            )
    
    async def get_system_info(self) -> Dict[str, Any]:
        """Obtiene información del sistema Windows."""
        info = {
            'hostname': self.hostname,
            'os': None,
            'version': None,
            'cpu_count': None,
            'memory_total': None
        }
        
        try:
            # Obtener información del sistema
            result = await self.execute("""
                $os = Get-CimInstance Win32_OperatingSystem
                $cpu = Get-CimInstance Win32_Processor
                $computer = Get-CimInstance Win32_ComputerSystem
                
                [PSCustomObject]@{
                    OS = $os.Caption
                    Version = $os.Version
                    CPUs = $computer.NumberOfProcessors
                    MemoryGB = [math]::Round($computer.TotalPhysicalMemory / 1GB, 2)
                } | ConvertTo-Json
            """)
            
            if result.success:
                import json
                data = json.loads(result.stdout)
                info['os'] = data.get('OS')
                info['version'] = data.get('Version')
                info['cpu_count'] = data.get('CPUs')
                info['memory_total'] = f"{data.get('MemoryGB')} GB"
                
        except Exception as e:
            logger.error(f"Error getting system info: {e}")
        
        return info
