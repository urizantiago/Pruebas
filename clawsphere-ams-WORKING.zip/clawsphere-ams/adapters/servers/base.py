"""
Clase base para adaptadores de servidores
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, Optional
from enum import Enum


class ServerType(Enum):
    """Tipos de servidor soportados."""
    LINUX = "linux"
    WINDOWS = "windows"
    AIX = "aix"


@dataclass
class CommandResult:
    """Resultado de un comando ejecutado."""
    success: bool
    stdout: str
    stderr: str
    exit_code: int
    execution_time_ms: float
    error: Optional[str] = None
    
    @property
    def is_error(self) -> bool:
        """Indica si el comando resultó en error."""
        return not self.success or self.exit_code != 0


class BaseServerAdapter(ABC):
    """Clase base para adaptadores de servidores."""
    
    name: str = "base"
    server_type: ServerType = ServerType.LINUX
    
    def __init__(self, hostname: str, config: Optional[Dict[str, Any]] = None):
        self.hostname = hostname
        self.config = config or {}
        self.is_connected = False
        self._client = None
    
    @abstractmethod
    async def connect(self) -> bool:
        """Establece conexión con el servidor."""
        pass
    
    @abstractmethod
    async def disconnect(self):
        """Cierra la conexión."""
        pass
    
    @abstractmethod
    async def execute(
        self,
        command: str,
        timeout: Optional[int] = None,
        sudo: bool = False
    ) -> CommandResult:
        """Ejecuta un comando en el servidor."""
        pass
    
    @abstractmethod
    async def get_system_info(self) -> Dict[str, Any]:
        """Obtiene información del sistema."""
        pass
    
    async def is_healthy(self) -> bool:
        """Verifica si el servidor está accesible."""
        try:
            if not self.is_connected:
                return await self.connect()
            return True
        except Exception:
            return False
