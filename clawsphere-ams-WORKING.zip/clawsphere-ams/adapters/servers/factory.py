"""
Factory para adaptadores de servidores.
"""

import logging
from typing import Dict, Any, Type, Optional

from .base import BaseServerAdapter
from .ssh import SSHAdapter
from .winrm import WinRMAdapter

logger = logging.getLogger(__name__)


class ServerAdapterFactory:
    """
    Factory para crear adaptadores de servidores.
    """
    
    _adapters: Dict[str, Type[BaseServerAdapter]] = {
        "ssh": SSHAdapter,
        "linux": SSHAdapter,
        "unix": SSHAdapter,
        "aix": SSHAdapter,
        "winrm": WinRMAdapter,
        "windows": WinRMAdapter
    }
    
    _instances: Dict[str, BaseServerAdapter] = {}
    
    @classmethod
    def register_adapter(
        cls, 
        name: str, 
        adapter_class: Type[BaseServerAdapter]
    ) -> None:
        """Registra un nuevo adaptador."""
        cls._adapters[name] = adapter_class
        logger.info(f"Adaptador de servidor registrado: {name}")
    
    @classmethod
    def create_adapter(
        cls, 
        server_type: str, 
        config: Dict[str, Any] = None
    ) -> BaseServerAdapter:
        """
        Crea un adaptador para el tipo de servidor.
        
        Args:
            server_type: Tipo de servidor
            config: Configuración
            
        Returns:
            Instancia del adaptador
        """
        server_type = server_type.lower()
        
        if server_type not in cls._adapters:
            raise ValueError(
                f"Tipo de servidor '{server_type}' no soportado. "
                f"Disponibles: {list(cls._adapters.keys())}"
            )
        
        adapter_class = cls._adapters[server_type]
        config = config or {}
        adapter = adapter_class(config)
        
        return adapter
    
    @classmethod
    async def get_adapter(
        cls, 
        server_type: str, 
        config: Dict[str, Any] = None
    ) -> BaseServerAdapter:
        """Obtiene un adaptador inicializado."""
        cache_key = f"{server_type}_{hash(str(config))}"
        
        if cache_key in cls._instances:
            return cls._instances[cache_key]
        
        adapter = cls.create_adapter(server_type, config)
        await adapter.initialize()
        
        cls._instances[cache_key] = adapter
        return adapter
    
    @classmethod
    def list_adapters(cls) -> Dict[str, str]:
        """Lista adaptadores disponibles."""
        return {
            name: adapter_class.description 
            for name, adapter_class in cls._adapters.items()
        }
