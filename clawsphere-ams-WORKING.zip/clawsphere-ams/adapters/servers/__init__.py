"""
Adaptadores de servidores para ClawSphere AMS
"""

from .base import BaseServerAdapter, CommandResult
from .ssh import SSHAdapter
from .winrm import WinRMAdapter

__all__ = [
    'BaseServerAdapter',
    'CommandResult',
    'SSHAdapter',
    'WinRMAdapter'
]
