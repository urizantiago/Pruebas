"""
Adaptador para Telegram.
"""

import logging
from typing import Dict, Any
from telegram import Update, Bot
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

from .base import BaseMessagingAdapter

logger = logging.getLogger(__name__)


class TelegramAdapter(BaseMessagingAdapter):
    """
    Adaptador para Telegram Bot.
    """
    
    name = "telegram"
    description = "Telegram Bot"
    supports_buttons = True
    supports_cards = False
    supports_images = True
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.bot_token = config.get("bot_token", "")
        self.webhook_url = config.get("webhook_url", "")
        self._application: Application = None
        self._bot: Bot = None
    
    async def initialize(self) -> None:
        """Inicializa el bot de Telegram."""
        self._application = Application.builder().token(self.bot_token).build()
        self._bot = self._application.bot
        
        # Registrar handlers
        self._application.add_handler(CommandHandler("start", self._start_command))
        self._application.add_handler(CommandHandler("help", self._help_command))
        self._application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self._handle_message))
        
        self._initialized = True
        logger.info("TelegramAdapter inicializado")
    
    async def send_message(
        self,
        recipient: str,
        message: str,
        **kwargs
    ) -> bool:
        """Envía un mensaje a Telegram."""
        try:
            parse_mode = kwargs.get("parse_mode", "Markdown")
            
            await self._bot.send_message(
                chat_id=recipient,
                text=message,
                parse_mode=parse_mode
            )
            
            logger.info(f"Mensaje enviado a Telegram: {recipient}")
            return True
            
        except Exception as e:
            logger.error(f"Error enviando mensaje a Telegram: {e}")
            return False
    
    async def send_card(
        self,
        recipient: str,
        card: Dict[str, Any],
        **kwargs
    ) -> bool:
        """Envía una tarjeta como mensaje formateado."""
        try:
            # Telegram no tiene cards nativas, usar texto formateado
            title = card.get("title", "")
            text = card.get("text", "")
            
            formatted = f"*{title}*\n\n{text}"
            
            # Agregar botones si existen
            actions = card.get("actions", [])
            if actions:
                from telegram import InlineKeyboardMarkup, InlineKeyboardButton
                
                keyboard = []
                for action in actions:
                    keyboard.append([InlineKeyboardButton(
                        action.get("title", "Action"),
                        callback_data=action.get("value", "")
                    )])
                
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                await self._bot.send_message(
                    chat_id=recipient,
                    text=formatted,
                    parse_mode="Markdown",
                    reply_markup=reply_markup
                )
            else:
                await self._bot.send_message(
                    chat_id=recipient,
                    text=formatted,
                    parse_mode="Markdown"
                )
            
            return True
            
        except Exception as e:
            logger.error(f"Error enviando card a Telegram: {e}")
            return False
    
    async def start_listening(self) -> None:
        """Inicia el polling o webhook."""
        if self.webhook_url:
            # Modo webhook
            await self._application.initialize()
            await self._application.start()
            logger.info(f"Telegram webhook configurado: {self.webhook_url}")
        else:
            # Modo polling
            logger.info("TelegramAdapter: Iniciando polling...")
            await self._application.initialize()
            await self._application.start()
            await self._application.updater.start_polling()
    
    async def stop_listening(self) -> None:
        """Detiene el bot."""
        if self._application:
            await self._application.stop()
            await self._application.shutdown()
    
    # Handlers
    async def _start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handler para /start."""
        await update.message.reply_text(
            "¡Bienvenido a ClawSphere AMS! 🤖\n\n"
            "Soy tu asistente de soporte L2/L3.\n"
            "Puedes preguntarme sobre:\n"
            "- Estado de servidores\n"
            "- Consultas a bases de datos\n"
            "- Análisis de logs\n"
            "- Performance de sistemas\n\n"
            "Escribe /help para más información."
        )
    
    async def _help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handler para /help."""
        await update.message.reply_text(
            "*Comandos disponibles:*\n\n"
            "• `estado del servidor <nombre>` - Verificar estado\n"
            "• `logs de <servidor>` - Ver logs\n"
            "• `consulta en <bd>: <sql>` - Ejecutar query\n"
            "• `performance de <bd>` - Análisis de performance\n"
            "• `alertas` - Ver alertas activas\n\n"
            "O simplemente pregúntame en lenguaje natural."
        )
    
    async def _handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handler para mensajes de texto."""
        user_id = str(update.effective_user.id)
        chat_id = str(update.effective_chat.id)
        message_text = update.message.text
        
        logger.info(f"Mensaje de Telegram de {user_id}: {message_text}")
        
        # Llamar al handler configurado
        if self._message_handler:
            response = await self._message_handler(
                sender=user_id,
                message=message_text,
                metadata={
                    "chat_id": chat_id,
                    "channel": "telegram",
                    "username": update.effective_user.username
                }
            )
            
            # Enviar respuesta
            if isinstance(response, dict):
                text = response.get("message", str(response))
            else:
                text = str(response)
            
            await update.message.reply_text(text, parse_mode="Markdown")
        else:
            await update.message.reply_text("Mensaje recibido. Procesando...")
    
    async def process_webhook_update(self, update_data: Dict[str, Any]) -> None:
        """
        Procesa una actualización de webhook.
        
        Args:
            update_data: Datos de la actualización de Telegram
        """
        update = Update.de_json(update_data, self._bot)
        await self._application.process_update(update)
