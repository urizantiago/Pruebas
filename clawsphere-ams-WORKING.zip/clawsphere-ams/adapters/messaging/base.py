"""
Clase base para adaptadores de mensajería.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, Callable


class BaseMessagingAdapter(ABC):
    """
    Clase base para adaptadores de mensajería.
    """
    
    name: str = ""
    description: str = ""
    supports_buttons: bool = False
    supports_cards: bool = False
    supports_images: bool = False
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self._initialized = False
        self._message_handler: Optional[Callable] = None
    
    @abstractmethod
    async def initialize(self) -> None:
        """Inicializa el adaptador."""
        pass
    
    @abstractmethod
    async def send_message(
        self,
        recipient: str,
        message: str,
        **kwargs
    ) -> bool:
        """
        Envía un mensaje.
        
        Args:
            recipient: ID del destinatario
            message: Mensaje a enviar
            
        Returns:
            True si se envió exitosamente
        """
        pass
    
    @abstractmethod
    async def send_card(
        self,
        recipient: str,
        card: Dict[str, Any],
        **kwargs
    ) -> bool:
        """
        Envía una tarjeta/card.
        
        Args:
            recipient: ID del destinatario
            card: Datos de la tarjeta
            
        Returns:
            True si se envió exitosamente
        """
        pass
    
    def set_message_handler(self, handler: Callable):
        """
        Establece el handler para mensajes entrantes.
        
        Args:
            handler: Función que recibe (sender, message, metadata)
        """
        self._message_handler = handler
    
    @abstractmethod
    async def start_listening(self) -> None:
        """Inicia la escucha de mensajes entrantes."""
        pass
    
    @abstractmethod
    async def stop_listening(self) -> None:
        """Detiene la escucha de mensajes."""
        pass
    
    def get_info(self) -> Dict[str, Any]:
        """Retorna información del adaptador."""
        return {
            "name": self.name,
            "description": self.description,
            "supports_buttons": self.supports_buttons,
            "supports_cards": self.supports_cards,
            "supports_images": self.supports_images
        }
