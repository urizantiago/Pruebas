"""
Adaptador para WhatsApp (Twilio).
"""

import logging
from typing import Dict, Any
from twilio.rest import Client
from twilio.twiml.messaging_response import MessagingResponse

from .base import BaseMessagingAdapter

logger = logging.getLogger(__name__)


class WhatsAppAdapter(BaseMessagingAdapter):
    """
    Adaptador para WhatsApp Business usando Twilio.
    """
    
    name = "whatsapp"
    description = "WhatsApp Business (Twilio)"
    supports_buttons = False
    supports_cards = False
    supports_images = True
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.account_sid = config.get("account_sid", "")
        self.auth_token = config.get("auth_token", "")
        self.phone_number = config.get("phone_number", "")
        self._client: Client = None
    
    async def initialize(self) -> None:
        """Inicializa el cliente de Twilio."""
        self._client = Client(self.account_sid, self.auth_token)
        self._initialized = True
        logger.info("WhatsAppAdapter inicializado")
    
    async def send_message(
        self,
        recipient: str,
        message: str,
        **kwargs
    ) -> bool:
        """
        Envía un mensaje de WhatsApp.
        
        Args:
            recipient: Número de teléfono (formato: +1234567890)
            message: Mensaje a enviar
        """
        try:
            # Asegurar formato correcto del número
            if not recipient.startswith("+"):
                recipient = f"+{recipient}"
            
            # Formato de WhatsApp en Twilio: whatsapp:+1234567890
            to_whatsapp = f"whatsapp:{recipient}"
            from_whatsapp = f"whatsapp:{self.phone_number}"
            
            message = self._client.messages.create(
                body=message,
                from_=from_whatsapp,
                to=to_whatsapp
            )
            
            logger.info(f"Mensaje de WhatsApp enviado a {recipient}: {message.sid}")
            return True
            
        except Exception as e:
            logger.error(f"Error enviando mensaje de WhatsApp: {e}")
            return False
    
    async def send_card(
        self,
        recipient: str,
        card: Dict[str, Any],
        **kwargs
    ) -> bool:
        """
        Envía una 'tarjeta' como mensaje formateado.
        WhatsApp no soporta tarjetas ricas, usamos texto formateado.
        """
        try:
            title = card.get("title", "")
            text = card.get("text", "")
            
            # Formato simple para WhatsApp
            formatted = f"*{title}*\n\n{text}"
            
            return await self.send_message(recipient, formatted)
            
        except Exception as e:
            logger.error(f"Error enviando card a WhatsApp: {e}")
            return False
    
    async def start_listening(self) -> None:
        """
        WhatsApp/Twilio usa webhooks.
        La recepción se maneja en el endpoint /api/messaging/whatsapp
        """
        logger.info("WhatsAppAdapter: Los mensajes se reciben vía webhook en /api/messaging/whatsapp")
    
    async def stop_listening(self) -> None:
        """Detiene la escucha."""
        pass
    
    async def process_incoming_message(
        self,
        from_number: str,
        body: str,
        message_sid: str = None
    ) -> str:
        """
        Procesa un mensaje entrante de WhatsApp.
        
        Args:
            from_number: Número del remitente
            body: Contenido del mensaje
            message_sid: SID del mensaje de Twilio
            
        Returns:
            Respuesta en formato TwiML
        """
        logger.info(f"Mensaje de WhatsApp de {from_number}: {body}")
        
        # Limpiar número
        user_id = from_number.replace("whatsapp:", "")
        
        # Llamar al handler si está configurado
        if self._message_handler:
            response = await self._message_handler(
                sender=user_id,
                message=body,
                metadata={
                    "channel": "whatsapp",
                    "phone_number": user_id,
                    "message_sid": message_sid
                }
            )
            
            # Crear respuesta TwiML
            twiml = MessagingResponse()
            
            if isinstance(response, dict):
                text = response.get("message", str(response))
            else:
                text = str(response)
            
            twiml.message(text)
            return str(twiml)
        
        # Respuesta por defecto
        twiml = MessagingResponse()
        twiml.message("Mensaje recibido. Procesando...")
        return str(twiml)
    
    async def send_media(
        self,
        recipient: str,
        media_url: str,
        caption: str = None
    ) -> bool:
        """
        Envía un mensaje multimedia.
        
        Args:
            recipient: Número de teléfono
            media_url: URL del medio
            caption: Leyenda opcional
        """
        try:
            if not recipient.startswith("+"):
                recipient = f"+{recipient}"
            
            to_whatsapp = f"whatsapp:{recipient}"
            from_whatsapp = f"whatsapp:{self.phone_number}"
            
            message = self._client.messages.create(
                body=caption or "",
                from_=from_whatsapp,
                to=to_whatsapp,
                media_url=[media_url]
            )
            
            logger.info(f"Mensaje multimedia de WhatsApp enviado: {message.sid}")
            return True
            
        except Exception as e:
            logger.error(f"Error enviando media a WhatsApp: {e}")
            return False
