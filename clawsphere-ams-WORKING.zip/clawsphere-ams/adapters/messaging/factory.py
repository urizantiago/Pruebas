"""
Factory para adaptadores de mensajería.
"""

import logging
from typing import Dict, Any, Type, Optional

from .base import BaseMessagingAdapter
from .teams import TeamsAdapter
from .telegram import TelegramAdapter
from .whatsapp import WhatsAppAdapter

logger = logging.getLogger(__name__)


class MessagingAdapterFactory:
    """
    Factory para crear adaptadores de mensajería.
    """
    
    _adapters: Dict[str, Type[BaseMessagingAdapter]] = {
        "teams": TeamsAdapter,
        "telegram": TelegramAdapter,
        "whatsapp": WhatsAppAdapter
    }
    
    _instances: Dict[str, BaseMessagingAdapter] = {}
    
    @classmethod
    def register_adapter(
        cls, 
        name: str, 
        adapter_class: Type[BaseMessagingAdapter]
    ) -> None:
        """Registra un nuevo adaptador."""
        cls._adapters[name] = adapter_class
        logger.info(f"Adaptador de mensajería registrado: {name}")
    
    @classmethod
    def create_adapter(
        cls, 
        platform: str, 
        config: Dict[str, Any]
    ) -> BaseMessagingAdapter:
        """
        Crea un adaptador para la plataforma especificada.
        
        Args:
            platform: Nombre de la plataforma
            config: Configuración
            
        Returns:
            Instancia del adaptador
        """
        platform = platform.lower()
        
        if platform not in cls._adapters:
            raise ValueError(
                f"Plataforma '{platform}' no soportada. "
                f"Disponibles: {list(cls._adapters.keys())}"
            )
        
        adapter_class = cls._adapters[platform]
        adapter = adapter_class(config)
        
        return adapter
    
    @classmethod
    async def get_adapter(
        cls, 
        platform: str, 
        config: Dict[str, Any]
    ) -> BaseMessagingAdapter:
        """Obtiene un adaptador inicializado."""
        cache_key = f"{platform}_{hash(str(config))}"
        
        if cache_key in cls._instances:
            return cls._instances[cache_key]
        
        adapter = cls.create_adapter(platform, config)
        await adapter.initialize()
        
        cls._instances[cache_key] = adapter
        return adapter
    
    @classmethod
    def list_adapters(cls) -> Dict[str, str]:
        """Lista adaptadores disponibles."""
        return {
            name: adapter_class.description 
            for name, adapter_class in cls._adapters.items()
        }
    
    @classmethod
    async def initialize_all(
        cls, 
        configs: Dict[str, Dict[str, Any]]
    ) -> Dict[str, BaseMessagingAdapter]:
        """
        Inicializa todos los adaptadores configurados.
        
        Args:
            configs: Dict de {plataforma: config}
            
        Returns:
            Dict de adaptadores inicializados
        """
        adapters = {}
        
        for platform, config in configs.items():
            try:
                adapter = await cls.get_adapter(platform, config)
                adapters[platform] = adapter
                logger.info(f"Adaptador {platform} inicializado")
            except Exception as e:
                logger.error(f"Error inicializando adaptador {platform}: {e}")
        
        return adapters
