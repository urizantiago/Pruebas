"""
Adaptador para Microsoft Teams.
"""

import logging
from typing import Dict, Any
import aiohttp

from .base import BaseMessagingAdapter

logger = logging.getLogger(__name__)


class TeamsAdapter(BaseMessagingAdapter):
    """
    Adaptador para Microsoft Teams usando Bot Framework.
    """
    
    name = "teams"
    description = "Microsoft Teams (Bot Framework)"
    supports_buttons = True
    supports_cards = True
    supports_images = True
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.app_id = config.get("app_id", "")
        self.app_password = config.get("app_password", "")
        self.tenant_id = config.get("tenant_id", "")
        self.base_url = "https://smba.trafficmanager.net/emea"
    
    async def initialize(self) -> None:
        """Inicializa el adaptador."""
        self._initialized = True
        logger.info("TeamsAdapter inicializado")
    
    async def send_message(
        self,
        recipient: str,
        message: str,
        **kwargs
    ) -> bool:
        """Envía un mensaje a Teams."""
        try:
            # Construir mensaje para Bot Framework
            activity = {
                "type": "message",
                "text": message,
                "textFormat": "markdown"
            }
            
            # Enviar a la conversación
            conversation_id = recipient
            
            async with aiohttp.ClientSession() as session:
                headers = {
                    "Authorization": f"Bearer {await self._get_access_token()}
                }
                
                url = f"{self.base_url}/v3/conversations/{conversation_id}/activities"
                
                async with session.post(url, json=activity, headers=headers) as response:
                    if response.status == 200 or response.status == 201:
                        logger.info(f"Mensaje enviado a Teams: {conversation_id}")
                        return True
                    else:
                        error = await response.text()
                        logger.error(f"Error enviando a Teams: {error}")
                        return False
                        
        except Exception as e:
            logger.error(f"Error enviando mensaje a Teams: {e}")
            return False
    
    async def send_card(
        self,
        recipient: str,
        card: Dict[str, Any],
        **kwargs
    ) -> bool:
        """Envía una tarjeta adaptativa a Teams."""
        try:
            activity = {
                "type": "message",
                "attachments": [{
                    "contentType": "application/vnd.microsoft.card.adaptive",
                    "content": card
                }]
            }
            
            conversation_id = recipient
            
            async with aiohttp.ClientSession() as session:
                headers = {
                    "Authorization": f"Bearer {await self._get_access_token()}"
                }
                
                url = f"{self.base_url}/v3/conversations/{conversation_id}/activities"
                
                async with session.post(url, json=activity, headers=headers) as response:
                    return response.status in [200, 201]
                    
        except Exception as e:
            logger.error(f"Error enviando card a Teams: {e}")
            return False
    
    async def start_listening(self) -> None:
        """Inicia el webhook para recibir mensajes."""
        # Teams usa webhooks, la recepción se maneja en el endpoint /api/messaging/teams
        logger.info("TeamsAdapter: Los mensajes se reciben vía webhook en /api/messaging/teams")
    
    async def stop_listening(self) -> None:
        """Detiene la escucha."""
        pass
    
    async def _get_access_token(self) -> str:
        """Obtiene token de acceso de Bot Framework."""
        try:
            async with aiohttp.ClientSession() as session:
                data = {
                    "grant_type": "client_credentials",
                    "client_id": self.app_id,
                    "client_secret": self.app_password,
                    "scope": "https://api.botframework.com/.default"
                }
                
                async with session.post(
                    "https://login.microsoftonline.com/botframework.com/oauth2/v2.0/token",
                    data=data
                ) as response:
                    if response.status == 200:
                        token_data = await response.json()
                        return token_data["access_token"]
                    else:
                        error = await response.text()
                        raise Exception(f"Error obteniendo token: {error}")
                        
        except Exception as e:
            logger.error(f"Error obteniendo token de Teams: {e}")
            raise
    
    async def process_incoming_activity(self, activity: Dict[str, Any]) -> Dict[str, Any]:
        """
        Procesa una actividad entrante de Teams.
        
        Args:
            activity: Actividad de Bot Framework
            
        Returns:
            Respuesta para el usuario
        """
        # Extraer información
        user_id = activity.get("from", {}).get("id")
        text = activity.get("text", "")
        conversation_id = activity.get("conversation", {}).get("id")
        
        # Llamar al handler si está configurado
        if self._message_handler:
            response = await self._message_handler(
                sender=user_id,
                message=text,
                metadata={
                    "conversation_id": conversation_id,
                    "channel": "teams",
                    "raw_activity": activity
                }
            )
            return response
        
        return {"text": "Mensaje recibido"}
    
    def create_adaptive_card(
        self,
        title: str,
        text: str,
        actions: list = None
    ) -> Dict[str, Any]:
        """
        Crea una tarjeta adaptativa.
        
        Args:
            title: Título de la tarjeta
            text: Contenido
            actions: Lista de acciones
            
        Returns:
            Tarjeta adaptativa
        """
        card = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.3",
            "body": [
                {
                    "type": "TextBlock",
                    "text": title,
                    "weight": "Bolder",
                    "size": "Medium"
                },
                {
                    "type": "TextBlock",
                    "text": text,
                    "wrap": True
                }
            ]
        }
        
        if actions:
            card["actions"] = actions
        
        return card
