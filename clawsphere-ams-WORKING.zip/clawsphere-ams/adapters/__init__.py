"""
Adaptadores de ClawSphere AMS.
Permiten conectar con diferentes servicios externos.
"""

from .ai.factory import AIAdapterFactory
from .databases.factory import DatabaseAdapterFactory
from .servers.factory import ServerAdapterFactory
from .messaging.factory import MessagingAdapterFactory

__all__ = [
    "AIAdapterFactory",
    "DatabaseAdapterFactory", 
    "ServerAdapterFactory",
    "MessagingAdapterFactory"
]
