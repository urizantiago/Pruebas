"""
Adaptador para PostgreSQL
"""

import logging
import time
from typing import Any, Dict, List, Optional

import asyncpg

from .base import BaseDatabaseAdapter, QueryResult

logger = logging.getLogger(__name__)


class PostgreSQLAdapter(BaseDatabaseAdapter):
    """Adaptador para PostgreSQL."""
    
    name = "postgresql"
    
    def __init__(self, connection_string: str, config: Optional[Dict[str, Any]] = None):
        super().__init__(connection_string, config)
        self.pool: Optional[asyncpg.Pool] = None
        self.pool_size = config.get('pool_size', 5) if config else 5
    
    async def connect(self) -> bool:
        """Establece conexión con PostgreSQL."""
        try:
            self.pool = await asyncpg.create_pool(
                self.connection_string,
                min_size=1,
                max_size=self.pool_size
            )
            self.is_connected = True
            logger.info("PostgreSQL adapter connected")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to PostgreSQL: {e}")
            return False
    
    async def disconnect(self):
        """Cierra la conexión."""
        if self.pool:
            await self.pool.close()
            self.pool = None
            self.is_connected = False
            logger.info("PostgreSQL adapter disconnected")
    
    async def execute(
        self,
        query: str,
        parameters: Optional[Dict[str, Any]] = None,
        read_only: bool = False
    ) -> QueryResult:
        """Ejecuta una query."""
        if not self.is_connected or not self.pool:
            return QueryResult(
                success=False,
                data=[],
                columns=[],
                row_count=0,
                execution_time_ms=0,
                error="Not connected to database"
            )
        
        start_time = time.time()
        
        try:
            async with self.pool.acquire() as connection:
                # Validar query read-only si es necesario
                if read_only:
                    query_upper = query.strip().upper()
                    forbidden_keywords = ['INSERT', 'UPDATE', 'DELETE', 'DROP', 'CREATE', 'ALTER']
                    if any(keyword in query_upper for keyword in forbidden_keywords):
                        return QueryResult(
                            success=False,
                            data=[],
                            columns=[],
                            row_count=0,
                            execution_time_ms=0,
                            error="Write operations not allowed in read-only mode"
                        )
                
                # Ejecutar query
                if parameters:
                    result = await connection.fetch(query, *parameters.values())
                else:
                    result = await connection.fetch(query)
                
                execution_time = (time.time() - start_time) * 1000
                
                # Convertir a diccionarios
                columns = []
                data = []
                
                if result:
                    columns = list(result[0].keys())
                    data = [dict(row) for row in result]
                
                return QueryResult(
                    success=True,
                    data=data,
                    columns=columns,
                    row_count=len(data),
                    execution_time_ms=execution_time
                )
                
        except Exception as e:
            execution_time = (time.time() - start_time) * 1000
            logger.error(f"Query execution error: {e}")
            return QueryResult(
                success=False,
                data=[],
                columns=[],
                row_count=0,
                execution_time_ms=execution_time,
                error=str(e)
            )
    
    async def test_connection(self) -> bool:
        """Prueba la conexión."""
        if not self.pool:
            return False
        
        try:
            async with self.pool.acquire() as connection:
                result = await connection.fetchval("SELECT 1")
                return result == 1
        except Exception as e:
            logger.error(f"Connection test failed: {e}")
            return False
    
    async def get_schema(self) -> Dict[str, Any]:
        """Obtiene el esquema de la base de datos."""
        if not self.pool:
            return {"error": "Not connected"}
        
        try:
            async with self.pool.acquire() as connection:
                # Obtener tablas
                tables_query = """
                    SELECT table_name 
                    FROM information_schema.tables 
                    WHERE table_schema = 'public'
                """
                tables = await connection.fetch(tables_query)
                
                schema = {"tables": []}
                
                for table in tables:
                    table_name = table['table_name']
                    
                    # Obtener columnas
                    columns_query = """
                        SELECT column_name, data_type, is_nullable
                        FROM information_schema.columns
                        WHERE table_name = $1
                    """
                    columns = await connection.fetch(columns_query, table_name)
                    
                    schema["tables"].append({
                        "name": table_name,
                        "columns": [
                            {
                                "name": col["column_name"],
                                "type": col["data_type"],
                                "nullable": col["is_nullable"] == "YES"
                            }
                            for col in columns
                        ]
                    })
                
                return schema
                
        except Exception as e:
            logger.error(f"Error getting schema: {e}")
            return {"error": str(e)}
