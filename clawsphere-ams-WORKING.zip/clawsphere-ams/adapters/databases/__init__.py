"""
Adaptadores de bases de datos para ClawSphere AMS
"""

from .base import BaseDatabaseAdapter, QueryResult
from .postgres import PostgreSQLAdapter
from .sqlserver import SQLServerAdapter

__all__ = [
    'BaseDatabaseAdapter',
    'QueryResult',
    'PostgreSQLAdapter',
    'SQLServerAdapter'
]
