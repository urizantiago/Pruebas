"""
Adaptador para MongoDB.
"""

import logging
from typing import Dict, Any, List, Optional
from datetime import datetime

from .base import BaseDatabaseAdapter, DatabaseConnection

logger = logging.getLogger(__name__)


class MongoDBAdapter(BaseDatabaseAdapter):
    """
    Adaptador para MongoDB.
    Usa motor para async o pymongo para sync.
    """
    
    name = "mongodb"
    description = "MongoDB"
    supports_async = True
    supports_transactions = True
    supports_prepared_statements = False
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.query_timeout = config.get("query_timeout", 300)
        try:
            from pymongo import MongoClient
            from pymongo.errors import PyMongoError
            self._MongoClient = MongoClient
            self._PyMongoError = PyMongoError
        except ImportError:
            logger.error("pymongo no está instalado. Ejecuta: pip install pymongo")
            raise
    
    async def initialize(self) -> None:
        """Inicializa el adaptador."""
        self._initialized = True
        logger.info("MongoDBAdapter inicializado")
    
    async def connect(
        self, 
        connection_string: str,
        connection_id: Optional[str] = None
    ) -> DatabaseConnection:
        """Establece conexión a MongoDB."""
        if not connection_id:
            import uuid
            connection_id = f"mongo_{uuid.uuid4().hex[:8]}"
        
        try:
            client = self._MongoClient(
                connection_string,
                serverSelectionTimeoutMS=5000
            )
            
            # Test connection
            client.admin.command('ping')
            
            db_conn = DatabaseConnection(connection_id, "mongodb", connection_string)
            db_conn.set_native_connection(client)
            
            self._connections[connection_id] = db_conn
            
            logger.info(f"Conexión MongoDB establecida: {connection_id}")
            return db_conn
            
        except Exception as e:
            logger.error(f"Error conectando a MongoDB: {e}")
            raise
    
    async def execute_query(
        self,
        query: str,
        parameters: List[Any] = None,
        connection_id: str = None,
        max_rows: int = None
    ) -> List[Dict[str, Any]]:
        """
        Ejecuta una consulta MongoDB.
        Query format: collection_name|operation|filter|projection
        """
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        try:
            # Parse query
            parts = query.split('|')
            collection_name = parts[0]
            operation = parts[1] if len(parts) > 1 else 'find'
            
            client = conn._native_conn
            db = client.get_default_database()
            collection = db[collection_name]
            
            if operation == 'find':
                filter_dict = {}
                if len(parts) > 2 and parts[2]:
                    import json
                    filter_dict = json.loads(parts[2])
                
                cursor = collection.find(filter_dict)
                
                if max_rows:
                    cursor = cursor.limit(max_rows)
                
                results = list(cursor)
                
                # Convertir ObjectId a string
                for doc in results:
                    if '_id' in doc:
                        doc['_id'] = str(doc['_id'])
                
                return results
            
            elif operation == 'aggregate':
                pipeline = []
                if len(parts) > 2 and parts[2]:
                    import json
                    pipeline = json.loads(parts[2])
                
                cursor = collection.aggregate(pipeline)
                results = list(cursor)
                
                for doc in results:
                    if '_id' in doc:
                        doc['_id'] = str(doc['_id'])
                
                return results
            
            else:
                raise ValueError(f"Operación no soportada: {operation}")
            
        except Exception as e:
            logger.error(f"Error ejecutando query MongoDB: {e}")
            raise
    
    async def execute_command(
        self,
        command: str,
        parameters: List[Any] = None,
        connection_id: str = None
    ) -> int:
        """Ejecuta un comando MongoDB."""
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        try:
            parts = command.split('|')
            collection_name = parts[0]
            operation = parts[1]
            
            client = conn._native_conn
            db = client.get_default_database()
            collection = db[collection_name]
            
            import json
            
            if operation == 'insert':
                docs = json.loads(parts[2])
                if isinstance(docs, list):
                    result = collection.insert_many(docs)
                    return len(result.inserted_ids)
                else:
                    result = collection.insert_one(docs)
                    return 1
            
            elif operation == 'update':
                filter_dict = json.loads(parts[2])
                update_dict = json.loads(parts[3])
                result = collection.update_many(filter_dict, update_dict)
                return result.modified_count
            
            elif operation == 'delete':
                filter_dict = json.loads(parts[2])
                result = collection.delete_many(filter_dict)
                return result.deleted_count
            
            else:
                raise ValueError(f"Operación no soportada: {operation}")
            
        except Exception as e:
            logger.error(f"Error ejecutando comando MongoDB: {e}")
            raise
    
    async def get_schema(
        self,
        table_name: str = None,
        connection_id: str = None
    ) -> Dict[str, Any]:
        """Obtiene el esquema de la base de datos MongoDB."""
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        try:
            client = conn._native_conn
            db = client.get_default_database()
            
            if table_name:
                # Schema de colección específica usando sample
                collection = db[table_name]
                
                # Obtener muestra de documentos
                sample = list(collection.aggregate([
                    {"$sample": {"size": 100}}
                ]))
                
                # Inferir esquema
                schema = self._infer_schema(sample)
                
                return {"collection": table_name, "schema": schema}
            
            else:
                # Listar colecciones
                collections = db.list_collection_names()
                
                collections_info = []
                for coll_name in collections:
                    stats = db.command("collStats", coll_name)
                    collections_info.append({
                        "name": coll_name,
                        "documents": stats.get("count", 0),
                        "size_mb": round(stats.get("size", 0) / 1024 / 1024, 2)
                    })
                
                return {"collections": collections_info}
            
        except Exception as e:
            logger.error(f"Error obteniendo esquema MongoDB: {e}")
            raise
    
    def _infer_schema(self, documents: List[Dict]) -> Dict[str, str]:
        """Infiere el esquema a partir de documentos de muestra."""
        schema = {}
        
        for doc in documents:
            for key, value in doc.items():
                if key not in schema:
                    schema[key] = type(value).__name__
        
        return schema
    
    async def test_connection(self, connection_string: str) -> tuple[bool, str]:
        """Prueba una conexión MongoDB."""
        try:
            client = self._MongoClient(
                connection_string,
                serverSelectionTimeoutMS=5000
            )
            
            # Test connection
            client.admin.command('ping')
            
            # Get version
            build_info = client.admin.command('buildInfo')
            version = build_info.get('version', 'unknown')
            
            client.close()
            return True, f"MongoDB {version}"
            
        except Exception as e:
            return False, str(e)
    
    async def get_server_status(self, connection_id: str) -> Dict[str, Any]:
        """Obtiene el estado del servidor MongoDB."""
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        client = conn._native_conn
        return client.admin.command('serverStatus')
