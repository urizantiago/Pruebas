"""
Adaptador para Oracle Database.
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional

from .base import BaseDatabaseAdapter, DatabaseConnection

logger = logging.getLogger(__name__)


class OracleAdapter(BaseDatabaseAdapter):
    """
    Adaptador para Oracle Database.
    Usa cx_Oracle para conexiones.
    """
    
    name = "oracle"
    description = "Oracle Database"
    supports_async = False
    supports_transactions = True
    supports_prepared_statements = True
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.query_timeout = config.get("query_timeout", 300)
        try:
            import cx_Oracle
            self._cx_Oracle = cx_Oracle
        except ImportError:
            logger.error("cx_Oracle no está instalado. Ejecuta: pip install cx_Oracle")
            raise
    
    async def initialize(self) -> None:
        """Inicializa el adaptador."""
        self._initialized = True
        logger.info("OracleAdapter inicializado")
    
    async def connect(
        self, 
        connection_string: str,
        connection_id: Optional[str] = None
    ) -> DatabaseConnection:
        """Establece conexión a Oracle."""
        if not connection_id:
            import uuid
            connection_id = f"ora_{uuid.uuid4().hex[:8]}"
        
        try:
            loop = asyncio.get_event_loop()
            
            def _connect():
                # Parse connection string
                # Format: user/password@host:port/service_name
                conn = self._cx_Oracle.connect(connection_string)
                return conn
            
            conn = await loop.run_in_executor(None, _connect)
            
            db_conn = DatabaseConnection(connection_id, "oracle", connection_string)
            db_conn.set_native_connection(conn)
            
            self._connections[connection_id] = db_conn
            
            logger.info(f"Conexión Oracle establecida: {connection_id}")
            return db_conn
            
        except Exception as e:
            logger.error(f"Error conectando a Oracle: {e}")
            raise
    
    async def execute_query(
        self,
        query: str,
        parameters: List[Any] = None,
        connection_id: str = None,
        max_rows: int = None
    ) -> List[Dict[str, Any]]:
        """Ejecuta una consulta SELECT."""
        query = self._sanitize_query(query)
        
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        try:
            loop = asyncio.get_event_loop()
            
            def _execute():
                cursor = conn._native_conn.cursor()
                
                if parameters:
                    cursor.execute(query, parameters)
                else:
                    cursor.execute(query)
                
                # Obtener columnas
                columns = [col[0] for col in cursor.description] if cursor.description else []
                
                # Obtener filas
                rows = cursor.fetchmany(max_rows) if max_rows else cursor.fetchall()
                
                # Convertir a diccionarios
                results = []
                for row in rows:
                    row_dict = {}
                    for i, col in enumerate(columns):
                        value = row[i]
                        # Convertir tipos Oracle
                        if isinstance(value, self._cx_Oracle.LOB):
                            value = value.read()
                        elif hasattr(value, 'isoformat'):
                            value = value.isoformat()
                        row_dict[col] = value
                    results.append(row_dict)
                
                cursor.close()
                return results
            
            return await loop.run_in_executor(None, _execute)
            
        except Exception as e:
            logger.error(f"Error ejecutando query Oracle: {e}")
            raise
    
    async def execute_command(
        self,
        command: str,
        parameters: List[Any] = None,
        connection_id: str = None
    ) -> int:
        """Ejecuta un comando DML."""
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        try:
            loop = asyncio.get_event_loop()
            
            def _execute():
                cursor = conn._native_conn.cursor()
                
                if parameters:
                    cursor.execute(command, parameters)
                else:
                    cursor.execute(command)
                
                conn._native_conn.commit()
                rows_affected = cursor.rowcount
                cursor.close()
                return rows_affected
            
            return await loop.run_in_executor(None, _execute)
            
        except Exception as e:
            logger.error(f"Error ejecutando comando Oracle: {e}")
            raise
    
    async def get_schema(
        self,
        table_name: str = None,
        connection_id: str = None
    ) -> Dict[str, Any]:
        """Obtiene el esquema de la base de datos Oracle."""
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        try:
            loop = asyncio.get_event_loop()
            
            def _get_schema():
                cursor = conn._native_conn.cursor()
                
                if table_name:
                    # Esquema de tabla específica
                    cursor.execute("""
                        SELECT column_name, data_type, data_length, nullable, data_default
                        FROM user_tab_columns
                        WHERE table_name = :table_name
                        ORDER BY column_id
                    """, {"table_name": table_name.upper()})
                    
                    columns = []
                    for row in cursor.fetchall():
                        columns.append({
                            "name": row[0],
                            "type": row[1],
                            "length": row[2],
                            "nullable": row[3] == "Y",
                            "default": row[4]
                        })
                    
                    return {"table": table_name, "columns": columns}
                
                else:
                    # Todas las tablas
                    cursor.execute("""
                        SELECT table_name, num_rows
                        FROM user_tables
                        ORDER BY table_name
                    """)
                    
                    tables = []
                    for row in cursor.fetchall():
                        tables.append({
                            "name": row[0],
                            "rows": row[1]
                        })
                    
                    return {"tables": tables}
            
            return await loop.run_in_executor(None, _get_schema)
            
        except Exception as e:
            logger.error(f"Error obteniendo esquema Oracle: {e}")
            raise
    
    async def test_connection(self, connection_string: str) -> tuple[bool, str]:
        """Prueba una conexión Oracle."""
        try:
            loop = asyncio.get_event_loop()
            
            def _test():
                conn = self._cx_Oracle.connect(connection_string)
                version = conn.version
                conn.close()
                return True, f"Oracle {version}"
            
            return await loop.run_in_executor(None, _test)
            
        except Exception as e:
            return False, str(e)
    
    async def get_performance_metrics(self, connection_id: str) -> Dict[str, Any]:
        """Obtiene métricas de performance de Oracle."""
        queries = {
            "wait_events": """
                SELECT event, total_waits, time_waited
                FROM v$system_event
                WHERE wait_class != 'Idle'
                ORDER BY time_waited DESC
                FETCH FIRST 10 ROWS ONLY
            """,
            "tablespace_usage": """
                SELECT tablespace_name, 
                       ROUND(used_space*8192/1024/1024, 2) as used_mb,
                       ROUND(tablespace_size*8192/1024/1024, 2) as total_mb,
                       ROUND((used_space/tablespace_size)*100, 2) as pct_used
                FROM dba_tablespace_usage_metrics
            """,
            "active_sessions": """
                SELECT COUNT(*) as active_sessions
                FROM v$session
                WHERE status = 'ACTIVE'
            """
        }
        
        results = {}
        for name, query in queries.items():
            try:
                results[name] = await self.execute_query(query, connection_id=connection_id)
            except Exception as e:
                results[name] = {"error": str(e)}
        
        return results
