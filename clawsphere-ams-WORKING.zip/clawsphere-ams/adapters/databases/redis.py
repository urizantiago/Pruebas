"""
Redis Adapter para ClawSphere AMS
Soporte para bases de datos Redis/Valkey
"""
import json
import redis
from typing import Any, Dict, List, Optional, Union
from .base import BaseDatabaseAdapter, DatabaseConnectionInfo, QueryResult


class RedisAdapter(BaseDatabaseAdapter):
    """Adaptador para bases de datos Redis"""
    
    name = "redis"
    display_name = "Redis"
    description = "Adaptador para Redis y Valkey"
    
    SUPPORTED_FEATURES = [
        "string_operations",
        "hash_operations",
        "list_operations",
        "set_operations",
        "sorted_set_operations",
        "pub_sub",
        "transactions",
        "pipelining",
        "cluster_mode"
    ]
    
    def __init__(self):
        super().__init__()
        self._connections: Dict[str, redis.Redis] = {}
        self._clusters: Dict[str, redis.cluster.RedisCluster] = {}
    
    async def connect(
        self,
        connection_string: str,
        timeout: int = 30,
        **kwargs
    ) -> str:
        """
        Conectar a Redis
        
        Formato connection_string:
        - Standalone: redis://host:port/db
        - Con auth: redis://username:password@host:port/db
        - Cluster: redis+cluster://host:port
        """
        try:
            parsed = self._parse_connection_string(connection_string)
            is_cluster = parsed.get('scheme') == 'redis+cluster'
            
            if is_cluster:
                conn = await self._connect_cluster(parsed, timeout, **kwargs)
            else:
                conn = await self._connect_standalone(parsed, timeout, **kwargs)
            
            # Test connection
            conn.ping()
            
            connection_id = self._generate_connection_id()
            
            if is_cluster:
                self._clusters[connection_id] = conn
            else:
                self._connections[connection_id] = conn
            
            self._connection_info[connection_id] = DatabaseConnectionInfo(
                host=parsed.get('host', 'localhost'),
                port=parsed.get('port', 6379),
                database=str(parsed.get('db', 0)),
                adapter_type=self.name,
                connection_id=connection_id
            )
            
            return connection_id
            
        except Exception as e:
            raise ConnectionError(f"Error conectando a Redis: {str(e)}")
    
    async def _connect_standalone(
        self,
        parsed: Dict[str, Any],
        timeout: int,
        **kwargs
    ) -> redis.Redis:
        """Conectar a Redis standalone"""
        connection_kwargs = {
            'host': parsed.get('host', 'localhost'),
            'port': parsed.get('port', 6379),
            'db': parsed.get('db', 0),
            'socket_timeout': timeout,
            'socket_connect_timeout': timeout,
            'decode_responses': kwargs.get('decode_responses', True),
        }
        
        if parsed.get('username') and parsed.get('password'):
            connection_kwargs['username'] = parsed['username']
            connection_kwargs['password'] = parsed['password']
        elif parsed.get('password'):
            connection_kwargs['password'] = parsed['password']
        
        # SSL/TLS support
        if parsed.get('ssl') or kwargs.get('ssl'):
            connection_kwargs['ssl'] = True
            connection_kwargs['ssl_cert_reqs'] = kwargs.get('ssl_cert_reqs', 'required')
        
        return redis.Redis(**connection_kwargs)
    
    async def _connect_cluster(
        self,
        parsed: Dict[str, Any],
        timeout: int,
        **kwargs
    ) -> redis.cluster.RedisCluster:
        """Conectar a Redis Cluster"""
        startup_nodes = [
            {"host": parsed.get('host', 'localhost'), "port": parsed.get('port', 6379)}
        ]
        
        connection_kwargs = {
            'startup_nodes': startup_nodes,
            'skip_full_coverage_check': True,
            'socket_timeout': timeout,
            'socket_connect_timeout': timeout,
            'decode_responses': kwargs.get('decode_responses', True),
        }
        
        if parsed.get('password'):
            connection_kwargs['password'] = parsed['password']
        
        return redis.cluster.RedisCluster(**connection_kwargs)
    
    def _parse_connection_string(self, connection_string: str) -> Dict[str, Any]:
        """Parsear string de conexión Redis"""
        from urllib.parse import urlparse
        
        parsed = urlparse(connection_string)
        
        result = {
            'scheme': parsed.scheme,
            'host': parsed.hostname,
            'port': parsed.port or 6379,
            'db': 0
        }
        
        if parsed.username:
            result['username'] = parsed.username
        if parsed.password:
            result['password'] = parsed.password
        
        # Extraer número de base de datos del path
        if parsed.path and parsed.path.strip('/'):
            try:
                result['db'] = int(parsed.path.strip('/'))
            except ValueError:
                pass
        
        return result
    
    async def disconnect(self, connection_id: str) -> None:
        """Cerrar conexión Redis"""
        if connection_id in self._connections:
            self._connections[connection_id].close()
            del self._connections[connection_id]
        elif connection_id in self._clusters:
            self._clusters[connection_id].close()
            del self._clusters[connection_id]
        
        if connection_id in self._connection_info:
            del self._connection_info[connection_id]
    
    async def execute_query(
        self,
        query: str,
        parameters: List[Any] = None,
        connection_id: str = None,
        **kwargs
    ) -> QueryResult:
        """
        Ejecutar comando Redis
        
        Formato de query:
        - "GET key"
        - "SET key value"
        - "HGETALL hash_key"
        - "LRANGE list_key 0 -1"
        - "SMEMBERS set_key"
        - "ZRANGE zset_key 0 -1 WITHSCORES"
        """
        conn = self._get_connection(connection_id)
        
        try:
            # Parsear comando
            parts = query.strip().split()
            if not parts:
                raise ValueError("Comando vacío")
            
            command = parts[0].upper()
            args = parts[1:]
            
            # Aplicar parámetros si existen
            if parameters:
                args = self._apply_parameters(args, parameters)
            
            # Ejecutar comando
            result = await self._execute_redis_command(conn, command, args)
            
            # Formatear resultado
            formatted_result = self._format_result(result)
            
            return QueryResult(
                success=True,
                data=formatted_result,
                row_count=self._count_result_items(result),
                execution_time_ms=0,  # Redis no proporciona timing nativo
                metadata={
                    'command': command,
                    'args': args,
                    'type': type(result).__name__
                }
            )
            
        except Exception as e:
            return QueryResult(
                success=False,
                data=None,
                error_message=str(e),
                metadata={'query': query}
            )
    
    async def _execute_redis_command(
        self,
        conn: Union[redis.Redis, redis.cluster.RedisCluster],
        command: str,
        args: List[str]
    ) -> Any:
        """Ejecutar comando Redis específico"""
        # Mapeo de comandos a métodos
        method = getattr(conn, command.lower(), None)
        
        if method is None:
            # Intentar usar execute_command para comandos no mapeados
            return conn.execute_command(command, *args)
        
        # Convertir argumentos al tipo correcto
        converted_args = self._convert_args(args)
        
        return method(*converted_args)
    
    def _convert_args(self, args: List[str]) -> List[Any]:
        """Convertir argumentos a tipos apropiados"""
        converted = []
        for arg in args:
            # Intentar convertir a número
            try:
                if '.' in arg:
                    converted.append(float(arg))
                else:
                    converted.append(int(arg))
            except ValueError:
                converted.append(arg)
        return converted
    
    def _format_result(self, result: Any) -> Any:
        """Formatear resultado Redis"""
        if result is None:
            return None
        elif isinstance(result, bytes):
            return result.decode('utf-8')
        elif isinstance(result, list):
            return [self._format_result(item) for item in result]
        elif isinstance(result, dict):
            return {self._format_result(k): self._format_result(v) 
                   for k, v in result.items()}
        elif isinstance(result, set):
            return [self._format_result(item) for item in result]
        else:
            return result
    
    def _count_result_items(self, result: Any) -> int:
        """Contar items en resultado"""
        if result is None:
            return 0
        elif isinstance(result, (list, set, dict)):
            return len(result)
        else:
            return 1
    
    async def execute_batch(
        self,
        queries: List[str],
        connection_id: str = None,
        **kwargs
    ) -> List[QueryResult]:
        """Ejecutar múltiples comandos Redis usando pipeline"""
        conn = self._get_connection(connection_id)
        
        try:
            # Crear pipeline
            pipeline = conn.pipeline()
            
            commands = []
            for query in queries:
                parts = query.strip().split()
                if parts:
                    command = parts[0].upper()
                    args = parts[1:]
                    method = getattr(pipeline, command.lower())
                    if method:
                        method(*args)
                        commands.append(command)
            
            # Ejecutar pipeline
            results = pipeline.execute()
            
            # Formatear resultados
            return [
                QueryResult(
                    success=True,
                    data=self._format_result(result),
                    metadata={'command': cmd}
                )
                for result, cmd in zip(results, commands)
            ]
            
        except Exception as e:
            return [
                QueryResult(
                    success=False,
                    error_message=str(e)
                )
                for _ in queries
            ]
    
    async def get_server_info(
        self,
        connection_id: str = None
    ) -> Dict[str, Any]:
        """Obtener información del servidor Redis"""
        conn = self._get_connection(connection_id)
        
        try:
            info = conn.info()
            
            return {
                'version': info.get('redis_version'),
                'mode': info.get('redis_mode', 'standalone'),
                'os': info.get('os'),
                'arch_bits': info.get('arch_bits'),
                'process_id': info.get('process_id'),
                'uptime_seconds': info.get('uptime_in_seconds'),
                'connected_clients': info.get('connected_clients'),
                'used_memory_human': info.get('used_memory_human'),
                'used_memory_peak_human': info.get('used_memory_peak_human'),
                'total_connections_received': info.get('total_connections_received'),
                'total_commands_processed': info.get('total_commands_processed'),
                'instantaneous_ops_per_sec': info.get('instantaneous_ops_per_sec'),
                'keyspace_hits': info.get('keyspace_hits'),
                'keyspace_misses': info.get('keyspace_misses'),
                'role': info.get('role'),
                'connected_slaves': info.get('connected_slaves', 0),
                'db_count': len([k for k in info.keys() if k.startswith('db')])
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    async def get_metrics(
        self,
        connection_id: str = None
    ) -> Dict[str, Any]:
        """Obtener métricas de Redis"""
        conn = self._get_connection(connection_id)
        
        try:
            info = conn.info()
            
            # Calcular hit ratio
            hits = info.get('keyspace_hits', 0)
            misses = info.get('keyspace_misses', 0)
            hit_ratio = hits / (hits + misses) if (hits + misses) > 0 else 0
            
            # Métricas de keyspace
            keyspace = {k: v for k, v in info.items() if k.startswith('db')}
            
            return {
                'memory': {
                    'used_bytes': info.get('used_memory'),
                    'used_human': info.get('used_memory_human'),
                    'peak_bytes': info.get('used_memory_peak'),
                    'peak_human': info.get('used_memory_peak_human'),
                    'fragmentation_ratio': info.get('mem_fragmentation_ratio')
                },
                'clients': {
                    'connected': info.get('connected_clients'),
                    'blocked': info.get('blocked_clients'),
                    'max': info.get('maxclients')
                },
                'stats': {
                    'commands_per_sec': info.get('instantaneous_ops_per_sec'),
                    'input_kb_per_sec': info.get('instantaneous_input_kbps'),
                    'output_kb_per_sec': info.get('instantaneous_output_kbps'),
                    'rejected_connections': info.get('rejected_connections'),
                    'expired_keys': info.get('expired_keys'),
                    'evicted_keys': info.get('evicted_keys')
                },
                'keyspace': {
                    'hit_ratio': round(hit_ratio, 4),
                    'hits': hits,
                    'misses': misses,
                    'databases': keyspace
                },
                'replication': {
                    'role': info.get('role'),
                    'connected_slaves': info.get('connected_slaves'),
                    'master_repl_offset': info.get('master_repl_offset')
                }
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    async def list_keys(
        self,
        pattern: str = '*',
        count: int = 100,
        connection_id: str = None
    ) -> List[str]:
        """Listar keys con patrón"""
        conn = self._get_connection(connection_id)
        
        try:
            keys = []
            cursor = 0
            
            while True:
                cursor, batch = conn.scan(cursor=cursor, match=pattern, count=count)
                keys.extend(batch)
                
                if cursor == 0 or len(keys) >= count:
                    break
            
            return keys[:count]
            
        except Exception as e:
            return []
    
    async def get_key_info(
        self,
        key: str,
        connection_id: str = None
    ) -> Dict[str, Any]:
        """Obtener información de una key"""
        conn = self._get_connection(connection_id)
        
        try:
            key_type = conn.type(key)
            ttl = conn.ttl(key)
            memory = conn.memory_usage(key)
            
            result = {
                'key': key,
                'type': key_type,
                'ttl': ttl,
                'memory_bytes': memory
            }
            
            # Obtener valor según tipo
            if key_type == 'string':
                result['value'] = conn.get(key)
                result['length'] = conn.strlen(key)
            elif key_type == 'hash':
                result['field_count'] = conn.hlen(key)
            elif key_type == 'list':
                result['length'] = conn.llen(key)
            elif key_type == 'set':
                result['cardinality'] = conn.scard(key)
            elif key_type == 'zset':
                result['cardinality'] = conn.zcard(key)
            
            return result
            
        except Exception as e:
            return {'error': str(e)}
    
    async def publish_message(
        self,
        channel: str,
        message: Union[str, dict],
        connection_id: str = None
    ) -> int:
        """Publicar mensaje en canal"""
        conn = self._get_connection(connection_id)
        
        if isinstance(message, dict):
            message = json.dumps(message)
        
        return conn.publish(channel, message)
    
    async def subscribe_channel(
        self,
        channel: str,
        callback: callable,
        connection_id: str = None
    ) -> None:
        """Suscribirse a canal Pub/Sub"""
        conn = self._get_connection(connection_id)
        
        pubsub = conn.pubsub()
        pubsub.subscribe(channel)
        
        for message in pubsub.listen():
            if message['type'] == 'message':
                await callback(message['channel'], message['data'])
    
    async def execute_transaction(
        self,
        commands: List[tuple],
        connection_id: str = None
    ) -> List[Any]:
        """Ejecutar transacción MULTI/EXEC"""
        conn = self._get_connection(connection_id)
        
        try:
            pipe = conn.pipeline(transaction=True)
            
            for cmd, args in commands:
                method = getattr(pipe, cmd.lower())
                if method:
                    method(*args)
            
            return pipe.execute()
            
        except Exception as e:
            raise Exception(f"Error en transacción: {str(e)}")
    
    def _get_connection(
        self,
        connection_id: str = None
    ) -> Union[redis.Redis, redis.cluster.RedisCluster]:
        """Obtener conexión por ID"""
        if connection_id:
            if connection_id in self._connections:
                return self._connections[connection_id]
            elif connection_id in self._clusters:
                return self._clusters[connection_id]
        
        # Retornar primera conexión disponible
        if self._connections:
            return next(iter(self._connections.values()))
        elif self._clusters:
            return next(iter(self._clusters.values()))
        
        raise ConnectionError("No hay conexiones Redis disponibles")
    
    async def health_check(self, connection_id: str = None) -> Dict[str, Any]:
        """Verificar salud de la conexión"""
        try:
            conn = self._get_connection(connection_id)
            start_time = __import__('time').time()
            conn.ping()
            response_time = (__import__('time').time() - start_time) * 1000
            
            return {
                'healthy': True,
                'response_time_ms': round(response_time, 2),
                'timestamp': __import__('datetime').datetime.now().isoformat()
            }
        except Exception as e:
            return {
                'healthy': False,
                'error': str(e),
                'timestamp': __import__('datetime').datetime.now().isoformat()
            }
