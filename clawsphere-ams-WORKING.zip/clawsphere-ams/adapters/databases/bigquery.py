"""
BigQuery Adapter para ClawSphere AMS
Soporte para Google Cloud BigQuery
"""
import json
from typing import Any, Dict, Iterator, List, Optional, Union
from google.cloud import bigquery
from google.cloud.bigquery import QueryJobConfig, ScalarQueryParameter
from google.oauth2 import service_account
from .base import BaseDatabaseAdapter, DatabaseConnectionInfo, QueryResult


class BigQueryAdapter(BaseDatabaseAdapter):
    """Adaptador para Google Cloud BigQuery"""
    
    name = "bigquery"
    display_name = "Google BigQuery"
    description = "Adaptador para Google Cloud BigQuery"
    
    SUPPORTED_FEATURES = [
        "standard_sql",
        "legacy_sql",
        "query_caching",
        "partitioned_tables",
        "clustered_tables",
        "materialized_views",
        "streaming_inserts",
        "batch_loads",
        "ml_models",
        "external_tables"
    ]
    
    def __init__(self):
        super().__init__()
        self._clients: Dict[str, bigquery.Client] = {}
    
    async def connect(
        self,
        connection_string: str,
        timeout: int = 300,
        **kwargs
    ) -> str:
        """
        Conectar a BigQuery
        
        Formato connection_string:
        - bigquery://project_id/location
        - Con service account: bigquery://project_id/location?credentials=/path/to/key.json
        """
        try:
            parsed = self._parse_connection_string(connection_string)
            
            project_id = parsed.get('project_id')
            location = parsed.get('location', 'US')
            credentials_path = parsed.get('credentials') or kwargs.get('credentials_path')
            
            # Configurar credenciales
            credentials = None
            if credentials_path:
                credentials = service_account.Credentials.from_service_account_file(
                    credentials_path,
                    scopes=['https://www.googleapis.com/auth/cloud-platform']
                )
            
            # Crear cliente
            client = bigquery.Client(
                project=project_id,
                credentials=credentials,
                location=location
            )
            
            # Test connection
            datasets = list(client.list_datasets(max_results=1))
            
            connection_id = self._generate_connection_id()
            self._clients[connection_id] = client
            
            self._connection_info[connection_id] = DatabaseConnectionInfo(
                host=f"{project_id}.{location}",
                port=None,
                database=project_id,
                adapter_type=self.name,
                connection_id=connection_id
            )
            
            return connection_id
            
        except Exception as e:
            raise ConnectionError(f"Error conectando a BigQuery: {str(e)}")
    
    def _parse_connection_string(self, connection_string: str) -> Dict[str, str]:
        """Parsear string de conexión BigQuery"""
        from urllib.parse import urlparse, parse_qs
        
        parsed = urlparse(connection_string)
        
        result = {}
        
        if parsed.scheme != 'bigquery':
            raise ValueError("URL debe comenzar con bigquery://")
        
        # Extraer project_id y location del path
        path_parts = parsed.path.strip('/').split('/')
        if path_parts:
            result['project_id'] = path_parts[0]
        if len(path_parts) > 1:
            result['location'] = path_parts[1]
        
        # Query parameters
        query_params = parse_qs(parsed.query)
        if 'credentials' in query_params:
            result['credentials'] = query_params['credentials'][0]
        
        return result
    
    async def disconnect(self, connection_id: str) -> None:
        """Cerrar conexión BigQuery"""
        if connection_id in self._clients:
            # BigQuery client no requiere cierre explícito
            del self._clients[connection_id]
        
        if connection_id in self._connection_info:
            del self._connection_info[connection_id]
    
    async def execute_query(
        self,
        query: str,
        parameters: List[Any] = None,
        connection_id: str = None,
        **kwargs
    ) -> QueryResult:
        """Ejecutar query BigQuery"""
        client = self._get_client(connection_id)
        
        try:
            start_time = __import__('time').time()
            
            # Configurar job
            job_config = QueryJobConfig()
            
            # Usar Standard SQL por defecto
            job_config.use_legacy_sql = kwargs.get('use_legacy_sql', False)
            
            # Configurar dry run si es necesario
            if kwargs.get('dry_run'):
                job_config.dry_run = True
            
            # Configurar parámetros
            if parameters:
                query_params = self._convert_parameters(parameters)
                job_config.query_parameters = query_params
            
            # Configurar destination table si se especifica
            if kwargs.get('destination_table'):
                dataset_id, table_id = kwargs['destination_table'].split('.')
                dataset_ref = client.dataset(dataset_id)
                table_ref = dataset_ref.table(table_id)
                job_config.destination = table_ref
                job_config.write_disposition = kwargs.get(
                    'write_disposition',
                    bigquery.WriteDisposition.WRITE_TRUNCATE
                )
            
            # Ejecutar query
            query_job = client.query(query, job_config=job_config)
            
            # Esperar resultados
            results = query_job.result()
            
            execution_time = (__import__('time').time() - start_time) * 1000
            
            # Extraer datos
            rows = [dict(row) for row in results]
            
            # Obtener schema
            schema = []
            if results.schema:
                schema = [
                    {
                        'name': field.name,
                        'type': field.field_type,
                        'mode': field.mode,
                        'description': field.description
                    }
                    for field in results.schema
                ]
            
            # Obtener información del job
            job_info = {
                'job_id': query_job.job_id,
                'total_bytes_processed': query_job.total_bytes_processed,
                'total_bytes_billed': query_job.total_bytes_billed,
                'slot_millis': query_job.slot_millis,
                'cache_hit': query_job.cache_hit,
                'statement_type': query_job.statement_type
            }
            
            return QueryResult(
                success=True,
                data=rows,
                row_count=len(rows),
                columns=[field['name'] for field in schema],
                execution_time_ms=round(execution_time, 2),
                metadata={
                    'schema': schema,
                    'job_info': job_info,
                    'query': query[:500]  # Limitar tamaño
                }
            )
            
        except Exception as e:
            return QueryResult(
                success=False,
                data=None,
                error_message=str(e),
                metadata={'query': query[:500]}
            )
    
    def _convert_parameters(
        self,
        parameters: List[Any]
    ) -> List[ScalarQueryParameter]:
        """Convertir parámetros a formato BigQuery"""
        query_params = []
        
        for i, param in enumerate(parameters):
            param_type = self._infer_bq_type(param)
            query_params.append(
                ScalarQueryParameter(f'param_{i}', param_type, param)
            )
        
        return query_params
    
    def _infer_bq_type(self, value: Any) -> str:
        """Inferir tipo BigQuery de valor Python"""
        if isinstance(value, bool):
            return 'BOOL'
        elif isinstance(value, int):
            return 'INT64'
        elif isinstance(value, float):
            return 'FLOAT64'
        elif isinstance(value, str):
            return 'STRING'
        elif isinstance(value, bytes):
            return 'BYTES'
        elif isinstance(value, list):
            return 'ARRAY'
        elif isinstance(value, dict):
            return 'STRUCT'
        else:
            return 'STRING'
    
    async def execute_batch(
        self,
        queries: List[str],
        connection_id: str = None,
        **kwargs
    ) -> List[QueryResult]:
        """Ejecutar múltiples queries BigQuery"""
        results = []
        
        for query in queries:
            result = await self.execute_query(query, connection_id=connection_id, **kwargs)
            results.append(result)
        
        return results
    
    async def get_tables(
        self,
        dataset_id: str,
        connection_id: str = None
    ) -> List[Dict[str, Any]]:
        """Listar tablas en dataset"""
        client = self._get_client(connection_id)
        
        try:
            dataset_ref = client.dataset(dataset_id)
            tables = list(client.list_tables(dataset_ref))
            
            return [
                {
                    'table_id': table.table_id,
                    'dataset_id': table.dataset_id,
                    'project': table.project,
                    'table_type': table.table_type,
                    'created': table.created.isoformat() if table.created else None,
                    'expires': table.expires.isoformat() if table.expires else None,
                    'num_bytes': table.num_bytes,
                    'num_rows': table.num_rows,
                    'partitioning_type': table.partitioning_type,
                    'time_partitioning': {
                        'type': table.time_partitioning.type if table.time_partitioning else None,
                        'field': table.time_partitioning.field if table.time_partitioning else None,
                        'expiration_ms': table.time_partitioning.expiration_ms if table.time_partitioning else None
                    } if table.time_partitioning else None,
                    'clustering_fields': table.clustering_fields
                }
                for table in tables
            ]
            
        except Exception as e:
            return [{'error': str(e)}]
    
    async def get_table_schema(
        self,
        dataset_id: str,
        table_id: str,
        connection_id: str = None
    ) -> Dict[str, Any]:
        """Obtener schema de tabla"""
        client = self._get_client(connection_id)
        
        try:
            table_ref = client.dataset(dataset_id).table(table_id)
            table = client.get_table(table_ref)
            
            def format_field(field):
                result = {
                    'name': field.name,
                    'field_type': field.field_type,
                    'mode': field.mode,
                    'description': field.description,
                    'is_nullable': field.is_nullable
                }
                
                if field.fields:
                    result['fields'] = [format_field(f) for f in field.fields]
                
                return result
            
            return {
                'table_id': table.table_id,
                'dataset_id': table.dataset_id,
                'project': table.project,
                'description': table.description,
                'schema': [format_field(field) for field in table.schema],
                'num_bytes': table.num_bytes,
                'num_rows': table.num_rows,
                'created': table.created.isoformat() if table.created else None,
                'modified': table.modified.isoformat() if table.modified else None,
                'partitioning_type': table.partitioning_type,
                'clustering_fields': table.clustering_fields,
                'labels': dict(table.labels) if table.labels else {}
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    async def get_datasets(
        self,
        connection_id: str = None
    ) -> List[Dict[str, Any]]:
        """Listar datasets en proyecto"""
        client = self._get_client(connection_id)
        
        try:
            datasets = list(client.list_datasets())
            
            return [
                {
                    'dataset_id': dataset.dataset_id,
                    'project': dataset.project,
                    'location': dataset.location,
                    'created': dataset.created.isoformat() if dataset.created else None,
                    'modified': dataset.modified.isoformat() if dataset.modified else None,
                    'description': dataset.description,
                    'labels': dict(dataset.labels) if dataset.labels else {}
                }
                for dataset in datasets
            ]
            
        except Exception as e:
            return [{'error': str(e)}]
    
    async def get_server_info(
        self,
        connection_id: str = None
    ) -> Dict[str, Any]:
        """Obtener información del proyecto BigQuery"""
        client = self._get_client(connection_id)
        
        try:
            project = client.project
            datasets = list(client.list_datasets(max_results=1000))
            
            # Calcular storage total
            total_bytes = 0
            total_tables = 0
            
            for dataset in datasets:
                try:
                    tables = list(client.list_tables(dataset.dataset_id))
                    total_tables += len(tables)
                    
                    for table in tables:
                        try:
                            table_info = client.get_table(table)
                            total_bytes += table_info.num_bytes or 0
                        except:
                            pass
                except:
                    pass
            
            return {
                'project_id': project,
                'location': client.location,
                'dataset_count': len(datasets),
                'table_count': total_tables,
                'total_storage_bytes': total_bytes,
                'total_storage_gb': round(total_bytes / (1024**3), 2)
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    async def get_metrics(
        self,
        connection_id: str = None
    ) -> Dict[str, Any]:
        """Obtener métricas de BigQuery"""
        client = self._get_client(connection_id)
        
        try:
            # Query para obtener métricas de jobs recientes
            query = """
            SELECT
                job_type,
                state,
                COUNT(*) as job_count,
                SUM(total_bytes_processed) as total_bytes_processed,
                SUM(total_slot_ms) as total_slot_ms,
                AVG(total_bytes_processed) as avg_bytes_processed
            FROM `region-us`.INFORMATION_SCHEMA.JOBS_BY_PROJECT
            WHERE creation_time > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 24 HOUR)
            GROUP BY job_type, state
            """
            
            query_job = client.query(query)
            results = query_job.result()
            
            metrics = {
                'jobs_24h': {},
                'bytes_processed_24h': 0,
                'slot_ms_24h': 0
            }
            
            for row in results:
                job_type = row.job_type
                state = row.state
                
                if job_type not in metrics['jobs_24h']:
                    metrics['jobs_24h'][job_type] = {}
                
                metrics['jobs_24h'][job_type][state] = {
                    'count': row.job_count,
                    'bytes_processed': row.total_bytes_processed,
                    'slot_ms': row.total_slot_ms
                }
                
                metrics['bytes_processed_24h'] += row.total_bytes_processed or 0
                metrics['slot_ms_24h'] += row.total_slot_ms or 0
            
            # Convertir a GB
            metrics['bytes_processed_24h_gb'] = round(
                metrics['bytes_processed_24h'] / (1024**3), 2
            )
            
            return metrics
            
        except Exception as e:
            return {'error': str(e)}
    
    async def stream_query(
        self,
        query: str,
        parameters: List[Any] = None,
        connection_id: str = None,
        **kwargs
    ) -> Iterator[Dict[str, Any]]:
        """Ejecutar query con streaming de resultados"""
        client = self._get_client(connection_id)
        
        try:
            job_config = QueryJobConfig()
            
            if parameters:
                job_config.query_parameters = self._convert_parameters(parameters)
            
            query_job = client.query(query, job_config=job_config)
            results = query_job.result()
            
            for row in results:
                yield dict(row)
                
        except Exception as e:
            raise Exception(f"Error en streaming: {str(e)}")
    
    async def load_data_from_gcs(
        self,
        dataset_id: str,
        table_id: str,
        gcs_uri: str,
        source_format: str = 'CSV',
        connection_id: str = None,
        **kwargs
    ) -> Dict[str, Any]:
        """Cargar datos desde Google Cloud Storage"""
        client = self._get_client(connection_id)
        
        try:
            dataset_ref = client.dataset(dataset_id)
            table_ref = dataset_ref.table(table_id)
            
            # Configurar job de carga
            job_config = bigquery.LoadJobConfig()
            
            if source_format.upper() == 'CSV':
                job_config.source_format = bigquery.SourceFormat.CSV
                job_config.skip_leading_rows = kwargs.get('skip_leading_rows', 1)
                job_config.autodetect = kwargs.get('autodetect', True)
            elif source_format.upper() == 'JSON':
                job_config.source_format = bigquery.SourceFormat.NEWLINE_DELIMITED_JSON
            elif source_format.upper() == 'PARQUET':
                job_config.source_format = bigquery.SourceFormat.PARQUET
            elif source_format.upper() == 'AVRO':
                job_config.source_format = bigquery.SourceFormat.AVRO
            
            job_config.write_disposition = kwargs.get(
                'write_disposition',
                bigquery.WriteDisposition.WRITE_APPEND
            )
            
            # Iniciar job de carga
            load_job = client.load_table_from_uri(
                gcs_uri,
                table_ref,
                job_config=job_config
            )
            
            # Esperar completación
            load_job.result()
            
            return {
                'success': True,
                'job_id': load_job.job_id,
                'output_rows': load_job.output_rows,
                'errors': load_job.errors
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    async def export_to_gcs(
        self,
        dataset_id: str,
        table_id: str,
        gcs_uri: str,
        destination_format: str = 'CSV',
        connection_id: str = None,
        **kwargs
    ) -> Dict[str, Any]:
        """Exportar tabla a Google Cloud Storage"""
        client = self._get_client(connection_id)
        
        try:
            dataset_ref = client.dataset(dataset_id)
            table_ref = dataset_ref.table(table_id)
            
            # Configurar job de extracción
            job_config = bigquery.ExtractJobConfig()
            
            if destination_format.upper() == 'CSV':
                job_config.destination_format = bigquery.DestinationFormat.CSV
                job_config.print_header = kwargs.get('print_header', True)
            elif destination_format.upper() == 'JSON':
                job_config.destination_format = bigquery.DestinationFormat.NEWLINE_DELIMITED_JSON
            elif destination_format.upper() == 'AVRO':
                job_config.destination_format = bigquery.DestinationFormat.AVRO
            
            # Iniciar job de extracción
            extract_job = client.extract_table(
                table_ref,
                gcs_uri,
                job_config=job_config
            )
            
            # Esperar completación
            extract_job.result()
            
            return {
                'success': True,
                'job_id': extract_job.job_id,
                'destination_uris': extract_job.destination_uris
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    async def create_ml_model(
        self,
        dataset_id: str,
        model_name: str,
        model_type: str,
        query: str,
        connection_id: str = None,
        **kwargs
    ) -> Dict[str, Any]:
        """Crear modelo ML en BigQuery"""
        client = self._get_client(connection_id)
        
        try:
            # Construir query CREATE MODEL
            create_query = f"""
            CREATE OR REPLACE MODEL `{dataset_id}.{model_name}`
            OPTIONS(
                MODEL_TYPE='{model_type}',
                {self._build_ml_options(kwargs)}
            )
            AS
            {query}
            """
            
            query_job = client.query(create_query)
            result = query_job.result()
            
            return {
                'success': True,
                'model_name': model_name,
                'job_id': query_job.job_id,
                'training_info': query_job.training_info if hasattr(query_job, 'training_info') else None
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def _build_ml_options(self, options: Dict[str, Any]) -> str:
        """Construir opciones para modelo ML"""
        option_strings = []
        
        for key, value in options.items():
            if isinstance(value, str):
                option_strings.append(f"{key}='{value}'")
            elif isinstance(value, bool):
                option_strings.append(f"{key}={str(value).upper()}")
            else:
                option_strings.append(f"{key}={value}")
        
        return ', '.join(option_strings)
    
    def _get_client(self, connection_id: str = None) -> bigquery.Client:
        """Obtener cliente por ID"""
        if connection_id and connection_id in self._clients:
            return self._clients[connection_id]
        
        if self._clients:
            return next(iter(self._clients.values()))
        
        raise ConnectionError("No hay conexiones BigQuery disponibles")
    
    async def health_check(self, connection_id: str = None) -> Dict[str, Any]:
        """Verificar salud de la conexión"""
        try:
            client = self._get_client(connection_id)
            start_time = __import__('time').time()
            
            # Test simple query
            query_job = client.query("SELECT 1 as test")
            result = query_job.result()
            list(result)  # Consumir resultado
            
            response_time = (__import__('time').time() - start_time) * 1000
            
            return {
                'healthy': True,
                'response_time_ms': round(response_time, 2),
                'project': client.project,
                'timestamp': __import__('datetime').datetime.now().isoformat()
            }
        except Exception as e:
            return {
                'healthy': False,
                'error': str(e),
                'timestamp': __import__('datetime').datetime.now().isoformat()
            }
