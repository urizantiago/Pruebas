"""
Adaptador para MySQL/MariaDB.
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional

from .base import BaseDatabaseAdapter, DatabaseConnection

logger = logging.getLogger(__name__)


class MySQLAdapter(BaseDatabaseAdapter):
    """
    Adaptador para MySQL y MariaDB.
    Usa PyMySQL para conexiones.
    """
    
    name = "mysql"
    description = "MySQL / MariaDB"
    supports_async = False
    supports_transactions = True
    supports_prepared_statements = True
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.query_timeout = config.get("query_timeout", 300)
        try:
            import pymysql
            self._pymysql = pymysql
        except ImportError:
            logger.error("PyMySQL no está instalado. Ejecuta: pip install pymysql")
            raise
    
    async def initialize(self) -> None:
        """Inicializa el adaptador."""
        self._initialized = True
        logger.info("MySQLAdapter inicializado")
    
    async def connect(
        self, 
        connection_string: str,
        connection_id: Optional[str] = None
    ) -> DatabaseConnection:
        """Establece conexión a MySQL."""
        if not connection_id:
            import uuid
            connection_id = f"mysql_{uuid.uuid4().hex[:8]}"
        
        try:
            # Parse connection string
            # Format: mysql://user:password@host:port/database
            from urllib.parse import urlparse
            parsed = urlparse(connection_string)
            
            connect_kwargs = {
                "host": parsed.hostname or "localhost",
                "port": parsed.port or 3306,
                "user": parsed.username,
                "password": parsed.password,
                "database": parsed.path[1:] if parsed.path else None,
                "connect_timeout": self.query_timeout,
                "cursorclass": self._pymysql.cursors.DictCursor
            }
            
            loop = asyncio.get_event_loop()
            conn = await loop.run_in_executor(
                None,
                lambda: self._pymysql.connect(**connect_kwargs)
            )
            
            db_conn = DatabaseConnection(connection_id, "mysql", connection_string)
            db_conn.set_native_connection(conn)
            
            self._connections[connection_id] = db_conn
            
            logger.info(f"Conexión MySQL establecida: {connection_id}")
            return db_conn
            
        except Exception as e:
            logger.error(f"Error conectando a MySQL: {e}")
            raise
    
    async def execute_query(
        self,
        query: str,
        parameters: List[Any] = None,
        connection_id: str = None,
        max_rows: int = None
    ) -> List[Dict[str, Any]]:
        """Ejecuta una consulta SELECT."""
        query = self._sanitize_query(query)
        
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        try:
            loop = asyncio.get_event_loop()
            
            def _execute():
                with conn._native_conn.cursor() as cursor:
                    if parameters:
                        cursor.execute(query, parameters)
                    else:
                        cursor.execute(query)
                    
                    results = cursor.fetchall()
                    
                    if max_rows and len(results) > max_rows:
                        results = results[:max_rows]
                    
                    # Convertir tipos
                    for row in results:
                        for key, value in row.items():
                            if hasattr(value, 'isoformat'):
                                row[key] = value.isoformat()
                    
                    return results
            
            return await loop.run_in_executor(None, _execute)
            
        except Exception as e:
            logger.error(f"Error ejecutando query MySQL: {e}")
            raise
    
    async def execute_command(
        self,
        command: str,
        parameters: List[Any] = None,
        connection_id: str = None
    ) -> int:
        """Ejecuta un comando DML."""
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        try:
            loop = asyncio.get_event_loop()
            
            def _execute():
                with conn._native_conn.cursor() as cursor:
                    if parameters:
                        cursor.execute(command, parameters)
                    else:
                        cursor.execute(command)
                    
                    conn._native_conn.commit()
                    return cursor.rowcount
            
            return await loop.run_in_executor(None, _execute)
            
        except Exception as e:
            logger.error(f"Error ejecutando comando MySQL: {e}")
            raise
    
    async def get_schema(
        self,
        table_name: str = None,
        connection_id: str = None
    ) -> Dict[str, Any]:
        """Obtiene el esquema de la base de datos MySQL."""
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        try:
            loop = asyncio.get_event_loop()
            
            def _get_schema():
                with conn._native_conn.cursor() as cursor:
                    if table_name:
                        cursor.execute("""
                            SELECT column_name, data_type, is_nullable, column_default, character_maximum_length
                            FROM information_schema.columns
                            WHERE table_name = %s
                            ORDER BY ordinal_position
                        """, (table_name,))
                        
                        columns = []
                        for row in cursor.fetchall():
                            columns.append({
                                "name": row["column_name"],
                                "type": row["data_type"],
                                "nullable": row["is_nullable"] == "YES",
                                "default": row["column_default"],
                                "max_length": row["character_maximum_length"]
                            })
                        
                        return {"table": table_name, "columns": columns}
                    
                    else:
                        cursor.execute("""
                            SELECT table_name, table_rows, data_length/1024/1024 as size_mb
                            FROM information_schema.tables
                            WHERE table_schema = DATABASE()
                            ORDER BY table_name
                        """)
                        
                        tables = []
                        for row in cursor.fetchall():
                            tables.append({
                                "name": row["table_name"],
                                "rows": row["table_rows"],
                                "size_mb": round(row["size_mb"] or 0, 2)
                            })
                        
                        return {"tables": tables}
            
            return await loop.run_in_executor(None, _get_schema)
            
        except Exception as e:
            logger.error(f"Error obteniendo esquema MySQL: {e}")
            raise
    
    async def test_connection(self, connection_string: str) -> tuple[bool, str]:
        """Prueba una conexión MySQL."""
        try:
            loop = asyncio.get_event_loop()
            
            def _test():
                from urllib.parse import urlparse
                parsed = urlparse(connection_string)
                
                conn = self._pymysql.connect(
                    host=parsed.hostname or "localhost",
                    port=parsed.port or 3306,
                    user=parsed.username,
                    password=parsed.password,
                    database=parsed.path[1:] if parsed.path else None,
                    connect_timeout=10
                )
                
                with conn.cursor() as cursor:
                    cursor.execute("SELECT VERSION()")
                    version = cursor.fetchone()["VERSION()"]
                
                conn.close()
                return True, f"MySQL {version}"
            
            return await loop.run_in_executor(None, _test)
            
        except Exception as e:
            return False, str(e)
    
    async def get_processlist(self, connection_id: str) -> List[Dict[str, Any]]:
        """Obtiene la lista de procesos activos."""
        query = """
            SELECT id, user, host, db, command, time, state, info
            FROM information_schema.processlist
            WHERE command != 'Sleep'
            ORDER BY time DESC
        """
        return await self.execute_query(query, connection_id=connection_id)
