"""
Clase base para adaptadores de bases de datos
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class QueryResult:
    """Resultado de una query."""
    success: bool
    data: List[Dict[str, Any]]
    columns: List[str]
    row_count: int
    execution_time_ms: float
    error: Optional[str] = None
    
    @property
    def is_error(self) -> bool:
        """Indica si la query resultó en error."""
        return not self.success or self.error is not None


class BaseDatabaseAdapter(ABC):
    """Clase base para adaptadores de bases de datos."""
    
    name: str = "base"
    supports_transactions: bool = True
    supports_prepared_statements: bool = True
    
    def __init__(self, connection_string: str, config: Optional[Dict[str, Any]] = None):
        self.connection_string = connection_string
        self.config = config or {}
        self.is_connected = False
        self._connection = None
    
    @abstractmethod
    async def connect(self) -> bool:
        """Establece conexión con la base de datos."""
        pass
    
    @abstractmethod
    async def disconnect(self):
        """Cierra la conexión."""
        pass
    
    @abstractmethod
    async def execute(
        self,
        query: str,
        parameters: Optional[Dict[str, Any]] = None,
        read_only: bool = False
    ) -> QueryResult:
        """Ejecuta una query."""
        pass
    
    @abstractmethod
    async def test_connection(self) -> bool:
        """Prueba la conexión."""
        pass
    
    @abstractmethod
    async def get_schema(self) -> Dict[str, Any]:
        """Obtiene el esquema de la base de datos."""
        pass
    
    async def is_healthy(self) -> bool:
        """Verifica si la conexión está saludable."""
        try:
            return await self.test_connection()
        except Exception:
            return False
