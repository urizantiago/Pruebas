"""
Factory para crear adaptadores de bases de datos.
"""

import logging
from typing import Dict, Any, Type, Optional

from .base import BaseDatabaseAdapter
from .sqlserver import SQLServerAdapter
from .postgresql import PostgreSQLAdapter
from .oracle import OracleAdapter
from .mysql import MySQLAdapter
from .mongodb import MongoDBAdapter
from .redis import RedisAdapter
from .bigquery import BigQueryAdapter

logger = logging.getLogger(__name__)


class DatabaseAdapterFactory:
    """
    Factory para crear adaptadores de bases de datos.
    """
    
    _adapters: Dict[str, Type[BaseDatabaseAdapter]] = {
        "sqlserver": SQLServerAdapter,
        "mssql": SQLServerAdapter,
        "postgresql": PostgreSQLAdapter,
        "postgres": PostgreSQLAdapter,
        "mysql": MySQLAdapter,
        "mariadb": MySQLAdapter,
        "oracle": OracleAdapter,
        "mongodb": MongoDBAdapter,
        "mongo": MongoDBAdapter,
        "redis": RedisAdapter,
        "valkey": RedisAdapter,
        "bigquery": BigQueryAdapter,
        "gbq": BigQueryAdapter,
        "db2": None,  # TODO: Implementar
        "informix": None,  # TODO: Implementar
    }
    
    _instances: Dict[str, BaseDatabaseAdapter] = {}
    
    @classmethod
    def register_adapter(
        cls, 
        name: str, 
        adapter_class: Type[BaseDatabaseAdapter]
    ) -> None:
        """Registra un nuevo adaptador."""
        cls._adapters[name] = adapter_class
        logger.info(f"Adaptador de BD registrado: {name}")
    
    @classmethod
    def create_adapter(
        cls, 
        db_type: str, 
        config: Dict[str, Any] = None
    ) -> BaseDatabaseAdapter:
        """
        Crea un adaptador para el tipo de BD especificado.
        
        Args:
            db_type: Tipo de base de datos
            config: Configuración
            
        Returns:
            Instancia del adaptador
        """
        db_type = db_type.lower()
        
        if db_type not in cls._adapters:
            raise ValueError(
                f"Tipo de BD '{db_type}' no soportado. "
                f"Disponibles: {list(cls._adapters.keys())}"
            )
        
        adapter_class = cls._adapters[db_type]
        if adapter_class is None:
            raise ValueError(f"Adaptador para '{db_type}' aún no implementado")
        
        config = config or {}
        adapter = adapter_class(config)
        
        return adapter
    
    @classmethod
    async def get_adapter(
        cls, 
        db_type: str, 
        config: Dict[str, Any] = None
    ) -> BaseDatabaseAdapter:
        """Obtiene un adaptador inicializado."""
        cache_key = f"{db_type}_{hash(str(config))}"
        
        if cache_key in cls._instances:
            return cls._instances[cache_key]
        
        adapter = cls.create_adapter(db_type, config)
        await adapter.initialize()
        
        cls._instances[cache_key] = adapter
        return adapter
    
    @classmethod
    def get_core_database(cls) -> BaseDatabaseAdapter:
        """Obtiene adaptador para la base de datos core del sistema."""
        # TODO: Implementar con configuración real
        return cls.create_adapter("sqlserver", {})
    
    @classmethod
    def list_supported_databases(cls) -> Dict[str, str]:
        """Lista las bases de datos soportadas."""
        return {
            name: "Soportado" if adapter else "Pendiente"
            for name, adapter in cls._adapters.items()
        }
    
    @classmethod
    def parse_connection_string(cls, connection_string: str) -> Dict[str, str]:
        """
        Parsea una cadena de conexión y extrae información.
        
        Supports:
        - SQL Server: Server=...;Database=...;User=...;Password=...
        - PostgreSQL: postgresql://user:pass@host:port/dbname
        """
        result = {"type": "unknown", "parsed": {}}
        
        if connection_string.startswith("postgresql://"):
            result["type"] = "postgresql"
            # Parsear URL
            from urllib.parse import urlparse
            parsed = urlparse(connection_string)
            result["parsed"] = {
                "host": parsed.hostname,
                "port": parsed.port or 5432,
                "database": parsed.path[1:] if parsed.path else "",
                "username": parsed.username,
                "password": "***" if parsed.password else None
            }
        
        elif "Server=" in connection_string or "Data Source=" in connection_string:
            result["type"] = "sqlserver"
            # Parsear key-value
            parts = {}
            for part in connection_string.split(";"):
                if "=" in part:
                    key, value = part.split("=", 1)
                    parts[key.strip()] = value.strip()
            
            result["parsed"] = {
                "server": parts.get("Server") or parts.get("Data Source"),
                "database": parts.get("Database") or parts.get("Initial Catalog"),
                "username": parts.get("User Id") or parts.get("UID"),
                "password": "***" if parts.get("Password") or parts.get("PWD") else None
            }
        
        return result
