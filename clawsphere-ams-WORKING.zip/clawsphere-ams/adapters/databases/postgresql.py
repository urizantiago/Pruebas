"""
Adaptador para PostgreSQL.
"""

import asyncpg
import logging
from typing import Dict, Any, List, Optional

from .base import BaseDatabaseAdapter, DatabaseConnection

logger = logging.getLogger(__name__)


class PostgreSQLAdapter(BaseDatabaseAdapter):
    """
    Adaptador para PostgreSQL.
    Usa asyncpg para soporte async nativo.
    """
    
    name = "postgresql"
    description = "PostgreSQL"
    supports_async = True
    supports_transactions = True
    supports_prepared_statements = True
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.query_timeout = config.get("query_timeout", 300)
        self.pool_size = config.get("pool_size", 10)
    
    async def initialize(self) -> None:
        """Inicializa el adaptador."""
        self._initialized = True
        logger.info("PostgreSQLAdapter inicializado")
    
    async def connect(
        self, 
        connection_string: str,
        connection_id: Optional[str] = None
    ) -> DatabaseConnection:
        """Establece conexión a PostgreSQL."""
        if not connection_id:
            import uuid
            connection_id = f"pg_{uuid.uuid4().hex[:8]}"
        
        try:
            # Parsear connection string
            # Format: postgresql://user:pass@host:port/dbname
            conn = await asyncpg.connect(
                dsn=connection_string,
                timeout=self.query_timeout
            )
            
            db_conn = DatabaseConnection(connection_id, "postgresql", connection_string)
            db_conn.set_native_connection(conn)
            
            self._connections[connection_id] = db_conn
            
            logger.info(f"Conexión PostgreSQL establecida: {connection_id}")
            return db_conn
            
        except Exception as e:
            logger.error(f"Error conectando a PostgreSQL: {e}")
            raise
    
    async def execute_query(
        self,
        query: str,
        parameters: List[Any] = None,
        connection_id: str = None,
        max_rows: int = None
    ) -> List[Dict[str, Any]]:
        """Ejecuta una consulta SELECT."""
        query = self._sanitize_query(query)
        
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        try:
            native_conn = conn._native_conn
            
            if parameters:
                # Convertir a tupla para asyncpg
                params = tuple(parameters)
                rows = await native_conn.fetch(query, *params)
            else:
                rows = await native_conn.fetch(query)
            
            # Limitar filas
            if max_rows and len(rows) > max_rows:
                rows = rows[:max_rows]
            
            # Convertir a diccionarios
            results = []
            for row in rows:
                row_dict = dict(row)
                # Convertir tipos
                for key, value in row_dict.items():
                    if hasattr(value, 'isoformat'):
                        row_dict[key] = value.isoformat()
                results.append(row_dict)
            
            return results
            
        except Exception as e:
            logger.error(f"Error ejecutando query: {e}")
            raise
    
    async def execute_command(
        self,
        command: str,
        parameters: List[Any] = None,
        connection_id: str = None
    ) -> int:
        """Ejecuta un comando."""
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        try:
            native_conn = conn._native_conn
            
            if parameters:
                result = await native_conn.execute(command, *tuple(parameters))
            else:
                result = await native_conn.execute(command)
            
            # Parsear resultado (formato: 'INSERT 0 1' o 'UPDATE 3')
            parts = result.split()
            if len(parts) >= 3:
                return int(parts[-1])
            return 0
            
        except Exception as e:
            logger.error(f"Error ejecutando comando: {e}")
            raise
    
    async def get_schema(
        self,
        table_name: str = None,
        connection_id: str = None
    ) -> Dict[str, Any]:
        """Obtiene el esquema de la base de datos."""
        conn = self.get_connection(connection_id)
        if not conn or not conn.is_connected:
            raise ValueError(f"Conexión no encontrada: {connection_id}")
        
        try:
            native_conn = conn._native_conn
            
            if table_name:
                # Esquema de tabla específica
                query = """
                    SELECT 
                        column_name,
                        data_type,
                        is_nullable,
                        column_default,
                        character_maximum_length
                    FROM information_schema.columns
                    WHERE table_name = $1
                    ORDER BY ordinal_position
                """
                rows = await native_conn.fetch(query, table_name)
                
                columns = []
                for row in rows:
                    columns.append({
                        "name": row["column_name"],
                        "type": row["data_type"],
                        "nullable": row["is_nullable"] == "YES",
                        "default": row["column_default"],
                        "max_length": row["character_maximum_length"]
                    })
                
                return {"table": table_name, "columns": columns}
            
            else:
                # Todas las tablas
                query = """
                    SELECT table_schema, table_name, table_type
                    FROM information_schema.tables
                    WHERE table_schema NOT IN ('pg_catalog', 'information_schema')
                    AND table_type = 'BASE TABLE'
                    ORDER BY table_schema, table_name
                """
                rows = await native_conn.fetch(query)
                
                tables = []
                for row in rows:
                    tables.append({
                        "schema": row["table_schema"],
                        "name": row["table_name"],
                        "type": row["table_type"]
                    })
                
                return {"tables": tables}
            
        except Exception as e:
            logger.error(f"Error obteniendo esquema: {e}")
            raise
    
    async def test_connection(self, connection_string: str) -> tuple[bool, str]:
        """Prueba una conexión."""
        try:
            conn = await asyncpg.connect(dsn=connection_string, timeout=10)
            version = await conn.fetchval("SELECT version()")
            await conn.close()
            return True, version
        except Exception as e:
            return False, str(e)
    
    async def get_active_queries(self, connection_id: str) -> List[Dict[str, Any]]:
        """Obtiene queries activas."""
        query = """
            SELECT 
                pid,
                usename,
                application_name,
                client_addr,
                state,
                query_start,
                state_change,
                query
            FROM pg_stat_activity
            WHERE state = 'active'
            AND query NOT LIKE '%pg_stat_activity%'
            ORDER BY query_start
        """
        return await self.execute_query(query, connection_id=connection_id)
    
    async def get_locks(self, connection_id: str) -> List[Dict[str, Any]]:
        """Obtiene bloqueos."""
        query = """
            SELECT 
                l.locktype,
                l.relation::regclass as table_name,
                l.mode,
                l.granted,
                a.usename,
                a.query
            FROM pg_locks l
            JOIN pg_stat_activity a ON l.pid = a.pid
            WHERE NOT l.granted
        """
        return await self.execute_query(query, connection_id=connection_id)
    
    async def kill_query(self, pid: int, connection_id: str) -> bool:
        """Mata un query por PID."""
        try:
            conn = self.get_connection(connection_id)
            await conn._native_conn.execute(f"SELECT pg_terminate_backend({pid})")
            return True
        except Exception as e:
            logger.error(f"Error matando query {pid}: {e}")
            return False
