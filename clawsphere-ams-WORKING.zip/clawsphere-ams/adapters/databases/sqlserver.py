"""
Adaptador para SQL Server
"""

import logging
import time
from typing import Any, Dict, List, Optional

import pyodbc

from .base import BaseDatabaseAdapter, QueryResult

logger = logging.getLogger(__name__)


class SQLServerAdapter(BaseDatabaseAdapter):
    """Adaptador para SQL Server."""
    
    name = "sqlserver"
    
    def __init__(self, connection_string: str, config: Optional[Dict[str, Any]] = None):
        super().__init__(connection_string, config)
        self._connection: Optional[pyodbc.Connection] = None
        self.timeout = config.get('timeout', 30) if config else 30
    
    async def connect(self) -> bool:
        """Establece conexión con SQL Server."""
        try:
            self._connection = pyodbc.connect(
                self.connection_string,
                timeout=self.timeout
            )
            self.is_connected = True
            logger.info("SQL Server adapter connected")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to SQL Server: {e}")
            return False
    
    async def disconnect(self):
        """Cierra la conexión."""
        if self._connection:
            self._connection.close()
            self._connection = None
            self.is_connected = False
            logger.info("SQL Server adapter disconnected")
    
    async def execute(
        self,
        query: str,
        parameters: Optional[Dict[str, Any]] = None,
        read_only: bool = False
    ) -> QueryResult:
        """Ejecuta una query."""
        if not self.is_connected or not self._connection:
            return QueryResult(
                success=False,
                data=[],
                columns=[],
                row_count=0,
                execution_time_ms=0,
                error="Not connected to database"
            )
        
        start_time = time.time()
        
        try:
            # Validar query read-only si es necesario
            if read_only:
                query_upper = query.strip().upper()
                forbidden_keywords = ['INSERT', 'UPDATE', 'DELETE', 'DROP', 'CREATE', 'ALTER']
                if any(keyword in query_upper for keyword in forbidden_keywords):
                    return QueryResult(
                        success=False,
                        data=[],
                        columns=[],
                        row_count=0,
                        execution_time_ms=0,
                        error="Write operations not allowed in read-only mode"
                    )
            
            cursor = self._connection.cursor()
            
            # Ejecutar query
            if parameters:
                cursor.execute(query, list(parameters.values()))
            else:
                cursor.execute(query)
            
            # Obtener resultados
            columns = []
            data = []
            
            if cursor.description:
                columns = [desc[0] for desc in cursor.description]
                rows = cursor.fetchall()
                data = [dict(zip(columns, row)) for row in rows]
            
            cursor.close()
            
            execution_time = (time.time() - start_time) * 1000
            
            return QueryResult(
                success=True,
                data=data,
                columns=columns,
                row_count=len(data),
                execution_time_ms=execution_time
            )
                
        except Exception as e:
            execution_time = (time.time() - start_time) * 1000
            logger.error(f"Query execution error: {e}")
            return QueryResult(
                success=False,
                data=[],
                columns=[],
                row_count=0,
                execution_time_ms=execution_time,
                error=str(e)
            )
    
    async def test_connection(self) -> bool:
        """Prueba la conexión."""
        if not self._connection:
            return False
        
        try:
            cursor = self._connection.cursor()
            cursor.execute("SELECT 1")
            result = cursor.fetchone()
            cursor.close()
            return result[0] == 1
        except Exception as e:
            logger.error(f"Connection test failed: {e}")
            return False
    
    async def get_schema(self) -> Dict[str, Any]:
        """Obtiene el esquema de la base de datos."""
        if not self._connection:
            return {"error": "Not connected"}
        
        try:
            cursor = self._connection.cursor()
            
            # Obtener tablas
            cursor.execute("""
                SELECT TABLE_NAME 
                FROM INFORMATION_SCHEMA.TABLES 
                WHERE TABLE_TYPE = 'BASE TABLE'
            """)
            tables = cursor.fetchall()
            
            schema = {"tables": []}
            
            for table_row in tables:
                table_name = table_row[0]
                
                # Obtener columnas
                cursor.execute("""
                    SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE TABLE_NAME = ?
                """, table_name)
                columns = cursor.fetchall()
                
                schema["tables"].append({
                    "name": table_name,
                    "columns": [
                        {
                            "name": col[0],
                            "type": col[1],
                            "nullable": col[2] == "YES"
                        }
                        for col in columns
                    ]
                })
            
            cursor.close()
            return schema
                
        except Exception as e:
            logger.error(f"Error getting schema: {e}")
            return {"error": str(e)}
