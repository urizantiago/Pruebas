"""
Políticas de remediación.

Define cuándo y cómo se deben ejecutar las acciones de remediación
automática basándose en alertas y condiciones.
"""

import logging
import yaml
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
from pathlib import Path
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class RemediationPolicy:
    """Política de remediación que define una regla de auto-curación."""
    
    # Identificación
    id: str
    name: str
    description: str = ""
    enabled: bool = True
    
    # Matching de alertas
    alert_matchers: Dict[str, Any] = field(default_factory=dict)
    """
    Ejemplo:
    {
        "name": "HighMemoryUsage",
        "severity": ["warning", "critical"],
        "labels": {
            "service": "api-gateway"
        }
    }
    """
    
    # Acción a ejecutar
    action_name: str = ""
    parameters: Dict[str, Any] = field(default_factory=dict)
    
    # Control de ejecución
    severity: str = "medium"  # low, medium, high, critical
    requires_approval: bool = False
    approval_timeout_minutes: int = 30
    auto_retry: bool = False
    max_retries: int = 3
    retry_delay_seconds: int = 60
    
    # Condiciones adicionales
    conditions: List[Dict[str, Any]] = field(default_factory=list)
    """
    Ejemplo:
    [
        {"type": "time_range", "start_hour": 2, "end_hour": 6},
        {"type": "day_of_week", "days": [0, 1, 2, 3, 4]},
        {"type": "metric_threshold", "metric": "cpu_usage", "operator": ">", "threshold": 90}
    ]
    """
    
    # Cooldown
    cooldown_minutes: int = 5
    
    # Notificaciones
    notify_on_success: bool = False
    notify_on_failure: bool = True
    notification_channels: List[str] = field(default_factory=lambda: ["teams"])
    
    # Metadata
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    created_by: str = "system"
    
    def matches_alert(self, alert: 'AlertContext') -> bool:
        """Verifica si esta política aplica a una alerta."""
        # Verificar nombre de alerta
        if "name" in self.alert_matchers:
            matcher_name = self.alert_matchers["name"]
            if isinstance(matcher_name, str):
                if alert.alert_name != matcher_name:
                    return False
            elif isinstance(matcher_name, list):
                if alert.alert_name not in matcher_name:
                    return False
        
        # Verificar severidad
        if "severity" in self.alert_matchers:
            matcher_severity = self.alert_matchers["severity"]
            if isinstance(matcher_severity, str):
                if alert.severity != matcher_severity:
                    return False
            elif isinstance(matcher_severity, list):
                if alert.severity not in matcher_severity:
                    return False
        
        # Verificar labels
        if "labels" in self.alert_matchers:
            for key, value in self.alert_matchers["labels"].items():
                if key not in alert.labels:
                    return False
                alert_value = alert.labels[key]
                if isinstance(value, str):
                    if alert_value != value:
                        return False
                elif isinstance(value, list):
                    if alert_value not in value:
                        return False
        
        # Verificar source
        if "source" in self.alert_matchers:
            if alert.source != self.alert_matchers["source"]:
                return False
        
        return True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convierte la política a diccionario."""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "enabled": self.enabled,
            "alert_matchers": self.alert_matchers,
            "action_name": self.action_name,
            "parameters": self.parameters,
            "severity": self.severity,
            "requires_approval": self.requires_approval,
            "approval_timeout_minutes": self.approval_timeout_minutes,
            "auto_retry": self.auto_retry,
            "max_retries": self.max_retries,
            "retry_delay_seconds": self.retry_delay_seconds,
            "conditions": self.conditions,
            "cooldown_minutes": self.cooldown_minutes,
            "notify_on_success": self.notify_on_success,
            "notify_on_failure": self.notify_on_failure,
            "notification_channels": self.notification_channels,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "created_by": self.created_by
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'RemediationPolicy':
        """Crea una política desde un diccionario."""
        return cls(
            id=data["id"],
            name=data["name"],
            description=data.get("description", ""),
            enabled=data.get("enabled", True),
            alert_matchers=data.get("alert_matchers", {}),
            action_name=data.get("action_name", ""),
            parameters=data.get("parameters", {}),
            severity=data.get("severity", "medium"),
            requires_approval=data.get("requires_approval", False),
            approval_timeout_minutes=data.get("approval_timeout_minutes", 30),
            auto_retry=data.get("auto_retry", False),
            max_retries=data.get("max_retries", 3),
            retry_delay_seconds=data.get("retry_delay_seconds", 60),
            conditions=data.get("conditions", []),
            cooldown_minutes=data.get("cooldown_minutes", 5),
            notify_on_success=data.get("notify_on_success", False),
            notify_on_failure=data.get("notify_on_failure", True),
            notification_channels=data.get("notification_channels", ["teams"]),
            created_at=datetime.fromisoformat(data["created_at"]) if "created_at" in data else datetime.utcnow(),
            updated_at=datetime.fromisoformat(data["updated_at"]) if "updated_at" in data else datetime.utcnow(),
            created_by=data.get("created_by", "system")
        )


class PolicyEngine:
    """Motor de evaluación de políticas de remediación."""
    
    def __init__(self):
        self._policies: Dict[str, RemediationPolicy] = {}
        self._policies_dir: Path = Path("config/remediation_policies")
        self._load_default_policies()
    
    def _load_default_policies(self):
        """Carga las políticas predefinidas."""
        default_policies = [
            # Políticas de servidor
            RemediationPolicy(
                id="srv-restart-on-high-memory",
                name="Restart Service on High Memory",
                description="Reinicia el servicio cuando el uso de memoria es crítico",
                alert_matchers={
                    "name": "ServiceHighMemoryUsage",
                    "severity": ["warning", "critical"]
                },
                action_name="restart_service",
                parameters={},
                severity="medium",
                requires_approval=False,
                cooldown_minutes=10,
                conditions=[
                    {"type": "time_range", "start_hour": 0, "end_hour": 23}
                ]
            ),
            
            RemediationPolicy(
                id="srv-clear-disk-space",
                name="Clear Disk Space",
                description="Limpia archivos temporales cuando el disco está lleno",
                alert_matchers={
                    "name": "DiskSpaceLow",
                    "severity": ["warning", "critical"]
                },
                action_name="clear_disk_space",
                parameters={"target_free_percent": 20},
                severity="high",
                requires_approval=False,
                cooldown_minutes=30,
                notify_on_success=True
            ),
            
            RemediationPolicy(
                id="srv-restart-on-oom",
                name="Restart Service on OOM",
                description="Reinicia el servicio después de un OutOfMemory",
                alert_matchers={
                    "name": "OutOfMemoryKilled",
                    "severity": ["critical"]
                },
                action_name="restart_service",
                parameters={},
                severity="medium",
                requires_approval=False,
                cooldown_minutes=5,
                auto_retry=True,
                max_retries=2
            ),
            
            RemediationPolicy(
                id="srv-scale-on-high-cpu",
                name="Scale Service on High CPU",
                description="Escala horizontalmente el servicio ante alta carga",
                alert_matchers={
                    "name": "HighCPUUsage",
                    "severity": ["warning", "critical"],
                    "labels": {"orchestrator": "docker"}
                },
                action_name="scale_service",
                parameters={"replicas": 3},
                severity="medium",
                requires_approval=True,
                approval_timeout_minutes=15,
                cooldown_minutes=20
            ),
            
            # Políticas de base de datos
            RemediationPolicy(
                id="db-restart-pool-on-many-connections",
                name="Restart DB Pool on Many Connections",
                description="Reinicia el pool de conexiones cuando hay demasiadas conexiones",
                alert_matchers={
                    "name": "DatabaseTooManyConnections",
                    "severity": ["warning", "critical"]
                },
                action_name="restart_db_pool",
                parameters={},
                severity="medium",
                requires_approval=False,
                cooldown_minutes=10
            ),
            
            RemediationPolicy(
                id="db-rebuild-index-on-slow-queries",
                name="Rebuild Index on Slow Queries",
                description="Reconstruye índices cuando hay consultas lentas",
                alert_matchers={
                    "name": "DatabaseSlowQueries",
                    "severity": ["warning"]
                },
                action_name="rebuild_db_index",
                parameters={},
                severity="low",
                requires_approval=True,
                approval_timeout_minutes=60,
                conditions=[
                    {"type": "time_range", "start_hour": 2, "end_hour": 5}
                ],
                cooldown_minutes=1440  # Una vez al día
            ),
            
            RemediationPolicy(
                id="db-clear-cache-on-high-memory",
                name="Clear DB Cache on High Memory",
                description="Limpia el query cache cuando la BD usa mucha memoria",
                alert_matchers={
                    "name": "DatabaseHighMemoryUsage",
                    "severity": ["warning", "critical"]
                },
                action_name="clear_db_cache",
                parameters={},
                severity="medium",
                requires_approval=False,
                cooldown_minutes=15
            ),
            
            # Políticas de seguridad
            RemediationPolicy(
                id="sec-block-ip-on-brute-force",
                name="Block IP on Brute Force",
                description="Bloquea IPs con intentos de fuerza bruta",
                alert_matchers={
                    "name": "SSHBruteForce",
                    "severity": ["warning", "critical"]
                },
                action_name="block_ip",
                parameters={"duration_minutes": 120},
                severity="high",
                requires_approval=False,
                cooldown_minutes=5,
                notify_on_success=True
            ),
            
            RemediationPolicy(
                id="sec-block-ip-on-suspicious",
                name="Block IP on Suspicious Activity",
                description="Bloquea IPs con actividad sospechosa",
                alert_matchers={
                    "name": "SuspiciousActivity",
                    "severity": ["critical"]
                },
                action_name="block_ip",
                parameters={"duration_minutes": 1440},  # 24 horas
                severity="critical",
                requires_approval=True,
                approval_timeout_minutes=10,
                notify_on_success=True,
                notify_on_failure=True
            ),
            
            RemediationPolicy(
                id="sec-rate-limit-on-ddos",
                name="Apply Rate Limit on DDoS",
                description="Aplica rate limiting ante posible ataque DDoS",
                alert_matchers={
                    "name": "HighRequestRate",
                    "severity": ["warning", "critical"]
                },
                action_name="apply_rate_limit",
                parameters={"rps": 50},
                severity="high",
                requires_approval=True,
                approval_timeout_minutes=5,
                cooldown_minutes=10
            ),
            
            # Políticas de aplicación
            RemediationPolicy(
                id="app-clear-cache-on-high-memory",
                name="Clear App Cache on High Memory",
                description="Limpia caché de aplicación cuando usa mucha memoria",
                alert_matchers={
                    "name": "ApplicationHighMemoryUsage",
                    "severity": ["warning", "critical"]
                },
                action_name="clear_app_cache",
                parameters={"cache_type": "redis", "pattern": "cache:*"},
                severity="low",
                requires_approval=False,
                cooldown_minutes=10
            ),
            
            RemediationPolicy(
                id="app-reload-config-on-change",
                name="Reload Config on Change",
                description="Recarga configuración cuando cambia el archivo",
                alert_matchers={
                    "name": "ConfigurationChanged",
                    "severity": ["info", "warning"]
                },
                action_name="reload_config",
                parameters={},
                severity="low",
                requires_approval=False,
                cooldown_minutes=1
            ),
        ]
        
        for policy in default_policies:
            self._policies[policy.id] = policy
        
        logger.info(f"Cargadas {len(default_policies)} políticas predefinidas")
    
    def evaluate(self, alert: 'AlertContext') -> List[RemediationPolicy]:
        """
        Evalúa todas las políticas contra una alerta.
        
        Returns:
            Lista de políticas aplicables ordenadas por severidad
        """
        applicable = []
        
        for policy in self._policies.values():
            if not policy.enabled:
                continue
            
            if policy.matches_alert(alert):
                applicable.append(policy)
        
        # Ordenar por severidad (critical > high > medium > low)
        severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        applicable.sort(key=lambda p: severity_order.get(p.severity, 4))
        
        return applicable
    
    def add_policy(self, policy: RemediationPolicy) -> bool:
        """Agrega una nueva política."""
        if policy.id in self._policies:
            logger.warning(f"Política {policy.id} ya existe, actualizando")
        
        self._policies[policy.id] = policy
        logger.info(f"Política agregada: {policy.id}")
        return True
    
    def update_policy(self, policy_id: str, updates: Dict[str, Any]) -> bool:
        """Actualiza una política existente."""
        if policy_id not in self._policies:
            return False
        
        policy = self._policies[policy_id]
        
        for key, value in updates.items():
            if hasattr(policy, key):
                setattr(policy, key, value)
        
        policy.updated_at = datetime.utcnow()
        logger.info(f"Política actualizada: {policy_id}")
        return True
    
    def delete_policy(self, policy_id: str) -> bool:
        """Elimina una política."""
        if policy_id not in self._policies:
            return False
        
        del self._policies[policy_id]
        logger.info(f"Política eliminada: {policy_id}")
        return True
    
    def get_policy(self, policy_id: str) -> Optional[RemediationPolicy]:
        """Obtiene una política por ID."""
        return self._policies.get(policy_id)
    
    def list_policies(
        self,
        enabled_only: bool = False,
        category: Optional[str] = None
    ) -> List[RemediationPolicy]:
        """Lista las políticas disponibles."""
        policies = []
        
        for policy in self._policies.values():
            if enabled_only and not policy.enabled:
                continue
            policies.append(policy)
        
        return policies
    
    def enable_policy(self, policy_id: str) -> bool:
        """Habilita una política."""
        if policy_id in self._policies:
            self._policies[policy_id].enabled = True
            logger.info(f"Política habilitada: {policy_id}")
            return True
        return False
    
    def disable_policy(self, policy_id: str) -> bool:
        """Deshabilita una política."""
        if policy_id in self._policies:
            self._policies[policy_id].enabled = False
            logger.info(f"Política deshabilitada: {policy_id}")
            return True
        return False
    
    def export_policies(self, file_path: str):
        """Exporta las políticas a un archivo YAML."""
        policies_data = [p.to_dict() for p in self._policies.values()]
        
        with open(file_path, 'w') as f:
            yaml.dump({"policies": policies_data}, f, default_flow_style=False)
        
        logger.info(f"Políticas exportadas a {file_path}")
    
    def import_policies(self, file_path: str):
        """Importa políticas desde un archivo YAML."""
        with open(file_path, 'r') as f:
            data = yaml.safe_load(f)
        
        for policy_data in data.get("policies", []):
            policy = RemediationPolicy.from_dict(policy_data)
            self.add_policy(policy)
        
        logger.info(f"Políticas importadas desde {file_path}")
    
    def get_stats(self) -> Dict[str, Any]:
        """Obtiene estadísticas del motor de políticas."""
        total = len(self._policies)
        enabled = sum(1 for p in self._policies.values() if p.enabled)
        by_severity = {}
        
        for policy in self._policies.values():
            by_severity[policy.severity] = by_severity.get(policy.severity, 0) + 1
        
        return {
            "total_policies": total,
            "enabled_policies": enabled,
            "disabled_policies": total - enabled,
            "by_severity": by_severity
        }


# Instancia global
policy_engine = PolicyEngine()
