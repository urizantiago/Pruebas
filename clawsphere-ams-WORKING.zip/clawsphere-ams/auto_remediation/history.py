"""
Historial de remediaciones.

Mantiene un registro de todas las acciones de remediación ejecutadas
para análisis, auditoría y mejora continua.
"""

import logging
import json
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from enum import Enum
import sqlite3
from pathlib import Path
import asyncio

logger = logging.getLogger(__name__)


class RemediationOutcome(Enum):
    """Resultado final de una remediación."""
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"
    ROLLED_BACK = "rolled_back"


@dataclass
class RemediationRecord:
    """Registro de una acción de remediación ejecutada."""
    
    remediation_id: str
    alert_id: str
    alert_name: str
    policy_id: str
    action_name: str
    target_service: Optional[str]
    target_instance: Optional[str]
    
    # Estado
    status: str
    outcome: RemediationOutcome
    success: bool
    
    # Detalles
    message: str
    error: Optional[str]
    output: Any
    
    # Tiempos
    started_at: datetime
    completed_at: Optional[datetime]
    execution_time_ms: float
    
    # Aprobación
    approved_by: Optional[str]
    approved_at: Optional[datetime]
    
    # Rollback
    rolled_back: bool
    rollback_at: Optional[datetime]
    rollback_result: Optional[Dict]
    
    # Contexto
    parameters: Dict[str, Any]
    alert_labels: Dict[str, Any]
    
    # Metadata
    created_at: datetime = field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convierte el registro a diccionario."""
        return {
            "remediation_id": self.remediation_id,
            "alert_id": self.alert_id,
            "alert_name": self.alert_name,
            "policy_id": self.policy_id,
            "action_name": self.action_name,
            "target_service": self.target_service,
            "target_instance": self.target_instance,
            "status": self.status,
            "outcome": self.outcome.value,
            "success": self.success,
            "message": self.message,
            "error": self.error,
            "output": self.output,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "execution_time_ms": self.execution_time_ms,
            "approved_by": self.approved_by,
            "approved_at": self.approved_at.isoformat() if self.approved_at else None,
            "rolled_back": self.rolled_back,
            "rollback_at": self.rollback_at.isoformat() if self.rollback_at else None,
            "rollback_result": self.rollback_result,
            "parameters": self.parameters,
            "alert_labels": self.alert_labels,
            "created_at": self.created_at.isoformat(),
            "metadata": self.metadata
        }
    
    @classmethod
    def from_result(
        cls,
        result: 'RemediationResult',
        alert: 'AlertContext',
        policy: 'RemediationPolicy'
    ) -> 'RemediationRecord':
        """Crea un registro desde un resultado de remediación."""
        return cls(
            remediation_id=result.remediation_id,
            alert_id=result.alert_id,
            alert_name=alert.alert_name,
            policy_id=policy.id,
            action_name=result.action_name,
            target_service=alert.target_service,
            target_instance=alert.target_instance,
            status=result.status.value,
            outcome=RemediationOutcome.SUCCESS if result.success else RemediationOutcome.FAILED,
            success=result.success,
            message=result.message,
            error=result.error,
            output=result.output,
            started_at=result.started_at,
            completed_at=result.completed_at,
            execution_time_ms=result.execution_time_ms,
            approved_by=result.approved_by,
            approved_at=None,
            rolled_back=result.rolled_back,
            rollback_at=None,
            rollback_result=result.rollback_result,
            parameters=policy.parameters,
            alert_labels=alert.labels,
            metadata=result.metadata
        )


class RemediationHistory:
    """Gestiona el historial de remediaciones."""
    
    def __init__(self, db_path: str = "data/remediation_history.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = asyncio.Lock()
        self._init_db()
    
    def _init_db(self):
        """Inicializa la base de datos SQLite."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS remediation_history (
                    remediation_id TEXT PRIMARY KEY,
                    alert_id TEXT,
                    alert_name TEXT,
                    policy_id TEXT,
                    action_name TEXT,
                    target_service TEXT,
                    target_instance TEXT,
                    status TEXT,
                    outcome TEXT,
                    success INTEGER,
                    message TEXT,
                    error TEXT,
                    output TEXT,
                    started_at TEXT,
                    completed_at TEXT,
                    execution_time_ms REAL,
                    approved_by TEXT,
                    approved_at TEXT,
                    rolled_back INTEGER,
                    rollback_at TEXT,
                    rollback_result TEXT,
                    parameters TEXT,
                    alert_labels TEXT,
                    created_at TEXT,
                    metadata TEXT
                )
            """)
            
            # Índices para consultas eficientes
            conn.execute("CREATE INDEX IF NOT EXISTS idx_alert_id ON remediation_history(alert_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_action_name ON remediation_history(action_name)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_target_service ON remediation_history(target_service)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_started_at ON remediation_history(started_at)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_outcome ON remediation_history(outcome)")
            
            conn.commit()
    
    async def save(self, result: 'RemediationResult', alert: 'AlertContext' = None, policy: 'RemediationPolicy' = None):
        """Guarda un resultado de remediación en el historial."""
        if alert is None or policy is None:
            # Crear registro mínimo
            record = RemediationRecord(
                remediation_id=result.remediation_id,
                alert_id=result.alert_id,
                alert_name="unknown",
                policy_id="unknown",
                action_name=result.action_name,
                target_service=None,
                target_instance=None,
                status=result.status.value,
                outcome=RemediationOutcome.SUCCESS if result.success else RemediationOutcome.FAILED,
                success=result.success,
                message=result.message,
                error=result.error,
                output=json.dumps(result.output) if result.output else None,
                started_at=result.started_at,
                completed_at=result.completed_at,
                execution_time_ms=result.execution_time_ms,
                approved_by=result.approved_by,
                approved_at=None,
                rolled_back=result.rolled_back,
                rollback_at=None,
                rollback_result=json.dumps(result.rollback_result) if result.rollback_result else None,
                parameters={},
                alert_labels={},
                metadata=result.metadata
            )
        else:
            record = RemediationRecord.from_result(result, alert, policy)
        
        async with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                    INSERT OR REPLACE INTO remediation_history VALUES (
                        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
                    )
                """, (
                    record.remediation_id,
                    record.alert_id,
                    record.alert_name,
                    record.policy_id,
                    record.action_name,
                    record.target_service,
                    record.target_instance,
                    record.status,
                    record.outcome.value,
                    int(record.success),
                    record.message,
                    record.error,
                    json.dumps(record.output) if record.output else None,
                    record.started_at.isoformat(),
                    record.completed_at.isoformat() if record.completed_at else None,
                    record.execution_time_ms,
                    record.approved_by,
                    record.approved_at.isoformat() if record.approved_at else None,
                    int(record.rolled_back),
                    record.rollback_at.isoformat() if record.rollback_at else None,
                    json.dumps(record.rollback_result) if record.rollback_result else None,
                    json.dumps(record.parameters),
                    json.dumps(record.alert_labels),
                    record.created_at.isoformat(),
                    json.dumps(record.metadata)
                ))
                conn.commit()
    
    async def get(
        self,
        remediation_id: str
    ) -> Optional[RemediationRecord]:
        """Obtiene un registro por ID."""
        async with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                row = conn.execute(
                    "SELECT * FROM remediation_history WHERE remediation_id = ?",
                    (remediation_id,)
                ).fetchone()
                
                if row:
                    return self._row_to_record(row)
                return None
    
    async def query(
        self,
        action_name: Optional[str] = None,
        target_service: Optional[str] = None,
        outcome: Optional[RemediationOutcome] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        limit: int = 100,
        offset: int = 0
    ) -> List[RemediationRecord]:
        """Consulta el historial con filtros."""
        query = "SELECT * FROM remediation_history WHERE 1=1"
        params = []
        
        if action_name:
            query += " AND action_name = ?"
            params.append(action_name)
        
        if target_service:
            query += " AND target_service = ?"
            params.append(target_service)
        
        if outcome:
            query += " AND outcome = ?"
            params.append(outcome.value)
        
        if start_date:
            query += " AND started_at >= ?"
            params.append(start_date.isoformat())
        
        if end_date:
            query += " AND started_at <= ?"
            params.append(end_date.isoformat())
        
        query += " ORDER BY started_at DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        
        async with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                rows = conn.execute(query, params).fetchall()
                return [self._row_to_record(row) for row in rows]
    
    async def was_successful_recently(
        self,
        action_name: str,
        time_window_minutes: int = 60
    ) -> bool:
        """Verifica si una acción fue exitosa recientemente."""
        since = datetime.utcnow() - timedelta(minutes=time_window_minutes)
        
        async with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                row = conn.execute("""
                    SELECT COUNT(*) FROM remediation_history
                    WHERE action_name = ? AND outcome = ? AND started_at >= ?
                """, (action_name, RemediationOutcome.SUCCESS.value, since.isoformat())).fetchone()
                
                return row[0] > 0
    
    async def get_success_rate(
        self,
        action_name: Optional[str] = None,
        days: int = 7
    ) -> Dict[str, Any]:
        """Calcula la tasa de éxito de remediaciones."""
        since = datetime.utcnow() - timedelta(days=days)
        
        async with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                query = """
                    SELECT 
                        COUNT(*) as total,
                        SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) as successful,
                        SUM(CASE WHEN success = 0 THEN 1 ELSE 0 END) as failed
                    FROM remediation_history
                    WHERE started_at >= ?
                """
                params = [since.isoformat()]
                
                if action_name:
                    query += " AND action_name = ?"
                    params.append(action_name)
                
                row = conn.execute(query, params).fetchone()
                
                total = row[0] or 0
                successful = row[1] or 0
                failed = row[2] or 0
                
                return {
                    "total": total,
                    "successful": successful,
                    "failed": failed,
                    "success_rate": (successful / total * 100) if total > 0 else 0,
                    "period_days": days
                }
    
    async def get_top_issues(
        self,
        days: int = 7,
        limit: int = 10
    ) -> List[Dict[str, Any]]:
        """Obtiene los problemas más frecuentes."""
        since = datetime.utcnow() - timedelta(days=days)
        
        async with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                rows = conn.execute("""
                    SELECT 
                        alert_name,
                        target_service,
                        COUNT(*) as count,
                        SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) as auto_resolved
                    FROM remediation_history
                    WHERE started_at >= ?
                    GROUP BY alert_name, target_service
                    ORDER BY count DESC
                    LIMIT ?
                """, (since.isoformat(), limit)).fetchall()
                
                return [
                    {
                        "alert_name": row[0],
                        "target_service": row[1],
                        "count": row[2],
                        "auto_resolved": row[3],
                        "resolution_rate": (row[3] / row[2] * 100) if row[2] > 0 else 0
                    }
                    for row in rows
                ]
    
    async def get_stats(self, days: int = 30) -> Dict[str, Any]:
        """Obtiene estadísticas generales."""
        since = datetime.utcnow() - timedelta(days=days)
        
        async with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                # Totales
                row = conn.execute("""
                    SELECT 
                        COUNT(*) as total,
                        SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) as successful,
                        AVG(execution_time_ms) as avg_execution_time
                    FROM remediation_history
                    WHERE started_at >= ?
                """, (since.isoformat(),)).fetchone()
                
                total = row[0] or 0
                successful = row[1] or 0
                avg_time = row[2] or 0
                
                # Por acción
                action_stats = conn.execute("""
                    SELECT 
                        action_name,
                        COUNT(*) as count,
                        SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) as successful
                    FROM remediation_history
                    WHERE started_at >= ?
                    GROUP BY action_name
                    ORDER BY count DESC
                """, (since.isoformat(),)).fetchall()
                
                # Por servicio
                service_stats = conn.execute("""
                    SELECT 
                        target_service,
                        COUNT(*) as count
                    FROM remediation_history
                    WHERE started_at >= ? AND target_service IS NOT NULL
                    GROUP BY target_service
                    ORDER BY count DESC
                    LIMIT 10
                """, (since.isoformat(),)).fetchall()
                
                return {
                    "period_days": days,
                    "total_remediations": total,
                    "successful_remediations": successful,
                    "failed_remediations": total - successful,
                    "success_rate": (successful / total * 100) if total > 0 else 0,
                    "average_execution_time_ms": avg_time,
                    "by_action": [
                        {
                            "action": row[0],
                            "count": row[1],
                            "success_rate": (row[2] / row[1] * 100) if row[1] > 0 else 0
                        }
                        for row in action_stats
                    ],
                    "by_service": [
                        {"service": row[0], "count": row[1]}
                        for row in service_stats
                    ]
                }
    
    async def cleanup_old_records(self, days_to_keep: int = 90):
        """Elimina registros antiguos."""
        cutoff = datetime.utcnow() - timedelta(days=days_to_keep)
        
        async with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                result = conn.execute(
                    "DELETE FROM remediation_history WHERE started_at < ?",
                    (cutoff.isoformat(),)
                )
                conn.commit()
                logger.info(f"Eliminados {result.rowcount} registros antiguos de remediación")
    
    def _row_to_record(self, row) -> RemediationRecord:
        """Convierte una fila de BD a RemediationRecord."""
        return RemediationRecord(
            remediation_id=row[0],
            alert_id=row[1],
            alert_name=row[2],
            policy_id=row[3],
            action_name=row[4],
            target_service=row[5],
            target_instance=row[6],
            status=row[7],
            outcome=RemediationOutcome(row[8]),
            success=bool(row[9]),
            message=row[10],
            error=row[11],
            output=json.loads(row[12]) if row[12] else None,
            started_at=datetime.fromisoformat(row[13]),
            completed_at=datetime.fromisoformat(row[14]) if row[14] else None,
            execution_time_ms=row[15],
            approved_by=row[16],
            approved_at=datetime.fromisoformat(row[17]) if row[17] else None,
            rolled_back=bool(row[18]),
            rollback_at=datetime.fromisoformat(row[19]) if row[19] else None,
            rollback_result=json.loads(row[20]) if row[20] else None,
            parameters=json.loads(row[21]) if row[21] else {},
            alert_labels=json.loads(row[22]) if row[22] else {},
            created_at=datetime.fromisoformat(row[23]),
            metadata=json.loads(row[24]) if row[24] else {}
        )


# Instancia global
remediation_history = RemediationHistory()
