"""
Sistema de Auto-Remediación para ClawSphere AMS.

Este módulo proporciona capacidades de auto-curación para detectar
problemas y ejecutar acciones correctivas automáticamente.
"""

from .remediator import AutoRemediator, RemediationResult
from .actions import RemediationAction, ActionRegistry
from .policies import RemediationPolicy, PolicyEngine
from .history import RemediationHistory, RemediationRecord

__all__ = [
    'AutoRemediator',
    'RemediationResult',
    'RemediationAction',
    'ActionRegistry',
    'RemediationPolicy',
    'PolicyEngine',
    'RemediationHistory',
    'RemediationRecord',
]
