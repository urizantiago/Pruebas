"""
Acciones de remediación predefinidas.

Define acciones correctivas que pueden ejecutarse automáticamente
ante diferentes tipos de problemas.
"""

import asyncio
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Callable
from datetime import datetime

from adapters.servers.factory import server_adapter_factory
from adapters.databases.factory import database_adapter_factory
from core.events.bus import event_bus, Event, EventType

logger = logging.getLogger(__name__)


@dataclass
class ActionResult:
    """Resultado de una acción de remediación."""
    success: bool
    output: Any = None
    message: str = ""
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class RemediationAction(ABC):
    """Clase base para acciones de remediación."""
    
    name: str = ""
    description: str = ""
    category: str = "general"
    supports_dry_run: bool = True
    rollback_supported: bool = False
    
    @abstractmethod
    async def execute(
        self,
        alert: 'AlertContext',
        parameters: Dict[str, Any],
        dry_run: bool = False
    ) -> ActionResult:
        """
        Ejecuta la acción de remediación.
        
        Args:
            alert: Contexto de la alerta que disparó la acción
            parameters: Parámetros específicos de la acción
            dry_run: Si es True, solo simula la ejecución
            
        Returns:
            ActionResult con el resultado de la ejecución
        """
        pass
    
    async def rollback(
        self,
        alert: 'AlertContext',
        execution_result: ActionResult,
        parameters: Dict[str, Any]
    ) -> ActionResult:
        """
        Revierte la acción ejecutada.
        
        Args:
            alert: Contexto de la alerta original
            execution_result: Resultado de la ejecución original
            parameters: Parámetros de la acción
            
        Returns:
            ActionResult del rollback
        """
        return ActionResult(
            success=False,
            message="Rollback no implementado para esta acción"
        )


# ==================== ACCIONES DE SERVIDOR ====================

class RestartServiceAction(RemediationAction):
    """Reinicia un servicio en un servidor."""
    
    name = "restart_service"
    description = "Reinicia un servicio/systemd en el servidor objetivo"
    category = "server"
    rollback_supported = False
    
    async def execute(
        self,
        alert: 'AlertContext',
        parameters: Dict[str, Any],
        dry_run: bool = False
    ) -> ActionResult:
        service_name = parameters.get("service_name") or alert.labels.get("service")
        instance = alert.target_instance
        
        if not service_name:
            return ActionResult(
                success=False,
                error="Nombre de servicio no especificado"
            )
        
        if dry_run:
            return ActionResult(
                success=True,
                message=f"[DRY RUN] Reiniciaría servicio {service_name} en {instance}"
            )
        
        try:
            adapter = await server_adapter_factory.get_adapter(instance)
            
            # Verificar estado del servicio
            status_result = await adapter.execute_command(
                f"systemctl is-active {service_name}"
            )
            
            if status_result.success and "active" in status_result.output:
                # Reiniciar servicio
                restart_result = await adapter.execute_command(
                    f"sudo systemctl restart {service_name}"
                )
                
                if restart_result.success:
                    # Verificar que el servicio está activo
                    await asyncio.sleep(2)
                    verify_result = await adapter.execute_command(
                        f"systemctl is-active {service_name}"
                    )
                    
                    if verify_result.success and "active" in verify_result.output:
                        return ActionResult(
                            success=True,
                            message=f"Servicio {service_name} reiniciado exitosamente",
                            output={"previous_status": status_result.output}
                        )
                    else:
                        return ActionResult(
                            success=False,
                            error=f"Servicio no está activo después del reinicio",
                            output={"verify_output": verify_result.output}
                        )
                else:
                    return ActionResult(
                        success=False,
                        error=f"Error reiniciando servicio: {restart_result.error}"
                    )
            else:
                # Servicio no estaba activo, intentar iniciarlo
                start_result = await adapter.execute_command(
                    f"sudo systemctl start {service_name}"
                )
                
                return ActionResult(
                    success=start_result.success,
                    message=f"Servicio {service_name} iniciado" if start_result.success else f"Error iniciando: {start_result.error}",
                    output={"previous_status": "inactive"}
                )
                
        except Exception as e:
            logger.exception(f"Error reiniciando servicio {service_name}")
            return ActionResult(success=False, error=str(e))


class ClearDiskSpaceAction(RemediationAction):
    """Libera espacio en disco."""
    
    name = "clear_disk_space"
    description = "Limpia archivos temporales y logs para liberar espacio"
    category = "server"
    rollback_supported = False
    
    async def execute(
        self,
        alert: 'AlertContext',
        parameters: Dict[str, Any],
        dry_run: bool = False
    ) -> ActionResult:
        instance = alert.target_instance
        mount_point = parameters.get("mount_point", "/")
        target_free_percent = parameters.get("target_free_percent", 20)
        
        if dry_run:
            return ActionResult(
                success=True,
                message=f"[DRY RUN] Limpiaría espacio en {mount_point} de {instance}"
            )
        
        try:
            adapter = await server_adapter_factory.get_adapter(instance)
            
            # Obtener uso actual
            df_result = await adapter.execute_command(
                f"df -h {mount_point} | tail -1"
            )
            
            if not df_result.success:
                return ActionResult(success=False, error="No se pudo obtener uso de disco")
            
            initial_usage = df_result.output
            space_freed_mb = 0
            actions_taken = []
            
            # 1. Limpiar logs antiguos
            log_cleanup = await adapter.execute_command(
                "find /var/log -name '*.log.*' -mtime +7 -delete 2>/dev/null; echo 'Logs cleaned'"
            )
            if log_cleanup.success:
                actions_taken.append("logs_old")
            
            # 2. Limpiar journalctl
            journal_cleanup = await adapter.execute_command(
                "sudo journalctl --vacuum-time=3d --quiet"
            )
            if journal_cleanup.success:
                actions_taken.append("journalctl")
            
            # 3. Limpiar /tmp
            tmp_cleanup = await adapter.execute_command(
                "find /tmp -type f -atime +3 -delete 2>/dev/null; echo 'TMP cleaned'"
            )
            if tmp_cleanup.success:
                actions_taken.append("tmp_files")
            
            # 4. Limpiar caché de paquetes
            cache_cleanup = await adapter.execute_command(
                "sudo apt-get autoclean -qq 2>/dev/null || sudo yum clean all -q 2>/dev/null; echo 'Cache cleaned'"
            )
            if cache_cleanup.success:
                actions_taken.append("package_cache")
            
            # 5. Limpiar Docker (si existe)
            docker_cleanup = await adapter.execute_command(
                "docker system prune -f --volumes 2>/dev/null || echo 'No Docker'"
            )
            if docker_cleanup.success and "No Docker" not in docker_cleanup.output:
                actions_taken.append("docker")
            
            # Verificar espacio liberado
            df_final = await adapter.execute_command(
                f"df -h {mount_point} | tail -1"
            )
            
            return ActionResult(
                success=True,
                message=f"Limpieza completada. Acciones: {', '.join(actions_taken)}",
                output={
                    "initial_usage": initial_usage,
                    "final_usage": df_final.output if df_final.success else None,
                    "actions_taken": actions_taken,
                    "space_freed_mb": space_freed_mb
                }
            )
            
        except Exception as e:
            logger.exception("Error limpiando espacio en disco")
            return ActionResult(success=False, error=str(e))


class RestartServerAction(RemediationAction):
    """Reinicia un servidor completo."""
    
    name = "restart_server"
    description = "Reinicia el servidor completo (uso con precaución)"
    category = "server"
    rollback_supported = False
    
    async def execute(
        self,
        alert: 'AlertContext',
        parameters: Dict[str, Any],
        dry_run: bool = False
    ) -> ActionResult:
        instance = alert.target_instance
        delay_seconds = parameters.get("delay_seconds", 60)
        
        if dry_run:
            return ActionResult(
                success=True,
                message=f"[DRY RUN] Reiniciaría servidor {instance} en {delay_seconds}s"
            )
        
        try:
            adapter = await server_adapter_factory.get_adapter(instance)
            
            # Programar reinicio con delay
            result = await adapter.execute_command(
                f"sudo shutdown -r +{delay_seconds // 60} 'Reinicio programado por ClawSphere AMS'"
            )
            
            return ActionResult(
                success=result.success,
                message=f"Reinicio programado en {delay_seconds} segundos",
                output={"scheduled_at": datetime.utcnow().isoformat()}
            )
            
        except Exception as e:
            logger.exception(f"Error programando reinicio de {instance}")
            return ActionResult(success=False, error=str(e))


class ScaleServiceAction(RemediationAction):
    """Escala un servicio (para entornos Docker/Kubernetes)."""
    
    name = "scale_service"
    description = "Escala horizontalmente un servicio"
    category = "server"
    rollback_supported = True
    
    async def execute(
        self,
        alert: 'AlertContext',
        parameters: Dict[str, Any],
        dry_run: bool = False
    ) -> ActionResult:
        service_name = parameters.get("service_name")
        replicas = parameters.get("replicas", 2)
        orchestrator = parameters.get("orchestrator", "docker")  # docker, k8s
        instance = alert.target_instance
        
        if dry_run:
            return ActionResult(
                success=True,
                message=f"[DRY RUN] Escalaría {service_name} a {replicas} réplicas"
            )
        
        try:
            adapter = await server_adapter_factory.get_adapter(instance)
            
            if orchestrator == "docker":
                # Docker Swarm
                result = await adapter.execute_command(
                    f"docker service scale {service_name}={replicas}"
                )
            elif orchestrator == "k8s":
                # Kubernetes
                namespace = parameters.get("namespace", "default")
                result = await adapter.execute_command(
                    f"kubectl scale deployment {service_name} --replicas={replicas} -n {namespace}"
                )
            else:
                return ActionResult(success=False, error=f"Orquestador no soportado: {orchestrator}")
            
            return ActionResult(
                success=result.success,
                message=f"Servicio escalado a {replicas} réplicas",
                output={"previous_replicas": parameters.get("previous_replicas", 1)},
                metadata={"can_rollback": True, "previous_replicas": parameters.get("previous_replicas", 1)}
            )
            
        except Exception as e:
            logger.exception(f"Error escalando servicio {service_name}")
            return ActionResult(success=False, error=str(e))
    
    async def rollback(
        self,
        alert: 'AlertContext',
        execution_result: ActionResult,
        parameters: Dict[str, Any]
    ) -> ActionResult:
        """Revierte el escalado."""
        previous_replicas = execution_result.metadata.get("previous_replicas", 1)
        parameters["replicas"] = previous_replicas
        
        return await self.execute(alert, parameters, dry_run=False)


# ==================== ACCIONES DE BASE DE DATOS ====================

class RestartDBConnectionPoolAction(RemediationAction):
    """Reinicia el pool de conexiones de una base de datos."""
    
    name = "restart_db_pool"
    description = "Reinicia el pool de conexiones de la aplicación"
    category = "database"
    rollback_supported = False
    
    async def execute(
        self,
        alert: 'AlertContext',
        parameters: Dict[str, Any],
        dry_run: bool = False
    ) -> ActionResult:
        db_name = parameters.get("database") or alert.labels.get("database")
        instance = alert.target_instance
        
        if dry_run:
            return ActionResult(
                success=True,
                message=f"[DRY RUN] Reiniciaría pool de conexiones de {db_name}"
            )
        
        try:
            adapter = await database_adapter_factory.get_adapter(instance, db_name)
            
            # Ejecutar comando para reiniciar conexiones
            # Esto varía según el tipo de base de datos
            if adapter.db_type == "postgresql":
                result = await adapter.execute_query(
                    "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE state = 'idle' AND state_change < NOW() - INTERVAL '5 minutes'"
                )
            elif adapter.db_type == "mysql":
                result = await adapter.execute_query(
                    "KILL QUERY WHERE TIME > 300 AND COMMAND = 'Sleep'"
                )
            else:
                return ActionResult(
                    success=False,
                    error=f"Tipo de BD no soportado para esta acción: {adapter.db_type}"
                )
            
            return ActionResult(
                success=result.success,
                message=f"Pool de conexiones reiniciado para {db_name}",
                output={"terminated_connections": result.data if result.success else None}
            )
            
        except Exception as e:
            logger.exception(f"Error reiniciando pool de {db_name}")
            return ActionResult(success=False, error=str(e))


class RebuildDBIndexAction(RemediationAction):
    """Reconstruye índices de base de datos."""
    
    name = "rebuild_db_index"
    description = "Reconstruye índices fragmentados"
    category = "database"
    rollback_supported = False
    
    async def execute(
        self,
        alert: 'AlertContext',
        parameters: Dict[str, Any],
        dry_run: bool = False
    ) -> ActionResult:
        db_name = parameters.get("database") or alert.labels.get("database")
        table_name = parameters.get("table")
        instance = alert.target_instance
        
        if dry_run:
            return ActionResult(
                success=True,
                message=f"[DRY RUN] Reconstruiría índices de {table_name} en {db_name}"
            )
        
        try:
            adapter = await database_adapter_factory.get_adapter(instance, db_name)
            
            rebuilt_indexes = []
            
            if adapter.db_type == "postgresql":
                if table_name:
                    result = await adapter.execute_query(
                        f"REINDEX INDEX CONCURRENTLY {table_name}_idx"
                    )
                    rebuilt_indexes.append(f"{table_name}_idx")
                else:
                    # Reconstruir todos los índices fragmentados
                    result = await adapter.execute_query(
                        """
                        SELECT schemaname, tablename, indexname 
                        FROM pg_indexes 
                        WHERE schemaname NOT IN ('pg_catalog', 'information_schema')
                        """
                    )
                    # Lógica para reconstruir índices fragmentados
                    
            elif adapter.db_type == "sqlserver":
                if table_name:
                    result = await adapter.execute_query(
                        f"ALTER INDEX ALL ON {table_name} REBUILD"
                    )
                    rebuilt_indexes.append(f"ALL on {table_name}")
            
            return ActionResult(
                success=True,
                message=f"Índices reconstruidos: {', '.join(rebuilt_indexes)}",
                output={"rebuilt_indexes": rebuilt_indexes}
            )
            
        except Exception as e:
            logger.exception(f"Error reconstruyendo índices de {db_name}")
            return ActionResult(success=False, error=str(e))


class ClearDBCacheAction(RemediationAction):
    """Limpia la caché de consultas de la base de datos."""
    
    name = "clear_db_cache"
    description = "Limpia el query cache de la base de datos"
    category = "database"
    rollback_supported = False
    
    async def execute(
        self,
        alert: 'AlertContext',
        parameters: Dict[str, Any],
        dry_run: bool = False
    ) -> ActionResult:
        db_name = parameters.get("database") or alert.labels.get("database")
        instance = alert.target_instance
        
        if dry_run:
            return ActionResult(
                success=True,
                message=f"[DRY RUN] Limpiaría caché de {db_name}"
            )
        
        try:
            adapter = await database_adapter_factory.get_adapter(instance, db_name)
            
            if adapter.db_type == "mysql":
                result = await adapter.execute_query("RESET QUERY CACHE")
            elif adapter.db_type == "postgresql":
                # PostgreSQL no tiene query cache, pero podemos limpiar buffers
                result = await adapter.execute_query("DISCARD PLANS")
            elif adapter.db_type == "sqlserver":
                result = await adapter.execute_query("DBCC FREEPROCCACHE")
            else:
                return ActionResult(
                    success=False,
                    error=f"Tipo de BD no soportado: {adapter.db_type}"
                )
            
            return ActionResult(
                success=result.success,
                message=f"Caché limpiada exitosamente en {db_name}"
            )
            
        except Exception as e:
            logger.exception(f"Error limpiando caché de {db_name}")
            return ActionResult(success=False, error=str(e))


# ==================== ACCIONES DE RED Y SEGURIDAD ====================

class BlockIPAction(RemediationAction):
    """Bloquea una dirección IP sospechosa."""
    
    name = "block_ip"
    description = "Bloquea una IP usando iptables/firewall"
    category = "security"
    rollback_supported = True
    
    async def execute(
        self,
        alert: 'AlertContext',
        parameters: Dict[str, Any],
        dry_run: bool = False
    ) -> ActionResult:
        ip_address = parameters.get("ip_address") or alert.labels.get("ip")
        instance = alert.target_instance
        duration_minutes = parameters.get("duration_minutes", 60)
        
        if not ip_address:
            return ActionResult(success=False, error="Dirección IP no especificada")
        
        if dry_run:
            return ActionResult(
                success=True,
                message=f"[DRY RUN] Bloquearía IP {ip_address} por {duration_minutes}min"
            )
        
        try:
            adapter = await server_adapter_factory.get_adapter(instance)
            
            # Agregar regla de iptables
            result = await adapter.execute_command(
                f"sudo iptables -A INPUT -s {ip_address} -j DROP"
            )
            
            if result.success:
                # Programar desbloqueo automático
                asyncio.create_task(
                    self._schedule_unblock(adapter, ip_address, duration_minutes)
                )
                
                return ActionResult(
                    success=True,
                    message=f"IP {ip_address} bloqueada por {duration_minutes} minutos",
                    metadata={"blocked_ip": ip_address, "duration": duration_minutes}
                )
            else:
                return ActionResult(
                    success=False,
                    error=f"Error bloqueando IP: {result.error}"
                )
            
        except Exception as e:
            logger.exception(f"Error bloqueando IP {ip_address}")
            return ActionResult(success=False, error=str(e))
    
    async def _schedule_unblock(self, adapter, ip_address: str, duration_minutes: int):
        """Programa el desbloqueo de una IP."""
        await asyncio.sleep(duration_minutes * 60)
        try:
            await adapter.execute_command(
                f"sudo iptables -D INPUT -s {ip_address} -j DROP"
            )
            logger.info(f"IP {ip_address} desbloqueada automáticamente")
        except Exception as e:
            logger.error(f"Error desbloqueando IP {ip_address}: {e}")
    
    async def rollback(
        self,
        alert: 'AlertContext',
        execution_result: ActionResult,
        parameters: Dict[str, Any]
    ) -> ActionResult:
        """Desbloquea la IP inmediatamente."""
        ip_address = execution_result.metadata.get("blocked_ip")
        instance = alert.target_instance
        
        if not ip_address:
            return ActionResult(success=False, error="IP no encontrada en metadata")
        
        try:
            adapter = await server_adapter_factory.get_adapter(instance)
            result = await adapter.execute_command(
                f"sudo iptables -D INPUT -s {ip_address} -j DROP"
            )
            
            return ActionResult(
                success=result.success,
                message=f"IP {ip_address} desbloqueada"
            )
        except Exception as e:
            return ActionResult(success=False, error=str(e))


class RateLimitAction(RemediationAction):
    """Aplica rate limiting a un servicio."""
    
    name = "apply_rate_limit"
    description = "Aplica límites de tasa a un endpoint o servicio"
    category = "security"
    rollback_supported = True
    
    async def execute(
        self,
        alert: 'AlertContext',
        parameters: Dict[str, Any],
        dry_run: bool = False
    ) -> ActionResult:
        service = parameters.get("service") or alert.labels.get("service")
        requests_per_second = parameters.get("rps", 100)
        instance = alert.target_instance
        
        if dry_run:
            return ActionResult(
                success=True,
                message=f"[DRY RUN] Aplicaría rate limit de {requests_per_second} rps a {service}"
            )
        
        try:
            adapter = await server_adapter_factory.get_adapter(instance)
            
            # Configurar rate limit en nginx (si existe)
            nginx_config = f"""
limit_req_zone $binary_remote_addr zone={service}_limit:10m rate={requests_per_second}r/s;
location /{service}/ {{
    limit_req zone={service}_limit burst=20 nodelay;
}}
"""
            result = await adapter.execute_command(
                f"echo '{nginx_config}' | sudo tee /etc/nginx/conf.d/{service}_rate_limit.conf"
            )
            
            if result.success:
                reload = await adapter.execute_command("sudo nginx -s reload")
                
                return ActionResult(
                    success=reload.success,
                    message=f"Rate limit aplicado a {service}: {requests_per_second} rps",
                    metadata={"service": service, "previous_rps": parameters.get("previous_rps", 0)}
                )
            
            return ActionResult(success=False, error="Error configurando rate limit")
            
        except Exception as e:
            logger.exception(f"Error aplicando rate limit a {service}")
            return ActionResult(success=False, error=str(e))


# ==================== ACCIONES DE APLICACIÓN ====================

class ClearApplicationCacheAction(RemediationAction):
    """Limpia la caché de la aplicación."""
    
    name = "clear_app_cache"
    description = "Limpia caché de aplicación (Redis, memcached, etc.)"
    category = "application"
    rollback_supported = False
    
    async def execute(
        self,
        alert: 'AlertContext',
        parameters: Dict[str, Any],
        dry_run: bool = False
    ) -> ActionResult:
        cache_type = parameters.get("cache_type", "redis")
        instance = alert.target_instance
        pattern = parameters.get("pattern", "*")
        
        if dry_run:
            return ActionResult(
                success=True,
                message=f"[DRY RUN] Limpiaría caché {cache_type} con patrón {pattern}"
            )
        
        try:
            if cache_type == "redis":
                adapter = await database_adapter_factory.get_adapter(instance, "redis")
                result = await adapter.execute_query(f"EVAL \"return redis.call('del', unpack(redis.call('keys', '{pattern}')))\" 0")
                
                return ActionResult(
                    success=result.success,
                    message=f"Caché Redis limpiada con patrón {pattern}",
                    output={"deleted_keys": result.data}
                )
            
            elif cache_type == "memcached":
                adapter = await server_adapter_factory.get_adapter(instance)
                result = await adapter.execute_command("echo 'flush_all' | nc localhost 11211")
                
                return ActionResult(
                    success=result.success,
                    message="Memcached flush_all ejecutado"
                )
            
            return ActionResult(success=False, error=f"Tipo de caché no soportado: {cache_type}")
            
        except Exception as e:
            logger.exception(f"Error limpiando caché {cache_type}")
            return ActionResult(success=False, error=str(e))


class ReloadConfigurationAction(RemediationAction):
    """Recarga la configuración de una aplicación."""
    
    name = "reload_config"
    description = "Recarga configuración sin reiniciar el servicio"
    category = "application"
    rollback_supported = False
    
    async def execute(
        self,
        alert: 'AlertContext',
        parameters: Dict[str, Any],
        dry_run: bool = False
    ) -> ActionResult:
        service_name = parameters.get("service_name") or alert.labels.get("service")
        config_path = parameters.get("config_path")
        instance = alert.target_instance
        
        if dry_run:
            return ActionResult(
                success=True,
                message=f"[DRY RUN] Recargaría configuración de {service_name}"
            )
        
        try:
            adapter = await server_adapter_factory.get_adapter(instance)
            
            # Enviar señal SIGHUP para recarga
            result = await adapter.execute_command(
                f"sudo killall -HUP {service_name} 2>/dev/null || sudo systemctl kill -s HUP {service_name}"
            )
            
            return ActionResult(
                success=result.success,
                message=f"Configuración recargada para {service_name}"
            )
            
        except Exception as e:
            logger.exception(f"Error recargando configuración de {service_name}")
            return ActionResult(success=False, error=str(e))


# ==================== REGISTRO DE ACCIONES ====================

class ActionRegistry:
    """Registro de acciones de remediación disponibles."""
    
    def __init__(self):
        self._actions: Dict[str, RemediationAction] = {}
        self._register_default_actions()
    
    def _register_default_actions(self):
        """Registra las acciones predefinidas."""
        actions = [
            RestartServiceAction(),
            ClearDiskSpaceAction(),
            RestartServerAction(),
            ScaleServiceAction(),
            RestartDBConnectionPoolAction(),
            RebuildDBIndexAction(),
            ClearDBCacheAction(),
            BlockIPAction(),
            RateLimitAction(),
            ClearApplicationCacheAction(),
            ReloadConfigurationAction(),
        ]
        
        for action in actions:
            self.register(action)
    
    def register(self, action: RemediationAction):
        """Registra una nueva acción."""
        self._actions[action.name] = action
        logger.debug(f"Acción registrada: {action.name}")
    
    def get_action(self, name: str) -> Optional[RemediationAction]:
        """Obtiene una acción por nombre."""
        return self._actions.get(name)
    
    def list_actions(self, category: Optional[str] = None) -> List[Dict[str, Any]]:
        """Lista las acciones disponibles."""
        actions = []
        for name, action in self._actions.items():
            if category and action.category != category:
                continue
            actions.append({
                "name": action.name,
                "description": action.description,
                "category": action.category,
                "supports_dry_run": action.supports_dry_run,
                "rollback_supported": action.rollback_supported
            })
        return actions
    
    def unregister(self, name: str):
        """Elimina una acción del registro."""
        if name in self._actions:
            del self._actions[name]


# Instancia global
action_registry = ActionRegistry()
