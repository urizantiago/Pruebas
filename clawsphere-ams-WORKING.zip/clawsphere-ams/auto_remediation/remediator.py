"""
Motor principal de auto-remediación.

Escucha alertas y eventos del sistema, evalúa políticas de remediación
y ejecuta acciones correctivas automáticamente.
"""

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Dict, Any, List, Optional, Callable, Set
from uuid import uuid4
import json

from core.events.bus import event_bus, Event, EventType
from core.state.manager import state_manager

logger = logging.getLogger(__name__)


class RemediationStatus(Enum):
    """Estados de una acción de remediación."""
    PENDING = "pending"
    ANALYZING = "analyzing"
    WAITING_APPROVAL = "waiting_approval"
    EXECUTING = "executing"
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"
    ROLLED_BACK = "rolled_back"


class RemediationSeverity(Enum):
    """Severidad de la remediación requerida."""
    LOW = "low"         # Auto-remediación inmediata
    MEDIUM = "medium"   # Auto-remediación con cooldown
    HIGH = "high"       # Requiere aprobación
    CRITICAL = "critical"  # Requiere aprobación + notificación


@dataclass
class RemediationResult:
    """Resultado de una acción de remediación."""
    remediation_id: str
    alert_id: str
    status: RemediationStatus
    action_name: str
    success: bool
    message: str = ""
    output: Any = None
    error: Optional[str] = None
    execution_time_ms: float = 0.0
    started_at: datetime = field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    approved_by: Optional[str] = None
    rolled_back: bool = False
    rollback_result: Optional[Dict] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convierte el resultado a diccionario."""
        return {
            "remediation_id": self.remediation_id,
            "alert_id": self.alert_id,
            "status": self.status.value,
            "action_name": self.action_name,
            "success": self.success,
            "message": self.message,
            "output": self.output,
            "error": self.error,
            "execution_time_ms": self.execution_time_ms,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "approved_by": self.approved_by,
            "rolled_back": self.rolled_back,
            "rollback_result": self.rollback_result,
            "metadata": self.metadata
        }


@dataclass
class AlertContext:
    """Contexto de una alerta que dispara remediación."""
    alert_id: str
    alert_name: str
    severity: str
    source: str  # prometheus, custom, etc.
    labels: Dict[str, Any]
    annotations: Dict[str, Any]
    value: Optional[float] = None
    started_at: datetime = field(default_factory=datetime.utcnow)
    
    @property
    def target_service(self) -> Optional[str]:
        """Obtiene el servicio objetivo de la alerta."""
        return self.labels.get("service") or self.labels.get("job")
    
    @property
    def target_instance(self) -> Optional[str]:
        """Obtiene la instancia objetivo."""
        return self.labels.get("instance")
    
    @property
    def is_resolved(self) -> bool:
        """Verifica si la alerta está resuelta."""
        return self.labels.get("status") == "resolved"


class AutoRemediator:
    """
    Motor de auto-remediación que escucha alertas y ejecuta acciones correctivas.
    """
    
    def __init__(self):
        self._policies: List['RemediationPolicy'] = []
        self._action_registry: 'ActionRegistry' = None
        self._history: 'RemediationHistory' = None
        self._policy_engine: 'PolicyEngine' = None
        self._running_remediations: Dict[str, RemediationResult] = {}
        self._cooldowns: Dict[str, datetime] = {}
        self._approval_callbacks: Dict[str, Callable] = {}
        self._enabled: bool = True
        self._dry_run: bool = False
        self._max_concurrent: int = 10
        self._semaphore = asyncio.Semaphore(self._max_concurrent)
        self._initialized = False
        
    async def initialize(
        self,
        action_registry: 'ActionRegistry',
        history: 'RemediationHistory',
        policy_engine: 'PolicyEngine',
        enabled: bool = True,
        dry_run: bool = False,
        max_concurrent: int = 10
    ):
        """Inicializa el remediador."""
        self._action_registry = action_registry
        self._history = history
        self._policy_engine = policy_engine
        self._enabled = enabled
        self._dry_run = dry_run
        self._max_concurrent = max_concurrent
        self._semaphore = asyncio.Semaphore(max_concurrent)
        
        # Suscribirse a eventos de alertas
        event_bus.subscribe(EventType.ALERT_RECEIVED, self._handle_alert)
        event_bus.subscribe(EventType.ALERT_RESOLVED, self._handle_alert_resolved)
        
        self._initialized = True
        logger.info(f"AutoRemediator inicializado (enabled={enabled}, dry_run={dry_run})")
    
    async def _handle_alert(self, event: Event):
        """Maneja un evento de alerta recibida."""
        if not self._enabled:
            logger.debug("Auto-remediación deshabilitada, ignorando alerta")
            return
        
        alert_data = event.data
        alert = AlertContext(
            alert_id=alert_data.get("id", str(uuid4())),
            alert_name=alert_data.get("name", "unknown"),
            severity=alert_data.get("severity", "warning"),
            source=alert_data.get("source", "unknown"),
            labels=alert_data.get("labels", {}),
            annotations=alert_data.get("annotations", {}),
            value=alert_data.get("value")
        )
        
        logger.info(f"Procesando alerta para remediación: {alert.alert_name}")
        
        # Verificar cooldown
        if self._is_in_cooldown(alert):
            logger.info(f"Alerta {alert.alert_name} en cooldown, ignorando")
            return
        
        # Evaluar políticas
        policies = self._policy_engine.evaluate(alert)
        
        if not policies:
            logger.debug(f"No hay políticas aplicables para {alert.alert_name}")
            return
        
        # Ejecutar remediación para cada política aplicable
        for policy in policies:
            await self._execute_remediation(alert, policy)
    
    async def _handle_alert_resolved(self, event: Event):
        """Maneja una alerta resuelta."""
        alert_id = event.data.get("id")
        
        # Cancelar remediaciones pendientes para esta alerta
        for remediation_id, result in list(self._running_remediations.items()):
            if result.alert_id == alert_id and result.status == RemediationStatus.PENDING:
                result.status = RemediationStatus.CANCELLED
                logger.info(f"Remediación {remediation_id} cancelada por alerta resuelta")
    
    def _is_in_cooldown(self, alert: AlertContext) -> bool:
        """Verifica si la alerta está en período de cooldown."""
        cooldown_key = f"{alert.target_service}:{alert.alert_name}"
        last_execution = self._cooldowns.get(cooldown_key)
        
        if last_execution:
            cooldown_period = timedelta(minutes=5)  # Configurable
            if datetime.utcnow() - last_execution < cooldown_period:
                return True
        
        return False
    
    async def _execute_remediation(
        self,
        alert: AlertContext,
        policy: 'RemediationPolicy'
    ) -> RemediationResult:
        """Ejecuta una remediación basada en una política."""
        remediation_id = str(uuid4())
        
        result = RemediationResult(
            remediation_id=remediation_id,
            alert_id=alert.alert_id,
            status=RemediationStatus.PENDING,
            action_name=policy.action_name,
            success=False
        )
        
        self._running_remediations[remediation_id] = result
        
        try:
            async with self._semaphore:
                result.status = RemediationStatus.ANALYZING
                
                # Verificar si requiere aprobación
                if policy.requires_approval:
                    result.status = RemediationStatus.WAITING_APPROVAL
                    await self._request_approval(alert, policy, result)
                    return result
                
                # Verificar condiciones de ejecución
                if not await self._check_conditions(policy, alert):
                    result.status = RemediationStatus.CANCELLED
                    result.message = "Condiciones de ejecución no cumplidas"
                    return result
                
                # Ejecutar acción
                result.status = RemediationStatus.EXECUTING
                start_time = datetime.utcnow()
                
                if self._dry_run:
                    logger.info(f"[DRY RUN] Ejecutaría: {policy.action_name}")
                    result.success = True
                    result.message = "Simulación exitosa (dry run)"
                else:
                    action = self._action_registry.get_action(policy.action_name)
                    if not action:
                        raise ValueError(f"Acción no encontrada: {policy.action_name}")
                    
                    action_result = await action.execute(
                        alert=alert,
                        parameters=policy.parameters,
                        dry_run=self._dry_run
                    )
                    
                    result.success = action_result.success
                    result.output = action_result.output
                    result.message = action_result.message
                    result.error = action_result.error
                
                result.execution_time_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
                result.status = RemediationStatus.SUCCESS if result.success else RemediationStatus.FAILED
                result.completed_at = datetime.utcnow()
                
                # Actualizar cooldown
                cooldown_key = f"{alert.target_service}:{alert.alert_name}"
                self._cooldowns[cooldown_key] = datetime.utcnow()
                
                # Guardar en historial
                await self._history.save(result)
                
                # Notificar resultado
                await self._notify_result(result, alert)
                
        except Exception as e:
            logger.exception(f"Error en remediación {remediation_id}")
            result.status = RemediationStatus.FAILED
            result.error = str(e)
            result.message = f"Error ejecutando remediación: {e}"
            result.completed_at = datetime.utcnow()
            await self._history.save(result)
        
        finally:
            if remediation_id in self._running_remediations:
                del self._running_remediations[remediation_id]
        
        return result
    
    async def _check_conditions(self, policy: 'RemediationPolicy', alert: AlertContext) -> bool:
        """Verifica las condiciones de ejecución de una política."""
        for condition in policy.conditions:
            if not await self._evaluate_condition(condition, alert):
                return False
        return True
    
    async def _evaluate_condition(self, condition: Dict, alert: AlertContext) -> bool:
        """Evalúa una condición individual."""
        condition_type = condition.get("type")
        
        if condition_type == "time_range":
            now = datetime.utcnow()
            start = condition.get("start_hour", 0)
            end = condition.get("end_hour", 23)
            return start <= now.hour <= end
        
        elif condition_type == "day_of_week":
            allowed_days = condition.get("days", [0, 1, 2, 3, 4, 5, 6])
            return datetime.utcnow().weekday() in allowed_days
        
        elif condition_type == "metric_threshold":
            metric = condition.get("metric")
            threshold = condition.get("threshold")
            operator = condition.get("operator", ">")
            
            # Obtener métrica actual
            current_value = await self._get_metric_value(metric, alert)
            if current_value is None:
                return False
            
            if operator == ">":
                return current_value > threshold
            elif operator == "<":
                return current_value < threshold
            elif operator == ">=":
                return current_value >= threshold
            elif operator == "<=":
                return current_value <= threshold
            elif operator == "==":
                return current_value == threshold
        
        elif condition_type == "previous_remediation_success":
            # Verificar si una remediación anterior fue exitosa
            action_name = condition.get("action_name")
            time_window = condition.get("time_window_minutes", 60)
            return await self._history.was_successful_recently(
                action_name, time_window
            )
        
        return True
    
    async def _get_metric_value(self, metric: str, alert: AlertContext) -> Optional[float]:
        """Obtiene el valor actual de una métrica."""
        # Integrar con MetricsCollector de Prometheus
        try:
            from integrations.prometheus.metrics import metrics_collector
            return await metrics_collector.get_current_value(
                metric,
                labels={"instance": alert.target_instance}
            )
        except Exception:
            return None
    
    async def _request_approval(
        self,
        alert: AlertContext,
        policy: 'RemediationPolicy',
        result: RemediationResult
    ):
        """Solicita aprobación para una remediación."""
        approval_request = {
            "remediation_id": result.remediation_id,
            "alert": {
                "id": alert.alert_id,
                "name": alert.alert_name,
                "severity": alert.severity,
                "service": alert.target_service
            },
            "action": policy.action_name,
            "description": policy.description,
            "requested_at": datetime.utcnow().isoformat(),
            "timeout_minutes": policy.approval_timeout_minutes
        }
        
        # Publicar evento de solicitud de aprobación
        await event_bus.publish(Event(
            type=EventType.APPROVAL_REQUIRED,
            data=approval_request,
            source="auto_remediation"
        ))
        
        # Configurar timeout
        asyncio.create_task(
            self._approval_timeout(result.remediation_id, policy.approval_timeout_minutes)
        )
    
    async def _approval_timeout(self, remediation_id: str, timeout_minutes: int):
        """Maneja el timeout de una aprobación."""
        await asyncio.sleep(timeout_minutes * 60)
        
        if remediation_id in self._running_remediations:
            result = self._running_remediations[remediation_id]
            if result.status == RemediationStatus.WAITING_APPROVAL:
                result.status = RemediationStatus.CANCELLED
                result.message = f"Aprobación no recibida en {timeout_minutes} minutos"
                await self._history.save(result)
                del self._running_remediations[remediation_id]
    
    async def approve_remediation(self, remediation_id: str, approved_by: str) -> bool:
        """Aprueba una remediación pendiente."""
        if remediation_id not in self._running_remediations:
            return False
        
        result = self._running_remediations[remediation_id]
        if result.status != RemediationStatus.WAITING_APPROVAL:
            return False
        
        result.approved_by = approved_by
        
        # Re-ejecutar la remediación
        # Encontrar la política y alerta originales
        # Esto requeriría almacenar más contexto
        
        return True
    
    async def _notify_result(self, result: RemediationResult, alert: AlertContext):
        """Notifica el resultado de una remediación."""
        event_type = (
            EventType.REMEDIATION_SUCCESS if result.success 
            else EventType.REMEDIATION_FAILED
        )
        
        await event_bus.publish(Event(
            type=event_type,
            data=result.to_dict(),
            source="auto_remediation"
        ))
    
    def get_running_remediations(self) -> List[RemediationResult]:
        """Obtiene las remediaciones en ejecución."""
        return list(self._running_remediations.values())
    
    def get_stats(self) -> Dict[str, Any]:
        """Obtiene estadísticas del remediador."""
        return {
            "enabled": self._enabled,
            "dry_run": self._dry_run,
            "running_remediations": len(self._running_remediations),
            "policies_loaded": len(self._policies),
            "cooldowns_active": len(self._cooldowns)
        }
    
    async def enable(self):
        """Habilita la auto-remediación."""
        self._enabled = True
        logger.info("Auto-remediación habilitada")
    
    async def disable(self):
        """Deshabilita la auto-remediación."""
        self._enabled = False
        logger.info("Auto-remediación deshabilitada")


# Instancia global
auto_remediator = AutoRemediator()
