"""
ClawSphere AMS - Core Module
============================
Núcleo del agente de IA empresarial para soporte L2/L3.
Proporciona orquestación, gestión de estado y eventos.
"""

from .orchestrator.agent import ClawSphereAgent
from .config.settings import Settings, get_settings
from .state.manager import StateManager
from .events.bus import EventBus

__version__ = "1.0.0"
__all__ = ["ClawSphereAgent", "Settings", "get_settings", "StateManager", "EventBus"]
