"""
Ejecutor de Skills.
Maneja la ejecución segura de skills con auditoría.
"""

import time
import logging
from typing import Dict, Any

from ..config.settings import Settings
from ..plugins.base import BaseSkill, SkillContext, SkillResult, RiskLevel
from ..security.audit.logger import AuditLogger

logger = logging.getLogger(__name__)


class SkillExecutor:
    """
    Ejecutor de skills con manejo de seguridad y auditoría.
    """
    
    def __init__(self, settings: Settings):
        self.settings = settings
        self.audit_logger = AuditLogger()
    
    async def initialize(self):
        """Inicializa el executor."""
        await self.audit_logger.initialize()
    
    async def execute(
        self,
        skill: BaseSkill,
        context: SkillContext,
        parameters: Dict[str, Any]
    ) -> SkillResult:
        """
        Ejecuta un skill con auditoría completa.
        
        Args:
            skill: Skill a ejecutar
            context: Contexto de ejecución
            parameters: Parámetros del skill
            
        Returns:
            SkillResult con el resultado
        """
        start_time = time.time()
        
        # Preparar entrada de auditoría
        audit_entry = {
            "request_id": context.request_id,
            "skill_name": skill.name,
            "skill_category": skill.category.value,
            "risk_level": skill.risk_level.value,
            "user_id": context.user_id,
            "user_roles": context.user_roles,
            "session_id": context.session_id,
            "application_context": context.application_context,
            "parameters": self._sanitize_parameters(parameters),
            "timestamp": context.timestamp.isoformat(),
            "status": "started"
        }
        
        try:
            # Log de inicio
            await self.audit_logger.log_action(audit_entry)
            
            # Verificar modo de solo lectura para operaciones de riesgo
            if (skill.risk_level in [RiskLevel.HIGH, RiskLevel.CRITICAL] and 
                self.settings.DATABASE.READ_ONLY_MODE):
                # Requiere aprobación explícita
                if not context.is_admin():
                    raise PermissionError(
                        f"Operación '{skill.name}' requiere permisos de administrador"
                    )
            
            # Ejecutar el skill
            result = await skill.execute(context, **parameters)
            
            # Calcular tiempo de ejecución
            execution_time = (time.time() - start_time) * 1000
            result.execution_time_ms = execution_time
            
            # Actualizar auditoría
            audit_entry.update({
                "status": "completed" if result.success else "failed",
                "execution_time_ms": execution_time,
                "result_summary": self._summarize_result(result),
                "error": result.error
            })
            
            await self.audit_logger.log_action(audit_entry)
            
            # Alertar si es operación sensible
            if skill.risk_level == RiskLevel.CRITICAL:
                await self.audit_logger.alert_sensitive_operation(audit_entry)
            
            return result
            
        except Exception as e:
            execution_time = (time.time() - start_time) * 1000
            
            audit_entry.update({
                "status": "error",
                "execution_time_ms": execution_time,
                "error": str(e),
                "error_type": type(e).__name__
            })
            
            await self.audit_logger.log_action(audit_entry)
            
            logger.exception(f"Error ejecutando skill {skill.name}")
            
            return SkillResult.error_result(
                error=str(e),
                message=f"Error ejecutando '{skill.name}'",
                execution_time_ms=execution_time,
                audit_log=audit_entry
            )
    
    def _sanitize_parameters(self, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Sanitiza parámetros para auditoría (remueve datos sensibles)."""
        sensitive_keys = ['password', 'token', 'secret', 'key', 'credential', 'auth']
        sanitized = {}
        
        for key, value in parameters.items():
            if any(s in key.lower() for s in sensitive_keys):
                sanitized[key] = "***REDACTED***"
            elif isinstance(value, dict):
                sanitized[key] = self._sanitize_parameters(value)
            elif isinstance(value, str) and len(value) > 100:
                sanitized[key] = value[:100] + "..."
            else:
                sanitized[key] = value
        
        return sanitized
    
    def _summarize_result(self, result: SkillResult) -> Dict[str, Any]:
        """Crea un resumen del resultado para auditoría."""
        summary = {
            "success": result.success,
            "has_data": result.data is not None
        }
        
        if result.data:
            if isinstance(result.data, list):
                summary["data_type"] = "list"
                summary["item_count"] = len(result.data)
            elif isinstance(result.data, dict):
                summary["data_type"] = "dict"
                summary["keys"] = list(result.data.keys())[:10]  # Limitar keys
            else:
                summary["data_type"] = type(result.data).__name__
        
        return summary
