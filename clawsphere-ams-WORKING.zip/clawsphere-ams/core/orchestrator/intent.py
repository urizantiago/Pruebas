"""
Clasificador de intenciones.
Determina qué skill debe ejecutarse basado en el mensaje del usuario.
"""

import re
import logging
from dataclasses import dataclass
from typing import Dict, Any, List, Optional

from ..config.settings import Settings
from ..plugins.base import SkillContext
from ..plugins.registry import SkillRegistry

logger = logging.getLogger(__name__)


@dataclass
class IntentResult:
    """Resultado de la clasificación de intención."""
    intent: str
    confidence: float
    parameters: Dict[str, Any]
    category: Optional[str] = None
    application: Optional[str] = None


class IntentClassifier:
    """
    Clasifica intenciones usando IA y reglas.
    """
    
    # Patrones de intención predefinidos
    INTENT_PATTERNS = {
        # Servidores
        "server_status": [
            r"estado (del|de los) servidor",
            r"status (of )?server",
            r"c[oó]mo est[aá]n? los servidores",
            r"verificar servidor",
            r"check server"
        ],
        "server_logs": [
            r"logs? (del|de) servidor",
            r"ver logs",
            r"revisar logs",
            r"buscar (en )?logs",
            r"tail log",
            r"grep log"
        ],
        "server_resources": [
            r"recursos (del|de) servidor",
            r"cpu (usage|uso)",
            r"memoria (ram)?",
            r"disco (lleno|espacio)",
            r"df -h",
            r"top",
            r"htop"
        ],
        "server_processes": [
            r"procesos (del|de) servidor",
            r"procesos zombie",
            r"ps aux",
            r"matar proceso",
            r"kill process"
        ],
        
        # Bases de Datos
        "db_query": [
            r"consultar (base de datos|bd|db)",
            r"query (a )?la (bd|db|base)",
            r"ejecutar (query|consulta|sql)",
            r"select .* from",
            r"traer (datos|informaci[oó]n|registros)"
        ],
        "db_performance": [
            r"performance (de )?la (bd|db|base)",
            r"rendimiento (de )?la base",
            r"consultas lentas",
            r"slow query",
            r"cuello de botella"
        ],
        "db_locks": [
            r"bloqueos (en )?la (bd|db)",
            r"deadlock",
            r"locks? (en )?base",
            r"procesos bloqueados"
        ],
        "db_connections": [
            r"conexiones (a )?la (bd|db)",
            r"connection pool",
            r"sp_who",
            r"sp_who2"
        ],
        
        # APIs
        "api_test": [
            r"probar api",
            r"test (endpoint|api)",
            r"curl .*",
            r"postman",
            r"invocar endpoint"
        ],
        "api_status": [
            r"estado (de )?la api",
            r"api status",
            r"health check",
            r"ping api"
        ],
        "api_logs": [
            r"logs? (de )?la api",
            r"api logs",
            r"request/response"
        ],
        
        # Seguridad
        "ssl_check": [
            r"certificado ssl",
            r"certificado tls",
            r"vigencia certificado",
            r"openssl",
            r"check ssl"
        ],
        "jwt_decode": [
            r"decodificar jwt",
            r"jwt token",
            r"verificar token",
            r"claims jwt"
        ],
        "connectivity_test": [
            r"test (de )?conectividad",
            r"telnet",
            r"ping",
            r"traceroute",
            r"test-netconnection",
            r"connection refused"
        ],
        
        # Colas y Caché
        "queue_check": [
            r"cola (de )?mensajes",
            r"rabbitmq",
            r"kafka",
            r"sqs",
            r"dead letter queue",
            r"mensajes atascados"
        ],
        "cache_flush": [
            r"limpiar cach[eé]",
            r"flush cache",
            r"redis flush",
            r"invalidar cach[eé]"
        ],
        
        # General
        "help": [
            r"^ayuda$",
            r"^help$",
            r"qu[eé] puedes hacer",
            r"comandos disponibles",
            r"skills disponibles"
        ],
        "general_query": [
            r"^hola$",
            r"^hi$",
            r"^hello$",
            r"qu[eé] eres",
            r"qui[eé]n eres",
            r"informaci[oó]n general"
        ]
    }
    
    # Mapeo de intenciones a aplicaciones
    APPLICATION_KEYWORDS = {
        "ventas": ["ventas", "sales", "facturacion", "facturación", "invoice"],
        "telefonia": ["telefonia", "telcel", "recarga", "telefonía", "phone"],
        "rrhh": ["rrhh", "rh", "recursos humanos", "nómina", "nomina", "personal"],
        "finanzas": ["finanzas", "contabilidad", "tesorería", "tesoreria", "pagos"],
        "inventario": ["inventario", "stock", "almacen", "almacén", "warehouse"],
        "crm": ["crm", "clientes", "customer"],
        "erp": ["erp", "sap", "oracle", "dynamics"]
    }
    
    def __init__(self, settings: Settings):
        self.settings = settings
        self._ai_adapter = None
    
    async def initialize(self):
        """Inicializa el clasificador."""
        from ...adapters.ai.factory import AIAdapterFactory
        self._ai_adapter = AIAdapterFactory.get_default_adapter()
    
    async def classify(self, message: str, context: SkillContext) -> IntentResult:
        """
        Clasifica la intención del mensaje.
        
        Returns:
            IntentResult con la intención detectada
        """
        message_lower = message.lower()
        
        # 1. Detectar aplicación
        application = self._detect_application(message_lower)
        
        # 2. Intentar coincidencia con patrones
        for intent, patterns in self.INTENT_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, message_lower, re.IGNORECASE):
                    parameters = self._extract_parameters(message, intent)
                    return IntentResult(
                        intent=intent,
                        confidence=0.9,
                        parameters=parameters,
                        application=application
                    )
        
        # 3. Usar IA para clasificación avanzada
        ai_intent = await self._classify_with_ai(message, context)
        if ai_intent:
            return ai_intent
        
        # 4. Fallback a búsqueda en skills disponibles
        skill_match = self._match_with_available_skills(message_lower)
        if skill_match:
            return IntentResult(
                intent=skill_match,
                confidence=0.6,
                parameters={},
                application=application
            )
        
        # 5. Último fallback
        return IntentResult(
            intent="general_query",
            confidence=0.5,
            parameters={"original_message": message},
            application=application
        )
    
    def _detect_application(self, message: str) -> Optional[str]:
        """Detecta la aplicación referenciada en el mensaje."""
        for app, keywords in self.APPLICATION_KEYWORDS.items():
            for keyword in keywords:
                if keyword in message:
                    return app
        return None
    
    def _extract_parameters(self, message: str, intent: str) -> Dict[str, Any]:
        """Extrae parámetros del mensaje según la intención."""
        params = {}
        
        # Extraer nombre de servidor
        server_patterns = [
            r"servidor[\s]+([a-zA-Z0-9_-]+)",
            r"server[\s]+([a-zA-Z0-9_-]+)",
            r"en[\s]+([a-zA-Z0-9_-]+)(?:\s+servidor)?"
        ]
        for pattern in server_patterns:
            match = re.search(pattern, message, re.IGNORECASE)
            if match:
                params["server_name"] = match.group(1)
                break
        
        # Extraer nombre de base de datos
        db_patterns = [
            r"base[\s]+([a-zA-Z0-9_-]+)",
            r"bd[\s]+([a-zA-Z0-9_-]+)",
            r"database[\s]+([a-zA-Z0-9_-]+)"
        ]
        for pattern in db_patterns:
            match = re.search(pattern, message, re.IGNORECASE)
            if match:
                params["database_name"] = match.group(1)
                break
        
        # Extraer tabla
        table_match = re.search(r"tabla[\s]+([a-zA-Z0-9_-]+)", message, re.IGNORECASE)
        if table_match:
            params["table_name"] = table_match.group(1)
        
        # Extraer límite de resultados
        limit_match = re.search(r"(top|limite|l[ií]mite|primeros?)[\s]*(\d+)", message, re.IGNORECASE)
        if limit_match:
            params["limit"] = int(limit_match.group(2))
        
        # Para queries SQL, intentar extraer la consulta
        if intent == "db_query":
            # Buscar SELECT ...
            sql_match = re.search(r"(SELECT[\s\S]+?)(?:\.|$)", message, re.IGNORECASE)
            if sql_match:
                params["sql"] = sql_match.group(1).strip()
        
        return params
    
    async def _classify_with_ai(self, message: str, context: SkillContext) -> Optional[IntentResult]:
        """Usa IA para clasificar la intención."""
        if not self._ai_adapter:
            return None
        
        # Obtener lista de skills disponibles
        registry = SkillRegistry()
        skills_info = registry.list_all()
        
        skills_text = "\n".join([
            f"- {s['name']}: {s['description']}" 
            for s in skills_info[:20]  # Limitar para no sobrecargar
        ])
        
        prompt = f"""Analiza el siguiente mensaje y determina la intención del usuario.
        
Mensaje: "{message}"

Skills disponibles:
{skills_text}

Responde ÚNICAMENTE con un JSON en este formato:
{{
    "intent": "nombre_del_skill",
    "confidence": 0.95,
    "parameters": {{}},
    "reasoning": "breve explicación"
}}

Si no coincide con ningún skill, usa "general_query".
"""
        
        try:
            response = await self._ai_adapter.generate_response(
                prompt=prompt,
                temperature=0.1,
                max_tokens=200
            )
            
            # Extraer JSON
            import json
            json_match = re.search(r'\{[^}]+\}', response, re.DOTALL)
            if json_match:
                result = json.loads(json_match.group())
                return IntentResult(
                    intent=result.get("intent", "general_query"),
                    confidence=result.get("confidence", 0.5),
                    parameters=result.get("parameters", {})
                )
        except Exception as e:
            logger.warning(f"Error clasificando con IA: {e}")
        
        return None
    
    def _match_with_available_skills(self, message: str) -> Optional[str]:
        """Busca coincidencia con skills disponibles."""
        registry = SkillRegistry()
        
        # Búsqueda exacta
        for name in registry.get_all().keys():
            if name.lower() in message:
                return name
        
        # Búsqueda parcial
        for name in registry.get_all().keys():
            words = name.lower().split("_")
            if any(word in message for word in words):
                return name
        
        return None
