"""
Agente principal de ClawSphere AMS.
Orquesta la interacción entre usuarios, IA y skills.
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime

from ..config.settings import Settings, get_settings
from ..plugins.base import SkillContext, SkillResult, RiskLevel
from ..plugins.registry import SkillRegistry
from .intent import IntentClassifier
from .executor import SkillExecutor
from ..state.manager import StateManager
from ..events.bus import EventBus

logger = logging.getLogger(__name__)


class ClawSphereAgent:
    """
    Agente principal de ClawSphere AMS.
    Coordina la clasificación de intenciones, ejecución de skills
    y generación de respuestas.
    """
    
    def __init__(self, settings: Optional[Settings] = None):
        self.settings = settings or get_settings()
        self.state_manager = StateManager()
        self.event_bus = EventBus()
        
        # Componentes de procesamiento
        self.intent_classifier = IntentClassifier(self.settings)
        self.skill_executor = SkillExecutor(self.settings)
        
        # Estado
        self._initialized = False
        self._conversations: Dict[str, List[Dict]] = {}
    
    async def initialize(self) -> None:
        """Inicializa el agente y sus componentes."""
        if self._initialized:
            return
        
        logger.info("Inicializando ClawSphere AMS...")
        
        # Inicializar clasificador de intenciones
        await self.intent_classifier.initialize()
        
        # Inicializar executor de skills
        await self.skill_executor.initialize()
        
        self._initialized = True
        logger.info("ClawSphere AMS inicializado correctamente")
    
    async def process_message(
        self,
        message: str,
        user_id: str,
        user_roles: List[str],
        session_id: str,
        application_context: Optional[str] = None,
        channel: str = "api"
    ) -> Dict[str, Any]:
        """
        Procesa un mensaje del usuario.
        
        Args:
            message: Mensaje del usuario
            user_id: ID del usuario
            user_roles: Roles del usuario
            session_id: ID de sesión
            application_context: Contexto de aplicación (ej: "Ventas")
            channel: Canal de comunicación
            
        Returns:
            Respuesta completa con resultado y metadata
        """
        if not self._initialized:
            await self.initialize()
        
        request_id = f"req_{datetime.utcnow().strftime('%Y%m%d%H%M%S%f')}"
        
        # Crear contexto
        context = SkillContext(
            user_id=user_id,
            user_roles=user_roles,
            session_id=session_id,
            request_id=request_id,
            application_context=application_context,
            metadata={"channel": channel, "message": message}
        )
        
        logger.info(f"[{request_id}] Procesando mensaje de {user_id}: {message[:100]}...")
        
        try:
            # 1. Clasificar intención
            intent_result = await self.intent_classifier.classify(message, context)
            logger.info(f"[{request_id}] Intención detectada: {intent_result.intent} "
                       f"(confianza: {intent_result.confidence})")
            
            # 2. Si es una consulta de información general, responder directamente
            if intent_result.intent == "general_query":
                response = await self._handle_general_query(message, context)
                return self._build_response(
                    success=True,
                    message=response,
                    request_id=request_id,
                    intent=intent_result.intent
                )
            
            # 3. Buscar skill apropiado
            skill = self._find_skill_for_intent(intent_result, application_context)
            
            if not skill:
                return self._build_response(
                    success=False,
                    message=f"No encontré un skill apropiado para: {intent_result.intent}. "
                           f"Por favor, sé más específico o contacta al administrador.",
                    request_id=request_id,
                    intent=intent_result.intent
                )
            
            # 4. Validar permisos
            is_valid, error_msg = await skill.validate(context, **intent_result.parameters)
            if not is_valid:
                return self._build_response(
                    success=False,
                    message=f"Permiso denegado: {error_msg}",
                    request_id=request_id,
                    intent=intent_result.intent
                )
            
            # 5. Verificar si requiere aprobación
            if skill.requires_approval and not context.is_admin():
                approval_result = await self._request_approval(skill, context, intent_result.parameters)
                if not approval_result:
                    return self._build_response(
                        success=False,
                        message=f"La operación '{skill.name}' requiere aprobación del administrador. "
                               f"Se ha enviado una solicitud de aprobación.",
                        request_id=request_id,
                        intent=intent_result.intent,
                        pending_approval=True
                    )
            
            # 6. Ejecutar skill
            execution_result = await self.skill_executor.execute(
                skill=skill,
                context=context,
                parameters=intent_result.parameters
            )
            
            # 7. Formatear respuesta
            response_message = self._format_result(execution_result, skill)
            
            return self._build_response(
                success=execution_result.success,
                message=response_message,
                data=execution_result.data,
                request_id=request_id,
                intent=intent_result.intent,
                skill_name=skill.name,
                execution_time_ms=execution_result.execution_time_ms,
                audit_log=execution_result.audit_log
            )
            
        except Exception as e:
            logger.exception(f"[{request_id}] Error procesando mensaje")
            return self._build_response(
                success=False,
                message=f"Error interno: {str(e)}",
                request_id=request_id,
                error=str(e)
            )
    
    def _find_skill_for_intent(self, intent_result, application_context: Optional[str]) -> Optional[Any]:
        """Encuentra el mejor skill para la intención detectada."""
        registry = SkillRegistry()
        
        # Buscar por nombre exacto
        skill = registry.get(intent_result.intent)
        if skill:
            return skill
        
        # Buscar en aplicación específica
        if application_context:
            app_skills = registry.get_by_application(application_context)
            for s in app_skills:
                if intent_result.intent in s.name.lower() or s.name.lower() in intent_result.intent:
                    return s
        
        # Buscar por categoría
        from ..plugins.base import SkillCategory
        if intent_result.category:
            cat_skills = registry.get_by_category(SkillCategory(intent_result.category))
            for s in cat_skills:
                if intent_result.intent in s.name.lower() or s.name.lower() in intent_result.intent:
                    return s
        
        # Búsqueda difusa
        search_results = registry.search(intent_result.intent)
        if search_results:
            return search_results[0]
        
        return None
    
    async def _handle_general_query(self, message: str, context: SkillContext) -> str:
        """Maneja consultas generales usando IA."""
        # Usar el adaptador de IA configurado
        from ...adapters.ai.factory import AIAdapterFactory
        
        ai_adapter = AIAdapterFactory.get_default_adapter()
        
        system_prompt = """Eres ClawSphere AMS, un agente de IA empresarial especializado 
        en soporte de aplicaciones nivel L2 y L3. Ayudas a ingenieros y administradores 
        a diagnosticar y resolver problemas en servidores, bases de datos, APIs y sistemas.
        
        Responde de manera profesional, concisa y técnica."""
        
        response = await ai_adapter.generate_response(
            prompt=message,
            system_prompt=system_prompt,
            temperature=0.3
        )
        
        return response
    
    async def _request_approval(
        self, 
        skill, 
        context: SkillContext, 
        parameters: Dict
    ) -> bool:
        """Solicita aprobación para ejecutar un skill crítico."""
        # Crear solicitud de aprobación
        approval_request = {
            "request_id": context.request_id,
            "skill_name": skill.name,
            "skill_description": skill.description,
            "risk_level": skill.risk_level.value,
            "requested_by": context.user_id,
            "requested_at": datetime.utcnow().isoformat(),
            "parameters": parameters,
            "status": "pending"
        }
        
        # Guardar en estado
        await self.state_manager.set(
            f"approval:{context.request_id}",
            approval_request,
            ttl=3600  # 1 hora de expiración
        )
        
        # Notificar a administradores
        await self.event_bus.publish("approval_required", {
            "request": approval_request,
            "notify_roles": skill.approval_roles
        })
        
        return False  # Retorna False indicando que está pendiente
    
    def _format_result(self, result: SkillResult, skill) -> str:
        """Formatea el resultado del skill para el usuario."""
        if not result.success:
            return f"❌ Error ejecutando '{skill.name}': {result.error or result.message}"
        
        # Formatear según el tipo de datos
        if result.data is None:
            return f"✅ {result.message or 'Operación completada exitosamente'}"
        
        if isinstance(result.data, str):
            return result.data
        
        if isinstance(result.data, (list, dict)):
            import json
            return f"```json\n{json.dumps(result.data, indent=2, ensure_ascii=False)}\n```"
        
        return str(result.data)
    
    def _build_response(
        self,
        success: bool,
        message: str,
        request_id: str,
        data: Any = None,
        intent: str = "",
        skill_name: str = "",
        execution_time_ms: float = 0,
        audit_log: Dict = None,
        pending_approval: bool = False,
        error: str = ""
    ) -> Dict[str, Any]:
        """Construye la respuesta estandarizada."""
        return {
            "success": success,
            "message": message,
            "data": data,
            "metadata": {
                "request_id": request_id,
                "intent": intent,
                "skill_name": skill_name,
                "execution_time_ms": execution_time_ms,
                "timestamp": datetime.utcnow().isoformat(),
                "pending_approval": pending_approval
            },
            "audit": audit_log or {},
            "error": error
        }
    
    async def get_available_skills(
        self, 
        user_roles: List[str],
        application: Optional[str] = None
    ) -> List[Dict]:
        """Obtiene los skills disponibles para el usuario."""
        registry = SkillRegistry()
        all_skills = registry.get_all()
        
        available = []
        for skill in all_skills.values():
            # Verificar roles
            has_role = any(role in user_roles for role in skill.required_roles)
            is_admin = "admin" in user_roles
            
            if not (has_role or is_admin):
                continue
            
            # Filtrar por aplicación
            if application and skill.supports_applications:
                if application not in skill.supports_applications:
                    continue
            
            available.append(skill.get_info())
        
        return available
    
    async def approve_request(self, request_id: str, admin_id: str, approved: bool) -> Dict:
        """Aprueba o rechaza una solicitud pendiente."""
        approval_key = f"approval:{request_id}"
        request = await self.state_manager.get(approval_key)
        
        if not request:
            return {"success": False, "error": "Solicitud no encontrada o expirada"}
        
        if request["status"] != "pending":
            return {"success": False, "error": f"Solicitud ya {request['status']}"}
        
        request["status"] = "approved" if approved else "rejected"
        request["processed_by"] = admin_id
        request["processed_at"] = datetime.utcnow().isoformat()
        
        await self.state_manager.set(approval_key, request)
        
        if approved:
            # Ejecutar el skill
            await self.event_bus.publish("approval_granted", {
                "request": request
            })
        
        return {
            "success": True,
            "message": f"Solicitud {request_id} {'aprobada' if approved else 'rechazada'}",
            "request": request
        }
