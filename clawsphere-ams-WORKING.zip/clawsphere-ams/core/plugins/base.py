"""
Clases base para el sistema de plugins y skills.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Callable
from datetime import datetime
from enum import Enum
import uuid


class SkillCategory(Enum):
    """Categorías de skills disponibles."""
    SERVER_MANAGEMENT = "server_management"
    DATABASE_MANAGEMENT = "database_management"
    API_MANAGEMENT = "api_management"
    SECURITY_MANAGEMENT = "security_management"
    MONITORING = "monitoring"
    AUTOMATION = "automation"
    INTEGRATION = "integration"
    CUSTOM = "custom"


class RiskLevel(Enum):
    """Niveles de riesgo para operaciones."""
    LOW = "low"           # Solo lectura, información pública
    MEDIUM = "medium"     # Lectura de datos sensibles
    HIGH = "high"         # Operaciones que modifican estado
    CRITICAL = "critical" # Operaciones destructivas o de alto impacto


@dataclass
class SkillContext:
    """Contexto de ejecución para un skill."""
    user_id: str
    user_roles: List[str]
    session_id: str
    request_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = field(default_factory=datetime.utcnow)
    application_context: Optional[str] = None  # Ej: "Ventas", "Telefonia"
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def has_role(self, role: str) -> bool:
        """Verifica si el usuario tiene un rol específico."""
        return role in self.user_roles
    
    def is_admin(self) -> bool:
        """Verifica si es administrador."""
        return "admin" in self.user_roles


@dataclass
class SkillResult:
    """Resultado de la ejecución de un skill."""
    success: bool
    data: Any = None
    message: str = ""
    error: Optional[str] = None
    execution_time_ms: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    audit_log: Dict[str, Any] = field(default_factory=dict)
    
    @classmethod
    def success_result(cls, data: Any, message: str = "", **kwargs) -> "SkillResult":
        """Crea un resultado exitoso."""
        return cls(success=True, data=data, message=message, **kwargs)
    
    @classmethod
    def error_result(cls, error: str, message: str = "", **kwargs) -> "SkillResult":
        """Crea un resultado de error."""
        return cls(success=False, error=error, message=message, **kwargs)


class BaseSkill(ABC):
    """
    Clase base para todos los skills.
    Cada skill es una capacidad específica que el agente puede ejecutar.
    """
    
    # Identificación
    name: str = ""
    description: str = ""
    category: SkillCategory = SkillCategory.CUSTOM
    version: str = "1.0.0"
    
    # Seguridad
    required_roles: List[str] = ["ingeniero"]
    risk_level: RiskLevel = RiskLevel.LOW
    requires_approval: bool = False
    approval_roles: List[str] = ["admin"]
    
    # Capacidades
    supports_applications: List[str] = []  # Aplicaciones soportadas
    
    def __init__(self):
        self._initialized = False
        self._config: Dict[str, Any] = {}
    
    @abstractmethod
    async def execute(self, context: SkillContext, **params) -> SkillResult:
        """
        Ejecuta el skill con los parámetros proporcionados.
        
        Args:
            context: Contexto de ejecución con información del usuario
            **params: Parámetros específicos del skill
            
        Returns:
            SkillResult con el resultado de la operación
        """
        pass
    
    async def validate(self, context: SkillContext, **params) -> tuple[bool, str]:
        """
        Valida si el skill puede ejecutarse.
        
        Returns:
            Tuple de (es_válido, mensaje_error)
        """
        # Validar roles
        has_required_role = any(
            role in context.user_roles for role in self.required_roles
        ) or context.is_admin()
        
        if not has_required_role:
            return False, f"Se requiere uno de los roles: {self.required_roles}"
        
        return True, ""
    
    async def initialize(self, config: Dict[str, Any]) -> None:
        """Inicializa el skill con configuración."""
        self._config = config
        self._initialized = True
    
    def get_info(self) -> Dict[str, Any]:
        """Retorna información del skill."""
        return {
            "name": self.name,
            "description": self.description,
            "category": self.category.value,
            "version": self.version,
            "required_roles": self.required_roles,
            "risk_level": self.risk_level.value,
            "requires_approval": self.requires_approval,
            "supports_applications": self.supports_applications
        }


class BasePlugin(ABC):
    """
    Clase base para plugins que agrupan múltiples skills.
    """
    
    name: str = ""
    description: str = ""
    version: str = "1.0.0"
    author: str = ""
    
    def __init__(self):
        self._skills: Dict[str, BaseSkill] = {}
        self._initialized = False
    
    @abstractmethod
    def register_skills(self) -> List[BaseSkill]:
        """Registra y retorna los skills del plugin."""
        pass
    
    async def initialize(self, config: Dict[str, Any]) -> None:
        """Inicializa el plugin."""
        skills = self.register_skills()
        for skill in skills:
            skill_config = config.get(skill.name, {})
            await skill.initialize(skill_config)
            self._skills[skill.name] = skill
        self._initialized = True
    
    def get_skills(self) -> Dict[str, BaseSkill]:
        """Retorna los skills registrados."""
        return self._skills
    
    def get_skill(self, name: str) -> Optional[BaseSkill]:
        """Obtiene un skill por nombre."""
        return self._skills.get(name)
