"""
Registro de plugins y skills.
Permite descubrir y acceder a skills dinámicamente.
"""

from typing import Dict, List, Type, Optional, Callable
from .base import BasePlugin, BaseSkill, SkillCategory
import logging

logger = logging.getLogger(__name__)


class SkillRegistry:
    """
    Registro central de skills.
    Permite buscar y filtrar skills por diversos criterios.
    """
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._skills: Dict[str, BaseSkill] = {}
            cls._instance._categories: Dict[SkillCategory, List[str]] = {
                cat: [] for cat in SkillCategory
            }
            cls._instance._applications: Dict[str, List[str]] = {}
        return cls._instance
    
    def register(self, skill: BaseSkill) -> None:
        """Registra un skill en el sistema."""
        if skill.name in self._skills:
            logger.warning(f"Skill '{skill.name}' ya existe. Sobrescribiendo...")
        
        self._skills[skill.name] = skill
        self._categories[skill.category].append(skill.name)
        
        # Registrar por aplicación
        for app in skill.supports_applications:
            if app not in self._applications:
                self._applications[app] = []
            self._applications[app].append(skill.name)
        
        logger.info(f"Skill registrado: {skill.name} ({skill.category.value})")
    
    def unregister(self, skill_name: str) -> None:
        """Elimina un skill del registro."""
        if skill_name not in self._skills:
            return
        
        skill = self._skills[skill_name]
        del self._skills[skill_name]
        
        # Limpiar de categorías
        if skill_name in self._categories[skill.category]:
            self._categories[skill.category].remove(skill_name)
        
        # Limpiar de aplicaciones
        for app, skills in self._applications.items():
            if skill_name in skills:
                skills.remove(skill_name)
        
        logger.info(f"Skill eliminado: {skill_name}")
    
    def get(self, name: str) -> Optional[BaseSkill]:
        """Obtiene un skill por nombre."""
        return self._skills.get(name)
    
    def get_all(self) -> Dict[str, BaseSkill]:
        """Obtiene todos los skills."""
        return self._skills.copy()
    
    def get_by_category(self, category: SkillCategory) -> List[BaseSkill]:
        """Obtiene skills por categoría."""
        skill_names = self._categories.get(category, [])
        return [self._skills[name] for name in skill_names if name in self._skills]
    
    def get_by_application(self, application: str) -> List[BaseSkill]:
        """Obtiene skills que soportan una aplicación específica."""
        skill_names = self._applications.get(application, [])
        return [self._skills[name] for name in skill_names if name in self._skills]
    
    def search(self, query: str) -> List[BaseSkill]:
        """Busca skills por nombre o descripción."""
        query = query.lower()
        results = []
        for skill in self._skills.values():
            if (query in skill.name.lower() or 
                query in skill.description.lower()):
                results.append(skill)
        return results
    
    def list_all(self) -> List[Dict]:
        """Lista información de todos los skills."""
        return [skill.get_info() for skill in self._skills.values()]
    
    def clear(self) -> None:
        """Limpia todos los registros."""
        self._skills.clear()
        for cat in self._categories:
            self._categories[cat].clear()
        self._applications.clear()


class PluginRegistry:
    """
    Registro central de plugins.
    """
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._plugins: Dict[str, BasePlugin] = {}
        return cls._instance
    
    def register(self, plugin: BasePlugin) -> None:
        """Registra un plugin y sus skills."""
        if plugin.name in self._plugins:
            logger.warning(f"Plugin '{plugin.name}' ya existe. Sobrescribiendo...")
        
        self._plugins[plugin.name] = plugin
        
        # Registrar todos los skills del plugin
        skill_registry = SkillRegistry()
        for skill in plugin.get_skills().values():
            skill_registry.register(skill)
        
        logger.info(f"Plugin registrado: {plugin.name} v{plugin.version}")
    
    def unregister(self, plugin_name: str) -> None:
        """Elimina un plugin y sus skills."""
        if plugin_name not in self._plugins:
            return
        
        plugin = self._plugins[plugin_name]
        
        # Eliminar skills asociados
        skill_registry = SkillRegistry()
        for skill_name in plugin.get_skills().keys():
            skill_registry.unregister(skill_name)
        
        del self._plugins[plugin_name]
        logger.info(f"Plugin eliminado: {plugin_name}")
    
    def get(self, name: str) -> Optional[BasePlugin]:
        """Obtiene un plugin por nombre."""
        return self._plugins.get(name)
    
    def get_all(self) -> Dict[str, BasePlugin]:
        """Obtiene todos los plugins."""
        return self._plugins.copy()
    
    def list_all(self) -> List[Dict]:
        """Lista información de todos los plugins."""
        return [
            {
                "name": p.name,
                "description": p.description,
                "version": p.version,
                "author": p.author,
                "skills_count": len(p.get_skills())
            }
            for p in self._plugins.values()
        ]
