"""
Sistema de Plugins de ClawSphere AMS.
Permite extender funcionalidad sin modificar el código base.
"""

from .registry import PluginRegistry, SkillRegistry
from .base import BasePlugin, BaseSkill, SkillContext, SkillResult
from .loader import PluginLoader

__all__ = [
    "PluginRegistry", 
    "SkillRegistry", 
    "BasePlugin", 
    "BaseSkill", 
    "SkillContext", 
    "SkillResult",
    "PluginLoader"
]
