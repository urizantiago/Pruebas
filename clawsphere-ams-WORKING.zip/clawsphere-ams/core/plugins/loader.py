"""
Cargador dinámico de plugins.
Permite cargar plugins desde archivos y módulos.
"""

import os
import sys
import importlib
import importlib.util
from typing import Dict, List, Type, Optional
from pathlib import Path
import logging

from .base import BasePlugin
from .registry import PluginRegistry

logger = logging.getLogger(__name__)


class PluginLoader:
    """
    Cargador de plugins que soporta carga desde:
    - Módulos Python instalados
    - Archivos Python individuales
    - Directorios de plugins
    """
    
    def __init__(self, plugins_dir: Optional[str] = None):
        self.plugins_dir = plugins_dir or os.path.join(
            os.path.dirname(__file__), "..", "..", "skills"
        )
        self._loaded_plugins: Dict[str, BasePlugin] = {}
    
    def load_from_module(self, module_path: str) -> Optional[BasePlugin]:
        """
        Carga un plugin desde un módulo Python.
        
        Args:
            module_path: Ruta al módulo (ej: 'skills.server_management.plugin')
            
        Returns:
            Instancia del plugin o None
        """
        try:
            module = importlib.import_module(module_path)
            
            # Buscar clase que herede de BasePlugin
            plugin_class = None
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                if (isinstance(attr, type) and 
                    issubclass(attr, BasePlugin) and 
                    attr != BasePlugin):
                    plugin_class = attr
                    break
            
            if plugin_class is None:
                logger.error(f"No se encontró clase plugin en {module_path}")
                return None
            
            plugin = plugin_class()
            PluginRegistry().register(plugin)
            self._loaded_plugins[plugin.name] = plugin
            
            return plugin
            
        except Exception as e:
            logger.error(f"Error cargando plugin desde {module_path}: {e}")
            return None
    
    def load_from_file(self, file_path: str) -> Optional[BasePlugin]:
        """
        Carga un plugin desde un archivo Python.
        
        Args:
            file_path: Ruta al archivo .py
            
        Returns:
            Instancia del plugin o None
        """
        try:
            spec = importlib.util.spec_from_file_location("plugin", file_path)
            if spec is None or spec.loader is None:
                logger.error(f"No se pudo cargar spec desde {file_path}")
                return None
            
            module = importlib.util.module_from_spec(spec)
            sys.modules["plugin"] = module
            spec.loader.exec_module(module)
            
            # Buscar clase plugin
            plugin_class = None
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                if (isinstance(attr, type) and 
                    issubclass(attr, BasePlugin) and 
                    attr != BasePlugin):
                    plugin_class = attr
                    break
            
            if plugin_class is None:
                return None
            
            plugin = plugin_class()
            PluginRegistry().register(plugin)
            self._loaded_plugins[plugin.name] = plugin
            
            return plugin
            
        except Exception as e:
            logger.error(f"Error cargando plugin desde archivo {file_path}: {e}")
            return None
    
    def load_from_directory(self, directory: Optional[str] = None) -> List[BasePlugin]:
        """
        Carga todos los plugins desde un directorio.
        Busca archivos plugin.py en subdirectorios.
        
        Args:
            directory: Directorio a escanear
            
        Returns:
            Lista de plugins cargados
        """
        directory = directory or self.plugins_dir
        plugins = []
        
        if not os.path.exists(directory):
            logger.warning(f"Directorio de plugins no existe: {directory}")
            return plugins
        
        for item in os.listdir(directory):
            item_path = os.path.join(directory, item)
            
            # Buscar plugin.py en subdirectorios
            if os.path.isdir(item_path):
                plugin_file = os.path.join(item_path, "plugin.py")
                if os.path.exists(plugin_file):
                    plugin = self.load_from_file(plugin_file)
                    if plugin:
                        plugins.append(plugin)
        
        logger.info(f"Cargados {len(plugins)} plugins desde {directory}")
        return plugins
    
    def load_builtin_plugins(self) -> List[BasePlugin]:
        """
        Carga los plugins built-in del sistema.
        """
        builtin_plugins = [
            "skills.server_management.plugin",
            "skills.database_management.plugin",
            "skills.api_management.plugin",
            "skills.security_management.plugin",
            "skills.monitoring.plugin",
            "skills.automation.plugin",
        ]
        
        plugins = []
        for plugin_path in builtin_plugins:
            try:
                plugin = self.load_from_module(plugin_path)
                if plugin:
                    plugins.append(plugin)
            except Exception as e:
                logger.warning(f"No se pudo cargar plugin built-in {plugin_path}: {e}")
        
        return plugins
    
    def get_loaded_plugins(self) -> Dict[str, BasePlugin]:
        """Obtiene los plugins cargados."""
        return self._loaded_plugins.copy()
    
    def unload_plugin(self, name: str) -> bool:
        """Descarga un plugin."""
        if name in self._loaded_plugins:
            PluginRegistry().unregister(name)
            del self._loaded_plugins[name]
            return True
        return False
