"""
Sistema de backup y restore para ClawSphere AMS.
"""

import os
import json
import shutil
import tarfile
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from pathlib import Path
import asyncio

logger = logging.getLogger(__name__)


class BackupManager:
    """
    Gestiona backups de configuración y datos de ClawSphere AMS.
    """
    
    def __init__(self, backup_path: str = "backups"):
        self.backup_path = Path(backup_path)
        self.backup_path.mkdir(parents=True, exist_ok=True)
        
        # Rutas a respaldar
        self.data_paths = {
            "database": "data/*.db",
            "config": "config",
            "workflows": "config/workflows",
            "ml_models": "data/ml_models",
            "tenants": "data/tenants",
            "remediation_history": "data/remediation_history.db",
            "env": ".env"
        }
    
    async def create_backup(
        self,
        name: Optional[str] = None,
        include_data: bool = True,
        include_logs: bool = False
    ) -> Dict[str, Any]:
        """
        Crea un nuevo backup.
        
        Args:
            name: Nombre del backup (opcional)
            include_data: Incluir datos de la aplicación
            include_logs: Incluir archivos de log
            
        Returns:
            Información del backup creado
        """
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        backup_name = name or f"backup_{timestamp}"
        backup_dir = self.backup_path / backup_name
        
        try:
            # Crear directorio de backup
            backup_dir.mkdir(parents=True, exist_ok=True)
            
            backup_info = {
                "name": backup_name,
                "created_at": datetime.utcnow().isoformat(),
                "version": "1.0.0",
                "components": []
            }
            
            # Backup de configuración
            await self._backup_config(backup_dir)
            backup_info["components"].append("config")
            
            # Backup de base de datos
            if include_data:
                await self._backup_database(backup_dir)
                backup_info["components"].append("database")
                
                # Backup de ML models
                await self._backup_ml_models(backup_dir)
                backup_info["components"].append("ml_models")
                
                # Backup de tenants
                await self._backup_tenants(backup_dir)
                backup_info["components"].append("tenants")
            
            # Backup de logs (opcional)
            if include_logs:
                await self._backup_logs(backup_dir)
                backup_info["components"].append("logs")
            
            # Guardar metadata
            metadata_path = backup_dir / "backup_info.json"
            with open(metadata_path, 'w') as f:
                json.dump(backup_info, f, indent=2)
            
            # Comprimir backup
            archive_path = await self._compress_backup(backup_dir)
            
            # Eliminar directorio temporal
            shutil.rmtree(backup_dir)
            
            logger.info(f"Backup creado: {archive_path}")
            
            return {
                "success": True,
                "backup_name": backup_name,
                "archive_path": str(archive_path),
                "size_bytes": archive_path.stat().st_size,
                "components": backup_info["components"]
            }
            
        except Exception as e:
            logger.exception(f"Error creando backup: {e}")
            # Limpiar en caso de error
            if backup_dir.exists():
                shutil.rmtree(backup_dir)
            
            return {
                "success": False,
                "error": str(e)
            }
    
    async def _backup_config(self, backup_dir: Path):
        """Respalda archivos de configuración."""
        config_backup = backup_dir / "config"
        config_backup.mkdir(exist_ok=True)
        
        # Backup de .env
        if Path(".env").exists():
            shutil.copy(".env", config_backup / ".env")
        
        # Backup de config/
        if Path("config").exists():
            shutil.copytree("config", config_backup / "config", dirs_exist_ok=True)
    
    async def _backup_database(self, backup_dir: Path):
        """Respalda la base de datos."""
        db_backup = backup_dir / "database"
        db_backup.mkdir(exist_ok=True)
        
        # SQLite
        for db_file in Path("data").glob("*.db"):
            shutil.copy(db_file, db_backup / db_file.name)
        
        # PostgreSQL (si está configurado)
        db_url = os.getenv("DATABASE_URL", "")
        if "postgresql" in db_url:
            await self._backup_postgresql(db_backup)
    
    async def _backup_postgresql(self, backup_dir: Path):
        """Respalda PostgreSQL usando pg_dump."""
        import subprocess
        
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        dump_file = backup_dir / f"postgres_dump_{timestamp}.sql"
        
        try:
            subprocess.run(
                ["pg_dump", "-f", str(dump_file)],
                check=True,
                capture_output=True
            )
        except subprocess.CalledProcessError as e:
            logger.error(f"Error en pg_dump: {e}")
    
    async def _backup_ml_models(self, backup_dir: Path):
        """Respalda modelos de ML."""
        ml_backup = backup_dir / "ml_models"
        ml_backup.mkdir(exist_ok=True)
        
        if Path("data/ml_models").exists():
            shutil.copytree(
                "data/ml_models",
                ml_backup / "ml_models",
                dirs_exist_ok=True
            )
    
    async def _backup_tenants(self, backup_dir: Path):
        """Respalda configuración de tenants."""
        tenants_backup = backup_dir / "tenants"
        tenants_backup.mkdir(exist_ok=True)
        
        if Path("data/tenants").exists():
            shutil.copytree(
                "data/tenants",
                tenants_backup / "tenants",
                dirs_exist_ok=True
            )
    
    async def _backup_logs(self, backup_dir: Path):
        """Respalda archivos de log."""
        logs_backup = backup_dir / "logs"
        logs_backup.mkdir(exist_ok=True)
        
        if Path("logs").exists():
            # Solo logs recientes (últimos 7 días)
            cutoff = datetime.utcnow() - timedelta(days=7)
            
            for log_file in Path("logs").glob("*.log"):
                mtime = datetime.fromtimestamp(log_file.stat().st_mtime)
                if mtime > cutoff:
                    shutil.copy(log_file, logs_backup / log_file.name)
    
    async def _compress_backup(self, backup_dir: Path) -> Path:
        """Comprime el backup en un archivo tar.gz."""
        archive_path = self.backup_path / f"{backup_dir.name}.tar.gz"
        
        with tarfile.open(archive_path, "w:gz") as tar:
            tar.add(backup_dir, arcname=backup_dir.name)
        
        return archive_path
    
    async def restore_backup(
        self,
        backup_name: str,
        restore_data: bool = True,
        restore_config: bool = True
    ) -> Dict[str, Any]:
        """
        Restaura un backup.
        
        Args:
            backup_name: Nombre del backup a restaurar
            restore_data: Restaurar datos
            restore_config: Restaurar configuración
            
        Returns:
            Resultado de la restauración
        """
        archive_path = self.backup_path / f"{backup_name}.tar.gz"
        
        if not archive_path.exists():
            return {
                "success": False,
                "error": f"Backup no encontrado: {backup_name}"
            }
        
        temp_dir = self.backup_path / f"temp_restore_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
        
        try:
            # Extraer backup
            with tarfile.open(archive_path, "r:gz") as tar:
                tar.extractall(temp_dir)
            
            # Encontrar directorio extraído
            extracted_dir = list(temp_dir.iterdir())[0]
            
            # Cargar metadata
            metadata_path = extracted_dir / "backup_info.json"
            with open(metadata_path, 'r') as f:
                metadata = json.load(f)
            
            restored_components = []
            
            # Restaurar configuración
            if restore_config and (extracted_dir / "config").exists():
                await self._restore_config(extracted_dir / "config")
                restored_components.append("config")
            
            # Restaurar datos
            if restore_data:
                if (extracted_dir / "database").exists():
                    await self._restore_database(extracted_dir / "database")
                    restored_components.append("database")
                
                if (extracted_dir / "ml_models").exists():
                    await self._restore_ml_models(extracted_dir / "ml_models")
                    restored_components.append("ml_models")
                
                if (extracted_dir / "tenants").exists():
                    await self._restore_tenants(extracted_dir / "tenants")
                    restored_components.append("tenants")
            
            # Limpiar
            shutil.rmtree(temp_dir)
            
            logger.info(f"Backup restaurado: {backup_name}")
            
            return {
                "success": True,
                "backup_name": backup_name,
                "restored_components": restored_components,
                "restored_at": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.exception(f"Error restaurando backup: {e}")
            
            if temp_dir.exists():
                shutil.rmtree(temp_dir)
            
            return {
                "success": False,
                "error": str(e)
            }
    
    async def _restore_config(self, config_dir: Path):
        """Restaura configuración."""
        # Restaurar .env
        env_file = config_dir / ".env"
        if env_file.exists():
            shutil.copy(env_file, ".env")
        
        # Restaurar config/
        config_source = config_dir / "config"
        if config_source.exists():
            if Path("config").exists():
                shutil.rmtree("config")
            shutil.copytree(config_source, "config")
    
    async def _restore_database(self, db_dir: Path):
        """Restaura base de datos."""
        # SQLite
        for db_file in db_dir.glob("*.db"):
            shutil.copy(db_file, f"data/{db_file.name}")
        
        # PostgreSQL dump
        for dump_file in db_dir.glob("*.sql"):
            await self._restore_postgresql_dump(dump_file)
    
    async def _restore_postgresql_dump(self, dump_file: Path):
        """Restaura dump de PostgreSQL."""
        import subprocess
        
        try:
            subprocess.run(
                ["psql", "-f", str(dump_file)],
                check=True,
                capture_output=True
            )
        except subprocess.CalledProcessError as e:
            logger.error(f"Error restaurando PostgreSQL: {e}")
    
    async def _restore_ml_models(self, ml_dir: Path):
        """Restaura modelos de ML."""
        ml_source = ml_dir / "ml_models"
        if ml_source.exists():
            if Path("data/ml_models").exists():
                shutil.rmtree("data/ml_models")
            shutil.copytree(ml_source, "data/ml_models")
    
    async def _restore_tenants(self, tenants_dir: Path):
        """Restaura configuración de tenants."""
        tenants_source = tenants_dir / "tenants"
        if tenants_source.exists():
            if Path("data/tenants").exists():
                shutil.rmtree("data/tenants")
            shutil.copytree(tenants_source, "data/tenants")
    
    def list_backups(self) -> List[Dict[str, Any]]:
        """Lista todos los backups disponibles."""
        backups = []
        
        for archive in self.backup_path.glob("*.tar.gz"):
            stat = archive.stat()
            backups.append({
                "name": archive.stem.replace(".tar", ""),
                "created_at": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                "size_bytes": stat.st_size,
                "size_human": self._format_bytes(stat.st_size)
            })
        
        return sorted(backups, key=lambda x: x["created_at"], reverse=True)
    
    def delete_backup(self, backup_name: str) -> bool:
        """Elimina un backup."""
        archive_path = self.backup_path / f"{backup_name}.tar.gz"
        
        if archive_path.exists():
            archive_path.unlink()
            logger.info(f"Backup eliminado: {backup_name}")
            return True
        
        return False
    
    def cleanup_old_backups(self, days_to_keep: int = 30):
        """Elimina backups antiguos."""
        cutoff = datetime.utcnow() - timedelta(days=days_to_keep)
        
        for archive in self.backup_path.glob("*.tar.gz"):
            mtime = datetime.fromtimestamp(archive.stat().st_mtime)
            if mtime < cutoff:
                archive.unlink()
                logger.info(f"Backup antiguo eliminado: {archive.name}")
    
    def _format_bytes(self, bytes_val: int) -> str:
        """Formatea bytes a unidad legible."""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if bytes_val < 1024:
                return f"{bytes_val:.2f} {unit}"
            bytes_val /= 1024
        return f"{bytes_val:.2f} PB"
    
    async def schedule_backups(self, interval_hours: int = 24):
        """Programa backups automáticos."""
        while True:
            try:
                result = await self.create_backup()
                
                if result["success"]:
                    logger.info(f"Backup automático completado: {result['backup_name']}")
                    # Limpiar backups antiguos
                    self.cleanup_old_backups()
                else:
                    logger.error(f"Backup automático fallido: {result.get('error')}")
                
            except Exception as e:
                logger.exception(f"Error en backup automático: {e}")
            
            await asyncio.sleep(interval_hours * 3600)


# Instancia global
backup_manager = BackupManager()
