"""Configuración de ClawSphere AMS"""
from .settings import settings

__all__ = ['settings']
