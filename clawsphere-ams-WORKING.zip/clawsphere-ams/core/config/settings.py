"""Configuración de la aplicación"""
import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    APP_NAME: str = "ClawSphere AMS"
    DEBUG: bool = os.getenv("CLAWSPHERE_DEBUG", "true").lower() == "true"
    HOST: str = os.getenv("CLAWSPHERE_HOST", "0.0.0.0")
    PORT: int = int(os.getenv("CLAWSPHERE_PORT", "7550"))
    
    # Security
    SECRET_KEY: str = os.getenv("CLAWSPHERE_SECURITY_SECRET_KEY", "change-me")
    ENCRYPTION_KEY: str = os.getenv("CLAWSPHERE_SECURITY_ENCRYPTION_KEY", "change-me")
    
    # Database
    DATABASE_URL: str = os.getenv("CLAWSPHERE_DATABASE_URL", "sqlite+aiosqlite:///data/clawsphere.db")
    
    # AI
    AI_DEFAULT_PROVIDER: str = os.getenv("CLAWSPHERE_AI_DEFAULT_PROVIDER", "ollama")
    AI_OLLAMA_BASE_URL: str = os.getenv("CLAWSPHERE_AI_OLLAMA_BASE_URL", "http://localhost:11434")
    AI_OLLAMA_MODEL: str = os.getenv("CLAWSPHERE_AI_OLLAMA_MODEL", "llama3.1")
    AI_OPENAI_API_KEY: str = os.getenv("CLAWSPHERE_AI_OPENAI_API_KEY", "")
    
    # Features
    PROMETHEUS_ENABLED: bool = os.getenv("CLAWSPHERE_PROMETHEUS_ENABLED", "false").lower() == "true"
    ALERT_ENABLED: bool = os.getenv("CLAWSPHERE_ALERT_ENABLED", "false").lower() == "true"
    MULTI_TENANT_ENABLED: bool = os.getenv("CLAWSPHERE_MULTI_TENANT_ENABLED", "false").lower() == "true"
    AUTO_REMEDIATION_ENABLED: bool = os.getenv("CLAWSPHERE_AUTO_REMEDIATION_ENABLED", "false").lower() == "true"
    ML_ENABLED: bool = os.getenv("CLAWSPHERE_ML_ENABLED", "false").lower() == "true"

settings = Settings()
