"""
Gestor de Estado.
Maneja el estado de sesiones, conversaciones y caché.
"""

import json
import logging
from typing import Dict, Any, Optional
from datetime import datetime, timedelta
from collections import OrderedDict

logger = logging.getLogger(__name__)


class StateManager:
    """
    Gestor de estado en memoria con persistencia opcional.
    Maneja sesiones, conversaciones y caché.
    """
    
    def __init__(self):
        self._cache: Dict[str, Dict] = {}
        self._sessions: Dict[str, Dict] = {}
        self._conversations: Dict[str, list] = {}
        self._max_cache_size = 1000
    
    async def initialize(self):
        """Inicializa el gestor de estado."""
        logger.info("StateManager inicializado")
    
    async def get(self, key: str) -> Optional[Any]:
        """
        Obtiene un valor del caché.
        
        Args:
            key: Clave del valor
            
        Returns:
            Valor o None si no existe o expiró
        """
        if key not in self._cache:
            return None
        
        entry = self._cache[key]
        
        # Verificar expiración
        if "expires_at" in entry:
            if datetime.utcnow() > entry["expires_at"]:
                del self._cache[key]
                return None
        
        return entry["value"]
    
    async def set(
        self, 
        key: str, 
        value: Any, 
        ttl: int = None
    ) -> None:
        """
        Establece un valor en el caché.
        
        Args:
            key: Clave
            value: Valor
            ttl: Tiempo de vida en segundos (opcional)
        """
        # Limpiar caché si está lleno
        if len(self._cache) >= self._max_cache_size:
            self._cleanup_expired()
        
        entry = {
            "value": value,
            "created_at": datetime.utcnow()
        }
        
        if ttl:
            entry["expires_at"] = datetime.utcnow() + timedelta(seconds=ttl)
        
        self._cache[key] = entry
    
    async def delete(self, key: str) -> bool:
        """Elimina un valor del caché."""
        if key in self._cache:
            del self._cache[key]
            return True
        return False
    
    async def get_session(self, session_id: str) -> Dict:
        """Obtiene datos de una sesión."""
        if session_id not in self._sessions:
            self._sessions[session_id] = {
                "created_at": datetime.utcnow().isoformat(),
                "data": {}
            }
        return self._sessions[session_id]
    
    async def update_session(self, session_id: str, data: Dict) -> None:
        """Actualiza datos de una sesión."""
        session = await self.get_session(session_id)
        session["data"].update(data)
        session["last_activity"] = datetime.utcnow().isoformat()
    
    async def get_conversation(self, session_id: str) -> list:
        """Obtiene el historial de conversación."""
        if session_id not in self._conversations:
            self._conversations[session_id] = []
        return self._conversations[session_id]
    
    async def add_to_conversation(
        self, 
        session_id: str, 
        role: str, 
        message: str,
        metadata: Dict = None
    ) -> None:
        """
        Agrega un mensaje a la conversación.
        
        Args:
            session_id: ID de sesión
            role: 'user' o 'assistant'
            message: Contenido del mensaje
            metadata: Metadatos adicionales
        """
        conversation = await self.get_conversation(session_id)
        
        entry = {
            "role": role,
            "message": message,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        if metadata:
            entry["metadata"] = metadata
        
        conversation.append(entry)
        
        # Limitar historial
        if len(conversation) > 100:
            self._conversations[session_id] = conversation[-100:]
    
    def _cleanup_expired(self):
        """Limpia entradas expiradas del caché."""
        now = datetime.utcnow()
        expired = [
            key for key, entry in self._cache.items()
            if "expires_at" in entry and now > entry["expires_at"]
        ]
        for key in expired:
            del self._cache[key]
        
        # Si sigue lleno, eliminar los más antiguos
        if len(self._cache) >= self._max_cache_size:
            sorted_items = sorted(
                self._cache.items(),
                key=lambda x: x[1].get("created_at", datetime.min)
            )
            to_remove = len(self._cache) - self._max_cache_size + 100
            for key, _ in sorted_items[:to_remove]:
                del self._cache[key]
    
    async def disconnect_all(self):
        """Limpia todas las conexiones y estado."""
        self._cache.clear()
        self._sessions.clear()
        self._conversations.clear()
        logger.info("StateManager: Todas las sesiones limpiadas")
    
    def get_stats(self) -> Dict[str, int]:
        """Retorna estadísticas del estado."""
        return {
            "cache_entries": len(self._cache),
            "active_sessions": len(self._sessions),
            "conversations": len(self._conversations)
        }
