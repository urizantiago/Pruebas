"""Métricas del sistema"""
from fastapi import FastAPI

def setup_metrics(app: FastAPI):
    """Configura métricas Prometheus"""
    pass
