"""Health checks"""
class HealthChecker:
    async def check_all(self):
        return {"status": "healthy"}

health_checker = HealthChecker()
