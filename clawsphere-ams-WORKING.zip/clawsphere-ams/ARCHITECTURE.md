# ClawSphere AMS - Arquitectura

## Visión General

ClawSphere AMS sigue una **Arquitectura Limpia (Clean Architecture)** con los siguientes principios:

1. **Independencia de Frameworks**: El núcleo no depende de frameworks externos
2. **Testabilidad**: Las reglas de negocio pueden probarse sin UI, base de datos o servidor
3. **Independencia de UI**: La UI puede cambiar sin afectar el sistema
4. **Independencia de Base de Datos**: Podemos cambiar de BD sin afectar el negocio
5. **Independencia de Agentes Externos**: Las reglas de negocio no saben nada del mundo exterior

## Diagrama de Arquitectura

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              PRESENTATION LAYER                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │   REST API   │  │  WebSocket   │  │    Teams     │  │  Telegram    │   │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
                                       │
                                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           ADAPTERS LAYER (Puertos)                           │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │  AI Models   │  │  Databases   │  │   Servers    │  │  Messaging   │   │
│  │  (Ollama,    │  │  (SQL, PG,   │  │  (SSH,       │  │  (Teams,     │   │
│  │   OpenAI...) │  │   Oracle...) │  │   WinRM)     │  │   Telegram)  │   │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
                                       │
                                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         CORE LAYER (Casos de Uso)                            │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      ORCHESTRATOR (Agente)                           │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │   Intent     │  │   Skill      │  │   Context    │              │   │
│  │  │  Classifier  │──│   Executor   │──│   Manager    │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                    PLUGIN SYSTEM (Skills)                            │   │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐  │   │
│  │  │  Server  │ │ Database │ │   API    │ │ Security │ │Monitoring│  │   │
│  │  │  Mgmt    │ │   Mgmt   │ │   Mgmt   │ │   Mgmt   │ │   Mgmt   │  │   │
│  │  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
                                       │
                                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                      SECURITY LAYER (Enterprise)                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │     Auth     │  │  Encryption  │  │    RBAC      │  │    Audit     │   │
│  │  (AD/LDAP)   │  │ (AES-256)    │  │ (Roles &     │  │  (Logging &  │   │
│  │              │  │              │  │  Permissions)│  │  Compliance) │   │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Flujo de Datos

### 1. Solicitud de Usuario
```
Usuario → Canal (Teams/API) → Auth Middleware → Intent Classifier
```

### 2. Procesamiento
```
Intent Classifier → Skill Selector → Permission Check → Skill Execution
```

### 3. Ejecución
```
Skill → Adapter (DB/Server/AI) → Result Formatter → Response
```

### 4. Auditoría
```
Skill Execution → Audit Logger → Log File/DB
```

## Componentes Principales

### Core

#### Orchestrator
- **ClawSphereAgent**: Orquestador principal
- **IntentClassifier**: Clasifica intenciones usando IA
- **SkillExecutor**: Ejecuta skills con auditoría

#### Plugins
- **BaseSkill**: Clase base para todos los skills
- **BasePlugin**: Clase base para plugins
- **SkillRegistry**: Registro central de skills
- **PluginLoader**: Carga dinámica de plugins

### Adapters

#### AI Adapters
- **OllamaAdapter**: Modelos locales (Qwen, Llama, Mistral)
- **OpenAIAdapter**: GPT-4, GPT-3.5
- **AnthropicAdapter**: Claude 3
- **GoogleAdapter**: Gemini
- **LocalAIAdapter**: LM Studio, GPT4All, vLLM

#### Database Adapters
- **SQLServerAdapter**: SQL Server y Azure SQL
- **PostgreSQLAdapter**: PostgreSQL
- **OracleAdapter**: Oracle DB (TODO)
- **DB2Adapter**: IBM DB2 (TODO)

#### Server Adapters
- **SSHAdapter**: Linux, Unix, AIX
- **WinRMAdapter**: Windows Server

#### Messaging Adapters
- **TeamsAdapter**: Microsoft Teams Bot
- **TelegramAdapter**: Telegram Bot
- **WhatsAppAdapter**: WhatsApp (Twilio)

### Security

#### Auth
- **AuthManager**: Autenticación AD/LDAP/Local
- JWT tokens con expiración
- MFA support

#### Encryption
- **EncryptionManager**: AES-256-GCM
- Fernet para datos de configuración
- Rotación de claves

#### RBAC
- **RBACManager**: Roles y permisos
- Roles: admin, ingeniero, seguridad, auditor, readonly
- Permisos granulares por skill

#### Audit
- **AuditLogger**: Logging de todas las acciones
- Retención configurable
- Reportes de compliance

## Sistema de Plugins

### Estructura de un Plugin

```python
class MiPlugin(BasePlugin):
    name = "mi_plugin"
    description = "Descripción"
    
    def register_skills(self):
        return [MiSkill()]

class MiSkill(BaseSkill):
    name = "mi_skill"
    description = "Descripción del skill"
    category = SkillCategory.CUSTOM
    required_roles = ["ingeniero"]
    risk_level = RiskLevel.LOW
    requires_approval = False
    
    async def execute(self, context: SkillContext, **params):
        # Implementación
        return SkillResult.success_result(data={}, message="OK")
```

### Registro de Plugins

Los plugins se registran automáticamente al cargar:

```python
loader = PluginLoader()
await loader.load_builtin_plugins()
```

## Seguridad

### Autenticación

```
Usuario → Login → AD/LDAP/Local → JWT Token
```

### Autorización

```
Request → JWT Verify → RBAC Check → Permission Check → Execute
```

### Aprobaciones

Operaciones críticas requieren aprobación:

```
Skill Execution → Requires Approval? → Notify Admin → Wait Approval → Execute
```

### Encriptación

- **En tránsito**: TLS 1.2+
- **En reposo**: AES-256-GCM
- **Contraseñas**: bcrypt
- **Tokens**: JWT

## Escalabilidad

### Horizontal
- Múltiples instancias con load balancer
- Redis para sesiones compartidas
- Base de datos compartida

### Vertical
- Workers de Uvicorn
- Async/await para I/O
- Connection pooling

## Monitoreo

### Métricas
- Tiempo de respuesta
- Tasa de éxito/error
- Uso por skill
- Eventos de seguridad

### Health Checks
```
/health → Component Status → Response
```

## Despliegue

### Docker
```
Dockerfile → Build → Run
```

### Docker Compose
```
docker-compose up -d
```

### Kubernetes
```yaml
Deployment → Service → Ingress
```

## Extensibilidad

### Agregar un Nuevo Adaptador de IA

1. Crear clase heredando de `BaseAIAdapter`
2. Implementar `generate_response()` y `generate_stream()`
3. Registrar en `AIAdapterFactory`

### Agregar un Nuevo Skill

1. Crear clase heredando de `BaseSkill`
2. Implementar `execute()`
3. Crear plugin que retorne el skill
4. Colocar en `skills/` directory

### Agregar un Nuevo Adaptador de BD

1. Crear clase heredando de `BaseDatabaseAdapter`
2. Implementar métodos requeridos
3. Registrar en `DatabaseAdapterFactory`

## Patrones de Diseño

- **Factory**: Creación de adaptadores
- **Singleton**: Registros y configuración
- **Strategy**: Diferentes adaptadores
- **Observer**: Event bus
- **Plugin**: Sistema de skills
- **Repository**: Acceso a datos

## Consideraciones de Seguridad

1. **Inyección SQL**: Validación y parametrización
2. **Inyección de Comandos**: Sanitización de inputs
3. **XSS**: Escapado de outputs
4. **CSRF**: Tokens en forms
5. **Secrets**: Nunca en código, usar variables de entorno

## Roadmap

### v1.0 (Actual)
- ✅ Core del agente
- ✅ Sistema de plugins
- ✅ Seguridad 360
- ✅ Múltiples IAs
- ✅ Múltiples BDs
- ✅ SSH/WinRM
- ✅ Teams/Telegram/WhatsApp

### v1.1 (Próximo)
- 🔄 Web UI
- 🔄 Más adaptadores de BD
- 🔄 Integración con Prometheus
- 🔄 Alertas avanzadas

### v2.0 (Futuro)
- 🔮 Auto-remediación
- 🔮 ML para predicción
- 🔮 Workflow engine
- 🔮 Multi-tenant
