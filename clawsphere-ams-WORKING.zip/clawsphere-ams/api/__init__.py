"""API de ClawSphere AMS"""
