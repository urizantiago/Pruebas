"""
API REST de ClawSphere AMS.
Punto de entrada principal para interacciones.
"""

import logging
from typing import Optional, List
from datetime import datetime
from contextlib import asynccontextmanager

from fastapi import FastAPI, Depends, HTTPException, Security, Request, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse

from ...core.config.settings import get_settings
from ...core.orchestrator.agent import ClawSphereAgent
from ...core.plugins.registry import SkillRegistry, PluginRegistry
from ...core.plugins.loader import PluginLoader
from ...security.auth.manager import AuthManager
from ...security.rbac.manager import get_rbac_manager, Permission
from ...security.encryption.manager import get_encryption_manager
from ...security.audit.logger import AuditLogger
from ...integrations.prometheus import (
    PrometheusClient,
    get_metrics_collector,
    get_alert_manager,
    get_metrics_exporter,
    AlertSeverity
)

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Security
security = HTTPBearer(auto_error=False)

# Instancias globales
agent: Optional[ClawSphereAgent] = None
auth_manager: Optional[AuthManager] = None
audit_logger: Optional[AuditLogger] = None


async def get_current_user(credentials: HTTPAuthorizationCredentials = Security(security)):
    """Obtiene el usuario actual del token JWT."""
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token no proporcionado"
        )
    
    success, payload = auth_manager.verify_token(credentials.credentials)
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=payload.get("error", "Token inválido")
        )
    
    return payload


async def require_permission(permission: str):
    """Dependency factory para requerir permisos."""
    async def checker(user: dict = Depends(get_current_user)):
        rbac = get_rbac_manager()
        if not rbac.has_permission(user["sub"], permission):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Permiso requerido: {permission}"
            )
        return user
    return checker


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Gestiona el ciclo de vida de la aplicación."""
    global agent, auth_manager, audit_logger
    
    logger.info("Iniciando ClawSphere AMS...")
    
    # Inicializar componentes
    settings = get_settings()
    
    # Inicializar auditoría
    audit_logger = AuditLogger(settings)
    await audit_logger.initialize()
    
    # Inicializar auth
    auth_manager = AuthManager(settings)
    
    # Cargar plugins
    loader = PluginLoader()
    await loader.load_builtin_plugins()
    
    # Inicializar agente
    agent = ClawSphereAgent(settings)
    await agent.initialize()
    
    logger.info("ClawSphere AMS iniciado correctamente")
    
    yield
    
    # Cleanup
    logger.info("Deteniendo ClawSphere AMS...")
    if agent:
        await agent.state_manager.disconnect_all()
    logger.info("ClawSphere AMS detenido")


# Crear aplicación FastAPI
app = FastAPI(
    title="ClawSphere AMS",
    description="Agente de IA empresarial para soporte L2/L3",
    version="1.0.0",
    lifespan=lifespan
)

# Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configurar según entorno
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(TrustedHostMiddleware, allowed_hosts=["*"])


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Manejador global de excepciones."""
    logger.exception("Error no manejado")
    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "error": "Error interno del servidor",
            "detail": str(exc) if get_settings().DEBUG else None
        }
    )


# ============================================================================
# Endpoints de Autenticación
# ============================================================================

@app.post("/auth/login")
async def login(credentials: dict):
    """Autentica un usuario y retorna token JWT."""
    username = credentials.get("username")
    password = credentials.get("password")
    method = credentials.get("method", "auto")
    
    if not username or not password:
        raise HTTPException(
            status_code=400,
            detail="Se requiere username y password"
        )
    
    success, result = await auth_manager.authenticate(username, password, method)
    
    if not success:
        raise HTTPException(
            status_code=401,
            detail=result.get("error", "Autenticación fallida")
        )
    
    # Log de auditoría
    await audit_logger.log_user_action(
        user_id=username,
        action="login",
        resource="auth",
        result="success"
    )
    
    return {
        "success": True,
        "token": result["token"],
        "user": result["user"],
        "expires_in": result["expires_in"]
    }


@app.post("/auth/logout")
async def logout(user: dict = Depends(get_current_user)):
    """Cierra sesión del usuario."""
    await auth_manager.logout(user["sub"])
    
    await audit_logger.log_user_action(
        user_id=user["sub"],
        action="logout",
        resource="auth",
        result="success"
    )
    
    return {"success": True, "message": "Sesión cerrada"}


@app.get("/auth/me")
async def get_current_user_info(user: dict = Depends(get_current_user)):
    """Obtiene información del usuario actual."""
    return {
        "username": user["sub"],
        "roles": user.get("roles", []),
        "department": user.get("department", "")
    }


# ============================================================================
# Endpoints del Agente (Chat)
# ============================================================================

@app.post("/api/chat")
async def chat(
    request: dict,
    user: dict = Depends(get_current_user)
):
    """
    Endpoint principal de chat con el agente.
    
    Request:
    {
        "message": "texto del usuario",
        "session_id": "opcional",
        "application_context": "opcional (ej: Ventas)",
        "channel": "api"
    }
    """
    message = request.get("message")
    session_id = request.get("session_id", f"session_{user['sub']}_{datetime.utcnow().timestamp()}")
    application_context = request.get("application_context")
    channel = request.get("channel", "api")
    
    if not message:
        raise HTTPException(status_code=400, detail="Se requiere message")
    
    # Procesar mensaje
    response = await agent.process_message(
        message=message,
        user_id=user["sub"],
        user_roles=user.get("roles", ["ingeniero"]),
        session_id=session_id,
        application_context=application_context,
        channel=channel
    )
    
    return response


@app.post("/api/chat/approve")
async def approve_request(
    request: dict,
    user: dict = Depends(require_permission(Permission.ADMIN_APPROVE.value))
):
    """Aprueba o rechaza una solicitud pendiente."""
    request_id = request.get("request_id")
    approved = request.get("approved", False)
    
    if not request_id:
        raise HTTPException(status_code=400, detail="Se requiere request_id")
    
    result = await agent.approve_request(request_id, user["sub"], approved)
    
    return result


# ============================================================================
# Endpoints de Skills
# ============================================================================

@app.get("/api/skills")
async def list_skills(
    category: str = None,
    application: str = None,
    user: dict = Depends(get_current_user)
):
    """Lista skills disponibles para el usuario."""
    skills = await agent.get_available_skills(
        user_roles=user.get("roles", ["ingeniero"]),
        application=application
    )
    
    if category:
        skills = [s for s in skills if s.get("category") == category]
    
    return {
        "success": True,
        "skills": skills,
        "count": len(skills)
    }


@app.get("/api/skills/{skill_name}")
async def get_skill_info(
    skill_name: str,
    user: dict = Depends(get_current_user)
):
    """Obtiene información de un skill específico."""
    registry = SkillRegistry()
    skill = registry.get(skill_name)
    
    if not skill:
        raise HTTPException(status_code=404, detail="Skill no encontrado")
    
    return {
        "success": True,
        "skill": skill.get_info()
    }


# ============================================================================
# Endpoints de Plugins
# ============================================================================

@app.get("/api/plugins")
async def list_plugins(user: dict = Depends(get_current_user)):
    """Lista plugins cargados."""
    registry = PluginRegistry()
    plugins = registry.list_all()
    
    return {
        "success": True,
        "plugins": plugins,
        "count": len(plugins)
    }


# ============================================================================
# Endpoints de Administración (RBAC)
# ============================================================================

@app.get("/api/admin/roles")
async def list_roles(
    user: dict = Depends(require_permission(Permission.ADMIN_ROLES.value))
):
    """Lista roles del sistema."""
    rbac = get_rbac_manager()
    return {
        "success": True,
        "roles": rbac.get_all_roles()
    }


@app.post("/api/admin/roles")
async def create_role(
    role_data: dict,
    user: dict = Depends(require_permission(Permission.ADMIN_ROLES.value))
):
    """Crea un nuevo rol."""
    from ...security.rbac.manager import Role
    
    rbac = get_rbac_manager()
    role = Role(
        name=role_data["name"],
        description=role_data.get("description", ""),
        permissions=set(role_data.get("permissions", [])),
        allowed_skills=role_data.get("allowed_skills", []),
        denied_skills=role_data.get("denied_skills", []),
        max_query_rows=role_data.get("max_query_rows", 100),
        requires_approval_for=role_data.get("requires_approval_for", [])
    )
    
    success = rbac.create_role(role)
    
    return {
        "success": success,
        "message": f"Rol '{role.name}' creado" if success else "Error creando rol"
    }


@app.post("/api/admin/users/{username}/roles")
async def assign_role(
    username: str,
    request: dict,
    user: dict = Depends(require_permission(Permission.ADMIN_USERS.value))
):
    """Asigna un rol a un usuario."""
    role_name = request.get("role")
    
    if not role_name:
        raise HTTPException(status_code=400, detail="Se requiere role")
    
    rbac = get_rbac_manager()
    success = rbac.assign_role_to_user(username, role_name)
    
    return {
        "success": success,
        "message": f"Rol '{role_name}' asignado a '{username}'"
    }


# ============================================================================
# Endpoints de Auditoría
# ============================================================================

@app.get("/api/admin/audit")
async def get_audit_trail(
    user_id: str = None,
    event_type: str = None,
    limit: int = 100,
    user: dict = Depends(require_permission(Permission.ADMIN_AUDIT.value))
):
    """Obtiene trail de auditoría."""
    entries = await audit_logger.get_audit_trail(
        user_id=user_id,
        event_type=event_type,
        limit=limit
    )
    
    return {
        "success": True,
        "entries": entries,
        "count": len(entries)
    }


# ============================================================================
# Endpoints de Configuración
# ============================================================================

@app.get("/api/config/applications")
async def list_applications(user: dict = Depends(get_current_user)):
    """Lista aplicaciones configuradas."""
    # TODO: Cargar desde configuración
    applications = [
        {
            "name": "Ventas",
            "description": "Sistema de ventas y facturación",
            "servers": ["VENTAS-APP01", "VENTAS-DB01"],
            "databases": ["VentasDB"]
        },
        {
            "name": "Telefonia",
            "description": "Sistema de recargas y telefonía",
            "servers": ["TEL-APP01", "TEL-DB01"],
            "databases": ["TelefoniaDB"]
        },
        {
            "name": "RRHH",
            "description": "Recursos Humanos y nómina",
            "servers": ["RRHH-APP01", "RRHH-DB01"],
            "databases": ["RRHHDB"]
        }
    ]
    
    return {
        "success": True,
        "applications": applications
    }


# ============================================================================
# Health Check
# ============================================================================

@app.get("/health")
async def health_check():
    """Health check del sistema."""
    return {
        "status": "healthy",
        "version": "1.0.0",
        "timestamp": datetime.utcnow().isoformat(),
        "components": {
            "agent": agent is not None,
            "auth": auth_manager is not None,
            "audit": audit_logger is not None
        }
    }


@app.get("/")
async def root():
    """Información básica del sistema."""
    return {
        "name": "ClawSphere AMS",
        "version": "1.0.0",
        "description": "Agente de IA empresarial para soporte L2/L3",
        "docs": "/docs"
    }


# ============================================================================
# Endpoints de Prometheus / Métricas
# ============================================================================

@app.get("/metrics")
async def get_prometheus_metrics():
    """Endpoint de métricas para Prometheus scraping."""
    exporter = get_metrics_exporter()
    from fastapi.responses import PlainTextResponse
    return PlainTextResponse(
        content=exporter.to_prometheus_format(),
        media_type="text/plain; version=0.0.4"
    )


@app.get("/api/metrics/snapshot")
async def get_metrics_snapshot(
    user: dict = Depends(get_current_user)
):
    """Obtener snapshot de métricas del sistema."""
    collector = get_metrics_collector()
    return {
        "success": True,
        "metrics": collector.get_metrics_snapshot()
    }


@app.get("/api/metrics/prometheus/query")
async def prometheus_query(
    query: str,
    user: dict = Depends(get_current_user)
):
    """Ejecutar query PromQL contra Prometheus."""
    settings = get_settings()
    
    if not settings.PROMETHEUS_URL:
        raise HTTPException(
            status_code=503,
            detail="Prometheus no configurado"
        )
    
    client = PrometheusClient(settings.PROMETHEUS_URL)
    try:
        result = await client.query(query)
        return {"success": True, "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        await client.close()


@app.get("/api/metrics/prometheus/alerts")
async def get_prometheus_alerts(
    severity: str = None,
    user: dict = Depends(get_current_user)
):
    """Obtener alertas activas de Prometheus."""
    settings = get_settings()
    
    if not settings.PROMETHEUS_URL:
        raise HTTPException(
            status_code=503,
            detail="Prometheus no configurado"
        )
    
    client = PrometheusClient(settings.PROMETHEUS_URL)
    try:
        result = await client.get_alerts()
        alerts = result.get('data', {}).get('alerts', [])
        
        if severity:
            alerts = [a for a in alerts 
                     if a.get('labels', {}).get('severity') == severity]
        
        return {"success": True, "alerts": alerts, "count": len(alerts)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        await client.close()


# ============================================================================
# Endpoints de Alertas
# ============================================================================

@app.get("/api/alerts/rules")
async def list_alert_rules(
    category: str = None,
    severity: str = None,
    user: dict = Depends(get_current_user)
):
    """Listar reglas de alerta configuradas."""
    alert_manager = get_alert_manager()
    
    sev = None
    if severity:
        try:
            sev = AlertSeverity(severity.lower())
        except ValueError:
            pass
    
    rules = alert_manager.list_rules(category=category, severity=sev)
    
    return {
        "success": True,
        "rules": [
            {
                "name": r.name,
                "expr": r.expr,
                "duration": r.duration,
                "severity": r.severity.value,
                "summary": r.summary,
                "description": r.description,
                "labels": r.labels,
                "enabled": r.enabled
            }
            for r in rules
        ],
        "count": len(rules)
    }


@app.get("/api/alerts/active")
async def get_active_alerts(
    severity: str = None,
    user: dict = Depends(get_current_user)
):
    """Obtener alertas activas."""
    alert_manager = get_alert_manager()
    
    sev = None
    if severity:
        try:
            sev = AlertSeverity(severity.lower())
        except ValueError:
            pass
    
    alerts = alert_manager.get_active_alerts(severity=sev)
    
    return {
        "success": True,
        "alerts": [a.to_dict() for a in alerts],
        "count": len(alerts)
    }


@app.post("/api/alerts/silences")
async def create_silence(
    request: dict,
    user: dict = Depends(require_permission(Permission.ADMIN_ALERTS.value))
):
    """Crear silencio de alerta."""
    alert_manager = get_alert_manager()
    
    silence_id = await alert_manager.create_silence(
        matchers=request.get("matchers", {}),
        duration_minutes=request.get("duration_minutes", 60),
        created_by=user["sub"],
        comment=request.get("comment", "")
    )
    
    if silence_id:
        return {
            "success": True,
            "silence_id": silence_id,
            "message": "Silencio creado correctamente"
        }
    else:
        raise HTTPException(
            status_code=500,
            detail="Error creando silencio"
        )


@app.get("/api/alerts/silences")
async def get_silences(
    user: dict = Depends(get_current_user)
):
    """Obtener silencios activos."""
    alert_manager = get_alert_manager()
    silences = await alert_manager.get_silences()
    
    return {
        "success": True,
        "silences": silences
    }


@app.delete("/api/alerts/silences/{silence_id}")
async def delete_silence(
    silence_id: str,
    user: dict = Depends(require_permission(Permission.ADMIN_ALERTS.value))
):
    """Eliminar silencio."""
    alert_manager = get_alert_manager()
    success = await alert_manager.delete_silence(silence_id)
    
    return {
        "success": success,
        "message": "Silencio eliminado" if success else "Error eliminando silencio"
    }
