"""Rutas de la API REST"""
from typing import Optional
from datetime import datetime
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()

class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None
    application_context: Optional[str] = None

class ChatResponse(BaseModel):
    response: str
    session_id: str
    confidence: float

@router.get("/")
async def root():
    return {"message": "ClawSphere AMS API v1"}

@router.get("/health")
async def health():
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

@router.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """Chat con el agente de IA"""
    # Integración simple con Ollama
    try:
        import httpx
        from core.config import settings
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{settings.AI_OLLAMA_BASE_URL}/api/generate",
                json={
                    "model": settings.AI_OLLAMA_MODEL,
                    "prompt": request.message,
                    "stream": False
                },
                timeout=60.0
            )
            
            if response.status_code == 200:
                data = response.json()
                return ChatResponse(
                    response=data.get("response", "Sin respuesta"),
                    session_id=request.session_id or "new",
                    confidence=0.9
                )
            else:
                return ChatResponse(
                    response=f"Error: {response.status_code}",
                    session_id=request.session_id or "new",
                    confidence=0.0
                )
    except Exception as e:
        return ChatResponse(
            response=f"Error: {str(e)}",
            session_id=request.session_id or "new",
            confidence=0.0
        )

@router.get("/incidents")
async def list_incidents():
    return {"incidents": []}

@router.get("/servers")
async def list_servers():
    return {"servers": []}
