"""API REST"""
from .routes import router
from fastapi import APIRouter

def create_rest_api() -> APIRouter:
    api = APIRouter()
    api.include_router(router, prefix="/api/v1")
    return api
