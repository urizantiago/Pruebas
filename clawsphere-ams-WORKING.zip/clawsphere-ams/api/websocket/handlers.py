"""
Handlers de WebSocket

Gestiona conexiones WebSocket para comunicación en tiempo real.
"""

import json
import logging
from typing import Dict, Set
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

logger = logging.getLogger(__name__)
router = APIRouter()

# Almacenar conexiones activas
class ConnectionManager:
    """Gestiona conexiones WebSocket activas."""
    
    def __init__(self):
        self.active_connections: Dict[str, Set[WebSocket]] = {}
        self.user_connections: Dict[str, WebSocket] = {}
    
    async def connect(self, websocket: WebSocket, client_id: str, room: str = "general"):
        """Acepta una nueva conexión WebSocket."""
        await websocket.accept()
        
        if room not in self.active_connections:
            self.active_connections[room] = set()
        
        self.active_connections[room].add(websocket)
        self.user_connections[client_id] = websocket
        
        logger.info(f"WebSocket connected: {client_id} in room {room}")
    
    def disconnect(self, websocket: WebSocket, client_id: str, room: str = "general"):
        """Desconecta un WebSocket."""
        if room in self.active_connections:
            self.active_connections[room].discard(websocket)
        
        self.user_connections.pop(client_id, None)
        
        logger.info(f"WebSocket disconnected: {client_id} from room {room}")
    
    async def send_personal_message(self, message: dict, websocket: WebSocket):
        """Envía un mensaje a un cliente específico."""
        await websocket.send_json(message)
    
    async def broadcast(self, message: dict, room: str = "general"):
        """Envía un mensaje a todos los clientes de una sala."""
        if room in self.active_connections:
            disconnected = []
            for connection in self.active_connections[room]:
                try:
                    await connection.send_json(message)
                except Exception:
                    disconnected.append(connection)
            
            # Limpiar conexiones rotas
            for conn in disconnected:
                self.active_connections[room].discard(conn)
    
    async def broadcast_to_all(self, message: dict):
        """Envía un mensaje a todos los clientes conectados."""
        for room in self.active_connections:
            await self.broadcast(message, room)
    
    def get_connection_count(self, room: str = None) -> int:
        """Obtiene el número de conexiones activas."""
        if room:
            return len(self.active_connections.get(room, set()))
        return sum(len(conns) for conns in self.active_connections.values())


# Instancia global del gestor de conexiones
manager = ConnectionManager()


@router.websocket("/chat/{client_id}")
async def websocket_chat(websocket: WebSocket, client_id: str):
    """
    WebSocket para chat en tiempo real con el agente.
    
    Args:
        websocket: Conexión WebSocket
        client_id: ID único del cliente
    """
    await manager.connect(websocket, client_id, room="chat")
    
    try:
        # Enviar mensaje de bienvenida
        await manager.send_personal_message({
            "type": "system",
            "message": "Connected to ClawSphere AMS",
            "client_id": client_id
        }, websocket)
        
        while True:
            # Recibir mensaje del cliente
            data = await websocket.receive_text()
            
            try:
                message = json.loads(data)
                msg_type = message.get("type", "message")
                content = message.get("content", "")
                
                logger.debug(f"Received {msg_type} from {client_id}: {content}")
                
                if msg_type == "message":
                    # Procesar mensaje con el agente
                    # TODO: Integrar con el orquestador real
                    response = {
                        "type": "response",
                        "content": f"Echo: {content}",
                        "actions": [],
                        "confidence": 0.95
                    }
                    
                    await manager.send_personal_message(response, websocket)
                
                elif msg_type == "ping":
                    await manager.send_personal_message({
                        "type": "pong",
                        "timestamp": message.get("timestamp")
                    }, websocket)
                
                elif msg_type == "typing":
                    # Notificar a otros que el usuario está escribiendo
                    await manager.broadcast({
                        "type": "typing",
                        "client_id": client_id
                    }, room="chat")
                    
            except json.JSONDecodeError:
                await manager.send_personal_message({
                    "type": "error",
                    "message": "Invalid JSON format"
                }, websocket)
                
    except WebSocketDisconnect:
        manager.disconnect(websocket, client_id, room="chat")


@router.websocket("/events/{client_id}")
async def websocket_events(websocket: WebSocket, client_id: str):
    """
    WebSocket para recibir eventos del sistema en tiempo real.
    
    Args:
        websocket: Conexión WebSocket
        client_id: ID único del cliente
    """
    await manager.connect(websocket, client_id, room="events")
    
    try:
        # Suscribirse a eventos del sistema
        from core.events import event_bus
        
        async def event_handler(event):
            await manager.send_personal_message({
                "type": "event",
                "event_type": event.type,
                "data": event.data,
                "timestamp": event.timestamp.isoformat()
            }, websocket)
        
        # Suscribir a todos los eventos
        event_bus.subscribe("*", event_handler)
        
        await manager.send_personal_message({
            "type": "system",
            "message": "Subscribed to system events"
        }, websocket)
        
        while True:
            # Mantener conexión viva
            data = await websocket.receive_text()
            message = json.loads(data)
            
            if message.get("type") == "ping":
                await manager.send_personal_message({
                    "type": "pong"
                }, websocket)
                
    except WebSocketDisconnect:
        manager.disconnect(websocket, client_id, room="events")
    except Exception as e:
        logger.error(f"Error in events WebSocket: {e}")
        manager.disconnect(websocket, client_id, room="events")


@router.websocket("/monitoring/{client_id}")
async def websocket_monitoring(websocket: WebSocket, client_id: str):
    """
    WebSocket para monitoreo en tiempo real.
    
    Envía métricas y estado del sistema periódicamente.
    
    Args:
        websocket: Conexión WebSocket
        client_id: ID único del cliente
    """
    await manager.connect(websocket, client_id, room="monitoring")
    
    import asyncio
    
    try:
        await manager.send_personal_message({
            "type": "system",
            "message": "Connected to monitoring stream"
        }, websocket)
        
        while True:
            # Enviar métricas cada 5 segundos
            # TODO: Integrar con métricas reales
            metrics = {
                "type": "metrics",
                "cpu_usage": 45.2,
                "memory_usage": 67.8,
                "active_connections": manager.get_connection_count(),
                "timestamp": logging.time.time() if hasattr(logging, 'time') else 0
            }
            
            await manager.send_personal_message(metrics, websocket)
            
            # Esperar antes de enviar siguiente actualización
            await asyncio.sleep(5)
            
    except WebSocketDisconnect:
        manager.disconnect(websocket, client_id, room="monitoring")
    except Exception as e:
        logger.error(f"Error in monitoring WebSocket: {e}")
        manager.disconnect(websocket, client_id, room="monitoring")


@router.get("/connections")
async def get_connections():
    """Obtiene información de conexiones activas."""
    return {
        "total_connections": manager.get_connection_count(),
        "rooms": {
            room: len(connections)
            for room, connections in manager.active_connections.items()
        }
    }
