"""
WebSocket API de ClawSphere AMS
"""

from fastapi import APIRouter
from .handlers import router


def create_websocket_router() -> APIRouter:
    """Crea y configura el router de WebSocket."""
    ws_router = APIRouter()
    ws_router.include_router(router)
    return ws_router


__all__ = ['create_websocket_router', 'router']
