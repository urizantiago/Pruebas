# ClawSphere AMS - Ejemplos de Uso

## Autenticación

### Login
```bash
curl -X POST http://localhost:7550/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "password123"
  }'
```

Respuesta:
```json
{
  "success": true,
  "token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "user": {
    "username": "admin",
    "roles": ["admin"],
    "display_name": "Administrator"
  },
  "expires_in": 28800
}
```

## Chat con el Agente

### Estado de Servidor
```bash
curl -X POST http://localhost:7550/api/chat \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "message": "estado del servidor VENTAS-APP01",
    "application_context": "Ventas"
  }'
```

### Consultar Logs
```bash
curl -X POST http://localhost:7550/api/chat \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "message": "logs del servidor WEB01 últimas 50 líneas",
    "application_context": "Ventas"
  }'
```

### Query a Base de Datos
```bash
curl -X POST http://localhost:7550/api/chat \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "message": "consulta en VentasDB: SELECT TOP 10 * FROM Clientes ORDER BY FechaRegistro DESC",
    "application_context": "Ventas"
  }'
```

### Performance de Base de Datos
```bash
curl -X POST http://localhost:7550/api/chat \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "message": "performance de la base de datos TelefoniaDB",
    "application_context": "Telefonia"
  }'
```

### Bloqueos en BD
```bash
curl -X POST http://localhost:7550/api/chat \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "message": "verificar bloqueos en VentasDB",
    "application_context": "Ventas"
  }'
```

### Probar API
```bash
curl -X POST http://localhost:7550/api/chat \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "message": "probar API https://api.ventas.com/health",
    "application_context": "Ventas"
  }'
```

### Verificar Certificado SSL
```bash
curl -X POST http://localhost:7550/api/chat \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "message": "verificar certificado SSL de api.ventas.com"
  }'
```

### Decodificar JWT
```bash
curl -X POST http://localhost:7550/api/chat \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "message": "decodificar token JWT eyJ0eXAiOiJKV1QiLCJhbGc..."
  }'
```

### Test de Conectividad
```bash
curl -X POST http://localhost:7550/api/chat \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "message": "test de conectividad a dbserver.ventas.com puerto 1433"
  }'
```

### Dashboard de Monitoreo
```bash
curl -X POST http://localhost:7550/api/chat \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "message": "mostrar dashboard de monitoreo",
    "application_context": "Ventas"
  }'
```

### Listar Alertas
```bash
curl -X POST http://localhost:7550/api/chat \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "message": "mostrar alertas críticas",
    "application_context": "Ventas"
  }'
```

## Administración

### Listar Skills
```bash
curl -X GET http://localhost:7550/api/skills \
  -H "Authorization: Bearer $TOKEN"
```

### Listar Plugins
```bash
curl -X GET http://localhost:7550/api/plugins \
  -H "Authorization: Bearer $TOKEN"
```

### Listar Roles
```bash
curl -X GET http://localhost:7550/api/admin/roles \
  -H "Authorization: Bearer $TOKEN"
```

### Asignar Rol a Usuario
```bash
curl -X POST http://localhost:7550/api/admin/users/juan.perez/roles \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "role": "ingeniero"
  }'
```

### Ver Trail de Auditoría
```bash
curl -X GET "http://localhost:7550/api/admin/audit?limit=50" \
  -H "Authorization: Bearer $TOKEN"
```

### Aprobar Solicitud
```bash
curl -X POST http://localhost:7550/api/chat/approve \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "request_id": "req_20240115103045000000",
    "approved": true
  }'
```

## Aplicaciones

### Listar Aplicaciones
```bash
curl -X GET http://localhost:7550/api/config/applications \
  -H "Authorization: Bearer $TOKEN"
```

## Health Check

```bash
curl http://localhost:7550/health
```

## Uso con Python

```python
import requests

# Login
response = requests.post("http://localhost:7550/auth/login", json={
    "username": "admin",
    "password": "password123"
})
token = response.json()["token"]

# Headers
headers = {"Authorization": f"Bearer {token}"}

# Chat
response = requests.post(
    "http://localhost:7550/api/chat",
    headers=headers,
    json={
        "message": "estado del servidor VENTAS-APP01",
        "application_context": "Ventas"
    }
)
print(response.json())
```

## Uso con JavaScript/Node.js

```javascript
const axios = require('axios');

async function main() {
    // Login
    const login = await axios.post('http://localhost:7550/auth/login', {
        username: 'admin',
        password: 'password123'
    });
    const token = login.data.token;
    
    // Chat
    const response = await axios.post(
        'http://localhost:7550/api/chat',
        {
            message: 'estado del servidor VENTAS-APP01',
            application_context: 'Ventas'
        },
        {
            headers: { Authorization: `Bearer ${token}` }
        }
    );
    console.log(response.data);
}

main();
```
