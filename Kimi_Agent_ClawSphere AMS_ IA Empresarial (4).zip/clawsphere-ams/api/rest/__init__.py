"""
API REST de ClawSphere AMS
"""

from fastapi import APIRouter
from .routes import router


def create_rest_api() -> APIRouter:
    """Crea y configura el router de la API REST."""
    api_router = APIRouter()
    api_router.include_router(router)
    return api_router


__all__ = ['create_rest_api', 'router']
