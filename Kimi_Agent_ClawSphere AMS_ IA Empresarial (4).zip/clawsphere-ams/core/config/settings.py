"""
Configuración de la aplicación ClawSphere AMS
"""

import os
from typing import List, Optional
from pydantic import Field
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Configuración de la aplicación."""
    
    # App
    APP_NAME: str = "ClawSphere AMS"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = Field(default=False, env="CLAWSPHERE_DEBUG")
    HOST: str = Field(default="0.0.0.0", env="CLAWSPHERE_HOST")
    PORT: int = Field(default=7550, env="CLAWSPHERE_PORT")
    
    # Security
    SECRET_KEY: str = Field(default="change-me-in-production", env="CLAWSPHERE_SECURITY_SECRET_KEY")
    ENCRYPTION_KEY: str = Field(default="change-me-in-production-32-chars!!", env="CLAWSPHERE_SECURITY_ENCRYPTION_KEY")
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    
    # LDAP (Optional)
    LDAP_SERVER: Optional[str] = Field(default=None, env="CLAWSPHERE_SECURITY_LDAP_SERVER")
    LDAP_BIND_DN: Optional[str] = Field(default=None, env="CLAWSPHERE_SECURITY_LDAP_BIND_DN")
    LDAP_BIND_PASSWORD: Optional[str] = Field(default=None, env="CLAWSPHERE_SECURITY_LDAP_BIND_PASSWORD")
    LDAP_BASE_DN: Optional[str] = Field(default=None, env="CLAWSPHERE_SECURITY_LDAP_BASE_DN")
    
    # Database
    DATABASE_URL: str = Field(
        default="sqlite+aiosqlite:///data/clawsphere.db",
        env="CLAWSPHERE_DATABASE_URL"
    )
    DATABASE_POOL_SIZE: int = 5
    DATABASE_MAX_OVERFLOW: int = 10
    
    # Redis
    REDIS_URL: str = Field(default="redis://localhost:6379/0", env="CLAWSPHERE_REDIS_URL")
    
    # AI Providers
    AI_DEFAULT_PROVIDER: str = Field(default="ollama", env="CLAWSPHERE_AI_DEFAULT_PROVIDER")
    AI_FALLBACK_PROVIDERS: List[str] = Field(default=["openai"], env="CLAWSPHERE_AI_FALLBACK_PROVIDERS")
    
    # Ollama
    AI_OLLAMA_BASE_URL: str = Field(default="http://localhost:11434", env="CLAWSPHERE_AI_OLLAMA_BASE_URL")
    AI_OLLAMA_MODEL: str = Field(default="qwen2.5-coder:14b", env="CLAWSPHERE_AI_OLLAMA_MODEL")
    AI_OLLAMA_TIMEOUT: int = 120
    
    # OpenAI
    AI_OPENAI_API_KEY: Optional[str] = Field(default=None, env="CLAWSPHERE_AI_OPENAI_API_KEY")
    AI_OPENAI_MODEL: str = Field(default="gpt-4", env="CLAWSPHERE_AI_OPENAI_MODEL")
    
    # Anthropic
    AI_ANTHROPIC_API_KEY: Optional[str] = Field(default=None, env="CLAWSPHERE_AI_ANTHROPIC_API_KEY")
    AI_ANTHROPIC_MODEL: str = Field(default="claude-3-opus-20240229", env="CLAWSPHERE_AI_ANTHROPIC_MODEL")
    
    # Google
    AI_GOOGLE_API_KEY: Optional[str] = Field(default=None, env="CLAWSPHERE_AI_GOOGLE_API_KEY")
    AI_GOOGLE_MODEL: str = Field(default="gemini-pro", env="CLAWSPHERE_AI_GOOGLE_MODEL")
    
    # DeepSeek
    AI_DEEPSEEK_API_KEY: Optional[str] = Field(default=None, env="CLAWSPHERE_AI_DEEPSEEK_API_KEY")
    AI_DEEPSEEK_MODEL: str = Field(default="deepseek-chat", env="CLAWSPHERE_AI_DEEPSEEK_MODEL")
    
    # LM Studio
    AI_LMSTUDIO_BASE_URL: str = Field(default="http://localhost:1234/v1", env="CLAWSPHERE_AI_LMSTUDIO_BASE_URL")
    
    # GPT4All
    AI_GPT4ALL_MODEL_PATH: Optional[str] = Field(default=None, env="CLAWSPHERE_AI_GPT4ALL_MODEL_PATH")
    
    # vLLM
    AI_VLLM_BASE_URL: str = Field(default="http://localhost:8000/v1", env="CLAWSPHERE_AI_VLLM_BASE_URL")
    
    # Prometheus
    PROMETHEUS_ENABLED: bool = Field(default=True, env="CLAWSPHERE_PROMETHEUS_ENABLED")
    PROMETHEUS_PORT: int = Field(default=9090, env="CLAWSPHERE_PROMETHEUS_PORT")
    
    # Alerting
    ALERT_ENABLED: bool = Field(default=True, env="CLAWSPHERE_ALERT_ENABLED")
    ALERT_CHANNELS: List[str] = Field(default=["teams", "telegram"], env="CLAWSPHERE_ALERT_CHANNELS")
    
    # Teams
    ALERT_TEAMS_APP_ID: Optional[str] = Field(default=None, env="CLAWSPHERE_MSG_TEAMS_APP_ID")
    ALERT_TEAMS_APP_PASSWORD: Optional[str] = Field(default=None, env="CLAWSPHERE_MSG_TEAMS_APP_PASSWORD")
    
    # Telegram
    ALERT_TELEGRAM_BOT_TOKEN: Optional[str] = Field(default=None, env="CLAWSPHERE_MSG_TELEGRAM_BOT_TOKEN")
    ALERT_TELEGRAM_CHAT_ID: Optional[str] = Field(default=None, env="CLAWSPHERE_MSG_TELEGRAM_CHAT_ID")
    
    # WhatsApp (Twilio)
    ALERT_TWILIO_ACCOUNT_SID: Optional[str] = Field(default=None, env="CLAWSPHERE_MSG_TWILIO_ACCOUNT_SID")
    ALERT_TWILIO_AUTH_TOKEN: Optional[str] = Field(default=None, env="CLAWSPHERE_MSG_TWILIO_AUTH_TOKEN")
    ALERT_TWILIO_PHONE_NUMBER: Optional[str] = Field(default=None, env="CLAWSPHERE_MSG_TWILIO_PHONE_NUMBER")
    
    # Multi-tenant
    MULTI_TENANT_ENABLED: bool = Field(default=False, env="CLAWSPHERE_MULTI_TENANT_ENABLED")
    DEFAULT_TENANT_ID: str = "default"
    
    # Workflow
    WORKFLOW_ENABLED: bool = True
    WORKFLOW_MAX_CONCURRENT: int = 10
    
    # Auto-remediation
    AUTO_REMEDIATION_ENABLED: bool = Field(default=True, env="CLAWSPHERE_AUTO_REMEDIATION_ENABLED")
    AUTO_REMEDIATION_REQUIRE_APPROVAL: bool = True
    
    # ML
    ML_ENABLED: bool = Field(default=True, env="CLAWSPHERE_ML_ENABLED")
    ML_MODEL_PATH: str = Field(default="data/models", env="CLAWSPHERE_ML_MODEL_PATH")
    
    # Plugins
    PLUGINS_ENABLED: bool = True
    PLUGINS_DIR: str = "plugins"
    
    # Backup
    BACKUP_ENABLED: bool = True
    BACKUP_DIR: str = "data/backups"
    BACKUP_RETENTION_DAYS: int = 30
    
    # CORS
    CORS_ORIGINS: List[str] = Field(default=["*"], env="CLAWSPHERE_CORS_ORIGINS")
    
    # Logging
    LOG_LEVEL: str = Field(default="INFO", env="CLAWSPHERE_LOG_LEVEL")
    LOG_FILE: str = "logs/clawsphere.log"
    LOG_MAX_BYTES: int = 10 * 1024 * 1024  # 10MB
    LOG_BACKUP_COUNT: int = 10
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


# Instancia global de configuración
settings = Settings()
