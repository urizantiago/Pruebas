"""
Bus de Eventos Asíncrono

Sistema de publicación/suscripción para eventos del sistema.
"""

import asyncio
import logging
from typing import Any, Callable, Dict, List, Optional
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class Event:
    """Representa un evento del sistema."""
    type: str
    data: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    source: Optional[str] = None
    tenant_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convierte el evento a diccionario."""
        return {
            "type": self.type,
            "data": self.data,
            "timestamp": self.timestamp.isoformat(),
            "source": self.source,
            "tenant_id": self.tenant_id
        }


class EventBus:
    """
    Bus de eventos asíncrono para comunicación entre componentes.
    
    Patrón publish/subscribe que permite desacoplar componentes.
    """
    
    def __init__(self):
        self._subscribers: Dict[str, List[Callable]] = {}
        self._event_queue: asyncio.Queue = asyncio.Queue()
        self._running: bool = False
        self._processor_task: Optional[asyncio.Task] = None
        logger.info("EventBus initialized")
    
    async def start(self):
        """Inicia el procesador de eventos."""
        if not self._running:
            self._running = True
            self._processor_task = asyncio.create_task(self._process_events())
            logger.info("EventBus started")
    
    async def stop(self):
        """Detiene el procesador de eventos."""
        self._running = False
        if self._processor_task:
            self._processor_task.cancel()
            try:
                await self._processor_task
            except asyncio.CancelledError:
                pass
        logger.info("EventBus stopped")
    
    def subscribe(self, event_type: str, callback: Callable) -> None:
        """
        Suscribe un callback a un tipo de evento.
        
        Args:
            event_type: Tipo de evento a escuchar
            callback: Función a llamar cuando ocurra el evento
        """
        if event_type not in self._subscribers:
            self._subscribers[event_type] = []
        self._subscribers[event_type].append(callback)
        logger.debug(f"Subscribed to event: {event_type}")
    
    def unsubscribe(self, event_type: str, callback: Callable) -> bool:
        """
        Desuscribe un callback de un tipo de evento.
        
        Args:
            event_type: Tipo de evento
            callback: Función a desuscribir
            
        Returns:
            True si se encontró y removió el callback
        """
        if event_type in self._subscribers:
            try:
                self._subscribers[event_type].remove(callback)
                logger.debug(f"Unsubscribed from event: {event_type}")
                return True
            except ValueError:
                pass
        return False
    
    async def publish(self, event: Event) -> None:
        """
        Publica un evento en el bus.
        
        Args:
            event: Evento a publicar
        """
        await self._event_queue.put(event)
        logger.debug(f"Event published: {event.type}")
    
    async def publish_sync(self, event_type: str, data: Dict[str, Any], **kwargs) -> None:
        """
        Publica un evento de forma síncrona (crea el Event automáticamente).
        
        Args:
            event_type: Tipo de evento
            data: Datos del evento
            **kwargs: Campos adicionales del Event
        """
        event = Event(type=event_type, data=data, **kwargs)
        await self.publish(event)
    
    async def _process_events(self):
        """Procesa eventos de la cola."""
        while self._running:
            try:
                event = await asyncio.wait_for(
                    self._event_queue.get(),
                    timeout=1.0
                )
                await self._dispatch_event(event)
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Error processing event: {e}")
    
    async def _dispatch_event(self, event: Event):
        """Despacha un evento a todos los suscriptores."""
        callbacks = self._subscribers.get(event.type, [])
        
        # También despachar a suscriptores de "*" (todos los eventos)
        callbacks.extend(self._subscribers.get("*", []))
        
        for callback in callbacks:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(event)
                else:
                    callback(event)
            except Exception as e:
                logger.error(f"Error in event handler for {event.type}: {e}")
    
    def get_subscriber_count(self, event_type: Optional[str] = None) -> int:
        """
        Obtiene el número de suscriptores.
        
        Args:
            event_type: Tipo de evento específico, o None para todos
            
        Returns:
            Número de suscriptores
        """
        if event_type:
            return len(self._subscribers.get(event_type, []))
        return sum(len(subs) for subs in self._subscribers.values())


# Instancia global del bus de eventos
event_bus = EventBus()
