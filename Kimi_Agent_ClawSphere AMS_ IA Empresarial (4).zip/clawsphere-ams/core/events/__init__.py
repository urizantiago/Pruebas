"""
Sistema de Eventos de ClawSphere AMS
"""

from .bus import EventBus, event_bus

__all__ = ['EventBus', 'event_bus']
