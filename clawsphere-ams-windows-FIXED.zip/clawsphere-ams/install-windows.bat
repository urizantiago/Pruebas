@echo off
chcp 65001 >nul
title ClawSphere AMS - Instalador para Windows

echo ============================================
echo   CLAWSPHERE AMS - Instalador para Windows
echo ============================================
echo.

REM Verificar Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python no encontrado.
    echo Por favor instala Python 3.9+ desde https://python.org
    echo Asegurate de marcar "Add Python to PATH"
    pause
    exit /b 1
)

echo [OK] Python detectado:
python --version
echo.

REM Verificar pip
pip --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] pip no encontrado.
    pause
    exit /b 1
)

echo [OK] pip detectado
echo.

REM Crear entorno virtual
echo [1/6] Creando entorno virtual...
if exist "venv" (
    echo      Entorno virtual ya existe. Saltando...
) else (
    python -m venv venv
    if errorlevel 1 (
        echo [ERROR] No se pudo crear el entorno virtual
        pause
        exit /b 1
    )
    echo [OK] Entorno virtual creado
)
echo.

REM Activar entorno virtual
echo [2/6] Activando entorno virtual...
call venv\Scripts\activate
if errorlevel 1 (
    echo [ERROR] No se pudo activar el entorno virtual
    pause
    exit /b 1
)
echo [OK] Entorno virtual activado
echo.

REM Actualizar pip
echo [3/6] Actualizando pip...
python -m pip install --upgrade pip -q
if errorlevel 1 (
    echo [WARNING] No se pudo actualizar pip, continuando...
) else (
    echo [OK] pip actualizado
)
echo.

REM Instalar wheel y setuptools
echo [4/6] Instalando herramientas base...
pip install wheel setuptools -q
if errorlevel 1 (
    echo [WARNING] Error instalando wheel/setuptools, continuando...
)
echo [OK] Herramientas base instaladas
echo.

REM Instalar dependencias
echo [5/6] Instalando dependencias (esto puede tomar varios minutos)...
pip install -r requirements-windows.txt
if errorlevel 1 (
    echo [ERROR] Error instalando dependencias
    pause
    exit /b 1
)
echo [OK] Dependencias instaladas
echo.

REM Crear directorios
echo [6/6] Creando estructura de directorios...
if not exist "data" mkdir data
if not exist "logs" mkdir logs
if not exist "plugins" mkdir plugins
if not exist "data\models" mkdir data\models
if not exist "data\backups" mkdir data\backups
echo [OK] Directorios creados
echo.

REM Crear archivo .env si no existe
echo Verificando configuracion...
if not exist ".env" (
    if exist ".env.example" (
        copy .env.example .env >nul
        echo [OK] Archivo .env creado desde .env.example
        echo.
        echo ============================================
        echo   IMPORTANTE: Edita el archivo .env
        echo ============================================
        echo.
        echo Antes de iniciar el servidor, edita el archivo .env:
        echo.
        echo   notepad .env
        echo.
        echo Cambia al menos estas variables:
        echo   - CLAWSPHERE_SECURITY_SECRET_KEY
        echo   - CLAWSPHERE_SECURITY_ENCRYPTION_KEY
        echo   - CLAWSPHERE_AI_DEFAULT_PROVIDER (ollama u openai)
        echo.
    ) else (
        echo [WARNING] No se encontro .env.example
    )
) else (
    echo [OK] Archivo .env ya existe
)
echo.

REM Verificar instalacion
echo ============================================
echo   Verificando instalacion...
echo ============================================
echo.

python tests\test_windows_setup.py
if errorlevel 1 (
    echo.
    echo [WARNING] Algunos tests fallaron.
    echo Revisa los errores arriba.
    echo.
)

echo.
echo ============================================
echo   INSTALACION COMPLETADA
echo ============================================
echo.
echo Para iniciar ClawSphere AMS:
echo.
echo   1. Activa el entorno virtual:
echo      venv\Scripts\activate
echo.
echo   2. Inicia el servidor:
echo      python main.py
echo.
echo   3. Abre en navegador:
echo      http://localhost:7550/docs
echo.
echo ============================================
echo.

pause
