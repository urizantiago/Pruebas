@echo off
chcp 65001 >nul
title ClawSphere AMS

echo ============================================
echo   CLAWSPHERE AMS - Iniciando Servidor
echo ============================================
echo.

REM Verificar entorno virtual
if not exist "venv\Scripts\activate" (
    echo [ERROR] Entorno virtual no encontrado.
    echo Ejecuta primero: install-windows.bat
    pause
    exit /b 1
)

REM Activar entorno virtual
call venv\Scripts\activate
if errorlevel 1 (
    echo [ERROR] No se pudo activar el entorno virtual
    pause
    exit /b 1
)

echo [OK] Entorno virtual activado
echo.

REM Verificar .env
if not exist ".env" (
    echo [ERROR] Archivo .env no encontrado.
    echo Copia .env.example a .env y configuralo:
    echo   copy .env.example .env
    echo   notepad .env
    pause
    exit /b 1
)

REM Crear directorios si no existen
if not exist "data" mkdir data
if not exist "logs" mkdir logs
if not exist "plugins" mkdir plugins

echo [OK] Directorios verificados
echo.

REM Verificar Ollama si está configurado
for /f "tokens=2 delims==" %%a in ('findstr /B "CLAWSPHERE_AI_DEFAULT_PROVIDER" .env') do (
    set PROVIDER=%%a
)

echo Configuracion detectada:
echo   - Proveedor IA: %PROVIDER%
echo.

if "%PROVIDER%"=="ollama" (
    echo Verificando Ollama...
    curl -s http://localhost:11434/api/tags >nul 2>&1
    if errorlevel 1 (
        echo [WARNING] Ollama no responde en http://localhost:11434
        echo Asegurate de que Ollama este ejecutandose.
        echo.
        echo Para iniciar Ollama:
        echo   1. Abre otra terminal
        echo   2. Ejecuta: ollama serve
        echo   3. Deja esa terminal abierta
        echo   4. Vuelve a ejecutar este script
        echo.
        choice /C SN /M "Deseas continuar de todos modos"
        if errorlevel 2 exit /b 1
    ) else (
        echo [OK] Ollama detectado
    )
)
echo.

REM Iniciar servidor
echo ============================================
echo   Iniciando servidor...
echo ============================================
echo.
echo La API estara disponible en:
echo   http://localhost:7550
echo.
echo Documentacion:
echo   http://localhost:7550/docs
echo.
echo Presiona Ctrl+C para detener
echo.

python main.py

if errorlevel 1 (
    echo.
    echo [ERROR] El servidor se detuvo con errores
    echo Revisa los logs en: logs\clawsphere.log
    pause
)
