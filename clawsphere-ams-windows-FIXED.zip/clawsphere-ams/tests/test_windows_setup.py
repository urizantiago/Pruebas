#!/usr/bin/env python3
"""
Tests de funcionamiento para instalación en Windows
Verifica que todos los componentes estén correctamente configurados
"""

import sys
import os
import subprocess
import importlib
from pathlib import Path


def print_header(text):
    print("\n" + "=" * 60)
    print(f"  {text}")
    print("=" * 60)


def print_result(test_name, success, message=""):
    status = "✅ PASS" if success else "❌ FAIL"
    print(f"  {status} - {test_name}")
    if message:
        print(f"       {message}")
    return success


def test_python_version():
    """Test 1: Verificar versión de Python"""
    print_header("TEST 1: Versión de Python")
    
    version = sys.version_info
    print(f"  Python version: {version.major}.{version.minor}.{version.micro}")
    
    if version.major >= 3 and version.minor >= 9:
        return print_result("Python >= 3.9", True)
    else:
        return print_result("Python >= 3.9", False, 
            f"Se requiere Python 3.9+. Tienes {version.major}.{version.minor}")


def test_pip():
    """Test 2: Verificar pip"""
    print_header("TEST 2: pip instalado")
    
    try:
        result = subprocess.run([sys.executable, "-m", "pip", "--version"], 
            capture_output=True, text=True)
        if result.returncode == 0:
            print(f"  {result.stdout.strip()}")
            return print_result("pip disponible", True)
        else:
            return print_result("pip disponible", False, "pip no encontrado")
    except Exception as e:
        return print_result("pip disponible", False, str(e))


def test_virtualenv():
    """Test 3: Verificar entorno virtual"""
    print_header("TEST 3: Entorno Virtual")
    
    in_venv = hasattr(sys, 'real_prefix') or (
        hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix
    )
    
    if in_venv:
        print(f"  Entorno virtual activo: {sys.prefix}")
        return print_result("Entorno virtual activo", True)
    else:
        print(f"  ⚠️  No estás en un entorno virtual")
        print(f"  Python usado: {sys.executable}")
        return print_result("Entorno virtual", False, 
            "Se recomienda usar entorno virtual")


def test_dependencies():
    """Test 4: Verificar dependencias instaladas"""
    print_header("TEST 4: Dependencias Instaladas")
    
    required_packages = [
        ("fastapi", "FastAPI"),
        ("uvicorn", "Uvicorn"),
        ("pydantic", "Pydantic"),
        ("sqlalchemy", "SQLAlchemy"),
        ("aiohttp", "aiohttp"),
        ("httpx", "httpx"),
        ("pyyaml", "PyYAML"),
        ("python-dotenv", "python-dotenv"),
    ]
    
    all_ok = True
    for package, name in required_packages:
        try:
            module = importlib.import_module(package.replace('-', '_'))
            version = getattr(module, '__version__', 'unknown')
            print_result(f"{name} ({version})", True)
        except ImportError:
            print_result(f"{name}", False, f"{package} no instalado")
            all_ok = False
    
    return all_ok


def test_directory_structure():
    """Test 5: Verificar estructura de directorios"""
    print_header("TEST 5: Estructura de Directorios")
    
    base_path = Path(__file__).parent.parent
    required_dirs = [
        "core", "api", "adapters", "config", "plugins",
        "monitoring", "tenant", "workflow", "auto_remediation"
    ]
    
    all_ok = True
    for dir_name in required_dirs:
        dir_path = base_path / dir_name
        if dir_path.exists():
            print_result(f"Directorio '{dir_name}/'", True)
        else:
            print_result(f"Directorio '{dir_name}/'", False, "No existe")
            all_ok = False
    
    # Verificar archivos principales
    required_files = ["main.py", "requirements.txt", ".env.example"]
    for file_name in required_files:
        file_path = base_path / file_name
        if file_path.exists():
            print_result(f"Archivo '{file_name}'", True)
        else:
            print_result(f"Archivo '{file_name}'", False, "No existe")
            all_ok = False
    
    return all_ok


def test_env_file():
    """Test 6: Verificar archivo .env"""
    print_header("TEST 6: Archivo de Configuración (.env)")
    
    base_path = Path(__file__).parent.parent
    env_file = base_path / ".env"
    env_example = base_path / ".env.example"
    
    if env_file.exists():
        print(f"  ✅ Archivo .env encontrado")
        
        # Verificar variables críticas
        with open(env_file, 'r') as f:
            content = f.read()
        
        critical_vars = [
            "CLAWSPHERE_SECURITY_SECRET_KEY",
            "CLAWSPHERE_SECURITY_ENCRYPTION_KEY",
            "CLAWSPHERE_DATABASE_URL"
        ]
        
        all_ok = True
        for var in critical_vars:
            if var in content:
                print_result(f"Variable {var}", True)
            else:
                print_result(f"Variable {var}", False, "No encontrada")
                all_ok = False
        
        return all_ok
    else:
        if env_example.exists():
            print_result("Archivo .env", False, 
                "No existe. Ejecuta: copy .env.example .env")
        else:
            print_result("Archivo .env", False, 
                "No existe .env ni .env.example")
        return False


def test_database_connection():
    """Test 7: Verificar conexión a base de datos"""
    print_header("TEST 7: Conexión a Base de Datos")
    
    try:
        from core.config import settings
        db_url = settings.DATABASE_URL
        print(f"  URL: {db_url}")
        
        if "sqlite" in db_url.lower():
            print_result("Base de datos SQLite", True, 
                "Usando SQLite (recomendado para desarrollo)")
            return True
        else:
            print_result("Base de datos", True, 
                f"Configurada: {db_url.split('://')[0]}")
            return True
            
    except Exception as e:
        print_result("Configuración BD", False, str(e))
        return False


def test_ai_provider():
    """Test 8: Verificar proveedor de IA"""
    print_header("TEST 8: Proveedor de IA")
    
    try:
        from core.config import settings
        provider = settings.AI_DEFAULT_PROVIDER
        print(f"  Proveedor configurado: {provider}")
        
        if provider == "ollama":
            print_result("Proveedor Ollama", True, 
                "Asegúrate de tener Ollama ejecutándose en http://localhost:11434")
        elif provider == "openai":
            if settings.AI_OPENAI_API_KEY:
                print_result("Proveedor OpenAI", True, "API Key configurada")
            else:
                print_result("Proveedor OpenAI", False, 
                    "AI_OPENAI_API_KEY no configurada")
                return False
        else:
            print_result(f"Proveedor {provider}", True)
        
        return True
        
    except Exception as e:
        print_result("Configuración IA", False, str(e))
        return False


def test_imports():
    """Test 9: Verificar imports del proyecto"""
    print_header("TEST 9: Imports del Proyecto")
    
    imports_to_test = [
        ("core.config", "settings"),
        ("core.events", "event_bus"),
        ("api.rest", "create_rest_api"),
        ("monitoring.metrics", "setup_metrics"),
    ]
    
    all_ok = True
    for module_name, item in imports_to_test:
        try:
            module = importlib.import_module(module_name)
            getattr(module, item)
            print_result(f"{module_name}.{item}", True)
        except Exception as e:
            print_result(f"{module_name}.{item}", False, str(e)[:50])
            all_ok = False
    
    return all_ok


def test_port_availability():
    """Test 10: Verificar puerto disponible"""
    print_header("TEST 10: Puerto 7550")
    
    import socket
    
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        result = sock.connect_ex(('localhost', 7550))
        sock.close()
        
        if result == 0:
            print_result("Puerto 7550", False, 
                "El puerto está en uso. Detén el proceso o cambia el puerto en .env")
            return False
        else:
            print_result("Puerto 7550", True, "Disponible")
            return True
            
    except Exception as e:
        print_result("Puerto 7550", False, str(e))
        return False


def main():
    """Ejecutar todos los tests"""
    print("\n" + "=" * 60)
    print("  CLAWSPHERE AMS - TESTS DE FUNCIONAMIENTO")
    print("=" * 60)
    print(f"  Sistema: {sys.platform}")
    print(f"  Python: {sys.executable}")
    print(f"  Directorio: {Path(__file__).parent.parent}")
    
    tests = [
        test_python_version,
        test_pip,
        test_virtualenv,
        test_dependencies,
        test_directory_structure,
        test_env_file,
        test_database_connection,
        test_ai_provider,
        test_imports,
        test_port_availability,
    ]
    
    results = []
    for test in tests:
        try:
            results.append(test())
        except Exception as e:
            print(f"  ❌ ERROR en {test.__name__}: {e}")
            results.append(False)
    
    # Resumen
    print_header("RESUMEN")
    passed = sum(results)
    total = len(results)
    
    print(f"  Tests pasados: {passed}/{total}")
    
    if passed == total:
        print("\n  🎉 ¡Todo está configurado correctamente!")
        print("  Ejecuta: python main.py")
        return 0
    elif passed >= total * 0.7:
        print("\n  ⚠️  Configuración parcial. Revisa los errores arriba.")
        print("  Algunos componentes pueden no funcionar correctamente.")
        return 1
    else:
        print("\n  ❌ Configuración incompleta.")
        print("  Sigue la guía de instalación para Windows.")
        return 2


if __name__ == "__main__":
    sys.exit(main())
