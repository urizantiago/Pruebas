#!/usr/bin/env python3
"""
ClawSphere AMS - Main Application Entry Point
Agente de Inteligencia Artificial Empresarial para Soporte L2/L3
"""

import os
import sys
import logging
from pathlib import Path
from datetime import datetime

# Configurar logging primero
log_dir = Path("logs")
log_dir.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(log_dir / 'clawsphere.log', encoding='utf-8')
    ]
)
logger = logging.getLogger(__name__)

# Verificar Python version
if sys.version_info < (3, 9):
    logger.error("Python 3.9+ requerido")
    sys.exit(1)

def check_environment():
    """Verifica que el entorno esté configurado correctamente."""
    checks = []
    
    # Verificar .env
    if not Path(".env").exists():
        checks.append("❌ Archivo .env no encontrado. Ejecuta: copy .env.windows .env")
    else:
        checks.append("✅ Archivo .env encontrado")
    
    # Verificar directorios
    for dir_name in ["data", "logs", "plugins"]:
        if Path(dir_name).exists():
            checks.append(f"✅ Directorio {dir_name}/")
        else:
            Path(dir_name).mkdir(exist_ok=True)
            checks.append(f"✅ Directorio {dir_name}/ creado")
    
    return checks

def create_minimal_app():
    """Crea una aplicación FastAPI mínima funcional."""
    from fastapi import FastAPI
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse
    
    app = FastAPI(
        title="ClawSphere AMS",
        description="Agente de IA para Soporte L2/L3",
        version="1.0.0"
    )
    
    # CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    @app.get("/")
    async def root():
        return {
            "name": "ClawSphere AMS",
            "version": "1.0.0",
            "status": "running",
            "docs": "/docs"
        }
    
    @app.get("/health")
    async def health():
        return {
            "status": "healthy",
            "timestamp": datetime.now().isoformat()
        }
    
    @app.post("/api/v1/chat")
    async def chat(request: dict):
        """Endpoint de chat simple."""
        message = request.get("message", "")
        return {
            "response": f"Recibido: {message}",
            "session_id": "test",
            "confidence": 0.95
        }
    
    return app

def main():
    """Punto de entrada principal."""
    import uvicorn
    
    print("=" * 60)
    print("  CLAWSPHERE AMS - Iniciando")
    print("=" * 60)
    print()
    
    # Verificar entorno
    checks = check_environment()
    for check in checks:
        print(f"  {check}")
    print()
    
    # Cargar configuracion si existe
    host = "0.0.0.0"
    port = 7550
    debug = True
    
    try:
        from dotenv import load_dotenv
        load_dotenv()
        host = os.getenv("CLAWSPHERE_HOST", "0.0.0.0")
        port = int(os.getenv("CLAWSPHERE_PORT", "7550"))
        debug = os.getenv("CLAWSPHERE_DEBUG", "true").lower() == "true"
        print(f"  ✅ Configuracion cargada desde .env")
    except Exception as e:
        print(f"  ⚠️  Usando configuracion por defecto ({e})")
    
    print()
    
    # Crear aplicacion
    try:
        # Intentar cargar la app completa
        from api.rest import create_rest_api
        from api.websocket import create_websocket_router
        
        app = create_rest_api()
        # Agregar websocket
        # app.include_router(create_websocket_router(), prefix="/ws")
        
        print("  ✅ API completa cargada")
    except Exception as e:
        print(f"  ⚠️  Usando API minima ({e})")
        app = create_minimal_app()
    
    print()
    print("=" * 60)
    print(f"  Servidor iniciando en http://{host}:{port}")
    print(f"  Documentacion: http://{host}:{port}/docs")
    print("=" * 60)
    print()
    print("  Presiona Ctrl+C para detener")
    print()
    
    # Iniciar servidor
    uvicorn.run(
        app,
        host=host,
        port=port,
        reload=debug,
        log_level="info"
    )

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n  Servidor detenido.")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Error fatal: {e}", exc_info=True)
        print(f"\n  ❌ Error: {e}")
        print("  Ejecuta diagnose-windows.bat para mas informacion")
        sys.exit(1)
